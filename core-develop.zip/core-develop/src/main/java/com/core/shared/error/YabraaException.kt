package com.core.shared.error

data class YabraaException(val yabraaError: YabraaError) : Exception()