package com.core.shared.error

import androidx.annotation.Keep


open class YabraaErrorException(message: String? = null, cause: Throwable? = null) : RuntimeException(message, cause)


@Keep
class GeneralException(message: String? = null, cause: Throwable? = null) : YabraaErrorException(message, cause)

@Keep
class IoException(message: String? = null, cause: Throwable? = null) : YabraaErrorException(message, cause)

@Keep
class ResponseError(message: String? = null, cause: Throwable? = null) : YabraaErrorException(message, cause)

@Keep
class ResponseUnAuthorizedError(message: String? = null, cause: Throwable? = null) : YabraaErrorException(message, cause)


@Keep
class FailedToDecodeJwt(message: String? = null, cause: Throwable? = null) : YabraaErrorException(message, cause)

@Keep
class RefreshTokenNotFound(message: String? = null, cause: Throwable? = null) : YabraaErrorException(message, cause)

@Keep
class EmptyBirthDate(message: String? = null, cause: Throwable? = null) : YabraaErrorException(message, cause)


@Keep
class EmptyCountryCode(message: String? = null, cause: Throwable? = null) : YabraaErrorException(message, cause)


@Keep
class InvalidEmail(message: String? = null, cause: Throwable? = null) : YabraaErrorException(message, cause)


@Keep
class EmptyFirstName(message: String? = null, cause: Throwable? = null) : YabraaErrorException(message, cause)


@Keep
class EmptyGender(message: String? = null, cause: Throwable? = null) : YabraaErrorException(message, cause)


@Keep
class EmptyLastName(message: String? = null, cause: Throwable? = null) : YabraaErrorException(message, cause)


@Keep
class EmptyPassword(message: String? = null, cause: Throwable? = null) : YabraaErrorException(message, cause)

@Keep
class PasswordLetThanSixCharacter(message: String? = null, cause: Throwable? = null) : YabraaErrorException(message, cause)

@Keep
class OperationMessage(message: String? = null, cause: Throwable? = null) : YabraaErrorException(message, cause)

@Keep
class EmptyPhoneNumber(message: String? = null, cause: Throwable? = null) : YabraaErrorException(message, cause)

@Keep
class EmptyConfirmPassword(message: String? = null, cause: Throwable? = null) : YabraaErrorException(message, cause)
@Keep
class PasswordNotMatched(message: String? = null, cause: Throwable? = null) : YabraaErrorException(message, cause)

@Keep
class PlaceSelectionException(message: String? = null, cause: Throwable? = null) : YabraaErrorException(message, cause)

@Keep
class PatientName(message: String? = null, cause: Throwable? = null) : YabraaErrorException(message, cause)

@Keep
class IdOrOrPassport(message: String? = null, cause: Throwable? = null) : YabraaErrorException(message, cause)
@Keep
class NotificationListPagingError(message: String? = null, cause: Throwable? = null) : YabraaErrorException(message, cause)
@Keep
class UnsuccessfulPayment(message: String? = null, cause: Throwable? = null) : YabraaErrorException(message, cause)

@Keep
class PaymentIsCancelled(message: String? = null, cause: Throwable? = null) : YabraaErrorException(message, cause)

