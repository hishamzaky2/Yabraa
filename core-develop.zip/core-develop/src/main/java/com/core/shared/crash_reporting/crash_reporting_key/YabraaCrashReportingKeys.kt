package com.core.shared.crash_reporting.crash_reporting_key

import com.core.shared.crash_reporting.CrashReportingKey

class YabraaCrashReportingKeys {

    enum class YabraaGaugeKeys(override val key: String) : CrashReportingKey {
        TOKEN("TOKEN")
    }
}