package com.core.shared.location_manager.di

import android.app.Activity
import com.core.shared.location_manager.LocationHandler
import com.core.shared.location_manager.LocationManager
import dagger.Module
import dagger.Provides
import dagger.hilt.InstallIn
import dagger.hilt.android.components.ActivityComponent


@Module
@InstallIn(ActivityComponent::class)
object LocationModule {

    @Provides
    fun provideLocationManager(activity: Activity): LocationHandler = LocationManager(activity)
}