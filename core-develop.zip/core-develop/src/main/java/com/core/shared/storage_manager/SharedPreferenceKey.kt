package com.core.shared.storage_manager

object SharedPreferenceKey {

    const val PREFERENCES_ENCRYPTED_NAME = "encryptedSharedPreference"
    const val SHARED_PREFERENCES_NAME = "SharedPreference"
}