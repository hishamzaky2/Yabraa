package com.core.shared.state

import com.core.shared.error.YabraaError


sealed class State<T> {
    var hasBeenHandled = false

    class Initial<T> : State<T>()

    class Loading<T> : State<T>()
    data class Success<T>(val data: T? = null, val error: YabraaError? = null) : State<T>()
    data class Error<T>(val error: YabraaError) : State<T>()

    companion object {
        fun <T> infoError(exception: Exception) = Error<T>(YabraaError.I(exception = exception))
        fun <T> warnError(exception: Exception, message: String? = null) =
            Error<T>(YabraaError.W(exception = exception, logMessageEn = message))

        fun <T> criticalError(exception: Exception) = Error<T>(YabraaError.E(exception = exception))
    }
}