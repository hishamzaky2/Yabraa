package com.core.shared.crash_reporting

import com.core.shared.crash_reporting.crash_reporting_tools.YabraaReportingTool

interface CrashReportingManager {

    val yabraaReportingTools: Map<CrashReportingToolIdentifier, YabraaReportingTool>
    val crashReportingKeys: Map<String, Any?>

    fun log(priority: Int, tag: String?, message: String, t: Throwable?)

    fun registerCrashReportingTool(yabraaReportingTool: YabraaReportingTool)

    fun unRegisterCrashReportingTool(identifier: CrashReportingToolIdentifier)

    fun getCrashReportingTool(identifier: CrashReportingToolIdentifier): YabraaReportingTool?

    fun initCrashReportingKeys()

    fun setCrashReportingKey(key: String, value: Any?, stored: Boolean = false)

    fun setCrashReportingKey(key: CrashReportingKey, value: Any?, stored: Boolean = false)

}

