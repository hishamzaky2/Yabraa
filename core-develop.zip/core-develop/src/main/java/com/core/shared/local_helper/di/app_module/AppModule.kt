package com.core.shared.local_helper.di.app_module

import dagger.Module
import dagger.Provides
import dagger.hilt.InstallIn
import dagger.hilt.components.SingletonComponent
import com.core.shared.local_helper.LocaleHelper
import com.core.shared.storage_manager.SharedPreferencesManager
import javax.inject.Singleton

@Module
@InstallIn(SingletonComponent::class)
object AppModule {

    @Singleton
    @Provides
    fun provideLocalHelper(sharedPreferencesManager: SharedPreferencesManager) =
        LocaleHelper(sharedPreferencesManager)

}