package com.core.shared.error

interface YabraaErrorHandler {
    fun handleError(error: YabraaError, callback: YabraaError.() -> Unit = {})
}