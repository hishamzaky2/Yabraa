package com.core.shared.crash_reporting

data class CrashReportingToolIdentifier(val identifier: String)