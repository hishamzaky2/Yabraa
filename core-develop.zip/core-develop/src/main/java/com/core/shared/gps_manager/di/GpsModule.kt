package com.core.shared.gps_manager.di

import android.app.Activity
import dagger.Module
import dagger.Provides
import dagger.hilt.InstallIn
import dagger.hilt.android.components.ActivityComponent
import com.core.shared.gps_manager.GpsStateHandler
import com.core.shared.gps_manager.GpsStateManager

@Module
@InstallIn(ActivityComponent::class)
object GpsModule {

    @Provides
    fun provideGpsStateManager(activity: Activity): GpsStateHandler = GpsStateManager(activity)
}