package com.core.shared.base_paging_source

import androidx.paging.PagingSource
import com.core.shared.error.ResponseUnAuthorizedError
import com.core.shared.error.YabraaError
import com.core.shared.error.YabraaException
import retrofit2.Response

abstract class BasePagingSource<key : Any, value : Any> : PagingSource<key, value>() {

    fun getNotSuccessfulError(response: Response<*>): LoadResult<key, value>? {
        return when {
            response.body() == 401 -> LoadResult.Error(getUnAuthorizedException(response))
            else -> null
        }
    }

    private fun getUnAuthorizedException(response: Response<*>): YabraaException {
        val yabraaError = YabraaError.E(
            exception = ResponseUnAuthorizedError(),
            logMessageEn = "Api request to url: ${response.raw().request.url}: failed with code ${response.code()}",
            extraData = response
        )
        return YabraaException(yabraaError)
    }
}