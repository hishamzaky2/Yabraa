package com.core.shared.crash_reporting.di

import com.core.shared.crash_reporting.CrashReportingManager
import com.core.shared.crash_reporting.YabraaCrashReportingManager
import dagger.Binds
import dagger.Module
import dagger.hilt.InstallIn
import dagger.hilt.components.SingletonComponent
import javax.inject.Singleton

@Module
@InstallIn(SingletonComponent::class)
abstract class CrashReportingModule {

    @Binds
    @Singleton
    abstract fun provideCrashReportingManager(reportingManager: YabraaCrashReportingManager): CrashReportingManager
}
