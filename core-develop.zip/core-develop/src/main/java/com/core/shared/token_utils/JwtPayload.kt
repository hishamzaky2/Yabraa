package com.core.shared.token_utils

import com.google.gson.annotations.SerializedName

data class JwtPayload(
    @SerializedName("aud")
    val aud: String,
    @SerializedName("exp")
    val exp: Long,
    @SerializedName("iss")
    val iss: String,
    @SerializedName("jti")
    val jti: String,
    @SerializedName("roles")
    val roles: String,
    @SerializedName("sub")
    val sub: String,
    @SerializedName("uid")
    val uid: String
)