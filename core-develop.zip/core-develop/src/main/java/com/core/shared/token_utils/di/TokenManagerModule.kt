package com.core.shared.token_utils.di

import dagger.Module
import dagger.Provides
import dagger.hilt.InstallIn
import dagger.hilt.components.SingletonComponent
import com.core.shared.storage_manager.StorageManager
import com.core.shared.storage_manager.di.StorageManagerModule.ENCRYPTED_SHARED_PREFERENCE
import com.core.shared.token_utils.TokenHandler
import com.core.shared.token_utils.TokensManager
import javax.inject.Named
import javax.inject.Singleton

@Module
@InstallIn(SingletonComponent::class)
object TokenManagerModule {

    @Provides
    @Singleton
    fun provideTokenManager(@Named(ENCRYPTED_SHARED_PREFERENCE) storageManager: StorageManager): TokenHandler =
        TokensManager(storageManager)
}