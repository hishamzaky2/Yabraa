package com.core.shared.crash_reporting

interface CrashReportingKey {
    val key: String
}