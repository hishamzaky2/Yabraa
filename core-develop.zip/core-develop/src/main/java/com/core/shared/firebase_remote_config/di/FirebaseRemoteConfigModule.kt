package com.core.shared.firebase_remote_config.di

import com.core.shared.firebase_remote_config.FirebaseRemoteConfigHandler
import com.core.shared.firebase_remote_config.FirebaseRemoteConfigManager
import dagger.Module
import dagger.Provides
import dagger.hilt.InstallIn
import dagger.hilt.android.components.ActivityComponent

@Module
@InstallIn(ActivityComponent::class)
object FirebaseRemoteConfigModule {

    @Provides
    fun provideFirebaseRemoteConfigManager(): FirebaseRemoteConfigHandler =
        FirebaseRemoteConfigManager()
}