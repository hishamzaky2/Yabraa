﻿namespace SmartAdmin.WebUI.ViewModel.AccountViewModels
{
    public class LoginViewModel
    {
        public string userName { get; set; }
        public string password { get; set; }
        public bool rememberMe { get; set; }
    }
}
