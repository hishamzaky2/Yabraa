﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace SmartAdmin.WebUI.ViewModel
{
    public enum Modules
    {
    
        Users,
        Roles,
        Services,
        Filters,
        Packages,
        StartPages,
        UsersMobile,
        Visits,
        Gallery,
        MedicalProfile,
    }
}
