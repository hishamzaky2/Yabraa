﻿namespace SmartAdmin.WebUI.Consts
{
    public static class TablesMaxRows
    {
        public static int UserMobileIndex { get; set; }
        static TablesMaxRows()
        {
            UserMobileIndex = 10;
        }
    }
}
