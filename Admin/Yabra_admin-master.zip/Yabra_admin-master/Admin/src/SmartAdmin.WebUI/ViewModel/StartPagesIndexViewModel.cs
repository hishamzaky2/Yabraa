﻿namespace SmartAdmin.WebUI.ViewModel
{
    public class StartPagesIndexViewModel
    {
        public int StartPageId { get; set; }
        public string TitleEn { get; set; }
        public string TitleAr { get; set; }
    }
}
