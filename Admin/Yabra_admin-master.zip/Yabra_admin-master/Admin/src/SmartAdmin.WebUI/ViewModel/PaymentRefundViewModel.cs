﻿using System.Collections.Generic;

namespace SmartAdmin.WebUI.ViewModel
{
    public class PaymentRefundViewModel
    {
        public string ServiceType { get; set; }
        public Dictionary<string, dynamic> HyperPayResponse { get; set; }
    }
}
