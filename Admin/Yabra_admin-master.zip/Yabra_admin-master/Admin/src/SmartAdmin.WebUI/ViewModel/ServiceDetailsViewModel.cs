﻿using Microsoft.AspNetCore.Http;
using System.Collections.Generic;
using System.ComponentModel.DataAnnotations;

namespace SmartAdmin.WebUI.ViewModel
{
    public class ServiceDetailsViewModel
    {
        public int ServiceId { get; set; }
        public string ServiceTypeName { get; set; }      
        public string NameAR { get; set; }
        public string NameEN { get; set; }
        public string CreateDT { get; set; }
        public string DetailsAR { get; set; }
        public string DetailsEN { get; set; }     
        public string Path { get; set; }
        public bool IsActive { get; set; }
        public List<CategoryDetails> Categories { get; set; }
        public List<PackageDetails> Packages { get; set; }
        //public bool clickButtonFilters { get; set; }
        //public bool ClickButtonPackeges { get; set; }
    }
    public class CategoryDetails
    {
        public int CategoryId { get; set; }
        public string NameAR { get; set; }
        public string NameEN { get; set; }
    }
    public class PackageDetails
    {
        public int PackageId { get; set; }
        public string NameAR { get; set; }
        public string NameEN { get; set; } 
        public string Category { get; set; }

    }
}
