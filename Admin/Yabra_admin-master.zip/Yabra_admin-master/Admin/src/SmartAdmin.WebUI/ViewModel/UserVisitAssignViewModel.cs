﻿using System.Collections.Generic;
using Microsoft.AspNetCore.Mvc.Rendering;

namespace SmartAdmin.WebUI.ViewModel
{
    public class VisitAssignViewModel
    {
        public int ServiceId { get; set; }
        public long VisitDetailsId { get; set; }
        public SelectList Emps { get; set; }
        public string jobe { get; set; }
        public string UserRole { get; set; }
        public string UserId { get; set; }
        public List<UserVisitAssignViewModel> EmpsHistory { get; set; }
    }
    public class UserVisitAssignViewModel
    {
        public long UserVisitAssignId { get; set; }
        public string UserName { get; set; }
        public string FirstName { get; set; }
        public string LastName { get; set; }
        public string Phone { get; set; }
        public string Email { get; set; }
        public string DateAssign  { get; set; }
        public string Status { get; set; }
        public string UserId { get; set; }


    }
}
