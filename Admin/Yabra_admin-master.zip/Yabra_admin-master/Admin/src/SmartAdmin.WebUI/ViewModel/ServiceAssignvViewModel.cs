﻿using System.Collections.Generic;
using Microsoft.AspNetCore.Mvc.Rendering;

namespace SmartAdmin.WebUI.ViewModel
{
    public class ServiceAssignvViewModel
    {
        public int ServiceId { get; set; }
        public SelectList Employes { get; set; }
        public string Jobe { get; set; }
        public List<EmployeeViewModel> ExistingEmployees { get; set; }
        public List<EmployeeViewModel> HistoryEmployees { get; set; }
    }
    public class EmployeeViewModel
    {
        public string Id { get; set; }
        public string UserName { get; set; }
        public string FirstName { get; set; }
        public string LastName { get; set; }
        public string Phone { get; set; }
        public string Email { get; set; }
        public string DateFrom { get; set; }
        public string DateTo { get; set; }
    }
}
