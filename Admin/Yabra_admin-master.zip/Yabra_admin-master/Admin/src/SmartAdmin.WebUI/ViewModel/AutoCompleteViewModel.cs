﻿namespace SmartAdmin.WebUI.ViewModel
{
    public class AutoCompleteViewModel
    {
        public long val { get; set; }
        public string label { get; set; }
    }
}
