﻿using System.Collections.Generic;
using System.Linq;
using Microsoft.EntityFrameworkCore;
using SmartAdmin.WebUI.ViewModel;
using YabraaEF;
using YabraaEF.Services;

namespace SmartAdmin.WebUI.Services
{
    public class PaymentService
    {
        public ApplicationDbContext _context { get; set; }
        public Payment _payment { get; set; }
        public PaymentService(Payment payment, ApplicationDbContext context)
        {
            _payment = payment;
            _context = context; 
        }
        public PaymentRefundViewModel Refund(long VisitDetailsId, string UserId)
        {
            var VisitDetails = _context.VisitDetails.Include(c=>c.InvoiceDetails.Invoice).Include(c => c.ServiceType).FirstOrDefault(c => c.VisitDetailsId == VisitDetailsId);
            if (VisitDetails is not null)
            {
              var response = _payment.Refund(VisitDetails.InvoiceDetails.Invoice.PaymentId,VisitDetails.InvoiceDetails.Invoice.PaymentMethodId,VisitDetails.InvoiceDetails.Price,VisitDetails.VisitDetailsId,UserId);
                PaymentRefundViewModel model = new PaymentRefundViewModel() {
                    HyperPayResponse = response,
                    ServiceType = VisitDetails.ServiceType.Name
                };
                return model;   
            }
            return null;
        }
    }
}
