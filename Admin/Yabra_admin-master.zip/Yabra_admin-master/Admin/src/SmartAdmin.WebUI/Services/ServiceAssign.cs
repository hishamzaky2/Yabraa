﻿using Microsoft.AspNetCore.Identity;
using Microsoft.AspNetCore.Mvc.Rendering;
using Microsoft.EntityFrameworkCore;
using SmartAdmin.WebUI.ViewModel;
using System;
using System.Linq;
using System.Threading.Tasks;
using YabraaEF;
using YabraaEF.Const;
using YabraaEF.Models;
using static SmartAdmin.WebUI.ViewModel.Permissions;

namespace SmartAdmin.WebUI.Services
{
    public class ServiceAssign
    {
        public ApplicationDbContext _context { get; set; }
        private readonly UserManager<ApplicationUser> _userManager;
        private readonly RoleManager<IdentityRole> _roleManager;
        public ServiceAssign(ApplicationDbContext context, UserManager<ApplicationUser> userManager, RoleManager<IdentityRole> roleManager)
        {
            _context = context;
            _userManager= userManager;
            _roleManager = roleManager;
        }
        public async Task<ServiceAssignvViewModel> GetJobes(int ServiceId , string Jobe)
        {
            var role = await _roleManager.FindByNameAsync(Jobe);
            var ExistingEmployees = _context.ServiceUserWorks.Include(c=>c.ApplicationUserWork).Where(c => c.ServiceId == ServiceId && !c.To.HasValue && c.RoleId == role.Id).Select(c => new EmployeeViewModel {
                Id=c.ApplicationUserWork.Id,
                UserName = c.ApplicationUserWork.UserName,
                FirstName= c.ApplicationUserWork.FirstName,
                LastName= c.ApplicationUserWork.LastName,
                Email= c.ApplicationUserWork.Email,
                Phone=c.ApplicationUserWork.PhoneNumber,
                DateFrom = c.From.ToString("dd-MM-yyyy")
            }).ToList();
            var HistoryEmployees = _context.ServiceUserWorks.Include(c => c.ApplicationUserWork).Where(c => c.ServiceId == ServiceId && c.To.HasValue && c.RoleId == role.Id).Select(c => new EmployeeViewModel
            {
                Id = c.ApplicationUserWork.Id,
                UserName = c.ApplicationUserWork.UserName,
                FirstName = c.ApplicationUserWork.FirstName,
                LastName = c.ApplicationUserWork.LastName,
                Email = c.ApplicationUserWork.Email,
                Phone = c.ApplicationUserWork.PhoneNumber,
                DateFrom = c.From.ToString("dd-MM-yyyy"),
                DateTo = c.To.HasValue ? c.To.Value.ToString("dd-MM-yyyy") : null
            }).ToList();
            ServiceAssignvViewModel model = new ServiceAssignvViewModel()
            {
                Employes = GetEmployes(ServiceId, Jobe).Result,
                Jobe = Jobe,
                ServiceId = ServiceId,
                ExistingEmployees = ExistingEmployees,
                HistoryEmployees= HistoryEmployees
            };

            return model;
        }
        public async Task<SelectList> GetEmployes(int ServiceId, string Jobe)
        {
            var usersInRole = await _userManager.GetUsersInRoleAsync(Jobe);
            var ExistingEmployees = _context.ServiceUserWorks.Where(c => c.ServiceId == ServiceId && !c.To.HasValue).Select(c=>c.ApplicationUserWorkId).ToList();
            var Users = usersInRole.Where(c=> !ExistingEmployees.Contains(c.Id)).Select(c=> new {c.Id , Name = $"{c.FirstName} {c.LastName} ( Username : {c.UserName} )"}).ToList();
            SelectList items;           
                items = new SelectList(Users, "Id", "Name");
          return items; 
        }
        public async Task<int> AssignUserService(int ServiceId, string Jobe, string UserId,string SystemUser)
        {
          
          var user = await _userManager.Users
            .FirstOrDefaultAsync(u => u.Id == UserId);
            var role = await _roleManager.FindByNameAsync(Jobe);
            var UserWorkId = _context.ServiceUserWorks.FirstOrDefault(c => c.ServiceId == ServiceId && !c.To.HasValue && c.ApplicationUserWorkId == UserId )?.ApplicationUserWorkId;
           

           if (user != null && string.IsNullOrWhiteSpace(UserWorkId) && role != null)
            {
                var roles = await _userManager.GetRolesAsync(user);
                if (roles is not null && roles.Count > 0 && roles.Contains(Jobe))
                {
                    ServiceUserWork serviceUser = new ServiceUserWork()
                    {
                        From = General.GetKSATimeZoneNow(),
                        RoleId = role.Id,
                        To = null,
                        ServiceId = ServiceId,
                        ApplicationUserWorkId = UserId,
                        ApplicationUserCreateId = SystemUser,
                    };
                    _context.ServiceUserWorks.Add(serviceUser);
                    _context.SaveChanges();
                    return serviceUser.ServiceUserWorkId;
                }
            }
            return 0;
   
          
        }

        public async Task<int> UnAssignUserService(int ServiceId, string Jobe, string UserId)
        {

            var user = await _userManager.Users
              .FirstOrDefaultAsync(u => u.Id == UserId);
            var role = await _roleManager.FindByNameAsync(Jobe);
            var UserWork = _context.ServiceUserWorks.FirstOrDefault(c => c.ServiceId == ServiceId && c.RoleId == role.Id && !c.To.HasValue && c.ApplicationUserWorkId == UserId);


            if (UserWork != null )
            {
                UserWork.To = General.GetKSATimeZoneNow();
                _context.SaveChanges();
                return 1; 
            }
            return 0;


        }

    }
}
