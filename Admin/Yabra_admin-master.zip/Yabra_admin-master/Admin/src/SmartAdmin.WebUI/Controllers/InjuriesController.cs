﻿using System.Threading.Tasks;
using Microsoft.AspNetCore.Mvc;
using YabraaEF.Models;
using YabraaEF;
using System.Linq;
using Microsoft.EntityFrameworkCore;

namespace SmartAdmin.WebUI.Controllers
{
    public class InjuriesController : Controller
    {
        public ApplicationDbContext _context { get; set; }

        public InjuriesController(ApplicationDbContext context)
        {
            _context = context;

        }
        public async Task<IActionResult> Index()
        {
            try
            {
                var model = await _context.Injuries.Where(c => !c.Deleted).ToListAsync();
                return View(model);
            }
            catch (System.Exception ex)
            {

                return View("Error404", ex);
            }
        }
        public IActionResult Create()
        {
            return View(new Injury());
        }
        [HttpPost]
        public async Task<IActionResult> Create(Injury model)
        {
            try
            {
                if (ModelState.IsValid)
                {
                    await _context.Injuries.AddAsync(model);
                    var status = _context.SaveChanges();
                    if (status > 0)
                    {
                        return RedirectToAction("Index");
                    }
                }
                return View(model);
            }
            catch (System.Exception ex)
            {

                return View("Error404", ex);
            }

        }
        [HttpGet]
        public async Task<IActionResult> Edit(int InjuryId)
        {
            try
            {
                var model = await _context.Injuries.FirstOrDefaultAsync(c => c.InjuryId == InjuryId);
                if (model is not null)
                {
                    return View("Create", model);
                }
                return View("Error404");
            }
            catch (System.Exception ex)
            {

                return View("Error404", ex);
            }
        }
        [HttpPost]
        public async Task<IActionResult> Edit(Injury model)
        {
            try
            {
                if (ModelState.IsValid && model.InjuryId > 0)
                {
                    var Injury = await _context.Injuries.FirstOrDefaultAsync(c => c.InjuryId == model.InjuryId);
                    if (Injury is not null)
                    {
                        Injury.TitleEN = model.TitleEN;
                        Injury.TitleAR = model.TitleAR;
                        _context.SaveChanges();
                        return RedirectToAction("Index");
                    }
                    return View("Error404");
                }
                return View("Create", model);
            }
            catch (System.Exception ex)
            {

                return View("Error404", ex);
            }
        }
        [HttpGet]
        public async Task<IActionResult> Delete(int InjuryId)
        {
            try
            {
                var Injury = await _context.Injuries.FirstOrDefaultAsync(c => c.InjuryId == InjuryId);
                if (Injury is not null)
                {
                    Injury.Deleted = true; _context.SaveChanges();
                    return Json(new { status = 1, message = "Done" });
                }
                return Json(new { status = 1, message = "Error" });
            }
            catch (System.Exception ex)
            {
                return Json(new { status = 1, message = ex.Message });
            }
        }
    }
}
