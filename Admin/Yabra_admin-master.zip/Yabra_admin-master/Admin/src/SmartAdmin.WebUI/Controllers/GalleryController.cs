﻿using System;
using System.Collections.Generic;
using System.IO;
using System.Linq;
using System.Threading.Tasks;
using Microsoft.AspNetCore.Hosting;
using Microsoft.AspNetCore.Http;
using Microsoft.AspNetCore.Mvc;
using Microsoft.EntityFrameworkCore;
using SmartAdmin.WebUI.Static;
using YabraaEF;
using YabraaEF.Models;

namespace SmartAdmin.WebUI.Controllers
{
    public class GalleryController : Controller
    {
        public ApplicationDbContext _context { get; set; }
        private readonly IWebHostEnvironment _env;
        public GalleryController(ApplicationDbContext context, IWebHostEnvironment env)
        {
            _context = context;
            _env = env;
        }
        public async Task<IActionResult> Index()
        {
            try
            {
                var model = await _context.Gallery.OrderBy(c=>c.OrderbyAscending).Select(c=>c.Path).ToListAsync();
                return View(model);
            }
            catch (System.Exception ex)
            {

                return View("Error404", ex);
            }

        }
        [HttpPost]
        public async Task<IActionResult> Upload(IEnumerable<IFormFile> Files)
        {
            try
            {
                if (Files != null && Files.Count() > 0)
                {
                    var oldImages = await _context.Gallery.ToListAsync();

                    if (oldImages != null && oldImages.Count > 0)
                    {
                        //  Photo.DeleteFiles(_env.WebRootPath, "gallery");
                        foreach (var item in oldImages)
                        {
                            Photo.Delete(_env.WebRootPath, item.Path);

                        }
                        _context.Gallery.RemoveRange(oldImages);
                        _context.SaveChanges();
                    }
                    List<Gallery> Gallerys = new List<Gallery>();
                    int i = Files.Count();
                    foreach (var file in Files)
                    {
                        if (file != null && file.Length > 0)
                        {
                            string fileName = await Photo.UploadAsync(file, "gallery");
                            if (!string.IsNullOrWhiteSpace(fileName))
                            {
                                Gallerys.Add(new Gallery()
                                {
                                    OrderbyAscending = i,
                                    Path = fileName
                                });
                                i--;
                            }
                        }
                    }

                    if (Gallerys.Count > 0)
                    {
                     
                    
                        _context.Gallery.AddRange(Gallerys);
                        _context.SaveChanges();
                        var model1 = await _context.Gallery.OrderBy(c => c.OrderbyAscending).Select(c => c.Path).ToListAsync();
                        return View("Index", model1);
                    }
                  
                }
                    
                var model = await _context.Gallery.OrderBy(c => c.OrderbyAscending).Select(c => c.Path).ToListAsync();
                ViewBag.errorMessage = "An error occurred. Please check the input";
                return View("Index" ,model);
                
            }
            catch (System.Exception ex)
            {

                return View("Error404", ex);
            }

        }
 
    }
}
