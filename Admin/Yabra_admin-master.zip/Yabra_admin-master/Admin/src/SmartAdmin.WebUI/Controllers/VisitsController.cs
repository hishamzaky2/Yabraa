﻿using System;
using System.Collections.Generic;
using System.Globalization;
using System.Linq;
using System.Security.Claims;
using System.Text.RegularExpressions;
using System.Threading.Tasks;
using FirebaseAdmin.Auth;
using Microsoft.AspNetCore.Http;
using Microsoft.AspNetCore.Identity;
using Microsoft.AspNetCore.Identity.UI.V4.Pages.Account.Internal;
using Microsoft.AspNetCore.Mvc;
using Microsoft.EntityFrameworkCore;
using SmartAdmin.WebUI.Services;
using YabraaEF;
using YabraaEF.Const;
using YabraaEF.Helpers;
using YabraaEF.Models;
using YabraaEF.Services;
using static SmartAdmin.WebUI.ViewModel.Permissions;

namespace SmartAdmin.WebUI.Controllers
{
    public class VisitsController : Controller
    {
        public VisitsService _visitsService { get; set; }
        public PaymentService _paymentService { get; set; }
        private SmsSender _SmsSender { get; set; }
        private Firebase _Firebase { get; set; }
        private ApplicationDbContext _dbContext { get; set; }
        public VisitsController(VisitsService visitsService, PaymentService paymentService, SmsSender smsSender, Firebase Firebase, ApplicationDbContext dbContext)
        {
            _visitsService = visitsService;
            _paymentService=paymentService;
            _SmsSender = smsSender;
            _Firebase = Firebase;
            _dbContext= dbContext;
        }
        public async Task<IActionResult> Normal(string getBy, int month = 0)
        {
            try
            {
                string UserId = User.FindFirstValue(ClaimTypes.NameIdentifier);
                bool IsUserInDoctorOrNurseRole = await _visitsService.IsUserInDoctorOrNurseRoleOrPhysiotherapySpecialist(UserId);
                var model = await _visitsService.GetVisits("Normal",UserId, IsUserInDoctorOrNurseRole, getBy, month);
                if (model is null)
                {
                    return View("Error404");
                }
                ViewBag.ServiceType = "Normal";
                ViewBag.monthNumber = month ;
                ViewBag.CountVisitsDaily = await _visitsService.GetVisitsCount("Normal", UserId, IsUserInDoctorOrNurseRole, "daily");
                ViewBag.CountVisitsMonthly = await _visitsService.GetVisitsCount("Normal", UserId, IsUserInDoctorOrNurseRole, "Monthly", General.GetKSATimeZoneNow().Month);
                ViewBag.CountVisitsMonth = await _visitsService.GetVisitsCount("Normal", UserId, IsUserInDoctorOrNurseRole, "Monthly" , month);
                return View("Index",model);
            }
            catch (System.Exception ex)
            {

                return View("Error404", ex);
            }
        }
        public async Task<IActionResult> Virtual(string getBy, int month = 0)
        {
            try
            {
                string UserId = User.FindFirstValue(ClaimTypes.NameIdentifier);
                bool IsUserInDoctorOrNurseRole = await _visitsService.IsUserInDoctorOrNurseRoleOrPhysiotherapySpecialist(UserId);
                var model = await _visitsService.GetVisits("Virtual", UserId, IsUserInDoctorOrNurseRole, getBy, month);
                if (model is null)
                {
                    return View("Error404");
                }
                ViewBag.ServiceType = "Virtual";
                ViewBag.monthNumber = month;
                ViewBag.CountVisitsDaily = await _visitsService.GetVisitsCount("Virtual", UserId, IsUserInDoctorOrNurseRole, "daily");
                ViewBag.CountVisitsMonthly = await _visitsService.GetVisitsCount("Virtual", UserId, IsUserInDoctorOrNurseRole, "Monthly", General.GetKSATimeZoneNow().Month);
                ViewBag.CountVisitsMonth = await _visitsService.GetVisitsCount("Virtual", UserId, IsUserInDoctorOrNurseRole, "Monthly", month);
                return View("Index", model);
            }
            catch (System.Exception ex)
            {

                return View("Error404", ex);
            }
        }
        [HttpGet]
        public async Task<IActionResult> View(int VisitDetailsId,string ErrorMessageNoteOrAttachment = null)
        {
            try
            {
                var model = await _visitsService.GetVisitById(VisitDetailsId);
                if (model is not null)
                {
                    if (!string.IsNullOrWhiteSpace(ErrorMessageNoteOrAttachment))
                    {
                        ViewBag.ErrorMessageNoteOrAttachment = "Error, Please check your inputs";
                    }
                    string UserId = User.FindFirstValue(ClaimTypes.NameIdentifier);
                    model.UserId = UserId;
                    model.UserRole = await _visitsService.GetRoleNameByUserId(UserId);
                    return View(model);
                }
                return View("Error404");
            }
            catch (System.Exception ex)
            {

                return View("Error404", ex);
            }
        }
        public async Task<IActionResult> ChangeStatus(int VisitDetailsId,string Status)
        {
            try
            {
                string systemUserId = User.FindFirstValue(ClaimTypes.NameIdentifier);
                if (VisitDetailsId > 0 && !string.IsNullOrEmpty(systemUserId))
                {
                    if (Status.Contains("Rejected"))
                    {
                        var model = _paymentService.Refund(VisitDetailsId, systemUserId);
                        if (model is not null && model.HyperPayResponse is not null)
                        {
                            string result = model.HyperPayResponse["result"]["code"];
                            string pattern = @"^(000\.000\.|000\.100\.1|000\.[36])";
                            bool isMatch = Regex.IsMatch(result, pattern);
                            string pattern2 = @"^(000\.400\.0[^3]|000\.400\.[0-1]{2}0)";
                            bool isMatch2 = Regex.IsMatch(result, pattern2);

                            if (isMatch || isMatch2)
                            {
                                var VisitDetails = _dbContext.VisitDetails.Include(c=>c.Package).FirstOrDefault(c => c.VisitDetailsId == VisitDetailsId);
                                var user = _dbContext.Users.FirstOrDefault(c => c.Id == VisitDetails.ApplicationUserId);
                                if (user is not null )
                                {
                                    CultureInfo cultureInfoAR = new CultureInfo("ar");
                                    CultureInfo cultureInfoEn = new CultureInfo("en-US");
                                    string messageAr = $"نأسف لإبلاغكم بأنه تم إلغاء حجز الخدمة الخاص بكم \n اسم الخدمه : {VisitDetails?.Package?.NameAR} \n التاريخ : {VisitDetails?.VisitDT.ToString("dddd, dd MMMM yyyy hh:mm tt", cultureInfoAR)} \n يرجى العلم أننا نقدر تفهمكم لهذا الأمر ونعتذر عن أي إزعاج قد تسببه هذا ";
                                    string messageEn = $"We regret to inform you that your service booking has been canceled \n Package : {VisitDetails?.Package?.NameEN} \n Date : {VisitDetails?.VisitDT.ToString("dddd, dd MMMM yyyy hh:mm tt", cultureInfoEn)} \n We apologize for any inconvenience this may have caused ";
                                    string mesg = $"{messageAr}\n{messageEn}";

                                    var responseData =  _SmsSender.SendAsync(user.PhoneNumber, mesg);
                                                               
                                    if (!string.IsNullOrEmpty(user.FirebaseToken))
                                    {
                                        ModelSendMessage modelSendMessage = new ModelSendMessage()
                                        {
                                            RegistrationToken = user.FirebaseToken,
                                            TitleAr = $"إلغاء الحجز {VisitDetails?.Package?.DetailsAR}",
                                            TitleEn = $"Cancel Reservation {VisitDetails?.Package?.DetailsEN}",
                                            BodyAr = messageAr,
                                            BodyEn = messageEn,
                                            NotificationTypeId = 3,
                                            UserId = user.Id
                                        };
                                        _Firebase.SendMessage(modelSendMessage);
                                    }
                                }
                                //return View("PaymentRefund", model);
                                return Json(new { status = 1, message = "Done" });
                            }
                        }
                    }
                    else
                    {
                        var Id = await _visitsService.ChangeStatus(VisitDetailsId, Status, systemUserId);
                        if (Id > 0)
                        {
                            //return RedirectToAction("View", new { VisitDetailsId });
                            return Json(new { status = 1, message = "Done" });

                        }
                    }
                }

                return Json(new { status = -1, message = "Error" });
            }
            catch (System.Exception ex)
            {
                return Json(new { status = -1, message = ex.Message });
            }
        }
        public async Task<IActionResult> Search(string ServiceType, string Status, DateTime From, DateTime? To)
        {
            try
            {
                string UserId = User.FindFirstValue(ClaimTypes.NameIdentifier);
                bool IsUserInDoctorOrNurseRole = await _visitsService.IsUserInDoctorOrNurseRoleOrPhysiotherapySpecialist(UserId);

                ViewBag.ServiceType = ServiceType;
                ViewBag.StatusSearch = Status;
                ViewBag.FromSearch = From;
                if (To.HasValue)
                {
                    ViewBag.ToSearch = To;
                }
              
                ViewBag.CountVisitsDaily = await _visitsService.GetVisitsCount(ServiceType, UserId, IsUserInDoctorOrNurseRole, "daily");
                ViewBag.CountVisitsMonthly = await _visitsService.GetVisitsCount(ServiceType, UserId, IsUserInDoctorOrNurseRole, "Monthly",General.GetKSATimeZoneNow().Month);
                ViewBag.CountVisitsMonth = await _visitsService.GetVisitsCount(ServiceType, UserId, IsUserInDoctorOrNurseRole, "Monthly");
                if (To.HasValue && From > To)
                {
                    ViewBag.errorMessageSearch = "To date cannot be younger than From date.";
                    var model2 = await _visitsService.GetVisits(ServiceType, UserId, IsUserInDoctorOrNurseRole,null);
                    View("Index", model2);
                }
                var model = await _visitsService.Search(ServiceType, UserId, IsUserInDoctorOrNurseRole, Status, From, To);

                return View("Index", model);

            }
            catch (System.Exception ex)
            {

                return View("Error404", ex);
            }
          
        }
        [HttpPost]
        public async Task<IActionResult> AddNote(int VisitDetailsId, string Title, string Description)
        {
            try
            {
                if (VisitDetailsId > 0 && !string.IsNullOrWhiteSpace(Title) && !string.IsNullOrWhiteSpace(Description))
                {
                    string userId = User.FindFirstValue(ClaimTypes.NameIdentifier);
                    //var userId = _dbContext.Users.FirstOrDefault(c => c.UserName == userName).Id;
                    var NoteId = await _visitsService.AddNote(VisitDetailsId, Title, Description, userId);
                    if (NoteId > 0)
                    {
                      
                        return RedirectToAction("View", new { VisitDetailsId });
                    }

                }               
             
                return RedirectToAction("View", new { VisitDetailsId, ErrorMessageNoteOrAttachment = "Error, Please check your inputs" });
              
            }
            catch (System.Exception ex)
            {

                return View("Error404", ex);
            }
        }
        [HttpPost]
        public async Task<IActionResult> AddAttachment(int VisitDetailsId, string Title, IFormFile File)
        {
            try
            {
                if (VisitDetailsId > 0 && !string.IsNullOrWhiteSpace(Title) && File != null && File.Length > 0)
                {
                    string userId = User.FindFirstValue(ClaimTypes.NameIdentifier);
                    //var userId = _dbContext.Users.FirstOrDefault(c => c.UserName == userName).Id;
                    var AttachmentId = await _visitsService.AddAttachment(VisitDetailsId, Title, File, userId);
                    if (AttachmentId > 0)
                    {
                        return RedirectToAction("View", new { VisitDetailsId });
                    }

                }
                return RedirectToAction("View", new { VisitDetailsId, ErrorMessageNoteOrAttachment = "Error, Please check your inputs" });
            }
            catch (System.Exception ex)
            {

                return View("Error404", ex);
            }
        }
        public async Task<IActionResult> GetAssignUsers(int ServiceId, string Jobe,long VisitDetailsId)
        {
            try
            {
                if (ServiceId > 0 && !string.IsNullOrWhiteSpace(Jobe))
                {
                    var model = await _visitsService.GetAssignUsers(ServiceId, Jobe, VisitDetailsId);
                    model.ServiceId = ServiceId;
                    string UserId = User.FindFirstValue(ClaimTypes.NameIdentifier);
                    model.UserId = UserId;
                    model.UserRole = await _visitsService.GetRoleNameByUserId(UserId);
                    return PartialView("_displayUsers", model);
                }
                return Content("An error occurred, please try again later");
            }
            catch (System.Exception ex)
            {

                return View("Error404", ex);
            }

        }
        public async Task<IActionResult> AssignUserToVisit(int ServiceId, long VisitDetailsId, string Jobe, string UserId)
        {
            try
            {
                if (VisitDetailsId > 0 && !string.IsNullOrWhiteSpace(Jobe) && !string.IsNullOrWhiteSpace(UserId))
                {
                    string systemUserId = User.FindFirstValue(ClaimTypes.NameIdentifier);
                    var UserVisitAssignId = await _visitsService.AssignUserToVisit(VisitDetailsId, UserId, systemUserId);
                    if (UserVisitAssignId > 0)
                    {
                        return RedirectToAction("GetAssignUsers", new {ServiceId , Jobe, VisitDetailsId });
                    }
                    
                }
                return Content("An error occurred, please try again later");
            }
            catch (System.Exception ex)
            {

                return View("Error404", ex);
            }

        }
        public async Task<IActionResult> ChangeEmployeeStatus(int ServiceId, long VisitDetailsId, string Jobe, long UserVisitAssignId,string Status)
        {
            try
            {
                if (VisitDetailsId > 0 && !string.IsNullOrWhiteSpace(Jobe) && !string.IsNullOrWhiteSpace(Status) && UserVisitAssignId>0)
                {
                    string systemUserId = User.FindFirstValue(ClaimTypes.NameIdentifier);
                    var userVisitAssignId = await _visitsService.ChangeEmployeeStatus(UserVisitAssignId, Status, systemUserId);
                    if (userVisitAssignId > 0)
                    {
                        return RedirectToAction("GetAssignUsers", new { ServiceId, Jobe, VisitDetailsId });
                    }

                }
                return Content("An error occurred, please try again later");
            }
            catch (System.Exception ex)
            {

                return View("Error404", ex);
            }

        }

        //public async Task<IActionResult> PaymentRefund(long VisitDetailsId)
        //{
        //    try
        //    {
        //        if (VisitDetailsId > 0 )
        //        {
        //            string systemUserId = User.FindFirstValue(ClaimTypes.NameIdentifier);
                 
        //            if (VisitDetailsId > 0 && !string.IsNullOrEmpty(systemUserId))
        //            {
        //                var model = _paymentService.Refund(VisitDetailsId, systemUserId);
        //                return View(model);
        //            }

        //        }
        //        return Content("An error occurred, please try again later");
        //    }
        //    catch (System.Exception ex)
        //    {

        //        return View("Error404", ex);
        //    }

        //}
    }
}
