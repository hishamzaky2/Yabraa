﻿using System.Threading.Tasks;
using Microsoft.AspNetCore.Mvc;
using YabraaEF.Models;
using YabraaEF;
using System.Linq;
using Microsoft.EntityFrameworkCore;

namespace SmartAdmin.WebUI.Controllers
{
    public class MedicationsController : Controller
    {
        public ApplicationDbContext _context { get; set; }

        public MedicationsController(ApplicationDbContext context)
        {
            _context = context;

        }
        public async Task<IActionResult> Index()
        {
            try
            {
                var model = await _context.Medications.Where(c => !c.Deleted).ToListAsync();
                return View(model);
            }
            catch (System.Exception ex)
            {

                return View("Error404", ex);
            }
        }
        public IActionResult Create()
        {
            return View(new Medication());
        }
        [HttpPost]
        public async Task<IActionResult> Create(Medication model)
        {
            try
            {
                if (ModelState.IsValid)
                {
                    await _context.Medications.AddAsync(model);
                    var status = _context.SaveChanges();
                    if (status > 0)
                    {
                        return RedirectToAction("Index");
                    }
                }
                return View(model);
            }
            catch (System.Exception ex)
            {

                return View("Error404", ex);
            }

        }
        [HttpGet]
        public async Task<IActionResult> Edit(int MedicationId)
        {
            try
            {
                var model = await _context.Medications.FirstOrDefaultAsync(c => c.MedicationId == MedicationId);
                if (model is not null)
                {
                    return View("Create", model);
                }
                return View("Error404");
            }
            catch (System.Exception ex)
            {

                return View("Error404", ex);
            }
        }
        [HttpPost]
        public async Task<IActionResult> Edit(Medication model)
        {
            try
            {
                if (ModelState.IsValid && model.MedicationId > 0)
                {
                    var Medication = await _context.Medications.FirstOrDefaultAsync(c => c.MedicationId == model.MedicationId);
                    if (Medication is not null)
                    {
                        Medication.TitleEN = model.TitleEN;
                        Medication.TitleAR = model.TitleAR;
                        _context.SaveChanges();
                        return RedirectToAction("Index");
                    }
                    return View("Error404");
                }
                return View("Create", model);
            }
            catch (System.Exception ex)
            {

                return View("Error404", ex);
            }
        }
        [HttpGet]
        public async Task<IActionResult> Delete(int MedicationId)
        {
            try
            {
                var Medication = await _context.Medications.FirstOrDefaultAsync(c => c.MedicationId == MedicationId);
                if (Medication is not null)
                {
                    Medication.Deleted = true; _context.SaveChanges();
                    return Json(new { status = 1, message = "Done" });
                }
                return Json(new { status = 1, message = "Error" });
            }
            catch (System.Exception ex)
            {
                return Json(new { status = 1, message = ex.Message });
            }
        }
    }
}
