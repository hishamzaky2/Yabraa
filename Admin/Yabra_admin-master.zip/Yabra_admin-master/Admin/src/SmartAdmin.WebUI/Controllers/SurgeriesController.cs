﻿using System.Threading.Tasks;
using Microsoft.AspNetCore.Mvc;
using YabraaEF.Models;
using YabraaEF;
using System.Linq;
using Microsoft.EntityFrameworkCore;

namespace SmartAdmin.WebUI.Controllers
{
    public class SurgeriesController : Controller
    {
        public ApplicationDbContext _context { get; set; }

        public SurgeriesController(ApplicationDbContext context)
        {
            _context = context;

        }
        public async Task<IActionResult> Index()
        {
            try
            {
                var model = await _context.Surgeries.Where(c => !c.Deleted).ToListAsync();
                return View(model);
            }
            catch (System.Exception ex)
            {

                return View("Error404", ex);
            }
        }
        public IActionResult Create()
        {
            return View(new Surgery());
        }
        [HttpPost]
        public async Task<IActionResult> Create(Surgery model)
        {
            try
            {
                if (ModelState.IsValid)
                {
                    await _context.Surgeries.AddAsync(model);
                    var status = _context.SaveChanges();
                    if (status > 0)
                    {
                        return RedirectToAction("Index");
                    }
                }
                return View(model);
            }
            catch (System.Exception ex)
            {

                return View("Error404", ex);
            }

        }
        [HttpGet]
        public async Task<IActionResult> Edit(int SurgeryId)
        {
            try
            {
                var model = await _context.Surgeries.FirstOrDefaultAsync(c => c.SurgeryId == SurgeryId);
                if (model is not null)
                {
                    return View("Create", model);
                }
                return View("Error404");
            }
            catch (System.Exception ex)
            {

                return View("Error404", ex);
            }
        }
        [HttpPost]
        public async Task<IActionResult> Edit(Surgery model)
        {
            try
            {
                if (ModelState.IsValid && model.SurgeryId > 0)
                {
                    var Surgery = await _context.Surgeries.FirstOrDefaultAsync(c => c.SurgeryId == model.SurgeryId);
                    if (Surgery is not null)
                    {
                        Surgery.TitleEN = model.TitleEN;
                        Surgery.TitleAR = model.TitleAR;
                        _context.SaveChanges();
                        return RedirectToAction("Index");
                    }
                    return View("Error404");
                }
                return View("Create", model);
            }
            catch (System.Exception ex)
            {

                return View("Error404", ex);
            }
        }
        [HttpGet]
        public async Task<IActionResult> Delete(int SurgeryId)
        {
            try
            {
                var Surgery = await _context.Surgeries.FirstOrDefaultAsync(c => c.SurgeryId == SurgeryId);
                if (Surgery is not null)
                {
                    Surgery.Deleted = true; _context.SaveChanges();
                    return Json(new { status = 1, message = "Done" });
                }
                return Json(new { status = 1, message = "Error" });
            }
            catch (System.Exception ex)
            {
                return Json(new { status = 1, message = ex.Message });
            }
        }
    }
}
