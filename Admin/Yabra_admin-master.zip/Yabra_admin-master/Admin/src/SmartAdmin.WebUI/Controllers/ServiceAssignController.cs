﻿using System.Security.Claims;
using System.Threading.Tasks;
using Microsoft.AspNetCore.Authorization;
using Microsoft.AspNetCore.Mvc;
using SmartAdmin.WebUI.ViewModel;

namespace SmartAdmin.WebUI.Controllers
{
    [Authorize(Permissions.Services.Manage)]
    public class ServiceAssignController : Controller    {
       
        public SmartAdmin.WebUI.Services.ServiceAssign _service { get; set; }
        public ServiceAssignController(SmartAdmin.WebUI.Services.ServiceAssign service)
        {
            _service = service;
        }
        public async Task<IActionResult> GetJobe(int ServiceId, string Job)
        {
            try
            {
                if (ServiceId > 0 && !string.IsNullOrWhiteSpace(Job))
                {
                    var model = await _service.GetJobes(ServiceId,Job);
                    return PartialView("_disPlayJobe",model);
                }
                return Content("An error occurred, please try again later");
            }
            catch (System.Exception ex)
            {

                return View("Error404", ex);
            }

        }
        public async Task<IActionResult> AssignUserService(int ServiceId, string Job,string UserId)
        {
            try
            {
                if (ServiceId > 0 && !string.IsNullOrWhiteSpace(Job) && !string.IsNullOrWhiteSpace(UserId) && UserId != "-1")
                {
                    string userId = User.FindFirstValue(ClaimTypes.NameIdentifier);
                    var ServiceUserWorkId = await _service.AssignUserService(ServiceId, Job,UserId, userId);
                    if (ServiceUserWorkId > 0)
                    {
                        return RedirectToAction("GetJobe", new { ServiceId , Job });
                    }
                    
                }
                return Content("An error occurred, please try again later");
            }
            catch (System.Exception ex)
            {

                return View("Error404", ex);
            }

        }

        [HttpGet]
        public async Task<IActionResult> UnAssignUserService(int ServiceId, string Job, string UserId)
        {
            try
            {
                var status = await _service.UnAssignUserService(ServiceId, Job,UserId);
                if (status== 1)
                {
                    return Json(new { status = 1, message = "Done" });
                }
                return Json(new { status = -1, message = "Error" });
            }
            catch (System.Exception ex)
            {
                return Json(new { status = -1, message = ex.Message });
            }
        }
    }
}
