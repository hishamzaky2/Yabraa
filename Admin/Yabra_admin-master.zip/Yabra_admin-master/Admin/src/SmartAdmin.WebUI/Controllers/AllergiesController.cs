﻿using System.Linq;
using System.Threading.Tasks;
using Microsoft.AspNetCore.Mvc;
using Microsoft.EntityFrameworkCore;
using SmartAdmin.WebUI.ViewModel;
using YabraaEF;
using YabraaEF.Models;

namespace SmartAdmin.WebUI.Controllers
{
    public class AllergiesController : Controller
    {
        public ApplicationDbContext _context { get; set; }

        public AllergiesController(ApplicationDbContext context)
        {
            _context = context;

        }
        public async Task<IActionResult> Index()
        {
            try
            {
                var model = await  _context.Allergies.Where(c=>!c.Deleted).ToListAsync();   
                return View(model);
            }
            catch (System.Exception ex)
            {

                return View("Error404", ex);
            }
        }
        public IActionResult Create()
        {
            return View(new Allergy());
        }
        [HttpPost]
        public async Task<IActionResult> Create(Allergy model)
        {
            try
            {
                if (ModelState.IsValid)
                {
                    await _context.Allergies.AddAsync(model);
                    var status = _context.SaveChanges();
                    if (status > 0)
                    {
                        return RedirectToAction("Index");
                    }
                }
                return View(model);
            }
            catch (System.Exception ex)
            {

                return View("Error404", ex);
            }

        }
        [HttpGet]
        public async Task<IActionResult> Edit(int AllergyId)
        {
            try
            {
                var model = await _context.Allergies.FirstOrDefaultAsync( c=> c.AllergyId == AllergyId);
                if (model is not null)
                {
                    return View("Create", model);
                }
                return View("Error404");
            }
            catch (System.Exception ex)
            {

                return View("Error404", ex);
            }
        }
        [HttpPost]
        public async Task<IActionResult> Edit(Allergy model)
        {
            try
            {
                if (ModelState.IsValid && model.AllergyId > 0)
                {
                    var Allergy = await _context.Allergies.FirstOrDefaultAsync(c => c.AllergyId == model.AllergyId);
                    if (Allergy is not null)
                    {
                        Allergy.TitleEN = model.TitleEN;
                        Allergy.TitleAR = model.TitleAR;
                        _context.SaveChanges();
                        return RedirectToAction("Index");
                    }
                    return View("Error404");
                }
                return View("Create", model);
            }
            catch (System.Exception ex)
            {

                return View("Error404", ex);
            }
        }
        [HttpGet]
        public async Task<IActionResult> Delete(int AllergyId)
        {
            try
            {
                var Allergy = await _context.Allergies.FirstOrDefaultAsync(c => c.AllergyId == AllergyId);
                if (Allergy is not null)
                {
                    Allergy.Deleted = true; _context.SaveChanges();
                    return Json(new { status = 1, message = "Done" });
                }
                return Json(new { status = 1, message = "Error" });
            }
            catch (System.Exception ex)
            {
                return Json(new { status = 1, message = ex.Message });
            }
        }

    }
}
