# SmartAdmin for ASP.NET Core 3.1 - Documentation

## Table of Contents

1. **[Introduction](introduction.md)**
1. **Getting Started**
1. **[Site Structure](site-structure.md)**
1. **[Solution Architecture](solution-architecture.md)**
1. **[How To Contribute](howto-contribute.md)**
1. **[Licensing Information](licensing-information.md)**
1. **[Changelog](changelog.md)**

---

### Getting Started

Getting started intro.
