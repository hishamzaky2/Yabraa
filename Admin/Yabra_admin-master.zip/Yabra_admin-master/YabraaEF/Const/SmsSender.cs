﻿using System;
using System.Collections.Generic;
using System.Collections.Specialized;
using System.Linq;
using System.Net;
using System.Text;
using System.Text.Json;
using System.Threading.Tasks;
using static System.Net.Mime.MediaTypeNames;

namespace YabraaEF.Const
{
    public class SmsSender
    {
        private readonly string apiUrl = "https://www.msegat.com/gw/sendsms.php";
        private readonly string userName = "yabra";
        private readonly string apiKey = "327b1513c46234855d4bd46b936cc49d";
        private readonly string userSender = "Yabraa Med";
        private readonly string msgEncoding = "UTF8";
        public async Task<bool> SendVerificationCode(string phoneNumber, string verificationCode, string lang)
        {
            try
            {
                using (HttpClient client = new HttpClient())
                {
                    client.DefaultRequestHeaders.Add("lang", lang);
                     var msg = "";
                    if (lang == "Ar")
                    {
                        msg = $"Your verification code is: {verificationCode}";
                    }
                    else
                    {
                        msg = $"رمز التحقق: {verificationCode}";
                    }
                  
                    var parameters = new FormUrlEncodedContent(new[]
                    {
                    new KeyValuePair<string, string>("userName", userName),
                    new KeyValuePair<string, string>("apiKey", apiKey),
                    new KeyValuePair<string, string>("number",$"966{phoneNumber}"),
                    new KeyValuePair<string, string>("userSender", userSender),
                    new KeyValuePair<string, string>("msg",msg ),
                    //new KeyValuePair<string, string>("msgEncoding",msgEncoding)
                    
                });

                    var response = await client.PostAsync(apiUrl, parameters);

                    if (response.IsSuccessStatusCode)
                    {
                        // SMS sent successfully
                        return true;
                    }
                    else
                    {
                        // Failed to send SMS
                        return false;
                    }
                }
            }
            catch (Exception ex)
            {
                // Handle exception
                return false;
            }
        }

        public  string SendOTP(string phoneNumber, string otp)
        {
           
            var postData = new NameValueCollection();
            postData.Add("userName", userName);
            postData.Add("apiKey", apiKey);
            postData.Add("number",$"966{phoneNumber}" );
            postData.Add("userSender", userSender);
            postData.Add("msg", $"رمز التحقق: {otp}");


            //postData.Add("msgEncoding", msgEncoding);
            Console.WriteLine($"966{phoneNumber}");
            var client = new WebClient();
            var response = client.UploadValues(apiUrl, postData);
          

            string responseString = Encoding.UTF8.GetString(response);

            return responseString;
        }
        public async Task<string> SendAsync(string phoneNumber,string msg)
        {

            var baseAddress = new Uri("https://www.msegat.com");

            using var httpClient = new HttpClient { BaseAddress = baseAddress };
            {

            //   phoneNumber = "966" + phoneNumber.Trim();

                using (var content = new StringContent($@"{{ ""userName"": ""{userName}"", ""numbers"": ""966{phoneNumber}"",""userSender"": ""{userSender}"",""apiKey"": ""{apiKey}"", ""msg"": ""{msg}""}}", System.Text.Encoding.Default, "application/json"))
              
                {

                    using (var response = await httpClient.PostAsync("/gw/sendsms.php", content))
                    {
                        string responseHeaders = response.Headers.ToString();
                        string responseData = await response.Content.ReadAsStringAsync();

                        Console.WriteLine("Status " + (int)response.StatusCode);
                        Console.WriteLine("Headers " + responseHeaders);
                        Console.WriteLine("Data " + responseData);
                        return responseData;
                    }
                }
            }
        }

    }
}
