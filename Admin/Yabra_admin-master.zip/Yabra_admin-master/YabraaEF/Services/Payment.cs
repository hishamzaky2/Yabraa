﻿using Microsoft.EntityFrameworkCore;
using Newtonsoft.Json;
using System;
using System.Collections.Generic;
using System.Globalization;
using System.Linq;
using System.Net;
using System.Text;
using System.Text.RegularExpressions;
using System.Threading.Tasks;
using YabraaEF.Models;

namespace YabraaEF.Services
{
    public class Payment
    {
        private ApplicationDbContext _context;
        public Payment(ApplicationDbContext dbContext)
        {
            _context = dbContext;
        }
        public Dictionary<string, dynamic> Refund(string Id, int PaymentMethodId, decimal amount,long VisitDetailsId,string userId,int VisitStatusId = -1)
        {
            string entityId = getentityId(PaymentMethodId);
            Dictionary<string, dynamic> responseData;
            string data = $"entityId={entityId}" +
                $"&amount={amount.ToString("0.00", CultureInfo.InvariantCulture)}" +
                "&currency=SAR" +
                "&paymentType=RF";
            Console.WriteLine(data);
            string url = $"https://eu-prod.oppwa.com/v1/payments/{Id}";
          
            byte[] buffer = Encoding.ASCII.GetBytes(data);
            HttpWebRequest request = (HttpWebRequest)HttpWebRequest.Create(url);
            request.Method = "POST";
            request.Headers["Authorization"] = "Bearer OGFjOWE0Y2U4YjQyNWYyOTAxOGI1NzM1YWIzMzU3Zjl8OXFYUHJSdHNiS0szUzVkdw==";
            request.ContentType = "application/x-www-form-urlencoded";
            Stream PostData = request.GetRequestStream();
            PostData.Write(buffer, 0, buffer.Length);
            PostData.Close();
            using (HttpWebResponse response = (HttpWebResponse)request.GetResponse())
            {
                Stream dataStream = response.GetResponseStream();
                StreamReader reader = new StreamReader(dataStream);
                //var s = new JavaScriptSerializer();
                //responseData = s.Deserialize<Dictionary<string, dynamic>>(reader.ReadToEnd());
                responseData = JsonConvert.DeserializeObject<Dictionary<string, dynamic>>(reader.ReadToEnd());
                reader.Close();
                dataStream.Close();
            }
            if (responseData is not null)
            {
                string result = responseData["result"]["code"];
                string pattern = @"^(000\.000\.|000\.100\.1|000\.[36])";
                bool isMatch = Regex.IsMatch(result, pattern);
                string pattern2 = @"^(000\.400\.0[^3]|000\.400\.[0-1]{2}0)";
                bool isMatch2 = Regex.IsMatch(result, pattern2);

                if (isMatch || isMatch2)
                {
                    var visitDetails = _context.VisitDetails.FirstOrDefault(c => c.VisitDetailsId == VisitDetailsId);
                    if (visitDetails is not null)
                    {
                        if (VisitStatusId > 0)
                        {
                            visitDetails.VisitStatusId = VisitStatusId;
                            VisitStatusLog log = new VisitStatusLog()
                            {
                                VisitStatusId = VisitStatusId,
                                VisitDetailsId = visitDetails.VisitDetailsId,
                                ApplicationUserActionId = userId

                            };
                            _context.VisitStatusLogs.Add(log);
                            _context.SaveChanges();
                        }
                        else
                        {
                            visitDetails.VisitStatusId = 7;
                            VisitStatusLog log = new VisitStatusLog()
                            {
                                VisitStatusId = 7,
                                VisitDetailsId = visitDetails.VisitDetailsId,
                                ApplicationUserActionId = userId

                            };
                            _context.VisitStatusLogs.Add(log);
                            _context.SaveChanges();
                        }
                       
                    }
                }
            }
            return responseData;
        }
        string getentityId(int PaymentMethodId)
        {
            var PaymentMethod = _context.PaymentMethods.FirstOrDefault(c => c.PaymentMethodId == PaymentMethodId);
            if (PaymentMethod != null)
            {
                if (PaymentMethod.NameEN == "Apple_Pay")
                {
                    return "8ac9a4cc8bae2959018be678ef2b669f";
                }
                else if (PaymentMethod.NameEN == "VISA" || PaymentMethod.NameEN == "MASTER" || PaymentMethod.NameEN == "STC")
                {
                    return "8ac9a4ce8b425f29018b573643cb5801";

                }
                else if (PaymentMethod.NameEN == "MADA")
                {
                    return "8ac9a4ce8b425f29018b5736d3855808";
                }
            }
            return null;
        }
    }
}
