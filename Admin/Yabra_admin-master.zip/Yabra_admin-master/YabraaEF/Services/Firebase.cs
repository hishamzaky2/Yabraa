﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using FirebaseAdmin;
using FirebaseAdmin.Messaging;
using Google.Apis.Auth.OAuth2;
using YabraaEF.Const;
using YabraaEF.Helpers;
using YabraaEF.Models;

namespace YabraaEF.Services
{
    public class Firebase
    {
        
        public async void SendMessage(ModelSendMessage modelSendMessage)
        {
            try
            {
               var firebaseCredential = await GoogleCredential.FromFileAsync("Resources/yabraaMediacalCenterFirebase.json", CancellationToken.None);
               
                var firebaseApp = FirebaseApp.Create(new AppOptions
                {
                    Credential = firebaseCredential,
                });

            
                Dictionary<string,string> data = new Dictionary<string, string>();
                data.Add("titleAr", modelSendMessage.TitleAr);
                data.Add("titleEn", modelSendMessage.TitleEn);
                data.Add("bodyAr", modelSendMessage.BodyAr);
                data.Add("bodyEn", modelSendMessage.BodyEn);
                // Create the message object.
                Message message = new Message()
                {
                    Token = modelSendMessage.RegistrationToken,
                    Data = data,
                    Notification = new Notification()
                    {
                        Title = modelSendMessage.TitleAr,
                        Body = modelSendMessage.BodyAr
                    }
                };
                UserNotification notification = new UserNotification()
                {
                     ApplicationUserId = modelSendMessage.UserId,
                     NotificationTypeId = modelSendMessage.NotificationTypeId,
                     TitleAR = modelSendMessage.TitleAr,
                     BodyAR = modelSendMessage.BodyAr,
                     BodyEn = modelSendMessage.BodyEn,
                     TitleEn = modelSendMessage.TitleEn,
                     dateTime = General.GetKSATimeZoneNow()
                };
                ApplicationDbContext context = new ApplicationDbContext();
                context.UserNotifications.Add(notification);
                context.SaveChanges();
                // Send the message.
                await FirebaseMessaging.DefaultInstance.SendAsync(message);

                int x = 0;

            }
            catch (Exception ex)
            {
                // Handle exceptions appropriately (e.g., log, throw, etc.)
                Console.WriteLine($"Exception: {ex.Message}");
            }

        }
        public async Task SendMessageToTopic(string topic, string title, string body)
        {
            try
            {
                var filePath = Path.Combine(AppDomain.CurrentDomain.BaseDirectory, "YabraaEF", "Resources", "yabraaMediacalCenterFirebase.json");
                var firebaseCredential = await GoogleCredential.FromFileAsync(filePath, CancellationToken.None);

                var firebaseApp = FirebaseApp.Create(new AppOptions
                {
                    Credential = firebaseCredential,
                });

                // Create the message object.
                Message message = new Message()
                {
                    Topic = topic,
                    Notification = new Notification()
                    {
                        Title = title,
                        Body = body
                    }
                };


                // Send the message.
                await FirebaseMessaging.DefaultInstance.SendAsync(message);
            }
            catch (Exception ex)
            {
                // Handle exceptions appropriately (e.g., log, throw, etc.)
                Console.WriteLine($"Exception: {ex.Message}");
            }
        }

        public async Task ReadFireBaseAdminSdkAsync()
        {
            var filePath = "yabraa-mediacal-center-firebase-adminsdk-riwgq-774cbf4fe0.json";

            using (var stream = new FileStream(filePath, FileMode.Open, FileAccess.Read))
            {
                var jsonContent = await new StreamReader(stream).ReadToEndAsync();

                if (FirebaseMessaging.DefaultInstance == null)
                {
                    FirebaseApp.Create(new AppOptions
                    {
                        Credential = GoogleCredential.FromJson(jsonContent)
                    });
                }
            }
        }
    }
}
