﻿using System;
using System.Collections.Generic;
using System.ComponentModel.DataAnnotations.Schema;
using System.ComponentModel.DataAnnotations;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace YabraaEF.Models
{
    public class VisitStatusLog
    {
        [Key]
        [DatabaseGenerated(DatabaseGeneratedOption.Identity)]
        public long VisitStatusLogId { get; set; }
        public int VisitStatusId { get; set; }
        [ForeignKey("VisitStatusId")]
        public virtual VisitStatus VisitStatus { get; set; }
        public long VisitDetailsId { get; set; }
        [ForeignKey("VisitDetailsId")]
        public virtual VisitDetails VisitDetails { get; set; }
        public string ApplicationUserActionId { get; set; }
        [ForeignKey("ApplicationUserActionId")]
        public virtual ApplicationUser ApplicationUserrAction { get; set; }
        public string? Commment { get; set; }
    }
}
