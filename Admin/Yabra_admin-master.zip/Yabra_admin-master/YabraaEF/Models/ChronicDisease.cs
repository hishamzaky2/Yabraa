﻿using System;
using System.Collections.Generic;
using System.ComponentModel.DataAnnotations.Schema;
using System.ComponentModel.DataAnnotations;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace YabraaEF.Models
{
	public class ChronicDisease
	{
		[Key]
		[DatabaseGenerated(DatabaseGeneratedOption.Identity)]
		public int ChronicDiseaseId { get; set; }
		public string TitleEN { get; set; }
		public string TitleAR { get; set; }
		public bool Deleted { get; set; }
	}
}
