﻿using System;
using System.Collections.Generic;
using System.ComponentModel.DataAnnotations.Schema;
using System.ComponentModel.DataAnnotations;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace YabraaEF.Models
{
    public class UserNotification
    {
        [Key]
        [DatabaseGenerated(DatabaseGeneratedOption.Identity)]
        public long UserNotificationId { get; set; }
        public string TitleAR { get; set; }
        public string TitleEn { get; set; }
        public string BodyAR { get; set; }
        public string BodyEn { get; set; }
        public DateTime dateTime { get; set; }
        public bool isRead { get; set; }
        public string ApplicationUserId { get; set; }
        [ForeignKey("ApplicationUserId")]
        public virtual ApplicationUser ApplicationUser { get; set; }
        public int NotificationTypeId { get; set; }
        [ForeignKey("NotificationTypeId")]
        public virtual NotificationType NotificationType { get; set; }
    }
}
