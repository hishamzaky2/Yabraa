﻿using System;
using System.Collections.Generic;
using System.ComponentModel.DataAnnotations.Schema;
using System.ComponentModel.DataAnnotations;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace YabraaEF.Models
{
	public class UserFamilyInjury
	{
		[Key]
		[DatabaseGenerated(DatabaseGeneratedOption.Identity)]
		public long UserFamilyInjuryId { get; set; }
        public long UserFamilyId { get; set; }
        [ForeignKey("UserFamilyId")]
        public virtual UserFamily UserFamily { get; set; }
        public int InjuryId { get; set; }
		[ForeignKey("InjuryId")]
		public virtual Injury Injury { get; set; }
		public bool Deleted { get; set; }
	}
}
