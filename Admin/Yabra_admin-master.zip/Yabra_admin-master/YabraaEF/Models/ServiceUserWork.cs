﻿using System;
using System.Collections.Generic;
using System.ComponentModel.DataAnnotations.Schema;
using System.ComponentModel.DataAnnotations;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using Microsoft.AspNetCore.Identity;

namespace YabraaEF.Models
{
    public class ServiceUserWork
    {
        [Key]
        [DatabaseGenerated(DatabaseGeneratedOption.Identity)]
        public int ServiceUserWorkId { get; set; }
        public int ServiceId { get; set; }
        [ForeignKey("ServiceId")]
        public virtual Service Service { get; set; }
        public string ApplicationUserWorkId { get; set; }
        [ForeignKey("ApplicationUserWorkId")]
        public virtual ApplicationUser ApplicationUserWork { get; set; }
        public string ApplicationUserCreateId { get; set; }
        [ForeignKey("ApplicationUserCreateId")]
        public virtual ApplicationUser ApplicationUserCreate { get; set; }
        public string RoleId { get; set; }
        public DateTime From { get; set; }
        public DateTime? To { get; set; }
      
    }
}
