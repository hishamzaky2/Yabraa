﻿using System;
using System.Collections.Generic;
using System.ComponentModel.DataAnnotations.Schema;
using System.ComponentModel.DataAnnotations;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace YabraaEF.Models
{
    public class UserVisitAssignStatusLog
    {
        [Key]
        [DatabaseGenerated(DatabaseGeneratedOption.Identity)]
        public long UserVisitAssignStatusLogId { get; set; }
        public int UserVisitAssignStatusId { get; set; }
        [ForeignKey("UserVisitAssignStatusId")]
        public virtual UserVisitAssignStatus UserVisitAssignStatus { get; set; }
        public long UserVisitAssignId { get; set; }
        [ForeignKey("UserVisitAssignId")]
        public virtual UserVisitAssign UserVisitAssign { get; set; }
        public string ApplicationUserActionId { get; set; }
        [ForeignKey("ApplicationUserActionId")]
        public virtual ApplicationUser ApplicationUserrAction { get; set; }
        public string? Commment { get; set; }
        public DateTime CreateDT { get; set; }

    }
}
