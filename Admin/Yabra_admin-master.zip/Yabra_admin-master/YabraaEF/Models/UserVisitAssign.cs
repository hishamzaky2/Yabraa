﻿using System;
using System.Collections.Generic;
using System.ComponentModel.DataAnnotations.Schema;
using System.ComponentModel.DataAnnotations;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace YabraaEF.Models
{
    public class UserVisitAssign
    {
        [Key]
        [DatabaseGenerated(DatabaseGeneratedOption.Identity)]
        public long UserVisitAssignId { get; set; }       
        public long VisitDetailsId { get; set; }
        [ForeignKey("VisitDetailsId")]
        public virtual VisitDetails VisitDetails { get; set; }
        public string ApplicationUserAssignId { get; set; }
        [ForeignKey("ApplicationUserAssignId")]
        public virtual ApplicationUser ApplicationUserAssign { get; set; }
        public int UserVisitAssignStatusId { get; set; }
        [ForeignKey("UserVisitAssignStatusId")]
        public virtual UserVisitAssignStatus UserVisitAssignStatus { get; set; }
        public DateTime CreateDT { get; set; }
    }
}
