﻿using System;
using System.Collections.Generic;
using System.ComponentModel.DataAnnotations.Schema;
using System.ComponentModel.DataAnnotations;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace YabraaEF.Models
{
	public class Injury
	{
		[Key]
		[DatabaseGenerated(DatabaseGeneratedOption.Identity)]
		public int InjuryId { get; set; }
		public string TitleEN { get; set; }
		public string TitleAR { get; set; }
		public bool Deleted { get; set; }
	}
}
