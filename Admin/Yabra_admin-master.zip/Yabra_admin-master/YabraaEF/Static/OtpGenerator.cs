﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace YabraaEF.Helper
{
    public static class OtpGenerator
    {
        //public static string GenerateOtp(string secretKey)
        //{
        //    var totp = new Totp(Base32Encoding.ToBytes(secretKey));
        //    return totp.ComputeTotp();
        //}
        public static string GenerateOTP(int length)
        {
            string numbers = "0123456789";
            Random objrandom = new Random();
            string strrandom = string.Empty;
            for (int i = 0; i < length; i++)
            {
                int temp = objrandom.Next(0, numbers.Length);
                strrandom += temp;
            }
            return strrandom;
        }

    }
}
