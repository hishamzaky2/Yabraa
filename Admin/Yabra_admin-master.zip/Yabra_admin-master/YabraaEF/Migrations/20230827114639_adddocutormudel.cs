﻿using System;
using Microsoft.EntityFrameworkCore.Migrations;

#nullable disable

namespace YabraaEF.Migrations
{
    public partial class adddocutormudel : Migration
    {
        protected override void Up(MigrationBuilder migrationBuilder)
        {
            migrationBuilder.CreateTable(
                name: "ServiceUserWorks",
                columns: table => new
                {
                    ServiceUserWorkId = table.Column<int>(type: "int", nullable: false)
                        .Annotation("SqlServer:Identity", "1, 1"),
                    ServiceId = table.Column<int>(type: "int", nullable: false),
                    ApplicationUserWorkId = table.Column<string>(type: "nvarchar(450)", nullable: false),
                    ApplicationUserCreateId = table.Column<string>(type: "nvarchar(450)", nullable: false),
                    RoleId = table.Column<string>(type: "nvarchar(max)", nullable: false),
                    From = table.Column<DateTime>(type: "datetime2", nullable: false),
                    To = table.Column<DateTime>(type: "datetime2", nullable: true)
                },
                constraints: table =>
                {
                    table.PrimaryKey("PK_ServiceUserWorks", x => x.ServiceUserWorkId);
                    table.ForeignKey(
                        name: "FK_ServiceUserWorks_AspNetUsers_ApplicationUserCreateId",
                        column: x => x.ApplicationUserCreateId,
                        principalTable: "AspNetUsers",
                        principalColumn: "Id",
                        onDelete: ReferentialAction.Cascade);
                    table.ForeignKey(
                        name: "FK_ServiceUserWorks_AspNetUsers_ApplicationUserWorkId",
                        column: x => x.ApplicationUserWorkId,
                        principalTable: "AspNetUsers",
                        principalColumn: "Id",
                        onDelete: ReferentialAction.NoAction);
                    table.ForeignKey(
                        name: "FK_ServiceUserWorks_Services_ServiceId",
                        column: x => x.ServiceId,
                        principalTable: "Services",
                        principalColumn: "ServiceId",
                        onDelete: ReferentialAction.Cascade);
                });

            migrationBuilder.CreateTable(
                name: "UserVisitAssignStatuses",
                columns: table => new
                {
                    UserVisitAssignStatusId = table.Column<int>(type: "int", nullable: false)
                        .Annotation("SqlServer:Identity", "1, 1"),
                    Name = table.Column<string>(type: "nvarchar(max)", nullable: false),
                    Description = table.Column<string>(type: "nvarchar(max)", nullable: true)
                },
                constraints: table =>
                {
                    table.PrimaryKey("PK_UserVisitAssignStatuses", x => x.UserVisitAssignStatusId);
                });

            migrationBuilder.CreateTable(
                name: "VisitStatusLogs",
                columns: table => new
                {
                    VisitStatusLogId = table.Column<long>(type: "bigint", nullable: false)
                        .Annotation("SqlServer:Identity", "1, 1"),
                    VisitStatusId = table.Column<int>(type: "int", nullable: false),
                    VisitDetailsId = table.Column<long>(type: "bigint", nullable: false),
                    ApplicationUserActionId = table.Column<string>(type: "nvarchar(450)", nullable: false),
                    Commment = table.Column<string>(type: "nvarchar(max)", nullable: true)
                },
                constraints: table =>
                {
                    table.PrimaryKey("PK_VisitStatusLogs", x => x.VisitStatusLogId);
                    table.ForeignKey(
                        name: "FK_VisitStatusLogs_AspNetUsers_ApplicationUserActionId",
                        column: x => x.ApplicationUserActionId,
                        principalTable: "AspNetUsers",
                        principalColumn: "Id",
                        onDelete: ReferentialAction.Cascade);
                    table.ForeignKey(
                        name: "FK_VisitStatusLogs_VisitDetails_VisitDetailsId",
                        column: x => x.VisitDetailsId,
                        principalTable: "VisitDetails",
                        principalColumn: "VisitDetailsId",
                        onDelete: ReferentialAction.NoAction);
                    table.ForeignKey(
                        name: "FK_VisitStatusLogs_VisitStatuses_VisitStatusId",
                        column: x => x.VisitStatusId,
                        principalTable: "VisitStatuses",
                        principalColumn: "VisitStatusId",
                        onDelete: ReferentialAction.Cascade);
                });

            migrationBuilder.CreateTable(
                name: "UserVisitAssigns",
                columns: table => new
                {
                    UserVisitAssignId = table.Column<long>(type: "bigint", nullable: false)
                        .Annotation("SqlServer:Identity", "1, 1"),
                    VisitDetailsId = table.Column<long>(type: "bigint", nullable: false),
                    ApplicationUserAssignId = table.Column<string>(type: "nvarchar(450)", nullable: false),
                    UserVisitAssignStatusId = table.Column<int>(type: "int", nullable: false)
                },
                constraints: table =>
                {
                    table.PrimaryKey("PK_UserVisitAssigns", x => x.UserVisitAssignId);
                    table.ForeignKey(
                        name: "FK_UserVisitAssigns_AspNetUsers_ApplicationUserAssignId",
                        column: x => x.ApplicationUserAssignId,
                        principalTable: "AspNetUsers",
                        principalColumn: "Id",
                        onDelete: ReferentialAction.Cascade);
                    table.ForeignKey(
                        name: "FK_UserVisitAssigns_UserVisitAssignStatuses_UserVisitAssignStatusId",
                        column: x => x.UserVisitAssignStatusId,
                        principalTable: "UserVisitAssignStatuses",
                        principalColumn: "UserVisitAssignStatusId",
                        onDelete: ReferentialAction.Cascade);
                    table.ForeignKey(
                        name: "FK_UserVisitAssigns_VisitDetails_VisitDetailsId",
                        column: x => x.VisitDetailsId,
                        principalTable: "VisitDetails",
                        principalColumn: "VisitDetailsId",
                        onDelete: ReferentialAction.NoAction);
                });

            migrationBuilder.CreateTable(
                name: "UserVisitAssignStatusLogs",
                columns: table => new
                {
                    UserVisitAssignStatusLogId = table.Column<long>(type: "bigint", nullable: false)
                        .Annotation("SqlServer:Identity", "1, 1"),
                    UserVisitAssignStatusId = table.Column<int>(type: "int", nullable: false),
                    UserVisitAssignId = table.Column<long>(type: "bigint", nullable: false),
                    ApplicationUserActionId = table.Column<string>(type: "nvarchar(450)", nullable: false),
                    Commment = table.Column<string>(type: "nvarchar(max)", nullable: true)
                },
                constraints: table =>
                {
                    table.PrimaryKey("PK_UserVisitAssignStatusLogs", x => x.UserVisitAssignStatusLogId);
                    table.ForeignKey(
                        name: "FK_UserVisitAssignStatusLogs_AspNetUsers_ApplicationUserActionId",
                        column: x => x.ApplicationUserActionId,
                        principalTable: "AspNetUsers",
                        principalColumn: "Id",
                        onDelete: ReferentialAction.Cascade);
                    table.ForeignKey(
                        name: "FK_UserVisitAssignStatusLogs_UserVisitAssigns_UserVisitAssignId",
                        column: x => x.UserVisitAssignId,
                        principalTable: "UserVisitAssigns",
                        principalColumn: "UserVisitAssignId",
                        onDelete: ReferentialAction.NoAction);
                    table.ForeignKey(
                        name: "FK_UserVisitAssignStatusLogs_UserVisitAssignStatuses_UserVisitAssignStatusId",
                        column: x => x.UserVisitAssignStatusId,
                        principalTable: "UserVisitAssignStatuses",
                        principalColumn: "UserVisitAssignStatusId",
                        onDelete: ReferentialAction.Cascade);
                });

            migrationBuilder.CreateIndex(
                name: "IX_ServiceUserWorks_ApplicationUserCreateId",
                table: "ServiceUserWorks",
                column: "ApplicationUserCreateId");

            migrationBuilder.CreateIndex(
                name: "IX_ServiceUserWorks_ApplicationUserWorkId",
                table: "ServiceUserWorks",
                column: "ApplicationUserWorkId");

            migrationBuilder.CreateIndex(
                name: "IX_ServiceUserWorks_ServiceId",
                table: "ServiceUserWorks",
                column: "ServiceId");

            migrationBuilder.CreateIndex(
                name: "IX_UserVisitAssigns_ApplicationUserAssignId",
                table: "UserVisitAssigns",
                column: "ApplicationUserAssignId");

            migrationBuilder.CreateIndex(
                name: "IX_UserVisitAssigns_UserVisitAssignStatusId",
                table: "UserVisitAssigns",
                column: "UserVisitAssignStatusId");

            migrationBuilder.CreateIndex(
                name: "IX_UserVisitAssigns_VisitDetailsId",
                table: "UserVisitAssigns",
                column: "VisitDetailsId");

            migrationBuilder.CreateIndex(
                name: "IX_UserVisitAssignStatusLogs_ApplicationUserActionId",
                table: "UserVisitAssignStatusLogs",
                column: "ApplicationUserActionId");

            migrationBuilder.CreateIndex(
                name: "IX_UserVisitAssignStatusLogs_UserVisitAssignId",
                table: "UserVisitAssignStatusLogs",
                column: "UserVisitAssignId");

            migrationBuilder.CreateIndex(
                name: "IX_UserVisitAssignStatusLogs_UserVisitAssignStatusId",
                table: "UserVisitAssignStatusLogs",
                column: "UserVisitAssignStatusId");

            migrationBuilder.CreateIndex(
                name: "IX_VisitStatusLogs_ApplicationUserActionId",
                table: "VisitStatusLogs",
                column: "ApplicationUserActionId");

            migrationBuilder.CreateIndex(
                name: "IX_VisitStatusLogs_VisitDetailsId",
                table: "VisitStatusLogs",
                column: "VisitDetailsId");

            migrationBuilder.CreateIndex(
                name: "IX_VisitStatusLogs_VisitStatusId",
                table: "VisitStatusLogs",
                column: "VisitStatusId");
        }

        protected override void Down(MigrationBuilder migrationBuilder)
        {
            migrationBuilder.DropTable(
                name: "ServiceUserWorks");

            migrationBuilder.DropTable(
                name: "UserVisitAssignStatusLogs");

            migrationBuilder.DropTable(
                name: "VisitStatusLogs");

            migrationBuilder.DropTable(
                name: "UserVisitAssigns");

            migrationBuilder.DropTable(
                name: "UserVisitAssignStatuses");
        }
    }
}
