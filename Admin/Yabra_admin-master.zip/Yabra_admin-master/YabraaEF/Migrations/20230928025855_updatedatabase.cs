﻿using Microsoft.EntityFrameworkCore.Migrations;

#nullable disable

namespace YabraaEF.Migrations
{
    public partial class updatedatabase : Migration
    {
        protected override void Up(MigrationBuilder migrationBuilder)
        {
            migrationBuilder.DropTable(
                name: "VisitAllergies");

            migrationBuilder.DropTable(
                name: "VisitChronicDiseases");

            migrationBuilder.DropTable(
                name: "VisitCurrentMedications");

            migrationBuilder.DropTable(
                name: "VisitInjuries");

            migrationBuilder.DropTable(
                name: "VisitPastMedications");

            migrationBuilder.DropTable(
                name: "VisitSurgeries");

            migrationBuilder.CreateTable(
                name: "UserFamilyAllergies",
                columns: table => new
                {
                    UserFamilyAllergyId = table.Column<long>(type: "bigint", nullable: false)
                        .Annotation("SqlServer:Identity", "1, 1"),
                    UserFamilyId = table.Column<long>(type: "bigint", nullable: false),
                    AllergyId = table.Column<int>(type: "int", nullable: false),
                    Deleted = table.Column<bool>(type: "bit", nullable: false)
                },
                constraints: table =>
                {
                    table.PrimaryKey("PK_UserFamilyAllergies", x => x.UserFamilyAllergyId);
                    table.ForeignKey(
                        name: "FK_UserFamilyAllergies_Allergies_AllergyId",
                        column: x => x.AllergyId,
                        principalTable: "Allergies",
                        principalColumn: "AllergyId",
                        onDelete: ReferentialAction.NoAction);
                    table.ForeignKey(
                        name: "FK_UserFamilyAllergies_UserFamilies_UserFamilyId",
                        column: x => x.UserFamilyId,
                        principalTable: "UserFamilies",
                        principalColumn: "UserFamilyId",
                        onDelete: ReferentialAction.NoAction);
                });

            migrationBuilder.CreateTable(
                name: "UserFamilyChronicDiseases",
                columns: table => new
                {
                    UserFamilyChronicDiseaseId = table.Column<long>(type: "bigint", nullable: false)
                        .Annotation("SqlServer:Identity", "1, 1"),
                    UserFamilyId = table.Column<long>(type: "bigint", nullable: false),
                    ChronicDiseaseId = table.Column<int>(type: "int", nullable: false),
                    Deleted = table.Column<bool>(type: "bit", nullable: false)
                },
                constraints: table =>
                {
                    table.PrimaryKey("PK_UserFamilyChronicDiseases", x => x.UserFamilyChronicDiseaseId);
                    table.ForeignKey(
                        name: "FK_UserFamilyChronicDiseases_ChronicDiseases_ChronicDiseaseId",
                        column: x => x.ChronicDiseaseId,
                        principalTable: "ChronicDiseases",
                        principalColumn: "ChronicDiseaseId",
                        onDelete: ReferentialAction.Cascade);
                    table.ForeignKey(
                        name: "FK_UserFamilyChronicDiseases_UserFamilies_UserFamilyId",
                        column: x => x.UserFamilyId,
                        principalTable: "UserFamilies",
                        principalColumn: "UserFamilyId",
                        onDelete: ReferentialAction.NoAction);
                });

            migrationBuilder.CreateTable(
                name: "UserFamilyCurrentMedications",
                columns: table => new
                {
                    UserFamilyCurrentMedicationId = table.Column<long>(type: "bigint", nullable: false)
                        .Annotation("SqlServer:Identity", "1, 1"),
                    UserFamilyId = table.Column<long>(type: "bigint", nullable: false),
                    MedicationId = table.Column<int>(type: "int", nullable: false),
                    Deleted = table.Column<bool>(type: "bit", nullable: false)
                },
                constraints: table =>
                {
                    table.PrimaryKey("PK_UserFamilyCurrentMedications", x => x.UserFamilyCurrentMedicationId);
                    table.ForeignKey(
                        name: "FK_UserFamilyCurrentMedications_Medications_MedicationId",
                        column: x => x.MedicationId,
                        principalTable: "Medications",
                        principalColumn: "MedicationId",
                        onDelete: ReferentialAction.NoAction);
                    table.ForeignKey(
                        name: "FK_UserFamilyCurrentMedications_UserFamilies_UserFamilyId",
                        column: x => x.UserFamilyId,
                        principalTable: "UserFamilies",
                        principalColumn: "UserFamilyId",
                        onDelete: ReferentialAction.NoAction);
                });

            migrationBuilder.CreateTable(
                name: "UserFamilyInjuries",
                columns: table => new
                {
                    UserFamilyInjuryId = table.Column<long>(type: "bigint", nullable: false)
                        .Annotation("SqlServer:Identity", "1, 1"),
                    UserFamilyId = table.Column<long>(type: "bigint", nullable: false),
                    InjuryId = table.Column<int>(type: "int", nullable: false),
                    Deleted = table.Column<bool>(type: "bit", nullable: false)
                },
                constraints: table =>
                {
                    table.PrimaryKey("PK_UserFamilyInjuries", x => x.UserFamilyInjuryId);
                    table.ForeignKey(
                        name: "FK_UserFamilyInjuries_Injuries_InjuryId",
                        column: x => x.InjuryId,
                        principalTable: "Injuries",
                        principalColumn: "InjuryId",
                        onDelete: ReferentialAction.NoAction);
                    table.ForeignKey(
                        name: "FK_UserFamilyInjuries_UserFamilies_UserFamilyId",
                        column: x => x.UserFamilyId,
                        principalTable: "UserFamilies",
                        principalColumn: "UserFamilyId",
                        onDelete: ReferentialAction.NoAction);
                });

            migrationBuilder.CreateTable(
                name: "UserFamilyPastMedications",
                columns: table => new
                {
                    UserFamilyPastMedicationId = table.Column<long>(type: "bigint", nullable: false)
                        .Annotation("SqlServer:Identity", "1, 1"),
                    UserFamilyId = table.Column<long>(type: "bigint", nullable: false),
                    MedicationId = table.Column<int>(type: "int", nullable: false),
                    Deleted = table.Column<bool>(type: "bit", nullable: false)
                },
                constraints: table =>
                {
                    table.PrimaryKey("PK_UserFamilyPastMedications", x => x.UserFamilyPastMedicationId);
                    table.ForeignKey(
                        name: "FK_UserFamilyPastMedications_Medications_MedicationId",
                        column: x => x.MedicationId,
                        principalTable: "Medications",
                        principalColumn: "MedicationId",
                        onDelete: ReferentialAction.NoAction);
                    table.ForeignKey(
                        name: "FK_UserFamilyPastMedications_UserFamilies_UserFamilyId",
                        column: x => x.UserFamilyId,
                        principalTable: "UserFamilies",
                        principalColumn: "UserFamilyId",
                        onDelete: ReferentialAction.NoAction);
                });

            migrationBuilder.CreateTable(
                name: "UserFamilySurgeries",
                columns: table => new
                {
                    UserFamilySurgeryId = table.Column<long>(type: "bigint", nullable: false)
                        .Annotation("SqlServer:Identity", "1, 1"),
                    UserFamilyId = table.Column<long>(type: "bigint", nullable: false),
                    SurgeryId = table.Column<int>(type: "int", nullable: false),
                    Deleted = table.Column<bool>(type: "bit", nullable: false)
                },
                constraints: table =>
                {
                    table.PrimaryKey("PK_UserFamilySurgeries", x => x.UserFamilySurgeryId);
                    table.ForeignKey(
                        name: "FK_UserFamilySurgeries_Surgeries_SurgeryId",
                        column: x => x.SurgeryId,
                        principalTable: "Surgeries",
                        principalColumn: "SurgeryId",
                        onDelete: ReferentialAction.NoAction);
                    table.ForeignKey(
                        name: "FK_UserFamilySurgeries_UserFamilies_UserFamilyId",
                        column: x => x.UserFamilyId,
                        principalTable: "UserFamilies",
                        principalColumn: "UserFamilyId",
                        onDelete: ReferentialAction.NoAction);
                });

            migrationBuilder.CreateIndex(
                name: "IX_UserFamilyAllergies_AllergyId",
                table: "UserFamilyAllergies",
                column: "AllergyId");

            migrationBuilder.CreateIndex(
                name: "IX_UserFamilyAllergies_UserFamilyId",
                table: "UserFamilyAllergies",
                column: "UserFamilyId");

            migrationBuilder.CreateIndex(
                name: "IX_UserFamilyChronicDiseases_ChronicDiseaseId",
                table: "UserFamilyChronicDiseases",
                column: "ChronicDiseaseId");

            migrationBuilder.CreateIndex(
                name: "IX_UserFamilyChronicDiseases_UserFamilyId",
                table: "UserFamilyChronicDiseases",
                column: "UserFamilyId");

            migrationBuilder.CreateIndex(
                name: "IX_UserFamilyCurrentMedications_MedicationId",
                table: "UserFamilyCurrentMedications",
                column: "MedicationId");

            migrationBuilder.CreateIndex(
                name: "IX_UserFamilyCurrentMedications_UserFamilyId",
                table: "UserFamilyCurrentMedications",
                column: "UserFamilyId");

            migrationBuilder.CreateIndex(
                name: "IX_UserFamilyInjuries_InjuryId",
                table: "UserFamilyInjuries",
                column: "InjuryId");

            migrationBuilder.CreateIndex(
                name: "IX_UserFamilyInjuries_UserFamilyId",
                table: "UserFamilyInjuries",
                column: "UserFamilyId");

            migrationBuilder.CreateIndex(
                name: "IX_UserFamilyPastMedications_MedicationId",
                table: "UserFamilyPastMedications",
                column: "MedicationId");

            migrationBuilder.CreateIndex(
                name: "IX_UserFamilyPastMedications_UserFamilyId",
                table: "UserFamilyPastMedications",
                column: "UserFamilyId");

            migrationBuilder.CreateIndex(
                name: "IX_UserFamilySurgeries_SurgeryId",
                table: "UserFamilySurgeries",
                column: "SurgeryId");

            migrationBuilder.CreateIndex(
                name: "IX_UserFamilySurgeries_UserFamilyId",
                table: "UserFamilySurgeries",
                column: "UserFamilyId");
        }

        protected override void Down(MigrationBuilder migrationBuilder)
        {
            migrationBuilder.DropTable(
                name: "UserFamilyAllergies");

            migrationBuilder.DropTable(
                name: "UserFamilyChronicDiseases");

            migrationBuilder.DropTable(
                name: "UserFamilyCurrentMedications");

            migrationBuilder.DropTable(
                name: "UserFamilyInjuries");

            migrationBuilder.DropTable(
                name: "UserFamilyPastMedications");

            migrationBuilder.DropTable(
                name: "UserFamilySurgeries");

            migrationBuilder.CreateTable(
                name: "VisitAllergies",
                columns: table => new
                {
                    VisitAllergyId = table.Column<long>(type: "bigint", nullable: false)
                        .Annotation("SqlServer:Identity", "1, 1"),
                    AllergyId = table.Column<int>(type: "int", nullable: false),
                    VisitDetailsId = table.Column<long>(type: "bigint", nullable: false),
                    Deleted = table.Column<bool>(type: "bit", nullable: false)
                },
                constraints: table =>
                {
                    table.PrimaryKey("PK_VisitAllergies", x => x.VisitAllergyId);
                    table.ForeignKey(
                        name: "FK_VisitAllergies_Allergies_AllergyId",
                        column: x => x.AllergyId,
                        principalTable: "Allergies",
                        principalColumn: "AllergyId",
                        onDelete: ReferentialAction.Cascade);
                    table.ForeignKey(
                        name: "FK_VisitAllergies_VisitDetails_VisitDetailsId",
                        column: x => x.VisitDetailsId,
                        principalTable: "VisitDetails",
                        principalColumn: "VisitDetailsId",
                        onDelete: ReferentialAction.Cascade);
                });

            migrationBuilder.CreateTable(
                name: "VisitChronicDiseases",
                columns: table => new
                {
                    VisitChronicDiseaseId = table.Column<long>(type: "bigint", nullable: false)
                        .Annotation("SqlServer:Identity", "1, 1"),
                    ChronicDiseaseId = table.Column<int>(type: "int", nullable: false),
                    VisitDetailsId = table.Column<long>(type: "bigint", nullable: false),
                    Deleted = table.Column<bool>(type: "bit", nullable: false)
                },
                constraints: table =>
                {
                    table.PrimaryKey("PK_VisitChronicDiseases", x => x.VisitChronicDiseaseId);
                    table.ForeignKey(
                        name: "FK_VisitChronicDiseases_ChronicDiseases_ChronicDiseaseId",
                        column: x => x.ChronicDiseaseId,
                        principalTable: "ChronicDiseases",
                        principalColumn: "ChronicDiseaseId",
                        onDelete: ReferentialAction.Cascade);
                    table.ForeignKey(
                        name: "FK_VisitChronicDiseases_VisitDetails_VisitDetailsId",
                        column: x => x.VisitDetailsId,
                        principalTable: "VisitDetails",
                        principalColumn: "VisitDetailsId",
                        onDelete: ReferentialAction.Cascade);
                });

            migrationBuilder.CreateTable(
                name: "VisitCurrentMedications",
                columns: table => new
                {
                    VisitCurrentMedicationId = table.Column<long>(type: "bigint", nullable: false)
                        .Annotation("SqlServer:Identity", "1, 1"),
                    MedicationId = table.Column<int>(type: "int", nullable: false),
                    VisitDetailsId = table.Column<long>(type: "bigint", nullable: false),
                    Deleted = table.Column<bool>(type: "bit", nullable: false)
                },
                constraints: table =>
                {
                    table.PrimaryKey("PK_VisitCurrentMedications", x => x.VisitCurrentMedicationId);
                    table.ForeignKey(
                        name: "FK_VisitCurrentMedications_Medications_MedicationId",
                        column: x => x.MedicationId,
                        principalTable: "Medications",
                        principalColumn: "MedicationId",
                        onDelete: ReferentialAction.Cascade);
                    table.ForeignKey(
                        name: "FK_VisitCurrentMedications_VisitDetails_VisitDetailsId",
                        column: x => x.VisitDetailsId,
                        principalTable: "VisitDetails",
                        principalColumn: "VisitDetailsId",
                        onDelete: ReferentialAction.Cascade);
                });

            migrationBuilder.CreateTable(
                name: "VisitInjuries",
                columns: table => new
                {
                    VisitInjuryId = table.Column<long>(type: "bigint", nullable: false)
                        .Annotation("SqlServer:Identity", "1, 1"),
                    InjuryId = table.Column<int>(type: "int", nullable: false),
                    VisitDetailsId = table.Column<long>(type: "bigint", nullable: false),
                    Deleted = table.Column<bool>(type: "bit", nullable: false)
                },
                constraints: table =>
                {
                    table.PrimaryKey("PK_VisitInjuries", x => x.VisitInjuryId);
                    table.ForeignKey(
                        name: "FK_VisitInjuries_Injuries_InjuryId",
                        column: x => x.InjuryId,
                        principalTable: "Injuries",
                        principalColumn: "InjuryId",
                        onDelete: ReferentialAction.Cascade);
                    table.ForeignKey(
                        name: "FK_VisitInjuries_VisitDetails_VisitDetailsId",
                        column: x => x.VisitDetailsId,
                        principalTable: "VisitDetails",
                        principalColumn: "VisitDetailsId",
                        onDelete: ReferentialAction.Cascade);
                });

            migrationBuilder.CreateTable(
                name: "VisitPastMedications",
                columns: table => new
                {
                    VisitPastMedicationId = table.Column<long>(type: "bigint", nullable: false)
                        .Annotation("SqlServer:Identity", "1, 1"),
                    MedicationId = table.Column<int>(type: "int", nullable: false),
                    VisitDetailsId = table.Column<long>(type: "bigint", nullable: false),
                    Deleted = table.Column<bool>(type: "bit", nullable: false)
                },
                constraints: table =>
                {
                    table.PrimaryKey("PK_VisitPastMedications", x => x.VisitPastMedicationId);
                    table.ForeignKey(
                        name: "FK_VisitPastMedications_Medications_MedicationId",
                        column: x => x.MedicationId,
                        principalTable: "Medications",
                        principalColumn: "MedicationId",
                        onDelete: ReferentialAction.Cascade);
                    table.ForeignKey(
                        name: "FK_VisitPastMedications_VisitDetails_VisitDetailsId",
                        column: x => x.VisitDetailsId,
                        principalTable: "VisitDetails",
                        principalColumn: "VisitDetailsId",
                        onDelete: ReferentialAction.Cascade);
                });

            migrationBuilder.CreateTable(
                name: "VisitSurgeries",
                columns: table => new
                {
                    VisitSurgeryId = table.Column<long>(type: "bigint", nullable: false)
                        .Annotation("SqlServer:Identity", "1, 1"),
                    SurgeryId = table.Column<int>(type: "int", nullable: false),
                    VisitDetailsId = table.Column<long>(type: "bigint", nullable: false),
                    Deleted = table.Column<bool>(type: "bit", nullable: false)
                },
                constraints: table =>
                {
                    table.PrimaryKey("PK_VisitSurgeries", x => x.VisitSurgeryId);
                    table.ForeignKey(
                        name: "FK_VisitSurgeries_Surgeries_SurgeryId",
                        column: x => x.SurgeryId,
                        principalTable: "Surgeries",
                        principalColumn: "SurgeryId",
                        onDelete: ReferentialAction.Cascade);
                    table.ForeignKey(
                        name: "FK_VisitSurgeries_VisitDetails_VisitDetailsId",
                        column: x => x.VisitDetailsId,
                        principalTable: "VisitDetails",
                        principalColumn: "VisitDetailsId",
                        onDelete: ReferentialAction.Cascade);
                });

            migrationBuilder.CreateIndex(
                name: "IX_VisitAllergies_AllergyId",
                table: "VisitAllergies",
                column: "AllergyId");

            migrationBuilder.CreateIndex(
                name: "IX_VisitAllergies_VisitDetailsId",
                table: "VisitAllergies",
                column: "VisitDetailsId");

            migrationBuilder.CreateIndex(
                name: "IX_VisitChronicDiseases_ChronicDiseaseId",
                table: "VisitChronicDiseases",
                column: "ChronicDiseaseId");

            migrationBuilder.CreateIndex(
                name: "IX_VisitChronicDiseases_VisitDetailsId",
                table: "VisitChronicDiseases",
                column: "VisitDetailsId");

            migrationBuilder.CreateIndex(
                name: "IX_VisitCurrentMedications_MedicationId",
                table: "VisitCurrentMedications",
                column: "MedicationId");

            migrationBuilder.CreateIndex(
                name: "IX_VisitCurrentMedications_VisitDetailsId",
                table: "VisitCurrentMedications",
                column: "VisitDetailsId");

            migrationBuilder.CreateIndex(
                name: "IX_VisitInjuries_InjuryId",
                table: "VisitInjuries",
                column: "InjuryId");

            migrationBuilder.CreateIndex(
                name: "IX_VisitInjuries_VisitDetailsId",
                table: "VisitInjuries",
                column: "VisitDetailsId");

            migrationBuilder.CreateIndex(
                name: "IX_VisitPastMedications_MedicationId",
                table: "VisitPastMedications",
                column: "MedicationId");

            migrationBuilder.CreateIndex(
                name: "IX_VisitPastMedications_VisitDetailsId",
                table: "VisitPastMedications",
                column: "VisitDetailsId");

            migrationBuilder.CreateIndex(
                name: "IX_VisitSurgeries_SurgeryId",
                table: "VisitSurgeries",
                column: "SurgeryId");

            migrationBuilder.CreateIndex(
                name: "IX_VisitSurgeries_VisitDetailsId",
                table: "VisitSurgeries",
                column: "VisitDetailsId");
        }
    }
}
