﻿using Microsoft.EntityFrameworkCore.Migrations;

#nullable disable

namespace YabraaEF.Migrations
{
    public partial class updatePatiProfile : Migration
    {
        protected override void Up(MigrationBuilder migrationBuilder)
        {
            migrationBuilder.CreateTable(
                name: "Allergies",
                columns: table => new
                {
                    AllergyId = table.Column<int>(type: "int", nullable: false)
                        .Annotation("SqlServer:Identity", "1, 1"),
                    TitleEN = table.Column<string>(type: "nvarchar(max)", nullable: false),
                    TitleAR = table.Column<string>(type: "nvarchar(max)", nullable: false),
                    Deleted = table.Column<bool>(type: "bit", nullable: false)
                },
                constraints: table =>
                {
                    table.PrimaryKey("PK_Allergies", x => x.AllergyId);
                });

            migrationBuilder.CreateTable(
                name: "ChronicDiseases",
                columns: table => new
                {
                    ChronicDiseaseId = table.Column<int>(type: "int", nullable: false)
                        .Annotation("SqlServer:Identity", "1, 1"),
                    TitleEN = table.Column<string>(type: "nvarchar(max)", nullable: false),
                    TitleAR = table.Column<string>(type: "nvarchar(max)", nullable: false),
                    Deleted = table.Column<bool>(type: "bit", nullable: false)
                },
                constraints: table =>
                {
                    table.PrimaryKey("PK_ChronicDiseases", x => x.ChronicDiseaseId);
                });

            migrationBuilder.CreateTable(
                name: "Injuries",
                columns: table => new
                {
                    InjuryId = table.Column<int>(type: "int", nullable: false)
                        .Annotation("SqlServer:Identity", "1, 1"),
                    TitleEN = table.Column<string>(type: "nvarchar(max)", nullable: false),
                    TitleAR = table.Column<string>(type: "nvarchar(max)", nullable: false),
                    Deleted = table.Column<bool>(type: "bit", nullable: false)
                },
                constraints: table =>
                {
                    table.PrimaryKey("PK_Injuries", x => x.InjuryId);
                });

            migrationBuilder.CreateTable(
                name: "Medications",
                columns: table => new
                {
                    MedicationId = table.Column<int>(type: "int", nullable: false)
                        .Annotation("SqlServer:Identity", "1, 1"),
                    TitleEN = table.Column<string>(type: "nvarchar(max)", nullable: false),
                    TitleAR = table.Column<string>(type: "nvarchar(max)", nullable: false),
                    Deleted = table.Column<bool>(type: "bit", nullable: false)
                },
                constraints: table =>
                {
                    table.PrimaryKey("PK_Medications", x => x.MedicationId);
                });

            migrationBuilder.CreateTable(
                name: "Surgeries",
                columns: table => new
                {
                    SurgeryId = table.Column<int>(type: "int", nullable: false)
                        .Annotation("SqlServer:Identity", "1, 1"),
                    TitleEN = table.Column<string>(type: "nvarchar(max)", nullable: false),
                    TitleAR = table.Column<string>(type: "nvarchar(max)", nullable: false),
                    Deleted = table.Column<bool>(type: "bit", nullable: false)
                },
                constraints: table =>
                {
                    table.PrimaryKey("PK_Surgeries", x => x.SurgeryId);
                });

            migrationBuilder.CreateTable(
                name: "VisitAllergies",
                columns: table => new
                {
                    VisitAllergyId = table.Column<long>(type: "bigint", nullable: false)
                        .Annotation("SqlServer:Identity", "1, 1"),
                    VisitDetailsId = table.Column<long>(type: "bigint", nullable: false),
                    AllergyId = table.Column<int>(type: "int", nullable: false),
                    Deleted = table.Column<bool>(type: "bit", nullable: false)
                },
                constraints: table =>
                {
                    table.PrimaryKey("PK_VisitAllergies", x => x.VisitAllergyId);
                    table.ForeignKey(
                        name: "FK_VisitAllergies_Allergies_AllergyId",
                        column: x => x.AllergyId,
                        principalTable: "Allergies",
                        principalColumn: "AllergyId",
                        onDelete: ReferentialAction.NoAction);
                    table.ForeignKey(
                        name: "FK_VisitAllergies_VisitDetails_VisitDetailsId",
                        column: x => x.VisitDetailsId,
                        principalTable: "VisitDetails",
                        principalColumn: "VisitDetailsId",
                        onDelete: ReferentialAction.NoAction);
                });

            migrationBuilder.CreateTable(
                name: "VisitChronicDiseases",
                columns: table => new
                {
                    VisitChronicDiseaseId = table.Column<long>(type: "bigint", nullable: false)
                        .Annotation("SqlServer:Identity", "1, 1"),
                    VisitDetailsId = table.Column<long>(type: "bigint", nullable: false),
                    ChronicDiseaseId = table.Column<int>(type: "int", nullable: false),
                    Deleted = table.Column<bool>(type: "bit", nullable: false)
                },
                constraints: table =>
                {
                    table.PrimaryKey("PK_VisitChronicDiseases", x => x.VisitChronicDiseaseId);
                    table.ForeignKey(
                        name: "FK_VisitChronicDiseases_ChronicDiseases_ChronicDiseaseId",
                        column: x => x.ChronicDiseaseId,
                        principalTable: "ChronicDiseases",
                        principalColumn: "ChronicDiseaseId",
                        onDelete: ReferentialAction.NoAction);
                    table.ForeignKey(
                        name: "FK_VisitChronicDiseases_VisitDetails_VisitDetailsId",
                        column: x => x.VisitDetailsId,
                        principalTable: "VisitDetails",
                        principalColumn: "VisitDetailsId",
                        onDelete: ReferentialAction.NoAction);
                });

            migrationBuilder.CreateTable(
                name: "VisitInjuries",
                columns: table => new
                {
                    VisitInjuryId = table.Column<long>(type: "bigint", nullable: false)
                        .Annotation("SqlServer:Identity", "1, 1"),
                    VisitDetailsId = table.Column<long>(type: "bigint", nullable: false),
                    InjuryId = table.Column<int>(type: "int", nullable: false),
                    Deleted = table.Column<bool>(type: "bit", nullable: false)
                },
                constraints: table =>
                {
                    table.PrimaryKey("PK_VisitInjuries", x => x.VisitInjuryId);
                    table.ForeignKey(
                        name: "FK_VisitInjuries_Injuries_InjuryId",
                        column: x => x.InjuryId,
                        principalTable: "Injuries",
                        principalColumn: "InjuryId",
                        onDelete: ReferentialAction.NoAction);
                    table.ForeignKey(
                        name: "FK_VisitInjuries_VisitDetails_VisitDetailsId",
                        column: x => x.VisitDetailsId,
                        principalTable: "VisitDetails",
                        principalColumn: "VisitDetailsId",
                        onDelete: ReferentialAction.NoAction);
                });

            migrationBuilder.CreateTable(
                name: "VisitCurrentMedications",
                columns: table => new
                {
                    VisitCurrentMedicationId = table.Column<long>(type: "bigint", nullable: false)
                        .Annotation("SqlServer:Identity", "1, 1"),
                    VisitDetailsId = table.Column<long>(type: "bigint", nullable: false),
                    MedicationId = table.Column<int>(type: "int", nullable: false),
                    Deleted = table.Column<bool>(type: "bit", nullable: false)
                },
                constraints: table =>
                {
                    table.PrimaryKey("PK_VisitCurrentMedications", x => x.VisitCurrentMedicationId);
                    table.ForeignKey(
                        name: "FK_VisitCurrentMedications_Medications_MedicationId",
                        column: x => x.MedicationId,
                        principalTable: "Medications",
                        principalColumn: "MedicationId",
                        onDelete: ReferentialAction.NoAction);
                    table.ForeignKey(
                        name: "FK_VisitCurrentMedications_VisitDetails_VisitDetailsId",
                        column: x => x.VisitDetailsId,
                        principalTable: "VisitDetails",
                        principalColumn: "VisitDetailsId",
                        onDelete: ReferentialAction.NoAction);
                });

            migrationBuilder.CreateTable(
                name: "VisitPastMedications",
                columns: table => new
                {
                    VisitPastMedicationId = table.Column<long>(type: "bigint", nullable: false)
                        .Annotation("SqlServer:Identity", "1, 1"),
                    VisitDetailsId = table.Column<long>(type: "bigint", nullable: false),
                    MedicationId = table.Column<int>(type: "int", nullable: false),
                    Deleted = table.Column<bool>(type: "bit", nullable: false)
                },
                constraints: table =>
                {
                    table.PrimaryKey("PK_VisitPastMedications", x => x.VisitPastMedicationId);
                    table.ForeignKey(
                        name: "FK_VisitPastMedications_Medications_MedicationId",
                        column: x => x.MedicationId,
                        principalTable: "Medications",
                        principalColumn: "MedicationId",
                        onDelete: ReferentialAction.NoAction);
                    table.ForeignKey(
                        name: "FK_VisitPastMedications_VisitDetails_VisitDetailsId",
                        column: x => x.VisitDetailsId,
                        principalTable: "VisitDetails",
                        principalColumn: "VisitDetailsId",
                        onDelete: ReferentialAction.NoAction);
                });

            migrationBuilder.CreateTable(
                name: "VisitSurgeries",
                columns: table => new
                {
                    VisitSurgeryId = table.Column<long>(type: "bigint", nullable: false)
                        .Annotation("SqlServer:Identity", "1, 1"),
                    VisitDetailsId = table.Column<long>(type: "bigint", nullable: false),
                    SurgeryId = table.Column<int>(type: "int", nullable: false),
                    Deleted = table.Column<bool>(type: "bit", nullable: false)
                },
                constraints: table =>
                {
                    table.PrimaryKey("PK_VisitSurgeries", x => x.VisitSurgeryId);
                    table.ForeignKey(
                        name: "FK_VisitSurgeries_Surgeries_SurgeryId",
                        column: x => x.SurgeryId,
                        principalTable: "Surgeries",
                        principalColumn: "SurgeryId",
                        onDelete: ReferentialAction.NoAction);
                    table.ForeignKey(
                        name: "FK_VisitSurgeries_VisitDetails_VisitDetailsId",
                        column: x => x.VisitDetailsId,
                        principalTable: "VisitDetails",
                        principalColumn: "VisitDetailsId",
                        onDelete: ReferentialAction.NoAction);
                });

            migrationBuilder.CreateIndex(
                name: "IX_VisitAllergies_AllergyId",
                table: "VisitAllergies",
                column: "AllergyId");

            migrationBuilder.CreateIndex(
                name: "IX_VisitAllergies_VisitDetailsId",
                table: "VisitAllergies",
                column: "VisitDetailsId");

            migrationBuilder.CreateIndex(
                name: "IX_VisitChronicDiseases_ChronicDiseaseId",
                table: "VisitChronicDiseases",
                column: "ChronicDiseaseId");

            migrationBuilder.CreateIndex(
                name: "IX_VisitChronicDiseases_VisitDetailsId",
                table: "VisitChronicDiseases",
                column: "VisitDetailsId");

            migrationBuilder.CreateIndex(
                name: "IX_VisitCurrentMedications_MedicationId",
                table: "VisitCurrentMedications",
                column: "MedicationId");

            migrationBuilder.CreateIndex(
                name: "IX_VisitCurrentMedications_VisitDetailsId",
                table: "VisitCurrentMedications",
                column: "VisitDetailsId");

            migrationBuilder.CreateIndex(
                name: "IX_VisitInjuries_InjuryId",
                table: "VisitInjuries",
                column: "InjuryId");

            migrationBuilder.CreateIndex(
                name: "IX_VisitInjuries_VisitDetailsId",
                table: "VisitInjuries",
                column: "VisitDetailsId");

            migrationBuilder.CreateIndex(
                name: "IX_VisitPastMedications_MedicationId",
                table: "VisitPastMedications",
                column: "MedicationId");

            migrationBuilder.CreateIndex(
                name: "IX_VisitPastMedications_VisitDetailsId",
                table: "VisitPastMedications",
                column: "VisitDetailsId");

            migrationBuilder.CreateIndex(
                name: "IX_VisitSurgeries_SurgeryId",
                table: "VisitSurgeries",
                column: "SurgeryId");

            migrationBuilder.CreateIndex(
                name: "IX_VisitSurgeries_VisitDetailsId",
                table: "VisitSurgeries",
                column: "VisitDetailsId");
        }

        protected override void Down(MigrationBuilder migrationBuilder)
        {
            migrationBuilder.DropTable(
                name: "VisitAllergies");

            migrationBuilder.DropTable(
                name: "VisitChronicDiseases");

            migrationBuilder.DropTable(
                name: "VisitCurrentMedications");

            migrationBuilder.DropTable(
                name: "VisitInjuries");

            migrationBuilder.DropTable(
                name: "VisitPastMedications");

            migrationBuilder.DropTable(
                name: "VisitSurgeries");

            migrationBuilder.DropTable(
                name: "Allergies");

            migrationBuilder.DropTable(
                name: "ChronicDiseases");

            migrationBuilder.DropTable(
                name: "Injuries");

            migrationBuilder.DropTable(
                name: "Medications");

            migrationBuilder.DropTable(
                name: "Surgeries");
        }
    }
}
