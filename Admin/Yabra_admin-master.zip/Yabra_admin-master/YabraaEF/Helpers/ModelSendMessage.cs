﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace YabraaEF.Helpers
{
    public class ModelSendMessage
    {
        public string RegistrationToken { get; set; }
        public string TitleEn { get; set; }
        public string TitleAr { get; set; }
        public string BodyEn { get; set; }
        public string BodyAr { get; set; }
        public int NotificationTypeId { get; set; }
        public string UserId  { get; set; }
    }
}
