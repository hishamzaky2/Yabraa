﻿using Microsoft.AspNetCore.Mvc;
using Microsoft.EntityFrameworkCore;
using Microsoft.EntityFrameworkCore.Storage.Internal;
using Newtonsoft.Json;
using Org.BouncyCastle.Asn1.Ocsp;
using Org.BouncyCastle.Crypto.Macs;
using System.Collections.Generic;
using System.ComponentModel.DataAnnotations;
using System.Globalization;
using System.Net;
using System.Runtime.Serialization;
using System.Security.Claims;
using System.Text;
using System.Text.RegularExpressions;
using Yabraa.DTOs;
using Yabraa.Helpers;
using YabraaEF;
using YabraaEF.Const;
using YabraaEF.Helpers;
using YabraaEF.Models;
using YabraaEF.Services;
using static System.Net.WebRequestMethods;

namespace Yabraa.Services
{
    public class PaymentService
    {
        private ApplicationDbContext _context;
        private readonly IConfiguration _configuration;
        private SmsSender _SmsSender;
        private Firebase _Firebase;        
        public PaymentService(ApplicationDbContext dbContext, IConfiguration configuration, SmsSender smsSender, Firebase Firebase)
        {

            _context = dbContext;
            _configuration = configuration;
            _SmsSender = smsSender;
             _Firebase = Firebase;
        }
        public async Task<string> Payment(PaymentDto paymentDto, string userId,decimal amount, string currency, string paymentType)
        {
            DateTime dateTime = General.GetKSATimeZoneNow();
            var status = _context.VisitStatuses.FirstOrDefault(c => c.Name.Contains("Pending"));
          
            if ( !string.IsNullOrWhiteSpace(userId) && status is not null)
            {
                    Invoice invoice = new Invoice()
                    {
                        CreateDT = dateTime,
                        LocationAltitude = paymentDto.locationAltitude,
                        LocationLongitude = paymentDto.locationLongitude,
                        LocationLatitude = paymentDto.locationLatitude,
                        PaymentMethodId = paymentDto.PaymentMethodId,
                        UserId = userId,
                        TotalPrice = paymentDto.amount,
                      //  CheckoutId = checkoutId,    
                    };
                    _context.Invoices.Add(invoice);
                    //_context.SaveChanges();
                    foreach (var package in paymentDto.packages)
                    {
                        InvoiceDetails invoiceDetails = new InvoiceDetails()
                        {
                            Count = 1,
                            InvoiceId = invoice.InvoiceId,
                            Invoice = invoice,
                            PackageId = package.packageId,
                            Price = package.price,

                        };
                        _context.InvoiceDetails.Add(invoiceDetails);
                        var serviceTypeId = _context.Packages.Where(c => c.PackageId == package.packageId).Include(c => c.Service).FirstOrDefault()?.Service.ServiceTypeId;
                        //_context.SaveChanges();
                        VisitDetails visitDetails = new VisitDetails()
                        {
                            ApplicationUserId = userId,
                            PackageId = package.packageId,
                            InvoiceDetailsId = invoiceDetails.InvoiceDetailsId,
                            InvoiceDetails = invoiceDetails,
                            LocationAltitude = paymentDto.locationAltitude,
                            LocationLongitude = paymentDto.locationLongitude,
                            LocationLatitude = paymentDto.locationLatitude,
                            UserFamilyId = package.userFamilyId,
                            Notes = package.notes,
                            VisitDT = package.dateTime,
                            VisitStatusId = status.VisitStatusId,
                            ServiceTypeId = serviceTypeId.Value

                        };
                        _context.VisitDetails.Add(visitDetails);
                        //_context.SaveChanges();
                        //invoiceDetails.VisitDetails.Add(visitDetails);
                        //invoice.InvoiceDetails.Add(invoiceDetails);
                    
				    }

                    //_context.Invoices.Add(invoice);
                    int statusOperation = _context.SaveChanges();
                    if (statusOperation > 0)
                    {
                         var checkout = GetCheckoutId(amount, currency, paymentType, invoice.InvoiceId, paymentDto.PaymentMethodId, userId);
                        // var checkout = GetCheckoutIdTest(amount, currency, paymentType,invoice.InvoiceId,paymentDto.PaymentMethodId,userId);
                        if (checkout != null && checkout.Count > 0)
                        {
                            string checkoutId = checkout["id"];
                            invoice.CheckoutId=checkoutId;
                            _context.SaveChanges();
                            return checkoutId;
                        }
                      
                    }             
            }

            return null;
        }
        string getentityId( int PaymentMethodId)
        {
          var PaymentMethod =  _context.PaymentMethods.FirstOrDefault(c => c.PaymentMethodId == PaymentMethodId);
            if (PaymentMethod != null)
            {
                if (PaymentMethod.NameEN== "Apple_Pay")
                {
                    return "8ac9a4cc8bae2959018be678ef2b669f";
                }
                else if (PaymentMethod.NameEN == "VISA" || PaymentMethod.NameEN == "MASTER" || PaymentMethod.NameEN == "STC")
                {
                    return "8ac9a4ce8b425f29018b573643cb5801";
                            
                }                
                else if (PaymentMethod.NameEN == "MADA")
                {
                    return "8ac9a4ce8b425f29018b5736d3855808";
                }
            }
            return null;
        }
        public Dictionary<string, dynamic> GetCheckoutId(decimal amount, string currency, string paymentType, long invoiceId, int PaymentMethodId, string userId)
        {
            Dictionary<string, dynamic> responseData;
            var user = _context.Users.FirstOrDefault(c => c.Id == userId);
            string email = "yabraa@yabraa.com";
            string frstName = "yabraa";
            string lastName = "yabraa";
            if (user is not null)
            {

                if (!string.IsNullOrEmpty(user.Email))
                {
                    email = user.Email;
                }
                if (!string.IsNullOrEmpty(user.FirstName))
                {
                    frstName = user.FirstName;
                }
                if (!string.IsNullOrEmpty(user.LastName))
                {
                    lastName = user.LastName;
                }


            }
            string entityId = getentityId(PaymentMethodId);// return identityId  based on PaymentMethod

            //string data =
            //    $"entityId={entityId}" +
            //    $"&amount={string.Format("{0:F2}", amount)}" +
            //    $"&currency=SAR" +
            //    $"&paymentType=DB" +
            //    $"&merchantTransactionId={invoiceId}"+            
            //    $"&customer.email={email}" +
            //    $"&billing.street1=KingFahdRoad" +
            //    $"&billing.city=Dammam" +
            //    $"&billing.state=Dammam" +
            //    $"&billing.country=SaudiArabia" +
            //    $"&billing.postcode=34325" +
            //    $"&customer.givenName={frstName}" +
            //    $"&customer.surname={lastName}";

            string data = $"entityId={entityId}" +
                            $"&amount={amount.ToString("0.00", CultureInfo.InvariantCulture)}" +
                            "&currency=SAR" +
                            "&paymentType=DB" +
                            $"&merchantTransactionId={invoiceId}" +
                            $"&customer.email={email}" +
                            "&billing.street1=test" +
                            "&billing.city=Riyadh" +
                            "&billing.state=test" +
                            "&billing.country=SA" +
                            "&billing.postcode=12345" +
                            $"&customer.givenName={frstName}" +
                            $"&customer.surname={lastName}";
           
            string url = "https://eu-prod.oppwa.com/v1/checkouts";

            byte[] buffer = Encoding.ASCII.GetBytes(data);
            HttpWebRequest request = (HttpWebRequest)HttpWebRequest.Create(url);
            request.Method = "POST";
            request.Headers["Authorization"] = "Bearer OGFjOWE0Y2U4YjQyNWYyOTAxOGI1NzM1YWIzMzU3Zjl8OXFYUHJSdHNiS0szUzVkdw==";
            
            request.ContentType = "application/x-www-form-urlencoded";
            Stream PostData = request.GetRequestStream();
            PostData.Write(buffer, 0, buffer.Length);
            PostData.Close();
            using (HttpWebResponse response = (HttpWebResponse)request.GetResponse())
            {
                HttpStatusCode statusCode = response.StatusCode;
                Console.WriteLine(statusCode);
                Stream dataStream = response.GetResponseStream();
                StreamReader reader = new StreamReader(dataStream);
                responseData = JsonConvert.DeserializeObject<Dictionary<string, dynamic>>(reader.ReadToEnd());
                reader.Close();
                dataStream.Close();
            }
            return responseData;
        }
        public  Dictionary<string, dynamic> GetCheckoutStatus(string CheckoutId, int PaymentMethodId,string FirebaseToken, string userId)
        {
            var user = _context.Users.FirstOrDefault(c => c.Id == userId);

            if (!string.IsNullOrEmpty(FirebaseToken) && user is not null)
            {              
                    user.FirebaseToken = FirebaseToken;
                    _context.SaveChanges();                
            }
            Dictionary<string, dynamic> responseData;
            string entityId = getentityId(PaymentMethodId);
            string data = $"entityId={entityId}";
            
            string url = $"https://eu-prod.oppwa.com/v1/checkouts/{CheckoutId}/payment?" + data;
            //string url = $" https://eu-prod.oppwa.com/v1/checkouts/{CheckoutId}/payment";
          
            HttpWebRequest request = (HttpWebRequest)HttpWebRequest.Create(url);
            request.Method = "GET";
            request.Headers["Authorization"] = "Bearer OGFjOWE0Y2U4YjQyNWYyOTAxOGI1NzM1YWIzMzU3Zjl8OXFYUHJSdHNiS0szUzVkdw==";
            using (HttpWebResponse response = (HttpWebResponse)request.GetResponse())
            {
                Stream dataStream = response.GetResponseStream();
                StreamReader reader = new StreamReader(dataStream);
                //var s = new JavaScriptSerializer();
                //responseData = s.Deserialize<Dictionary<string, dynamic>>(reader.ReadToEnd());
                responseData = JsonConvert.DeserializeObject<Dictionary<string, dynamic>>(reader.ReadToEnd());

                reader.Close();
                dataStream.Close();
            }

            if (responseData is not null)
            {
                string result = responseData["result"]["code"];
                string pattern = @"^(000\.000\.|000\.100\.1|000\.[36])";
                bool isMatch = Regex.IsMatch(result, pattern);
                string pattern2 = @"^(000\.400\.0[^3]|000\.400\.[0-1]{2}0)";
                bool isMatch2 = Regex.IsMatch(result, pattern2);              

                if (isMatch || isMatch2)
                {
                    var invoice = _context.Invoices.Include(c=>c.InvoiceDetails).FirstOrDefault(c => c.CheckoutId == CheckoutId);
                    string PaymentId = responseData.ContainsKey("id") ? responseData["id"] : "Empty";

                    if (invoice is not null)
                    {
                        invoice.PaymentId = PaymentId;
                        invoice.Paid = true;
                        _context.SaveChanges();
                        CultureInfo cultureInfoAR = new CultureInfo("ar");
                        CultureInfo cultureInfoEn = new CultureInfo("en-US");
                        //string formattedDateTime = now.ToString("dddd, dd MMMM yyyy hh:mm:ss tt", cultureInfo);
                        if (user is not null)
                        {
                            string messageAr = "";
                            string messageEn = "";
                            foreach (var item in invoice.InvoiceDetails)
                            {
                                messageAr = "";
                                messageEn = "";
                                var visit = _context.VisitDetails.Include(c=>c.Package).FirstOrDefault(c=>c.InvoiceDetailsId == item.InvoiceDetailsId);
                                if (visit != null)
                                {
                                    messageAr = $"تم حجز الخدمه بنجاح \n اسم الخدمه : {visit?.Package?.NameAR} \n التاريخ : {visit?.VisitDT.ToString("dddd, dd MMMM yyyy hh:mm tt", cultureInfoAR)} ";
                                    messageEn = $"The service has been booked successfully \n Package : {visit?.Package?.NameEN} \n Date : {visit?.VisitDT.ToString("dddd, dd MMMM yyyy hh:mm tt", cultureInfoEn)} ";
                                    string mesg = $"{messageAr}\n{messageEn}";

                                    var Status = _SmsSender.SendAsync(user.PhoneNumber, mesg);
                                    ModelSendMessage modelSendMessage = new ModelSendMessage()
                                    {
                                        RegistrationToken = FirebaseToken,
                                        TitleAr = $"حجز خدمة {visit?.Package?.DetailsAR}",
                                        TitleEn = $"Booking a Service {visit?.Package?.DetailsEN}",
                                        BodyAr = messageAr,
                                        BodyEn = messageEn,
                                        NotificationTypeId = 1,
                                        UserId = userId
                                    };

                                    _Firebase.SendMessage(modelSendMessage);
                                }
                               
                            }
                           
                        }
                       
                    }
                }
            }
            return responseData;
        }
        
        // TEST
        
        string getentityIdTest(int PaymentMethodId)
        {
            var PaymentMethod = _context.PaymentMethods.FirstOrDefault(c => c.PaymentMethodId == PaymentMethodId);
            if (PaymentMethod != null)
            {
                if (PaymentMethod.NameEN == "Apple_Pay")
                {
                    return "8ac7a4c889bff1b60189c946252f04be";
                }
                else if (PaymentMethod.NameEN == "VISA" || PaymentMethod.NameEN == "MASTER" || PaymentMethod.NameEN == "STC")
                {
                    return "8ac7a4c889bff1b60189c941f49d04b1";

                }
                else if (PaymentMethod.NameEN == "MADA")
                {
                    return "8ac7a4c889bff1b60189c94298a804b5";
                }
            }
            return null;
        }
        public Dictionary<string, dynamic> GetCheckoutIdTest(decimal amount, string currency, string paymentType, long invoiceId, int PaymentMethodId, string userId)
        {
            Dictionary<string, dynamic> responseData;
            var user = _context.Users.FirstOrDefault(c => c.Id == userId);
            string email = "yabraa@yabraa.com";
            string frstName = "yabraa";
            string lastName = "yabraa";
            if (user is not null)
            {

                if (!string.IsNullOrEmpty(user.Email))
                {
                    email = user.Email;
                }
                if (!string.IsNullOrEmpty(user.FirstName))
                {
                    frstName = user.FirstName;
                }
                if (!string.IsNullOrEmpty(user.LastName))
                {
                    lastName = user.LastName;
                }


            }
            string entityId = getentityIdTest(PaymentMethodId);// return identityId  based on PaymentMethod

           

            string data = $"entityId={entityId}" +
                           $"&amount={amount.ToString("0.00", CultureInfo.InvariantCulture)}" +
                            "&currency=SAR" +
                            "&paymentType=DB" +
                            $"&merchantTransactionId={invoiceId}" +
                            $"&customer.email={email}" +
                            "&billing.street1=test" +
                            "&billing.city=Riyadh" +
                            "&billing.state=test" +
                            "&billing.country=SA" +
                            "&billing.postcode=12345" +
                            $"&customer.givenName={frstName}" +
                            $"&customer.surname={lastName}"+
                            $"&customParameters[3DS2_enrolled]=true" +
                            $"&testMode=EXTERNAL" ;


            string url = "https://eu-test.oppwa.com/v1/checkouts";

            byte[] buffer = Encoding.ASCII.GetBytes(data);
            HttpWebRequest request = (HttpWebRequest)HttpWebRequest.Create(url);
            request.Method = "POST";
            request.Headers["Authorization"] = "Bearer OGFjN2E0Yzg4OWJmZjFiNjAxODljOTQwZDI1OTA0YWR8cHJmMkJ5SlE0Zg==";                                                    
            request.ContentType = "application/x-www-form-urlencoded";
            Stream PostData = request.GetRequestStream();
            PostData.Write(buffer, 0, buffer.Length);
            PostData.Close();
            using (HttpWebResponse response = (HttpWebResponse)request.GetResponse())
            {
                HttpStatusCode statusCode = response.StatusCode;
                Console.WriteLine(statusCode);
                Stream dataStream = response.GetResponseStream();
                StreamReader reader = new StreamReader(dataStream);
                responseData = JsonConvert.DeserializeObject<Dictionary<string, dynamic>>(reader.ReadToEnd());
                reader.Close();
                dataStream.Close();
            }
            return responseData;
        }
        public Dictionary<string, dynamic> GetCheckoutStatusTest(string CheckoutId, int PaymentMethodId, string FirebaseToken, string userId)
        {
            var user = _context.Users.FirstOrDefault(c => c.Id == userId);

            if (!string.IsNullOrEmpty(FirebaseToken) && user is not null)
            {
                user.FirebaseToken = FirebaseToken;
                _context.SaveChanges();
            }
            Dictionary<string, dynamic> responseData;
            string entityId = getentityIdTest(PaymentMethodId);

            string data = $"entityId={entityId}";
            
            string url = $"https://eu-test.oppwa.com/v1/checkouts/{CheckoutId}/payment?" + data;

         //   string url = $" https://eu-test.oppwa.com/v1/checkouts/{CheckoutId}/payment";

            HttpWebRequest request = (HttpWebRequest)HttpWebRequest.Create(url);
            request.Method = "GET";
            request.Headers["Authorization"] = "Bearer OGFjN2E0Yzg4OWJmZjFiNjAxODljOTQwZDI1OTA0YWR8cHJmMkJ5SlE0Zg==";
            using (HttpWebResponse response = (HttpWebResponse)request.GetResponse())
            {
                Stream dataStream = response.GetResponseStream();
                StreamReader reader = new StreamReader(dataStream);
                //var s = new JavaScriptSerializer();
                //responseData = s.Deserialize<Dictionary<string, dynamic>>(reader.ReadToEnd());
                responseData = JsonConvert.DeserializeObject<Dictionary<string, dynamic>>(reader.ReadToEnd());

                reader.Close();
                dataStream.Close();
            }

            if (responseData is not null)
            {
                string result = responseData["result"]["code"];
                string pattern = @"^(000\.000\.|000\.100\.1|000\.[36])";
                bool isMatch = Regex.IsMatch(result, pattern);
                string pattern2 = @"^(000\.400\.0[^3]|000\.400\.[0-1]{2}0)";
                bool isMatch2 = Regex.IsMatch(result, pattern2);

                if (isMatch || isMatch2)
                {
                    string PaymentId = responseData.ContainsKey("id") ? responseData["id"] : "Empty";
                    var invoice = _context.Invoices.FirstOrDefault(c => c.CheckoutId == CheckoutId);
                    if (invoice is not null)
                    {
                        invoice.PaymentId = PaymentId;
                        invoice.Paid = true;
                        _context.SaveChanges();
                        string mesg = $"تم حجز الخدمه بنجاح , The service has been booked successfully";
                        if (user is not null)
                        {
                            var Status = _SmsSender.SendAsync(user.PhoneNumber, mesg);
                            ModelSendMessage modelSendMessage = new ModelSendMessage()
                            {
                                RegistrationToken = FirebaseToken,
                                TitleAr = "حجز خدمة",
                                TitleEn = "Booking a Service",
                                BodyAr = "تم حجز الخدمه بنجاح",
                                BodyEn = "The service has been booked successfully",
                                NotificationTypeId = 1,
                                UserId = userId
                            };

                            _Firebase.SendMessage(modelSendMessage);
                        }
                    }
                }

            }


            return responseData;
        }
        public async Task<object> GetTransactionInfo2(string checkoutId)
        {
           
            string merchantId = "8a8294174d0595bb014d05d82e5b01d2";
            string accessToken = "OGE4Mjk0MTc0ZDA1OTViYjAxNGQwNWQ4MjllNzAxZDF8OVRuSlBjMm45aA==";

            // إعداد واجهة الاستعلام للحصول على معلومات المعاملة
            string url = $"https://test.oppwa.com/v1/checkouts/{checkoutId}/payment";
            HttpClient client = new HttpClient();
            client.DefaultRequestHeaders.Authorization = new System.Net.Http.Headers.AuthenticationHeaderValue("Bearer", accessToken);

            // إرسال طلب الاستعلام
            HttpResponseMessage response = await client.GetAsync(url + "?entityId=" + merchantId);
            string jsonResponse = await response.Content.ReadAsStringAsync();

            // تحليل استجابة الاستعلام
        //    dynamic transactionInfo = Newtonsoft.Json.JsonConvert.DeserializeObject(jsonResponse);
           var transactionInfo = JsonConvert.DeserializeObject<Dictionary<string, dynamic>>(jsonResponse);

            // الحصول على معلومات المعاملة
            //string invoiceId = transactionInfo.id;
            //decimal amount = transactionInfo.amount.value;
            //string status = transactionInfo.status;

            // استخدام معلومات المعاملة كما تحتاج
            //Console.WriteLine($"Invoice ID: {invoiceId}");
            //Console.WriteLine($"Amount: {amount}");
            //Console.WriteLine($"Status: {status}");

            Console.WriteLine(transactionInfo);
            return transactionInfo;
        }

        public string GetTransactionInfo(string CheckoutId)
        {
            //Dictionary<string, dynamic> responseData;
            //string data = "entityId=8a8294174d0595bb014d05d82e5b01d2";
            //string url = $"https://test.oppwa.com/v3/query/{CheckoutId}?" + data;
            //HttpWebRequest request = (HttpWebRequest)HttpWebRequest.Create(url);
            //request.Method = "GET";
            //request.Headers["Authorization"] = "Bearer OGE4Mjk0MTc0ZDA1OTViYjAxNGQwNWQ4MjllNzAxZDF8OVRuSlBjMm45aA==";
            //using (HttpWebResponse response = (HttpWebResponse)request.GetResponse())
            //{
            //    Stream dataStream = response.GetResponseStream();
            //    StreamReader reader = new StreamReader(dataStream);
            //    //var s = new JavaScriptSerializer();
            //    //responseData = s.Deserialize<Dictionary<string, dynamic>>(reader.ReadToEnd());
            //    responseData = JsonConvert.DeserializeObject<Dictionary<string, dynamic>>(reader.ReadToEnd());
            //    reader.Close();
            //    dataStream.Close();
            //}
            //return responseData;
            var client = new HttpClient();
            var uri = "https://test.oppwa.com/payment/rest/payments/lookup.json";
            var payload = "{\"checkoutId\":\"" + CheckoutId + "\"}";
            var content = new StringContent(payload, Encoding.UTF8, "application/json");
            var response = client.PostAsync(uri, content).Result;
            var responseContent = response.Content.ReadAsStringAsync().Result;
          //  var data = JsonConvert.DeserializeObject<object>(responseContent);
            //var data2 = JsonConvert.DeserializeObject<Dictionary<string, dynamic>>(responseContent);
           var data3 = JsonConvert.DeserializeObject<string>(responseContent);
            return data3;
          

        }
        public async Task<List<Payments>> GetHistoryPayment( string userId)
        {           
           var dates = _context.VisitDetails.Where(c => c.ApplicationUserId == userId && c.InvoiceDetails.Invoice.Paid)
               .Include(c => c.ApplicationUser).Include(c => c.VisitStatus).Include(c => c.UserFamily).Include(c => c.Package.Service).Include(c => c.InvoiceDetails.Invoice)
               .Select(c => new HistoryVisitsDTO
               {
                   PackageNameAR = c.Package.NameAR,
                   PackageNameEN = c.Package.NameEN,
                   ServiceAR = c.Package.Service.NameAR,
                   ServiceEN = c.Package.Service.NameEN,
                   Price =  c.InvoiceDetails.Price,                  
                   VisitDT = c.VisitDT.Date.ToString(),
                   Status = c.VisitStatus.Name,               
                 
               }).OrderByDescending(c => c.VisitDT).ToList();


             Dictionary<string, List<HistoryVisitsDTO>> visitsByDate = dates.GroupBy(visit => visit.VisitDT).ToDictionary(group => group.Key, group => group.ToList());
            List<Payments> payments = new List<Payments>();    
            foreach (KeyValuePair<string, List<HistoryVisitsDTO>> kvp in visitsByDate)
            {
                payments.Add(new Payments
                {
                    Date = kvp.Key, 
                    Items=kvp.Value
                });
            }

            return payments;
        }
        public async Task<List<PaymentMethodDTO>> GetPaymentMethods()
        {
            var PaymentMethodDTOs = _context.PaymentMethods
                         .Select(c => new PaymentMethodDTO
                         {
                  
                             Name = c.NameEN,
                             PaymentMethodId = c.PaymentMethodId
                         }).ToList();         

            return PaymentMethodDTOs;
        }

        public async Task<int> FirebaseTest(FirebaseDTO firebaseDTO,string userId)
        {
            try
            {

                // await _firebase.SendMessageToTopic("all", "Your Notification Title", "Your Notification Body");
                ModelSendMessage modelSendMessage = new ModelSendMessage()
                {
                    RegistrationToken = firebaseDTO.FirebaseToken,
                    TitleAr = "مركز يبرا",
                    TitleEn = "Yebra Center",
                    BodyAr = "مرحباً بكم في مركز يبراء الطبي، نتمنى لكم تجربة ممتعة مع تطبيقنا",
                    BodyEn = "Welcome to Yabra Medical Center, and we wish you an enjoyable experience with our application",
                    NotificationTypeId = 4,
                    UserId = userId
                };
                _Firebase.SendMessage(modelSendMessage);
                return 1;

            }
            catch (Exception ex)
            {
                return 0;

            }
        }

        //public object FormatAppointments()
        //{
        //   string userId = "c68a8973-b486-4ea4-af94-d9bab7d7abe1";
        //    var dates =  _context.VisitDetails.Where(c => c.ApplicationUserId == userId)
        //        .Include(c => c.ApplicationUser).Include(c => c.VisitStatus).Include(c => c.UserFamily).Include(c => c.Package.Service).Include(c => c.InvoiceDetails.Invoice)
        //        .Select(c => new HistoryVisitsDTO
        //        {
        //            //PackageNameAR = c.Package.NameAR,
        //            PackageNameEN = c.Package.NameEN,
        //            ServiceAR = c.Package.Service.NameAR,
        //            PackageId = c.Package.PackageId,
        //           // ServiceEN = c.Package.Service.NameEN,
        //            Price = c.InvoiceDetails.Price,
        //            Date = c.VisitDT.Date,
        //           // Status = c.VisitStatus.Name,
        //           // AppointmentId = c.VisitDetailsId
        //        }).ToList();
        //    var filteredAppointments = dates.Join(_context.Packages.ToList(), appointment => appointment.PackageId, package => package.PackageId, (appointment, package) => new { Appointment = appointment, Package = package });
        //    var results = filteredAppointments.Join(_context.Services.ToList(), appointment => appointment.Package.ServiceId, service => service.ServiceId, (appointment, service) => new { Appointment = appointment, Package = appointment.Package, Service = service });

        //    var output = new List<object>();

        //    foreach (var result in results)
        //    {
        //        output.Add(new { Appointment = result.Appointment, Service = result.Service, Package = result.Package });
        //    }

        //    // Send the data to the mobile developer
        //    var json = JsonConvert.SerializeObject(output);
        //    //using (var stream = new MemoryStream())
        //    //{
        //    //    stream.Write(json.ToUtf8Bytes());
        //    //    var response = new HttpResponseMessage(HttpStatusCode.OK);
        //    //    response.Content = new ByteArrayContent(stream.ToArray());
        //    //    response.Content.Headers.ContentType = new MediaTypeHeaderValue("application/json");

        //    //    Console.WriteLine(json);
        //    //}

        //    return json;
        //}
    }
    public class Payments
    {
        public string Date { get; set; }
        public List<HistoryVisitsDTO> Items { get; set; }
    }
   

  
}
