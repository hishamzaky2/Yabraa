﻿namespace Yabraa.Const
{
    static class UrlAdmin
    {
        public static string AdminProjectUrl = "http://yabraa-001-site2.dtempurl.com";
    }
}
