﻿using Microsoft.AspNetCore.Authorization;
using Microsoft.AspNetCore.Http;
using Microsoft.AspNetCore.Mvc;
using Microsoft.EntityFrameworkCore;
using System.Net;
using Yabraa.Helpers;
using YabraaEF;
using YabraaEF.Models;

namespace Yabraa.Controllers
{
	[Route("api/[controller]")]
	[ApiController]
	public class AllergiesController : ControllerBase
	{
		private readonly ApplicationDbContext _dbContext;
		public AllergiesController(ApplicationDbContext dbContext)
		{
			_dbContext = dbContext;
		}
		[HttpGet("GetAllergies")]
		public async Task<IActionResult> GetAllergies()
		{
			try
			{
				var model = _dbContext.Allergies.Where(c => !c.Deleted).Select(c => new { c.AllergyId, c.TitleAR, c.TitleEN }).ToList();
				return Ok(new ResponseVM() { StatusCode = HttpStatusCode.OK, Data = model });
			}
			catch (Exception)
			{
				return Ok(new ResponseVM() { StatusCode = HttpStatusCode.BadRequest, ErrorMessageEn = $"An error has occurred, please try again later", ErrorMessageAr = "لقد حدث خطأ، يرجى المحاولة في وقت لاحق" });
			}

		}
		[HttpPost("AddAllergyUser")]
		[Authorize]
		public async Task<IActionResult> AddAllergyUser(int AllergyId, long UserFamilyId)
		{
			try
			{
				if (AllergyId > 0 && UserFamilyId > 0)
				{
					var Exist = _dbContext.UserFamilyAllergies.FirstOrDefault(c => c.AllergyId == AllergyId && c.UserFamilyId == UserFamilyId);
					if (Exist is null)
					{
						UserFamilyAllergy Allergy = new UserFamilyAllergy()
						{
							AllergyId = AllergyId,
                            UserFamilyId = UserFamilyId,
							Deleted = false
						};
						_dbContext.UserFamilyAllergies.Add(Allergy);
					}
					else
					{
						Exist.Deleted = false;
					}

					_dbContext.SaveChanges();
					var model = _dbContext.UserFamilyAllergies.Include(c => c.Allergy).Where(c => !c.Deleted && c.UserFamilyId == UserFamilyId).Select(c => new { c.AllergyId, c.Allergy.TitleAR, c.Allergy.TitleEN }).ToList();

					return Ok(new ResponseVM() { StatusCode = HttpStatusCode.OK, Data = model });
				}


				return Ok(new ResponseVM() { StatusCode = HttpStatusCode.BadRequest, ErrorMessageEn = $"Please verify your input", ErrorMessageAr = "يرجى التحقق من المدخلات الخاصة بك" });

			}
			catch (Exception)
			{
				return Ok(new ResponseVM() { StatusCode = HttpStatusCode.BadRequest, ErrorMessageEn = $"An error has occurred, please try again later", ErrorMessageAr = "لقد حدث خطأ، يرجى المحاولة في وقت لاحق" });
			}

		}
		[HttpGet("GetAllergiesUser")]
		public async Task<IActionResult> GetAllergiesUser(long UserFamilyId)
		{
			try
			{
				var model = _dbContext.UserFamilyAllergies.Where(c => !c.Deleted && c.UserFamilyId == UserFamilyId).Include(c => c.Allergy).Select(c => new { c.AllergyId, c.Allergy.TitleAR, c.Allergy.TitleEN }).ToList();
				return Ok(new ResponseVM() { StatusCode = HttpStatusCode.OK, Data = model });
			}
			catch (Exception)
			{
				return Ok(new ResponseVM() { StatusCode = HttpStatusCode.BadRequest, ErrorMessageEn = $"An error has occurred, please try again later", ErrorMessageAr = "لقد حدث خطأ، يرجى المحاولة في وقت لاحق" });
			}

		}

		[HttpDelete("DeleteAllergyUser")]
		[Authorize]
		public async Task<IActionResult> DeleteAllergyUser(int AllergyId, long UserFamilyId)
		{
			try
			{
				if (AllergyId > 0 && UserFamilyId > 0)
				{
					var Allergy = _dbContext.UserFamilyAllergies.FirstOrDefault(c => c.AllergyId == AllergyId && c.UserFamilyId == UserFamilyId);
					if (Allergy is not null)
					{
						Allergy.Deleted = true;
						_dbContext.SaveChanges();
						var model = _dbContext.UserFamilyAllergies.Include(c => c.Allergy).Where(c => !c.Deleted && c.UserFamilyId == UserFamilyId).Select(c => new { c.AllergyId, c.Allergy.TitleAR, c.Allergy.TitleEN }).ToList();

						return Ok(new ResponseVM() { StatusCode = HttpStatusCode.OK, Data = model });
					}
					return Ok(new ResponseVM() { StatusCode = HttpStatusCode.BadRequest, ErrorMessageEn = $"An error has occurred, please try again later", ErrorMessageAr = "لقد حدث خطأ، يرجى المحاولة في وقت لاحق" });

				}


				return Ok(new ResponseVM() { StatusCode = HttpStatusCode.BadRequest, ErrorMessageEn = $"Please verify your input", ErrorMessageAr = "يرجى التحقق من المدخلات الخاصة بك" });

			}
			catch (Exception)
			{
				return Ok(new ResponseVM() { StatusCode = HttpStatusCode.BadRequest, ErrorMessageEn = $"An error has occurred, please try again later", ErrorMessageAr = "لقد حدث خطأ، يرجى المحاولة في وقت لاحق" });
			}

		}

	}
}
