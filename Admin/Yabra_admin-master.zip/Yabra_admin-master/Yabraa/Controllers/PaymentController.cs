﻿using FirebaseAdmin.Auth;
using Microsoft.AspNetCore.Authorization;
using Microsoft.AspNetCore.Http;
using Microsoft.AspNetCore.Mvc;
using Microsoft.EntityFrameworkCore;

using System;
using System.ComponentModel.DataAnnotations;
using System.Data;
using System.Globalization;
using System.Net;
using System.Security.Claims;
using System.Text;
using System.Text.RegularExpressions;
using Yabraa.DTOs;
using Yabraa.Helpers;
using Yabraa.Services;
using YabraaEF;
using YabraaEF.Helpers;
using YabraaEF.Models;
using YabraaEF.Services;

namespace Yabraa.Controllers
{
    [Route("api/[controller]")]
    [ApiController]
    [Authorize(Roles = "User")]
    public class PaymentController : ControllerBase
    {
        private readonly PaymentService _paymentservice;
        private  Firebase _firebase;
        private ApplicationDbContext _context;
        public PaymentController(PaymentService service, ApplicationDbContext context, Firebase firebase)
        {
            _paymentservice = service;
            _context = context;
            _firebase = firebase;
        }
        [HttpPost("GetCheckoutId")]
        public async Task<IActionResult> GetCheckoutId(PaymentDto paymentDto)
        {
            try
            {
                string errorMessage = "";
                if ( paymentDto.ServiceTypeId == 1)
                {
                    if (paymentDto.locationLongitude == 0 )
                    {
                        ModelState.AddModelError("locationLongitude", "locationLongitude is required");
                    }
                   
                }
                if ( paymentDto.ServiceTypeId == 1)
                {
                    if (paymentDto.locationLatitude == 0)
                    {
                        ModelState.AddModelError("locationLatitude", "locationLatitude is required");

                    }
                }

                if (ModelState.IsValid && paymentDto.packages is not null && paymentDto.packages.Count > 0 )
                {                  
                    bool errorFlag = true;
                  
                    foreach (var package in paymentDto.packages)
                    {
                       
                        var validationResults = new List<ValidationResult>();
                        var isValid = Validator.TryValidateObject(package, new ValidationContext(package), validationResults, true);
                        if (!isValid)
                        {
                            foreach (var validationResult in validationResults)
                            {
                                foreach (var memberName in validationResult.MemberNames)
                                {
                                    errorFlag = false;
                                    errorMessage = $" {memberName} {validationResult.ErrorMessage},";
                                }

                            }
                        }
                    }
                    if (!errorFlag)
                    {
                        return Ok(new ResponseVM() { StatusCode = HttpStatusCode.BadRequest, ErrorMessageEn = $"Please check your input ({errorMessage}).", ErrorMessageAr = $"({errorMessage}) يرجى التحقق من المدخلات الخاصة بك." });

                    }
                   
                    List<int> packageIds = paymentDto.packages.Select(c => c.packageId).ToList();
                    var totalPriceDB = _context.Packages.Where(c => packageIds.Contains(c.PackageId)).Sum(c => c.Price);
                    if (totalPriceDB != paymentDto.amount)
                    {
                        return Ok(new ResponseVM() { StatusCode = HttpStatusCode.BadRequest, ErrorMessageEn = $"Please restart the application).", ErrorMessageAr = $"الرجاء إعادة تشغيل التطبيق." });

                    }
                    string userName = User.FindFirstValue(ClaimTypes.NameIdentifier);
                    var userId = _context.Users.FirstOrDefault(c => c.UserName == userName).Id;
                    var checkoutId = await _paymentservice.Payment(paymentDto, userId, paymentDto.amount, paymentDto.currency, "DB");
                    if (!string.IsNullOrWhiteSpace(checkoutId) )
                    {
                        return Ok(new ResponseVM() { StatusCode = HttpStatusCode.OK, Data = new { checkoutId = checkoutId, model = paymentDto } }) ;
                    }
                }
                foreach (var entry in ModelState.Values)
                {
                    foreach (var error in entry.Errors)
                    {
                        errorMessage = $" {error.ErrorMessage},";

                    }
                }
                return Ok(new ResponseVM() { StatusCode = HttpStatusCode.BadRequest, ErrorMessageEn = $"Please check your input ({errorMessage}).", ErrorMessageAr = $" ({errorMessage}) . يرجى التحقق من المدخلات الخاصة بك." });

            }
            catch (Exception)
            {
                return Ok(new ResponseVM() { StatusCode = HttpStatusCode.BadRequest, ErrorMessageEn = $"An error has occurred, please try again later", ErrorMessageAr = "لقد حدث خطأ، يرجى المحاولة في وقت لاحق" });
            }


        }
      
        [HttpGet("GetCheckoutStatus")]
        public async Task<IActionResult> GetCheckoutStatus(string CheckoutId, int PaymentMethodId, string FirebaseToken)
        {
            try
            {

                string userName = User.FindFirstValue(ClaimTypes.NameIdentifier);
                var userId = _context.Users.FirstOrDefault(c => c.UserName == userName).Id;

               
                    var responseData = _paymentservice.GetCheckoutStatus(CheckoutId, PaymentMethodId, FirebaseToken, userId);
                //  var responseData =  _paymentservice.GetCheckoutStatusTest(CheckoutId, PaymentMethodId, FirebaseToken, userId);
                if (responseData is not null && responseData.Count > 0)
                {
                    string code = responseData["result"]["code"];
                    string description = responseData["result"]["description"];
                    return Ok(new ResponseVM() { StatusCode = HttpStatusCode.OK, Data = new { code, description } });

                }

                return Ok(new ResponseVM() { StatusCode = HttpStatusCode.BadRequest, ErrorMessageEn = $"Please check your input.", ErrorMessageAr = $". يرجى التحقق من المدخلات الخاصة بك." });

            }
            catch (Exception ex)
            {
              
                if ((ex is WebException webException && webException.Status == WebExceptionStatus.Timeout )|| ex is TimeoutException timeoutException)
                {
                    int maxRetries = 5;
                    int retry;
                    string userName = User.FindFirstValue(ClaimTypes.NameIdentifier);
                    var userId = _context.Users.FirstOrDefault(c => c.UserName == userName).Id;
                    for (retry = 1; retry <= maxRetries; retry++)
                    {
                        try
                        {
                            var responseData = _paymentservice.GetCheckoutStatus(CheckoutId, PaymentMethodId, FirebaseToken, userId);
                         // var responseData =  _paymentservice.GetCheckoutStatusTest(CheckoutId, PaymentMethodId, FirebaseToken, userId);
                            if (responseData is not null && responseData.Count > 0)
                            {
                                string code = responseData["result"]["code"];
                                string description = responseData["result"]["description"];
                                return Ok(new ResponseVM() { StatusCode = HttpStatusCode.OK, Data = new { code, description } });
                            }
                         
                        }
                        catch (Exception exf)
                        {
                            if ((exf is WebException webExceptionf && webExceptionf.Status == WebExceptionStatus.Timeout) || exf is TimeoutException timeoutExceptionf)
                            {
                                continue;
                            }
                            else
                            {
                                return Ok(new ResponseVM() { StatusCode = HttpStatusCode.BadRequest, ErrorMessageEn = $"An error has occurred, please try again later", ErrorMessageAr = "لقد حدث خطأ، يرجى المحاولة في وقت لاحق" });
                            }
                        }
                    }
                }
                return Ok(new ResponseVM() { StatusCode = HttpStatusCode.BadRequest, ErrorMessageEn = $"An error has occurred, please try again later", ErrorMessageAr = "لقد حدث خطأ، يرجى المحاولة في وقت لاحق" });
                            
            }


        }
        //[HttpGet("GetCheckoutStatus")]
        //public async Task<IActionResult> GetCheckoutStatus(string CheckoutId, int PaymentMethodId, string FirebaseToken)
        //{
        //    try
        //    {
        //        string userName = User.FindFirstValue(ClaimTypes.NameIdentifier);
        //        var userId = _context.Users.FirstOrDefault(c => c.UserName == userName).Id;
        //        var responseData = _paymentservice.GetCheckoutStatus(CheckoutId, PaymentMethodId, FirebaseToken, userId);
        //        //  var responseData =  _paymentservice.GetCheckoutStatusTest(CheckoutId, PaymentMethodId, FirebaseToken, userId);
        //        if (responseData is not null && responseData.Count > 0)
        //        {
        //            string code = responseData["result"]["code"];
        //            string description = responseData["result"]["description"];
        //            return Ok(new ResponseVM() { StatusCode = HttpStatusCode.OK, Data = new { code, description } });

        //        }

        //        return Ok(new ResponseVM() { StatusCode = HttpStatusCode.BadRequest, ErrorMessageEn = $"Please check your input.", ErrorMessageAr = $". يرجى التحقق من المدخلات الخاصة بك." });

        //    }
        //    catch (Exception ex)
        //    {
        //        return Ok(new ResponseVM() { StatusCode = HttpStatusCode.BadRequest, ErrorMessageEn = $"An error has occurred, please try again later", ErrorMessageAr = "لقد حدث خطأ، يرجى المحاولة في وقت لاحق" });
        //    }


        //}
        [HttpGet("GetTransactionInfo")]
        public async Task<IActionResult> GetTransactionInfo(string CheckoutId)
        {
            try
            {

                var responseData = _paymentservice.GetTransactionInfo(CheckoutId);
                //if (responseData is not null && responseData.Count > 0)
                //{
                //    string code = responseData["result"]["code"];
                //    string description = responseData["result"]["description"];
                  

                //}
                return Ok(new ResponseVM() { StatusCode = HttpStatusCode.OK, Data = new { responseData } });
                return Ok(new ResponseVM() { StatusCode = HttpStatusCode.BadRequest, ErrorMessageEn = $"Please check your input.", ErrorMessageAr = $". يرجى التحقق من المدخلات الخاصة بك." });

            }
            catch (Exception)
            {
                return Ok(new ResponseVM() { StatusCode = HttpStatusCode.BadRequest, ErrorMessageEn = $"An error has occurred, please try again later", ErrorMessageAr = "لقد حدث خطأ، يرجى المحاولة في وقت لاحق" });
            }


        }

        [HttpGet("HistoryPayment")]
        public async Task<IActionResult> HistoryPayment()
        {
            try
            {
                string userName = User.FindFirstValue(ClaimTypes.NameIdentifier);
                var userId = _context.Users.FirstOrDefault(c => c.UserName == userName).Id;
                var responseData = _paymentservice.GetHistoryPayment(userId);             

                return Ok(new ResponseVM() { StatusCode = HttpStatusCode.OK, Data = new {  responseData.Result } });

            }
            catch (Exception ex )
            {
                return Ok(new ResponseVM() { StatusCode = HttpStatusCode.BadRequest, ErrorMessageEn = $"An error has occurred, please try again later", ErrorMessageAr = "لقد حدث خطأ، يرجى المحاولة في وقت لاحق" });
            }


        }
        [HttpGet("GetPaymentMethods")]
        [AllowAnonymous]
        public async Task<IActionResult> GetPaymentMethods()
        {
            try
            {                
                var responseData = _paymentservice.GetPaymentMethods();
                return Ok(new ResponseVM() { StatusCode = HttpStatusCode.OK, Data = new { responseData.Result } });

            }
            catch (Exception)
            {
                return Ok(new ResponseVM() { StatusCode = HttpStatusCode.BadRequest, ErrorMessageEn = $"An error has occurred, please try again later", ErrorMessageAr = "لقد حدث خطأ، يرجى المحاولة في وقت لاحق" });
            }


        }
        [HttpPost("FirebaseTest")]       
        public async Task<IActionResult> FirebaseTest(FirebaseDTO firebaseDTO)
        {
            try
            {
              //  string userName = User.FindFirstValue(ClaimTypes.NameIdentifier);
              //  var userId = _context.Users.FirstOrDefault(c => c.UserName == userName).Id;
              //var test =  _paymentservice.FirebaseTest(firebaseDTO,userId);


                //// await _firebase.SendMessageToTopic("all", "Your Notification Title", "Your Notification Body");
                //ModelSendMessage modelSendMessage = new ModelSendMessage()
                //{
                //    RegistrationToken = firebaseDTO.FirebaseToken,
                //    TitleAr = "مركز يبرا",
                //    TitleEn = "Yebra Center",
                //    BodyAr = "مرحباً بكم في مركز يبراء الطبي، نتمنى لكم تجربة ممتعة مع تطبيقنا",
                //    BodyEn = "Welcome to Yabra Medical Center, and we wish you an enjoyable experience with our application",
                //    NotificationTypeId = 4,
                //    UserId = userId
                //};
                // _firebase.SendMessage(modelSendMessage);
                DateTime now = DateTime.Now;

                CultureInfo cultureInfo = new CultureInfo("en-US");
                string formattedDateTime = now.ToString("dddd, dd MMMM yyyy hh:mm:ss tt", cultureInfo);

                return Ok(new ResponseVM() { StatusCode = HttpStatusCode.OK, Data = formattedDateTime });

            }
            catch (Exception)
            {
                return Ok(new ResponseVM() { StatusCode = HttpStatusCode.BadRequest, ErrorMessageEn = $"An error has occurred, please try again later", ErrorMessageAr = "لقد حدث خطأ، يرجى المحاولة في وقت لاحق" });
            }


        }

    }
    
}
