﻿using Microsoft.AspNetCore.Authorization;
using Microsoft.AspNetCore.Http;
using Microsoft.AspNetCore.Mvc;
using System.Globalization;
using System.Net;
using Yabraa.Const;
using Yabraa.DTOs;
using Yabraa.Helpers;
using Yabraa.Services;
using YabraaEF.Const;
using YabraaEF.Models;

namespace Yabraa.Controllers
{
    [Route("api/[controller]")]
    [ApiController]
    public class ServicesController : ControllerBase
    {
        private readonly MainService _mainService;
        public ServicesController(MainService mainService)
        {
            _mainService = mainService; 
        }
        [HttpGet("GetServiceTypes")]
        public IActionResult GetServiceTypes()
        {
            try
            {
                var result = _mainService.GetServiceTypes();
                return Ok(new ResponseVM() { StatusCode = HttpStatusCode.OK, Data = result });

            }
            catch (Exception)
            {
                return Ok(new ResponseVM() { StatusCode = HttpStatusCode.BadRequest, ErrorMessageEn = $"An error has occurred, please try again later", ErrorMessageAr = "لقد حدث خطأ، يرجى المحاولة في وقت لاحق" });
            }
        }

        [HttpGet("servicesDetails")]
        public IActionResult GetServicesDetails(int serviceTypeId)
        {
            try
            {
              var result =   _mainService.GetServicesDetails(serviceTypeId);               
               return Ok(new ResponseVM() { StatusCode = HttpStatusCode.OK, Data = result });

            }
            catch (Exception)
            {
                return Ok(new ResponseVM() { StatusCode = HttpStatusCode.BadRequest, ErrorMessageEn = $"An error has occurred, please try again later", ErrorMessageAr = "لقد حدث خطأ، يرجى المحاولة في وقت لاحق" });
            }
        }
        [HttpGet("getDates")]
        public IActionResult GetDates()
        {
            try
            {
                DateTime dateTime = General.GetKSATimeZoneNow();
                List<DateDto> GetDates = new List<DateDto>();
                DateDto dateDto;
                for (int i = 0; i < 30; i++)
                {
                    dateDto = new DateDto()
                    {
                        Year = dateTime.Year,
                        MonthName = dateTime.ToString("MMMM"),
                        MonthNumber = dateTime.ToString("MM"),
                        DayName  = dateTime.ToString("dddd"),
                        DayOfMonth = dateTime.ToString("dd"),
                        MonthShortName = dateTime.ToString("MMM")                        
                    };

                    dateTime = dateTime.AddDays(1);
                    GetDates.Add(dateDto);
                }

                return Ok(new ResponseVM() { StatusCode = HttpStatusCode.OK, Data = GetDates });

            }
            catch (Exception)
            {
                return Ok(new ResponseVM() { StatusCode = HttpStatusCode.BadRequest, ErrorMessageEn = $"An error has occurred, please try again later", ErrorMessageAr = "لقد حدث خطأ، يرجى المحاولة في وقت لاحق" });
            }
        }
        [HttpGet("GetDatesAr")]
        public IActionResult GetDatesAr()
        {
            try
            {
                DateTime dateTime = General.GetKSATimeZoneNow();
                List<DateDto> GetDates = new List<DateDto>();
                DateDto dateDto;
                CultureInfo arabicCulture = new CultureInfo("ar"); // تعيين الثقافة العربية

                for (int i = 0; i < 30; i++)
                {
                    dateDto = new DateDto()
                    {
                        Year = dateTime.Year,
                        MonthName = dateTime.ToString("MMMM", arabicCulture), // استخدام الثقافة العربية هنا
                        MonthNumber = dateTime.ToString("MM"),
                        DayName = dateTime.ToString("dddd", arabicCulture), // استخدام الثقافة العربية هنا
                        DayOfMonth = dateTime.ToString("dd"),
                        MonthShortName = dateTime.ToString("MMM", arabicCulture) // استخدام الثقافة العربية هنا
                    };

                    dateTime = dateTime.AddDays(1);
                    GetDates.Add(dateDto);
                }

                return Ok(new ResponseVM() { StatusCode = HttpStatusCode.OK, Data = GetDates });

            }
            catch (Exception)
            {
                return Ok(new ResponseVM() { StatusCode = HttpStatusCode.BadRequest, ErrorMessageEn = $"An error has occurred, please try again later", ErrorMessageAr = "لقد حدث خطأ، يرجى المحاولة في وقت لاحق" });
            }
        }
        [AllowAnonymous]
        [HttpGet("setData")]
        public IActionResult setData()
        {
            try
            {
                DateTime dateTime = General.GetKSATimeZoneNow();
                CultureInfo cultureInfoAR = new CultureInfo("ar");
                CultureInfo cultureInfoEn = new CultureInfo("en-US");
                string messageAr = $"تم إلغاء حجز الخدمة الخاص بكم \n اسم الخدمه :  \n التاريخ : {dateTime.ToString("dddd, dd MMMM yyyy hh:mm tt", cultureInfoAR)} ";
                string messageEn = $"Your service request has been cancelled \n Package :  \n Date : {dateTime.ToString("dddd, dd MMMM yyyy hh:mm tt", cultureInfoEn)} ";
                string mesg = $"{messageAr}\n{messageEn}";
                return Ok(mesg);
            }
            catch (Exception ex)
            {
                return Ok(new ResponseVM() { StatusCode = HttpStatusCode.BadRequest/*, Error = ex.Message, OperationMessage = ex.InnerException?.Message*/ });
            }
        }

    }
}
