﻿using Microsoft.AspNetCore.Authorization;
using Microsoft.AspNetCore.Http;
using Microsoft.AspNetCore.Mvc;
using Microsoft.EntityFrameworkCore;
using System.Net;
using Yabraa.Helpers;
using YabraaEF;
using YabraaEF.Models;

namespace Yabraa.Controllers
{
	[Route("api/[controller]")]
	[ApiController]
	public class ChronicDiseasesController : ControllerBase
	{
		private readonly ApplicationDbContext _dbContext;
		public ChronicDiseasesController(ApplicationDbContext dbContext)
		{
			_dbContext = dbContext;
		}
		[HttpGet("GetChronicDiseases")]
		public async Task<IActionResult> GetChronicDiseases()
		{
			try
			{
				var model = _dbContext.ChronicDiseases.Where(c => !c.Deleted).Select(c => new { c.ChronicDiseaseId, c.TitleAR, c.TitleEN }).ToList();
				return Ok(new ResponseVM() { StatusCode = HttpStatusCode.OK, Data = model });
			}
			catch (Exception)
			{
				return Ok(new ResponseVM() { StatusCode = HttpStatusCode.BadRequest, ErrorMessageEn = $"An error has occurred, please try again later", ErrorMessageAr = "لقد حدث خطأ، يرجى المحاولة في وقت لاحق" });
			}

		}
		[HttpPost("AddChronicDiseaseUser")]
		[Authorize]
		public async Task<IActionResult> AddChronicDiseaseUser(int ChronicDiseaseId, long UserFamilyId)
		{
			try
			{
				if (ChronicDiseaseId > 0 && UserFamilyId > 0)
				{
					var Exist = _dbContext.UserFamilyChronicDiseases.FirstOrDefault(c => c.ChronicDiseaseId == ChronicDiseaseId && c.UserFamilyId == UserFamilyId);
					if (Exist is null)
					{
						UserFamilyChronicDisease UserFamilyChronicDisease = new UserFamilyChronicDisease()
						{
							ChronicDiseaseId = ChronicDiseaseId,
                            UserFamilyId = UserFamilyId,
							Deleted = false
						};
						_dbContext.UserFamilyChronicDiseases.Add(UserFamilyChronicDisease);
					}
					else
					{
						Exist.Deleted = false;
					}

					_dbContext.SaveChanges();
					var model = _dbContext.UserFamilyChronicDiseases.Include(c => c.ChronicDisease).Where(c => !c.Deleted && c.UserFamilyId == UserFamilyId).Select(c => new { c.ChronicDiseaseId, c.ChronicDisease.TitleAR, c.ChronicDisease.TitleEN }).ToList();

					return Ok(new ResponseVM() { StatusCode = HttpStatusCode.OK, Data = model });
				}


				return Ok(new ResponseVM() { StatusCode = HttpStatusCode.BadRequest, ErrorMessageEn = $"Please verify your input", ErrorMessageAr = "يرجى التحقق من المدخلات الخاصة بك" });

			}
			catch (Exception)
			{
				return Ok(new ResponseVM() { StatusCode = HttpStatusCode.BadRequest, ErrorMessageEn = $"An error has occurred, please try again later", ErrorMessageAr = "لقد حدث خطأ، يرجى المحاولة في وقت لاحق" });
			}

		}
		[HttpGet("GetChronicDiseasesUser")]
		public async Task<IActionResult> GetChronicDiseasesUser(long UserFamilyId)
		{
			try
			{
				var model = _dbContext.UserFamilyChronicDiseases.Where(c => !c.Deleted && c.UserFamilyId == UserFamilyId).Include(c => c.ChronicDisease).Select(c => new { c.ChronicDiseaseId, c.ChronicDisease.TitleAR, c.ChronicDisease.TitleEN }).ToList();
				return Ok(new ResponseVM() { StatusCode = HttpStatusCode.OK, Data = model });
			}
			catch (Exception)
			{
				return Ok(new ResponseVM() { StatusCode = HttpStatusCode.BadRequest, ErrorMessageEn = $"An error has occurred, please try again later", ErrorMessageAr = "لقد حدث خطأ، يرجى المحاولة في وقت لاحق" });
			}

		}

		[HttpDelete("DeleteChronicDiseaseUser")]
		[Authorize]
		public async Task<IActionResult> DeleteChronicDiseaseUser(int ChronicDiseaseId, long UserFamilyId)
		{
			try
			{
				if (ChronicDiseaseId > 0 && UserFamilyId > 0)
				{
					var ChronicDisease = _dbContext.UserFamilyChronicDiseases.FirstOrDefault(c => c.ChronicDiseaseId == ChronicDiseaseId && c.UserFamilyId == UserFamilyId);
					if (ChronicDisease is not null)
					{
						ChronicDisease.Deleted = true;
						_dbContext.SaveChanges();
						var model = _dbContext.UserFamilyChronicDiseases.Include(c => c.ChronicDisease).Where(c => !c.Deleted && c.UserFamilyId == UserFamilyId).Select(c => new { c.ChronicDiseaseId, c.ChronicDisease.TitleAR, c.ChronicDisease.TitleEN }).ToList();

						return Ok(new ResponseVM() { StatusCode = HttpStatusCode.OK, Data = model });
					}
					return Ok(new ResponseVM() { StatusCode = HttpStatusCode.BadRequest, ErrorMessageEn = $"An error has occurred, please try again later", ErrorMessageAr = "لقد حدث خطأ، يرجى المحاولة في وقت لاحق" });

				}


				return Ok(new ResponseVM() { StatusCode = HttpStatusCode.BadRequest, ErrorMessageEn = $"Please verify your input", ErrorMessageAr = "يرجى التحقق من المدخلات الخاصة بك" });

			}
			catch (Exception)
			{
				return Ok(new ResponseVM() { StatusCode = HttpStatusCode.BadRequest, ErrorMessageEn = $"An error has occurred, please try again later", ErrorMessageAr = "لقد حدث خطأ، يرجى المحاولة في وقت لاحق" });
			}

		}
	}
}
