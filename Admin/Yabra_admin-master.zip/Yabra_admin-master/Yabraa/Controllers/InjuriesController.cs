﻿using Microsoft.AspNetCore.Authorization;
using Microsoft.AspNetCore.Http;
using Microsoft.AspNetCore.Mvc;
using System.Net;
using Yabraa.Helpers;
using YabraaEF.Models;
using YabraaEF;
using Microsoft.EntityFrameworkCore;

namespace Yabraa.Controllers
{
	[Route("api/[controller]")]
	[ApiController]
	public class InjuriesController : ControllerBase
	{
		private readonly ApplicationDbContext _dbContext;
		public InjuriesController(ApplicationDbContext dbContext)
		{
			_dbContext = dbContext;
		}
		[HttpGet("GetInjuries")]
		public async Task<IActionResult> GetInjuries()
		{
			try
			{
				var model = _dbContext.Injuries.Where(c => !c.Deleted).Select(c => new { c.InjuryId, c.TitleAR, c.TitleEN }).ToList();
				return Ok(new ResponseVM() { StatusCode = HttpStatusCode.OK, Data = model });
			}
			catch (Exception)
			{
				return Ok(new ResponseVM() { StatusCode = HttpStatusCode.BadRequest, ErrorMessageEn = $"An error has occurred, please try again later", ErrorMessageAr = "لقد حدث خطأ، يرجى المحاولة في وقت لاحق" });
			}

		}
		[HttpPost("AddInjuryUser")]
		[Authorize]
		public async Task<IActionResult> AddInjuryUser(int InjuryId, long UserFamilyId)
		{
			try
			{
				if (InjuryId > 0 && UserFamilyId > 0)
				{
					var Exist = _dbContext.UserFamilyInjuries.FirstOrDefault(c => c.InjuryId == InjuryId && c.UserFamilyId == UserFamilyId);
					if (Exist is null)
					{
						UserFamilyInjury UserFamilyInjury = new UserFamilyInjury()
						{
							InjuryId = InjuryId,
                            UserFamilyId = UserFamilyId,
							Deleted = false
						};
						_dbContext.UserFamilyInjuries.Add(UserFamilyInjury);
					}
					else
					{
						Exist.Deleted = false;
					}

					_dbContext.SaveChanges();
					var model = _dbContext.UserFamilyInjuries.Include(c => c.Injury).Where(c => !c.Deleted && c.UserFamilyId == UserFamilyId).Select(c => new { c.InjuryId, c.Injury.TitleAR, c.Injury.TitleEN }).ToList();

					return Ok(new ResponseVM() { StatusCode = HttpStatusCode.OK, Data = model });
				}


				return Ok(new ResponseVM() { StatusCode = HttpStatusCode.BadRequest, ErrorMessageEn = $"Please verify your input", ErrorMessageAr = "يرجى التحقق من المدخلات الخاصة بك" });

			}
			catch (Exception)
			{
				return Ok(new ResponseVM() { StatusCode = HttpStatusCode.BadRequest, ErrorMessageEn = $"An error has occurred, please try again later", ErrorMessageAr = "لقد حدث خطأ، يرجى المحاولة في وقت لاحق" });
			}

		}
		[HttpGet("GetInjuriesUser")]
		public async Task<IActionResult> GetInjuriesUser(long UserFamilyId)
		{
			try
			{
				var model = _dbContext.UserFamilyInjuries.Where(c => !c.Deleted && c.UserFamilyId == UserFamilyId).Include(c => c.Injury).Select(c => new { c.InjuryId, c.Injury.TitleAR, c.Injury.TitleEN }).ToList();
				return Ok(new ResponseVM() { StatusCode = HttpStatusCode.OK, Data = model });
			}
			catch (Exception)
			{
				return Ok(new ResponseVM() { StatusCode = HttpStatusCode.BadRequest, ErrorMessageEn = $"An error has occurred, please try again later", ErrorMessageAr = "لقد حدث خطأ، يرجى المحاولة في وقت لاحق" });
			}

		}

		[HttpDelete("DeleteInjuryUser")]
		[Authorize]
		public async Task<IActionResult> DeleteInjury(int InjuryId, long UserFamilyId)
		{
			try
			{
				if (InjuryId > 0 && UserFamilyId > 0)
				{
					var Injury = _dbContext.UserFamilyInjuries.FirstOrDefault(c => c.InjuryId == InjuryId && c.UserFamilyId == UserFamilyId);
					if (Injury is not null)
					{
						Injury.Deleted = true;
						_dbContext.SaveChanges();
						var model = _dbContext.UserFamilyInjuries.Include(c => c.Injury).Where(c => !c.Deleted && c.UserFamilyId == UserFamilyId).Select(c => new { c.InjuryId, c.Injury.TitleAR, c.Injury.TitleEN }).ToList();

						return Ok(new ResponseVM() { StatusCode = HttpStatusCode.OK, Data = model });
					}
					return Ok(new ResponseVM() { StatusCode = HttpStatusCode.BadRequest, ErrorMessageEn = $"An error has occurred, please try again later", ErrorMessageAr = "لقد حدث خطأ، يرجى المحاولة في وقت لاحق" });

				}


				return Ok(new ResponseVM() { StatusCode = HttpStatusCode.BadRequest, ErrorMessageEn = $"Please verify your input", ErrorMessageAr = "يرجى التحقق من المدخلات الخاصة بك" });

			}
			catch (Exception)
			{
				return Ok(new ResponseVM() { StatusCode = HttpStatusCode.BadRequest, ErrorMessageEn = $"An error has occurred, please try again later", ErrorMessageAr = "لقد حدث خطأ، يرجى المحاولة في وقت لاحق" });
			}

		}
	}
}
