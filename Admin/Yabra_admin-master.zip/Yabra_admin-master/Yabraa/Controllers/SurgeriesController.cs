﻿using Microsoft.AspNetCore.Authorization;
using Microsoft.AspNetCore.Http;
using Microsoft.AspNetCore.Mvc;
using Microsoft.EntityFrameworkCore;
using System.Net;
using Yabraa.Helpers;
using YabraaEF;
using YabraaEF.Models;

namespace Yabraa.Controllers
{
	[Route("api/[controller]")]
	[ApiController]
	public class SurgeriesController : ControllerBase
	{
		private readonly ApplicationDbContext _dbContext;
		public SurgeriesController(ApplicationDbContext dbContext)
		{
			_dbContext = dbContext;
		}
		[HttpGet("GetSurgeries")]
		public async Task<IActionResult> GetSurgeries()
		{
			try
			{
				var model = _dbContext.Surgeries.Where(c => !c.Deleted).Select(c => new { c.SurgeryId, c.TitleAR, c.TitleEN }).ToList();
				return Ok(new ResponseVM() { StatusCode = HttpStatusCode.OK, Data = model });
			}
			catch (Exception)
			{
				return Ok(new ResponseVM() { StatusCode = HttpStatusCode.BadRequest, ErrorMessageEn = $"An error has occurred, please try again later", ErrorMessageAr = "لقد حدث خطأ، يرجى المحاولة في وقت لاحق" });
			}

		}
		[HttpPost("AddSurgeryUser")]
		[Authorize]
		public async Task<IActionResult> AddSurgery(int SurgeryId, long UserFamilyId)
		{
			try
			{
				if (SurgeryId > 0 && UserFamilyId > 0)
				{
					var Exist = _dbContext.UserFamilySurgeries.FirstOrDefault(c => c.SurgeryId == SurgeryId && c.UserFamilyId == UserFamilyId);
					if (Exist is null)
					{
						UserFamilySurgery UserFamilySurgery = new UserFamilySurgery()
						{
							SurgeryId = SurgeryId,
                            UserFamilyId = UserFamilyId,
							Deleted = false
						};
						_dbContext.UserFamilySurgeries.Add(UserFamilySurgery);
					}
					else
					{
						Exist.Deleted = false;
					}

					_dbContext.SaveChanges();
					var model = _dbContext.UserFamilySurgeries.Include(c => c.Surgery).Where(c => !c.Deleted && c.UserFamilyId == UserFamilyId).Select(c => new { c.SurgeryId, c.Surgery.TitleAR, c.Surgery.TitleEN }).ToList();

					return Ok(new ResponseVM() { StatusCode = HttpStatusCode.OK, Data = model });
				}


				return Ok(new ResponseVM() { StatusCode = HttpStatusCode.BadRequest, ErrorMessageEn = $"Please verify your input", ErrorMessageAr = "يرجى التحقق من المدخلات الخاصة بك" });

			}
			catch (Exception)
			{
				return Ok(new ResponseVM() { StatusCode = HttpStatusCode.BadRequest, ErrorMessageEn = $"An error has occurred, please try again later", ErrorMessageAr = "لقد حدث خطأ، يرجى المحاولة في وقت لاحق" });
			}

		}
		[HttpGet("GetSurgeriesUser")]
		public async Task<IActionResult> GetSurgeries(long UserFamilyId)
		{
			try
			{
				var model = _dbContext.UserFamilySurgeries.Where(c => !c.Deleted && c.UserFamilyId == UserFamilyId).Include(c => c.Surgery).Select(c => new { c.SurgeryId, c.Surgery.TitleAR, c.Surgery.TitleEN }).ToList();
				return Ok(new ResponseVM() { StatusCode = HttpStatusCode.OK, Data = model });
			}
			catch (Exception)
			{
				return Ok(new ResponseVM() { StatusCode = HttpStatusCode.BadRequest, ErrorMessageEn = $"An error has occurred, please try again later", ErrorMessageAr = "لقد حدث خطأ، يرجى المحاولة في وقت لاحق" });
			}

		}

		[HttpDelete("DeleteSurgeryUser")]
		[Authorize]
		public async Task<IActionResult> DeleteSurgery(int SurgeryId, long UserFamilyId)
		{
			try
			{
				if (SurgeryId > 0 && UserFamilyId > 0)
				{
					var Surgery = _dbContext.UserFamilySurgeries.FirstOrDefault(c => c.SurgeryId == SurgeryId && c.UserFamilyId == UserFamilyId);
					if (Surgery is not null)
					{
						Surgery.Deleted = true;
						_dbContext.SaveChanges();
						var model = _dbContext.UserFamilySurgeries.Include(c => c.Surgery).Where(c => !c.Deleted && c.UserFamilyId == UserFamilyId).Select(c => new { c.SurgeryId, c.Surgery.TitleAR, c.Surgery.TitleEN }).ToList();

						return Ok(new ResponseVM() { StatusCode = HttpStatusCode.OK, Data = model });
					}
					return Ok(new ResponseVM() { StatusCode = HttpStatusCode.BadRequest, ErrorMessageEn = $"An error has occurred, please try again later", ErrorMessageAr = "لقد حدث خطأ، يرجى المحاولة في وقت لاحق" });

				}


				return Ok(new ResponseVM() { StatusCode = HttpStatusCode.BadRequest, ErrorMessageEn = $"Please verify your input", ErrorMessageAr = "يرجى التحقق من المدخلات الخاصة بك" });

			}
			catch (Exception)
			{
				return Ok(new ResponseVM() { StatusCode = HttpStatusCode.BadRequest, ErrorMessageEn = $"An error has occurred, please try again later", ErrorMessageAr = "لقد حدث خطأ، يرجى المحاولة في وقت لاحق" });
			}

		}
	}
}
