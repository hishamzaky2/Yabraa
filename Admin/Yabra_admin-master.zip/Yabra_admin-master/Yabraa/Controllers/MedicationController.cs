﻿using Microsoft.AspNetCore.Authorization;
using Microsoft.AspNetCore.Http;
using Microsoft.AspNetCore.Mvc;
using Microsoft.EntityFrameworkCore;
using System.Linq;
using System.Net;
using System.Security.Claims;
using Yabraa.Helpers;
using Yabraa.Services;
using YabraaEF;
using YabraaEF.Models;

namespace Yabraa.Controllers
{
	[Route("api/[controller]")]
	[ApiController]
	public class MedicationController : ControllerBase
	{
		private readonly ApplicationDbContext _dbContext;
		public MedicationController(ApplicationDbContext dbContext)
		{
			_dbContext = dbContext;
		}
		[HttpGet("GetMedications")]
		public async Task<IActionResult> GetMedications()
		{
			try
			{			
				var model = _dbContext.Medications.Where(c=>!c.Deleted).Select(c => new { c.MedicationId, c.TitleAR, c.TitleEN }).ToList();
				return Ok(new ResponseVM() { StatusCode = HttpStatusCode.OK, Data = model });
			}
			catch (Exception)
			{
				return Ok(new ResponseVM() { StatusCode = HttpStatusCode.BadRequest, ErrorMessageEn = $"An error has occurred, please try again later", ErrorMessageAr = "لقد حدث خطأ، يرجى المحاولة في وقت لاحق" });
			}

		}
		[HttpGet("GetCurrentMedicationsUser")]
		public async Task<IActionResult> GetCurrentMedicationsUser(long UserFamilyId)
		{
			try
			{
				var model = _dbContext.UserFamilyCurrentMedications.Where(c => !c.Deleted && c.UserFamilyId == UserFamilyId).Include(c=>c.Medication).Select(c => new { c.MedicationId, c.Medication.TitleAR, c.Medication.TitleEN }).ToList();
				return Ok(new ResponseVM() { StatusCode = HttpStatusCode.OK, Data = model });
			}
			catch (Exception)
			{
				return Ok(new ResponseVM() { StatusCode = HttpStatusCode.BadRequest, ErrorMessageEn = $"An error has occurred, please try again later", ErrorMessageAr = "لقد حدث خطأ، يرجى المحاولة في وقت لاحق" });
			}

		}
		[HttpGet("GetPastMedicationsUser")]
		public async Task<IActionResult> GetPastMedicationsUser(long UserFamilyId)
		{
			try
			{
				var model = _dbContext.UserFamilyPastMedications.Where(c => !c.Deleted && c.UserFamilyId == UserFamilyId).Include(c => c.Medication).Select(c => new { c.MedicationId, c.Medication.TitleAR, c.Medication.TitleEN }).ToList();
				return Ok(new ResponseVM() { StatusCode = HttpStatusCode.OK, Data = model });
			}
			catch (Exception)
			{
				return Ok(new ResponseVM() { StatusCode = HttpStatusCode.BadRequest, ErrorMessageEn = $"An error has occurred, please try again later", ErrorMessageAr = "لقد حدث خطأ، يرجى المحاولة في وقت لاحق" });
			}

		}

		[HttpPost("AddCurrentMedicationUser")]
		[Authorize]
		public async Task<IActionResult> AddCurrentMedicationUser(int MedicationId, long UserFamilyId)
		{
			try
			{  
				if (MedicationId > 0 && UserFamilyId > 0) 
				{
					var Exist = _dbContext.UserFamilyCurrentMedications.FirstOrDefault(c => c.MedicationId == MedicationId &&c.UserFamilyId == UserFamilyId);
					if (Exist is null)
					{
						UserFamilyCurrentMedication UserFamilyCurrentMedication = new UserFamilyCurrentMedication()
						{
							MedicationId = MedicationId,
                            UserFamilyId = UserFamilyId,
							Deleted = false
						};
						_dbContext.UserFamilyCurrentMedications.Add(UserFamilyCurrentMedication);
					}
					else
					{
						Exist.Deleted = false;	
					}
					
					_dbContext.SaveChanges();
					var model = _dbContext.UserFamilyCurrentMedications.Include(c => c.Medication).Where(c => !c.Deleted && c.UserFamilyId == UserFamilyId).Select(c => new { c.MedicationId, c.Medication.TitleAR, c.Medication.TitleEN }).ToList();

					return Ok(new ResponseVM() { StatusCode = HttpStatusCode.OK, Data = model });
				}
				
			
				return Ok(new ResponseVM() { StatusCode = HttpStatusCode.BadRequest, ErrorMessageEn = $"Please verify your input", ErrorMessageAr = "يرجى التحقق من المدخلات الخاصة بك" });

			}
			catch (Exception)
			{
				return Ok(new ResponseVM() { StatusCode = HttpStatusCode.BadRequest, ErrorMessageEn = $"An error has occurred, please try again later", ErrorMessageAr = "لقد حدث خطأ، يرجى المحاولة في وقت لاحق" });
			}

		}

		[HttpPost("AddPastMedicationUser")]
		[Authorize]
		public async Task<IActionResult> AddPastMedicationUser(int MedicationId, long UserFamilyId)
		{
			try
			{
				if (MedicationId > 0 && UserFamilyId > 0)
				{
					var Exist = _dbContext.UserFamilyPastMedications.FirstOrDefault(c => c.MedicationId == MedicationId && c.UserFamilyId == UserFamilyId);
					if (Exist is null)
					{
						UserFamilyPastMedication UserFamilyPastMedication = new UserFamilyPastMedication()
						{
							MedicationId = MedicationId,
                            UserFamilyId = UserFamilyId,
							Deleted = false
						};
						_dbContext.UserFamilyPastMedications.Add(UserFamilyPastMedication);
					}
					else {
						Exist.Deleted = false;
					}

					_dbContext.SaveChanges();
					var model = _dbContext.UserFamilyPastMedications.Include(c => c.Medication).Where(c => !c.Deleted && c.UserFamilyId == UserFamilyId).Select(c => new { c.MedicationId, c.Medication.TitleAR, c.Medication.TitleEN }).ToList();

					return Ok(new ResponseVM() { StatusCode = HttpStatusCode.OK, Data = model });
				}


				return Ok(new ResponseVM() { StatusCode = HttpStatusCode.BadRequest, ErrorMessageEn = $"Please verify your input", ErrorMessageAr = "يرجى التحقق من المدخلات الخاصة بك" });

			}
			catch (Exception)
			{
				return Ok(new ResponseVM() { StatusCode = HttpStatusCode.BadRequest, ErrorMessageEn = $"An error has occurred, please try again later", ErrorMessageAr = "لقد حدث خطأ، يرجى المحاولة في وقت لاحق" });
			}

		}

		[HttpDelete("DeletePastMedicationUser")]
		[Authorize]
		public async Task<IActionResult> DeletePastMedication(int MedicationId, long UserFamilyId)
		{
			try
			{
				if (MedicationId > 0 && UserFamilyId > 0)
				{
					var PastMedication = _dbContext.UserFamilyPastMedications.FirstOrDefault(c => c.MedicationId == MedicationId && c.UserFamilyId == UserFamilyId);
					if (PastMedication is not null )
					{
						PastMedication.Deleted = true;
						_dbContext.SaveChanges();
						var model = _dbContext.UserFamilyPastMedications.Include(c => c.Medication).Where(c => !c.Deleted && c.UserFamilyId == UserFamilyId).Select(c => new { c.MedicationId, c.Medication.TitleAR, c.Medication.TitleEN }).ToList();

						return Ok(new ResponseVM() { StatusCode = HttpStatusCode.OK, Data = model });
					}
					return Ok(new ResponseVM() { StatusCode = HttpStatusCode.BadRequest, ErrorMessageEn = $"An error has occurred, please try again later", ErrorMessageAr = "لقد حدث خطأ، يرجى المحاولة في وقت لاحق" });

				}


				return Ok(new ResponseVM() { StatusCode = HttpStatusCode.BadRequest, ErrorMessageEn = $"Please verify your input", ErrorMessageAr = "يرجى التحقق من المدخلات الخاصة بك" });

			}
			catch (Exception)
			{
				return Ok(new ResponseVM() { StatusCode = HttpStatusCode.BadRequest, ErrorMessageEn = $"An error has occurred, please try again later", ErrorMessageAr = "لقد حدث خطأ، يرجى المحاولة في وقت لاحق" });
			}

		}

		[HttpDelete("DeleteCurrentMedicationUser")]
		[Authorize]
		public async Task<IActionResult> DeleteCurrentMedication(int MedicationId, long UserFamilyId)
		{
			try
			{
				if (MedicationId > 0 && UserFamilyId > 0)
				{
					var CurrentMedication = _dbContext.UserFamilyCurrentMedications.FirstOrDefault(c => c.MedicationId == MedicationId && c.UserFamilyId == UserFamilyId);
					if (CurrentMedication is not null)
					{
						CurrentMedication.Deleted = true;
						_dbContext.SaveChanges();
						var model = _dbContext.UserFamilyCurrentMedications.Include(c=>c.Medication).Where(c => !c.Deleted && c.UserFamilyId == UserFamilyId).Select(c=> new {c.MedicationId,c.Medication.TitleAR,c.Medication.TitleEN}).ToList();
						return Ok(new ResponseVM() { StatusCode = HttpStatusCode.OK, Data = model });
					}
					return Ok(new ResponseVM() { StatusCode = HttpStatusCode.BadRequest, ErrorMessageEn = $"An error has occurred, please try again later", ErrorMessageAr = "لقد حدث خطأ، يرجى المحاولة في وقت لاحق" });

				}


				return Ok(new ResponseVM() { StatusCode = HttpStatusCode.BadRequest, ErrorMessageEn = $"Please verify your input", ErrorMessageAr = "يرجى التحقق من المدخلات الخاصة بك" });

			}
			catch (Exception)
			{
				return Ok(new ResponseVM() { StatusCode = HttpStatusCode.BadRequest, ErrorMessageEn = $"An error has occurred, please try again later", ErrorMessageAr = "لقد حدث خطأ، يرجى المحاولة في وقت لاحق" });
			}

		}
	}
}
