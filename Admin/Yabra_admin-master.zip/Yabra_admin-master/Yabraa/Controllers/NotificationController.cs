﻿using Microsoft.AspNetCore.Authorization;
using Microsoft.AspNetCore.Http;
using Microsoft.AspNetCore.Mvc;
using Microsoft.EntityFrameworkCore;
using System.ComponentModel.DataAnnotations;
using System.Globalization;
using System.Net;
using System.Security.Claims;
using System.Threading;
using Twilio.TwiML.Messaging;
using Yabraa.DTOs;
using Yabraa.Helpers;
using YabraaEF;
using YabraaEF.Models;

namespace Yabraa.Controllers
{
    [Route("api/[controller]")]
    [ApiController]
    [Authorize]
    public class NotificationController : ControllerBase
    {
        private readonly ApplicationDbContext _dbContext;
        public NotificationController(ApplicationDbContext dbContext)
        {
            _dbContext=dbContext;
        }
        [HttpGet("GetNotifications")]
        public async Task<IActionResult> GetNotifications(int pageNumber,int pageSize)
        {
            try
            {
                NotificationDTO model = new NotificationDTO();

                string userName = User.FindFirstValue(ClaimTypes.NameIdentifier);
                var userId = _dbContext.Users.FirstOrDefault(c => c.UserName == userName).Id;
                if (!string.IsNullOrEmpty(userId))
                {
                   var items = _dbContext.UserNotifications.Where(c => c.ApplicationUserId == userId).OrderByDescending(c => c.UserNotificationId)
                        .Skip(((pageNumber - 1) * pageSize)).Take(pageSize)
                        .Select(c => new NotificationItemDTO { 
                            bodyAR= c.BodyAR,
                            bodyEn= c.BodyEn,
                            isRead=c.isRead,
                            notificationId=c.UserNotificationId,
                            titleAR= c.TitleAR,
                            titleEn= c.TitleEn,
                        }
                      ).ToList();
                    model.notifications = items;
                    model.pageNumber = pageNumber;
                    model.pageSize = pageSize;
                    model.count = items.Count;
                    model.isALLRead = _dbContext.UserNotifications.FirstOrDefault(c => c.ApplicationUserId == userId && !c.isRead) != null ? false: true;
                    return Ok(new ResponseVM() { StatusCode = HttpStatusCode.OK, Data = model });

                }
                return Ok(new ResponseVM() { StatusCode = HttpStatusCode.BadRequest, ErrorMessageEn = $"An error has occurred, please try again later", ErrorMessageAr = "لقد حدث خطأ، يرجى المحاولة في وقت لاحق" });

            }
            catch (Exception)
            {
                return Ok(new ResponseVM() { StatusCode = HttpStatusCode.BadRequest, ErrorMessageEn = $"An error has occurred, please try again later", ErrorMessageAr = "لقد حدث خطأ، يرجى المحاولة في وقت لاحق" });
            }


        }
        [HttpGet("ReadNotification")]
        public async Task<IActionResult> ReadNotification(long notificationId)
        {
            try
            {
                var Notification = _dbContext.UserNotifications.FirstOrDefault(c => c.UserNotificationId == notificationId);
                if (Notification is not null)
                {
                    Notification.isRead = true;
                    _dbContext.SaveChanges();

                    return Ok(new ResponseVM()
                    {
                        StatusCode = HttpStatusCode.OK,
                        Data = new NotificationItemDTO
                        {
                            bodyAR = Notification.BodyAR,
                            bodyEn = Notification.BodyEn,
                            isRead = Notification.isRead,
                            notificationId = Notification.UserNotificationId,
                            titleAR = Notification.TitleAR,
                            titleEn = Notification.TitleEn,
                        }
                    });
                }
                return Ok(new ResponseVM() { StatusCode = HttpStatusCode.BadRequest, ErrorMessageEn = $"An error has occurred, please try again later", ErrorMessageAr = "لقد حدث خطأ، يرجى المحاولة في وقت لاحق" });

            }
            catch (Exception)
            {
                return Ok(new ResponseVM() { StatusCode = HttpStatusCode.BadRequest, ErrorMessageEn = $"An error has occurred, please try again later", ErrorMessageAr = "لقد حدث خطأ، يرجى المحاولة في وقت لاحق" });
            }


        }

    }
}
