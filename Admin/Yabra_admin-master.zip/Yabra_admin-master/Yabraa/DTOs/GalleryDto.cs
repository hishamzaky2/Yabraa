﻿namespace Yabraa.DTOs
{
    public class GalleryDto
    {
        public int Id { get; set; }
        public string Path { get; set; }

    }
}
