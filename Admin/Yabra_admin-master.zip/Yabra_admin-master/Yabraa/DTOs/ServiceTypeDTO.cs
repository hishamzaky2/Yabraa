﻿namespace Yabraa.DTOs
{
    public class ServiceTypeDTO
    {
        public int ServiceTypeId { get; set; }
        public string Name { get; set; }
        public string Description { get; set; }
    }
}
