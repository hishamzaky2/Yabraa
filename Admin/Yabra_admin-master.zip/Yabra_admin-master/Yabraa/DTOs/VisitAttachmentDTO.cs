﻿namespace Yabraa.DTOs
{
    public class VisitAttachmentDTO
    {
        public string Title { get; set; }
        public string Path { get; set; }
        public DateTime CreateDTs { get; set; }
    }
}
