﻿namespace Yabraa.DTOs
{
    public class PhoneVerificationCodeDto
    {
        public string PhoneNumber { get; set; }
        public string Code { get; set; }
        public string Password { get; set; }

    }
}
