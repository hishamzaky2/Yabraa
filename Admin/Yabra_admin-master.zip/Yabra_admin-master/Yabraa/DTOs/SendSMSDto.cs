﻿namespace Yabraa.DTOs
{
    public class SendSMSDto
    {
        public string MobileNumber { get; set; }
        public string Body { get; set; }
    }
}
