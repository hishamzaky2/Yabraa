﻿namespace Yabraa.DTOs
{
    public class FirebaseDTO
    {
        public string FirebaseToken { get; set; }
    }
}
