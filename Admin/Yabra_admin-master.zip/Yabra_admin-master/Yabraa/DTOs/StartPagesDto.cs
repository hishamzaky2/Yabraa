﻿namespace Yabraa.DTOs
{
    public class StartPagesDto
    {
        public int Id { get; set; }
        public string TitleEn { get; set; }
        public string SubTitleEn { get; set; }
        public string TitleAr { get; set; }
        public string SubTitleAr { get; set; }
        public string Path { get; set; }
    }
}
