﻿namespace Yabraa.DTOs
{
    public class MainServiceDto
    {
        public List<ServiceDto> OneDimensionalService { get; set; }
        public List<TwoDimensionalServiceDto> TwoDimensionalService { get; set; }
    }
}
