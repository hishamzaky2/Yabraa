﻿namespace Yabraa.DTOs
{
    public class NotificationDTO
    {
        public int pageNumber { get; set; }
        public int pageSize { get; set; }
        public int count { get; set; }
        public bool isALLRead { get; set; }
        public List<NotificationItemDTO> notifications { get; set; }
    }
    public class NotificationItemDTO
    {
        public long notificationId { get; set; }
        public string titleAR { get; set; }
        public string titleEn { get; set; }
        public string bodyAR { get; set; }
        public string bodyEn { get; set; }
        public bool isRead { get; set; }
    }
}
