﻿namespace Yabraa.DTOs
{
    public class PaymentMethodDTO
    {
        public int PaymentMethodId { get; set; }
        public string Name { get; set; }

    }
}
