﻿namespace Yabraa.DTOs
{
    public class NationalityDTO
    {
        public string CountryCode { get; set; }     
        public string CountryEnNationality { get; set; }
        public string CountryArNationality { get; set; }
    }
}
