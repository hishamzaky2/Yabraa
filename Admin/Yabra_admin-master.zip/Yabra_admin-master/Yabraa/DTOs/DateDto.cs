﻿namespace Yabraa.DTOs
{
    public class DateDto
    {
        public int Year { get; set; }
        public string MonthName { get; set; }
        public string MonthNumber { get; set; }
        public string MonthShortName  { get; set; }
        public string DayName { get; set; }
        public string DayOfMonth { get; set; }

    }
}
