﻿namespace Yabraa.DTOs
{
    public class RevokeToken
    {
        public string? Token { get; set; }
    }
}
