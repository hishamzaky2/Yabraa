﻿using Microsoft.Build.Framework;

namespace Yabraa.DTOs
{
    public class AppointmentEditDto
    {
        public long AppointmentId { get; set; }        
        public double? LocationLongitude { get; set; }        
        public double? LocationLatitude { get; set; }
        public double? LocationAltitude { get; set; }
        public string? Notes { get; set; }

        public int ServiceTypeId { get; set; }
    }
}
