﻿namespace Yabraa.DTOs
{
    public class LoginOTPDTo
    {
        public string PhoneNumber { get; set; }
        public string Code { get; set; }
    }
}
