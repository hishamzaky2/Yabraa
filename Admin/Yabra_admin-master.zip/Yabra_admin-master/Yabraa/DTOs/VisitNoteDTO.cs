﻿namespace Yabraa.DTOs
{
    public class VisitNoteDTO
    {
        public string Title { get; set; }
        public string Description { get; set; }
        public DateTime CreateDTs { get; set; }
    }
}
