package com.yabraa.medical.feature.fragments.select_date_and_time.domain.repository

import kotlinx.coroutines.flow.Flow
import com.core.shared.state.State
import com.yabraa.medical.feature.fragments.select_date_and_time.data.response.DatesResponseDto

interface DatesRepository {

    suspend fun getDates(): Flow<State<DatesResponseDto>>
}