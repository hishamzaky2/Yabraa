package com.yabraa.medical.feature.fragments.home.presentation

import android.annotation.SuppressLint
import android.os.Bundle
import android.view.View
import androidx.core.view.isVisible
import androidx.core.widget.doAfterTextChanged
import androidx.fragment.app.viewModels
import androidx.hilt.navigation.fragment.hiltNavGraphViewModels
import androidx.lifecycle.Lifecycle
import androidx.lifecycle.flowWithLifecycle
import androidx.lifecycle.lifecycleScope
import androidx.navigation.fragment.findNavController
import androidx.recyclerview.widget.LinearLayoutManager
import androidx.recyclerview.widget.LinearSnapHelper
import com.yabraa.medical.R
import com.yabraa.medical.core.base_fragment.BaseFragment
import com.yabraa.medical.core.base_fragment.navigate
import com.yabraa.medical.core.base_fragment.setOnGoToConnectionSettingClicked
import com.core.shared.error.OperationMessage
import com.core.shared.error.YabraaError
import com.core.shared.state.State
import com.core.shared.utils.CommonUtils.handleExpirationDate
import com.core.shared.utils.CommonUtils.handleTimerCallBack
import com.core.shared.utils.CommonUtils.load
import com.yabraa.medical.core.utils.containsArabicLetters
import com.yabraa.medical.core.utils.custom_views.confirmation_appointment.ConfirmationAppointmentHandler
import com.yabraa.medical.core.utils.custom_views.yabraa_bar.YabraaBarHandler
import com.yabraa.medical.core.utils.dialog.yabraa_dialog.YabraaDialogBuilder
import com.yabraa.medical.core.utils.getErrorMessage
import com.yabraa.medical.databinding.FragmentHomeBinding
import com.yabraa.medical.feature.fragments.common.domain.model.ErrorMessageUi
import com.yabraa.medical.feature.fragments.common.domain.viewmodel.TransactionViewModel
import com.yabraa.medical.feature.fragments.home.data.model.response.services_details_response.OneDimensionalService
import com.yabraa.medical.feature.fragments.home.domain.model.ServiceTypeName.NORMAL
import com.yabraa.medical.feature.fragments.home.domain.model.ServiceTypeName.VIRTUAL
import com.yabraa.medical.feature.fragments.home.domain.viewmodel.HomeViewModel
import com.yabraa.medical.feature.fragments.home.presentation.adapter.GalleryAdapter
import com.yabraa.medical.feature.fragments.home.presentation.adapter.ServicesDetailsAdapter
import com.yabraa.medical.feature.fragments.notification.notification_hisotry.data.model.request.notification_history_request.NotificationHistoryRequestDto
import dagger.hilt.android.AndroidEntryPoint
import kotlinx.coroutines.FlowPreview
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.collectLatest
import kotlinx.coroutines.flow.debounce
import kotlinx.coroutines.launch
import timber.log.Timber

const val SCROLL_DELAY = 3000L
const val PERIOD_TIME = 3000L
const val NOTIFICATION_STATUS_PAGE_NUMBER = 1
const val NOTIFICATION_STATUS_PAGE_SIZE = 1

@AndroidEntryPoint
class HomeFragment : BaseFragment<FragmentHomeBinding>() {

    override val binding by lazy { FragmentHomeBinding.inflate(layoutInflater) }
    private val viewModel: TransactionViewModel by hiltNavGraphViewModels(R.id.mainNavGraph)
    private val homeViewModel: HomeViewModel by viewModels()
    private lateinit var galleryAdapter: GalleryAdapter

    private val searchOnServicesFlow = MutableStateFlow(OneDimensionalService())
    private val servicesDetails get() = viewModel.getOneDimensionServices()
    private lateinit var servicesDetailsAdapter: ServicesDetailsAdapter

    private val isHomeFragment get() = findNavController().currentDestination?.id == R.id.homeFragment
    private val serviceTypeName get() = if (isHomeFragment) NORMAL.typeValue else VIRTUAL.typeValue
    private val serviceTypeId get() = homeViewModel.getServiceTypeId(serviceTypeName)

    private val isReadNotification get() = homeViewModel.isReadAllNotification() ?: false

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        showExpirationDateError()
    }

    override fun onViewCreated(view: View, savedInstanceState: Bundle?) {
        super.onViewCreated(view, savedInstanceState)
        binding.handleNetworkConnection()
        binding.setUpViews()
    }

    override fun onStart() {
        super.onStart()
        viewModel.clearAllListOfTransaction()
    }

    override fun onResume() {
        super.onResume()
        yabraaBarView?.setUpYabraaBarViews()
        confirmationView?.setUpConfirmationViews()
        showBottomNavigation(true)
    }

    private fun FragmentHomeBinding.setUpViews() {
        internetConnection.goToSettingBtn.setOnGoToConnectionSettingClicked(requireActivity())
        setOnNotificationClicked()
        lifecycleScope.apply {
            launch { collectOnNotificationStatusResponseStat() }
        }
        handleSearchService()
        setOnCloseGalleryRootBtn()
        //TODO WILL BE REMOVE WHEN HANDLING REMOTE VISIT
        handleRemoteVisitMessage(isHomeFragment)
    }


    @SuppressLint("FragmentLiveDataObserve")
    private fun FragmentHomeBinding.handleNetworkConnection() {
        if (!isHomeFragment) return //TODO WILL BE REMOVE THIS CONDITION WHEN HANDLING REMOTE VISIT
        connectivityManager?.isNetworkConnected?.observe(viewLifecycleOwner) {
            handleConnectionViewVisibility(it)
            if (!it) return@observe
            setUpGetData()
        }
    }

    private fun FragmentHomeBinding.handleConnectionViewVisibility(isVisible: Boolean) {
        homeGroup.isVisible = isVisible
        homeBarGroup.isVisible = isVisible
        internetConnection.root.isVisible = !isVisible
    }


    private fun FragmentHomeBinding.setOnNotificationClicked() =
        notificationStatusIv.setOnClickListener { navigateToNotificationHistoryFragment() }

    private fun navigateToNotificationHistoryFragment() {
        val actionId = if (isHomeFragment) {
            R.id.actionHomeFragmentToNotificationHistoryFragment
        } else {
            R.id.actionRemoteVisitFragmentToNotificationHistoryFragment
        }
        navigate(actionId)
    }

    private fun setUpGetData() {
        homeViewModel.getNotificationStatus(getNotificationHistoryRequestDto())
        homeViewModel.getServiceType()
        homeViewModel.getGallery()
    }

    private fun getNotificationHistoryRequestDto() = NotificationHistoryRequestDto(
        pageNumber = NOTIFICATION_STATUS_PAGE_NUMBER,
        pageSize = NOTIFICATION_STATUS_PAGE_SIZE
    )

    private suspend fun collectOnNotificationStatusResponseStat() {
        homeViewModel.notificationStatusResponse.collectLatest {
            hideProgressDialog()
            when (it) {
                is State.Error -> it.error.handleHomeResponseError()
                is State.Initial -> {}
                is State.Loading -> showProgressDialog()
                is State.Success -> {
                    handleNotificationIconState()
                    collectOnServiceTypeResponseState()
                }
            }
        }
    }

    private fun handleNotificationIconState() {
        val imageResource = if (isReadNotification) {
            R.drawable.ic_vector_notification
        } else {
            R.drawable.ic_vector_notification_with_alert

        }
        binding.notificationStatusIv.setImageResource(imageResource)
    }

    private suspend fun collectOnServiceTypeResponseState() {
        homeViewModel.serviceTypeResponseState.collect {
            hideProgressDialog()
            when (it) {
                is State.Error -> it.error.handleHomeResponseError()
                is State.Initial -> {}
                is State.Loading -> showProgressDialog()
                is State.Success -> {
                    viewModel.getServicesDetails(serviceTypeId)
                    collectOnGalleryResponseState()
                }
            }
        }
    }

    private suspend fun collectOnGalleryResponseState() {
        homeViewModel.galleryResponseState.flowWithLifecycle(lifecycle, Lifecycle.State.RESUMED)
            .collect {
                hideProgressDialog()
                when (it) {
                    is State.Initial -> {}
                    is State.Error -> it.error.handleHomeResponseError()
                    is State.Loading -> showProgressDialog()
                    is State.Success -> {
                        setGalleryAdapter(it.data?.galleryDataResponse?.galleryImages)
                        collectOnServicesDetailsResponseState()
                    }
                }
            }
    }

    private fun setGalleryAdapter(data: List<String>?) {
        val galleryImages = data ?: return
        val snapHelper = LinearSnapHelper()
        val layoutManager = binding.galleryRV.layoutManager as LinearLayoutManager
        galleryAdapter = GalleryAdapter(galleryImages) { binding.handleShowGalleryImage(it) }
        binding.galleryRV.adapter = galleryAdapter
        if (binding.galleryRV.onFlingListener != null) return
        snapHelper.attachToRecyclerView(binding.galleryRV)
        handleTimerCallBack(SCROLL_DELAY, PERIOD_TIME) {
            val findFirstPosition = layoutManager.findFirstCompletelyVisibleItemPosition()
            if (findFirstPosition < (galleryAdapter.itemCount - 1)) {
                binding.galleryRV.smoothScrollToPosition(findFirstPosition + 1)
                return@handleTimerCallBack
            }
            binding.galleryRV.smoothScrollToPosition(0)
        }
    }

    private fun FragmentHomeBinding.handleShowGalleryImage(image: String) {
        previewImage.galleryImageRoot.isVisible = true
        previewImage.showGalleryIv.load(requireContext(), image)
    }

    private fun FragmentHomeBinding.setOnCloseGalleryRootBtn() {
        previewImage.closeGalleryImageBtn.setOnClickListener {
            handleGalleryRootVisibility(false)
        }
    }

    private fun FragmentHomeBinding.handleGalleryRootVisibility(isVisible: Boolean) {
        previewImage.galleryImageRoot.isVisible = isVisible
    }

    private suspend fun collectOnServicesDetailsResponseState() {
        viewModel.servicesDetailsResponseState.flowWithLifecycle(lifecycle, Lifecycle.State.RESUMED)
            .collect {
                hideProgressDialog()
                when (it) {
                    is State.Error -> it.error.handleHomeResponseError()
                    is State.Initial -> {}
                    is State.Loading -> showProgressDialog()
                    is State.Success -> {
                        binding.setServicesAdapter()
                        observeSearchFlow()
                    }
                }
            }
    }

    private fun YabraaError.handleHomeResponseError() {
        val errorMessageUi = ErrorMessageUi(logMessageEn, logMessageAr)
        handleError {
            when (exception) {
                is OperationMessage -> showHomeResponseErrorPopup(errorMessageUi)
            }
        }
    }

    private fun showHomeResponseErrorPopup(errorMessageUi: ErrorMessageUi) {
        val errorMessage = getErrorMessage(errorMessageUi)
        YabraaDialogBuilder(requireActivity())
            .setIcon(R.drawable.ic_vector_error)
            .setTitle(R.string.warning)
            .setMessage(errorMessage)
            .setTopButton(R.string.ok) {
                setUpGetData()
            }
            .setCancelable(false)
            .show()
    }

    private fun FragmentHomeBinding.setServicesAdapter() {
        servicesDetailsAdapter = ServicesDetailsAdapter(servicesDetails) {
            navigateToFilterScreen(it)
        }
        servicesDetailsRV.adapter = servicesDetailsAdapter
    }

    @OptIn(FlowPreview::class)
    private suspend fun observeSearchFlow() =
        searchOnServicesFlow.debounce(500).collect {
            try {
                it.getSearchServices()
            } catch (e: Exception) {
                Timber.e(e)
            }
        }


    private fun OneDimensionalService.getSearchServices() {
        if (nameAR.isNullOrBlank() && nameEN.isNullOrBlank()) {
            binding.setServicesAdapter()
            return
        }
        val nationalityList = viewModel.getOneDimensionServicesByName(binding.searchEt.text.toString())
        nationalityList.setSearchServicesAdapter()
    }

    private fun List<OneDimensionalService>.setSearchServicesAdapter() {
        servicesDetailsAdapter = ServicesDetailsAdapter(this) {
            navigateToFilterScreen(it)
        }
        binding.servicesDetailsRV.adapter = servicesDetailsAdapter
    }

    private fun FragmentHomeBinding.handleSearchService() {
        searchEt.doAfterTextChanged { editable ->
            val text = editable.toString().trim()
            val searchServices = when {
                text.containsArabicLetters() -> OneDimensionalService(nameAR = text)
                else -> OneDimensionalService(nameEN = text)
            }
            searchOnServicesFlow.tryEmit(searchServices)
        }
    }

    private fun navigateToFilterScreen(serviceId: Long) = showDelayProgressDialog {
        setServicesModel(serviceId)
        if (serviceTypeName == NORMAL.typeValue) {
            navigate(R.id.actionHomeFragmentToFilterFragment)
            return@showDelayProgressDialog
        }
        navigate(R.id.actionRemoteFragmentToFilterFragment)
    }

    private fun setServicesModel(serviceId: Long) {
        viewModel.serviceId = serviceId
        viewModel.serviceTypeName = serviceTypeName
        viewModel.serviceTypeId = serviceTypeId
    }

    private fun YabraaBarHandler.setUpYabraaBarViews() {
        setYabraaBarVisibility(false)
    }

    private fun ConfirmationAppointmentHandler.setUpConfirmationViews() =
        setConfirmationAppointmentVisibility(false)


    private fun TransactionViewModel.clearAllListOfTransaction() {
        if (packagesTransactionList.isNotEmpty() || addPackageItemsList.isNotEmpty())
            handleClearAllLists()
    }

    private fun FragmentHomeBinding.handleRemoteVisitMessage(isVisible: Boolean) {
        homeGroup.isVisible = isVisible
        homeBarGroup.isVisible = isVisible
        remoteVisitMessage.remoteVisitRoot.isVisible = !isVisible
    }

    private fun showExpirationDateError() =
        tokenHandler.handleExpirationDate { showExpirationDatePopupError() }
}