package com.yabraa.medical.feature.fragments.patients.add_patient.di

import dagger.Module
import dagger.Provides
import dagger.hilt.InstallIn
import dagger.hilt.android.components.ViewModelComponent
import com.yabraa.medical.core.di.network_sevices.YabraaServices
import com.yabraa.medical.feature.fragments.patients.add_patient.data.repository.AddPatientRepositoryImpl
import com.yabraa.medical.feature.fragments.patients.add_patient.domain.repository.AddPatientRepository

@Module
@InstallIn(ViewModelComponent::class)
object AddPatientModule {

    @Provides
    fun provideAddPatientRepository(yabraaServices: YabraaServices): AddPatientRepository =
        AddPatientRepositoryImpl(yabraaServices)
}