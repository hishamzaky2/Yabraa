package com.yabraa.medical.feature.fragments.notification.notification_hisotry.data.model.request.notification_history_request

data class NotificationHistoryRequestDto(val pageNumber: Int, val pageSize: Int)
