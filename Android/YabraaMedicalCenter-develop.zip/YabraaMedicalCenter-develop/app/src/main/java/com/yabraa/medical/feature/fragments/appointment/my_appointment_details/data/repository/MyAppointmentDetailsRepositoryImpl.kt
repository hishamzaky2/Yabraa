package com.yabraa.medical.feature.fragments.appointment.my_appointment_details.data.repository

import com.yabraa.medical.core.base_repository.BaseRepository
import com.yabraa.medical.core.di.network_sevices.YabraaServices
import com.core.shared.state.State
import com.yabraa.medical.core.utils.getResponseMessageError
import com.yabraa.medical.feature.fragments.appointment.my_appointment_details.data.model.MyAppointmentDetailsResponseDto
import com.yabraa.medical.feature.fragments.appointment.my_appointment_details.domain.repository.MyAppointmentDetailsRepository
import kotlinx.coroutines.flow.flow
import retrofit2.Response
import javax.inject.Inject

const val TAG_MY_APPOINTMENT_DETAILS_RESPONSE = "TAG_MY_APPOINTMENT_DETAILS_RESPONSE"

class MyAppointmentDetailsRepositoryImpl @Inject constructor(private val yabraaServices: YabraaServices) :
    BaseRepository<Long, MyAppointmentDetailsResponseDto>(), MyAppointmentDetailsRepository {

    override suspend fun getAppointmentDetails(id: Long) = flow {
        emit(getOperationState(id))
    }

    override suspend fun performApiCall(requestDto: Long): State<MyAppointmentDetailsResponseDto> {
        val response = yabraaServices.getMyAppointmentDetailsByAppointmentId(requestDto)
        return handleGetMyAppointmentDetailsResponse(response)
    }

    private fun handleGetMyAppointmentDetailsResponse(response: Response<MyAppointmentDetailsResponseDto>): State<MyAppointmentDetailsResponseDto> {
        val responseBody = response.body()
        val errorMessageEn = responseBody?.errorMessageEn ?: ""
        val errorMessageAr = responseBody?.errorMessageAr ?: ""
        return when {
            response.isSuccessful && responseBody?.myAppointmentDetailsResponse != null -> State.Success(
                response.body()
            )

            response.isSuccessful && !responseBody?.errorMessageEn.isNullOrEmpty() -> getResponseMessageError(
                errorMessageEn = errorMessageEn,
                errorMessageAr = errorMessageAr,
                logTag = TAG_MY_APPOINTMENT_DETAILS_RESPONSE
            )

            else -> getNotSuccessfulResponseState(response)
        }
    }
}