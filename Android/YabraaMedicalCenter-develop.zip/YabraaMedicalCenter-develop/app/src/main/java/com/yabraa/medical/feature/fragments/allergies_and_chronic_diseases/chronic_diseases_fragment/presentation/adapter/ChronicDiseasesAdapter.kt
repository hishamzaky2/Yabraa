package com.yabraa.medical.feature.fragments.allergies_and_chronic_diseases.chronic_diseases_fragment.presentation.adapter

import android.view.LayoutInflater
import android.view.ViewGroup
import androidx.core.view.isVisible
import androidx.recyclerview.widget.RecyclerView
import com.core.shared.utils.CommonUtils
import com.yabraa.medical.databinding.ItemGeneralAllergiesAndDiseasesBinding
import com.yabraa.medical.feature.fragments.allergies_and_chronic_diseases.chronic_diseases_fragment.domain.model.ChronicDiseasesEntityModel

class ChronicDiseasesAdapter(
    private val chronicDiseasesItems: List<ChronicDiseasesEntityModel>,
    private val onAddItemClicked: (Long) -> Unit,
    private val onDeleteItemClicked: (Long) -> Unit
) : RecyclerView.Adapter<ChronicDiseasesAdapter.ViewHolder>() {


    override fun onCreateViewHolder(parent: ViewGroup, viewType: Int): ViewHolder {
        val binding = ItemGeneralAllergiesAndDiseasesBinding.inflate(
            LayoutInflater.from(parent.context),
            parent,
            false
        )
        return ViewHolder(binding)
    }

    override fun onBindViewHolder(viewHolder: ViewHolder, position: Int) {
        val chronicDiseasesItems = chronicDiseasesItems[position]
        viewHolder.bin(chronicDiseasesItems)
    }

    override fun getItemCount() = chronicDiseasesItems.size

    override fun getItemViewType(position: Int) = position


    inner class ViewHolder(val binding: ItemGeneralAllergiesAndDiseasesBinding) :
        RecyclerView.ViewHolder(binding.root) {
        fun bin(item: ChronicDiseasesEntityModel) {
            binding.setUpViews(item)
        }

        private fun ItemGeneralAllergiesAndDiseasesBinding.setUpViews(item: ChronicDiseasesEntityModel) {
            addBtn.setOnClickListener { onAddItemClicked(item.chronicDiseaseId) }
            deleteBtn.setOnClickListener { onDeleteItemClicked(item.chronicDiseaseId) }
            titleTv.text = CommonUtils.getLocalizedValue(item.titleEN, item.titleAR)
            handleAddBtnVisibility(item.isAdded)
        }

        private fun ItemGeneralAllergiesAndDiseasesBinding.handleAddBtnVisibility(isShow: Boolean) {
            checkIv.isVisible = isShow
            addBtn.isVisible = !isShow
            deleteBtn.isVisible = isShow
        }
    }
}