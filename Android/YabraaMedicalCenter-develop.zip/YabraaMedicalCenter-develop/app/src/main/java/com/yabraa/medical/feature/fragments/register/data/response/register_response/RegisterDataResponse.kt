package com.yabraa.medical.feature.fragments.register.data.response.register_response

import com.google.gson.annotations.SerializedName


data class RegisterDataResponse(
    @SerializedName("email")
    val email: String,
    @SerializedName("expiresOn")
    val expiresOn: String,
    @SerializedName("isAuthenticated")
    val isAuthenticated: Boolean,
    @SerializedName("message")
    val message: String? = null,
    @SerializedName("phoneNumber")
    val phoneNumber: String,
    @SerializedName("phoneNumberConfirmed")
    val phoneNumberConfirmed: Boolean,
    @SerializedName("token")
    val token: String,
    @SerializedName("username")
    val username: String
)