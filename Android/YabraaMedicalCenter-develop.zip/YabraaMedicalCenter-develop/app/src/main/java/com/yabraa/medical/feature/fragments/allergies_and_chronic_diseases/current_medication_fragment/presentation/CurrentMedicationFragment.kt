package com.yabraa.medical.feature.fragments.allergies_and_chronic_diseases.current_medication_fragment.presentation

import android.os.Bundle
import android.view.View
import androidx.core.view.isVisible
import androidx.fragment.app.viewModels
import androidx.lifecycle.lifecycleScope
import androidx.navigation.fragment.findNavController
import com.yabraa.medical.R
import com.yabraa.medical.core.base_fragment.BaseFragment
import com.core.shared.error.OperationMessage
import com.core.shared.error.YabraaError
import com.core.shared.state.State
import com.core.shared.utils.CommonUtils.handleExpirationDate
import com.yabraa.medical.core.utils.custom_views.yabraa_bar.YabraaBarHandler
import com.yabraa.medical.core.utils.dialog.yabraa_dialog.YabraaDialogBuilder
import com.yabraa.medical.core.utils.getErrorMessage
import com.yabraa.medical.databinding.FragmentGeneralAllergiesAndChronicDiseasesBinding
import com.yabraa.medical.feature.fragments.allergies_and_chronic_diseases.current_medication_fragment.data.model.request.CurrentMedicationRequestDto
import com.yabraa.medical.feature.fragments.allergies_and_chronic_diseases.current_medication_fragment.domain.viewmodel.CurrentMedicationViewModel
import com.yabraa.medical.feature.fragments.allergies_and_chronic_diseases.current_medication_fragment.presentation.adapter.CurrentMedicationAdapter
import com.yabraa.medical.feature.fragments.allergies_and_chronic_diseases.select_patient_fragment.presentation.USER_FAMILY_ID
import com.yabraa.medical.feature.fragments.common.domain.model.ErrorMessageUi
import dagger.hilt.android.AndroidEntryPoint
import kotlinx.coroutines.launch

@AndroidEntryPoint
class CurrentMedicationFragment :
    BaseFragment<FragmentGeneralAllergiesAndChronicDiseasesBinding>() {

    override val binding by lazy {
        FragmentGeneralAllergiesAndChronicDiseasesBinding.inflate(
            layoutInflater
        )
    }

    private val viewModel: CurrentMedicationViewModel by viewModels()
    lateinit var adapter: CurrentMedicationAdapter
    private val userFamilyId get() = arguments?.getLong(USER_FAMILY_ID) ?: 0L

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        showExpirationDateError()
    }

    override fun onViewCreated(view: View, savedInstanceState: Bundle?) {
        super.onViewCreated(view, savedInstanceState)
        handleInternetConnection()
        lifecycleScope.apply {
            launch { collectOnCurrentMedicationResponseState() }
            launch { collectOnAddCurrentMedicationResponseState() }
            launch { collectOnDeleteCurrentMedicationResponseState() }
        }
    }

    override fun onResume() {
        super.onResume()
        yabraaBarView?.setUpYabraaBarView()
        confirmationView?.setConfirmationAppointmentVisibility(false)
        showBottomNavigation(false)
    }

    private fun YabraaBarHandler.setUpYabraaBarView() {
        setYabraaBarVisibility(true)
        setClearAllVisibility(false)
        setBarTitle(R.string.currentMedication.localize())
        setOnBackArrowClicked { findNavController().popBackStack() }
    }

    private fun handleInternetConnection() {
        connectivityManager?.isNetworkConnected?.observe(viewLifecycleOwner) {
            binding.handleConnectionViewVisibility(it)
            if (!it) return@observe
            handelCurrentMedicationRequest()
        }
    }

    private fun FragmentGeneralAllergiesAndChronicDiseasesBinding.handleConnectionViewVisibility(
        isVisible: Boolean
    ) {
        generalRv.isVisible = isVisible
        internetConnection.root.isVisible = !isVisible
    }

    private suspend fun collectOnCurrentMedicationResponseState() {
        viewModel.currentMedicationResponseState.collect {
            hideProgressDialog()
            when (it) {
                is State.Error -> it.error.handleHomeResponseError()
                is State.Initial -> {}
                is State.Loading -> showProgressDialog()
                is State.Success -> collectOnChronicDiseasesByUserFamilyIdState()
            }
        }
    }

    private suspend fun collectOnChronicDiseasesByUserFamilyIdState() {
        viewModel.currentMedicationByUserFamilyIdResponseState.collect {
            hideProgressDialog()
            when (it) {
                is State.Error -> it.error.handleHomeResponseError()
                is State.Initial -> {}
                is State.Loading -> showProgressDialog()
                is State.Success -> binding.setUpAdapter()
            }
        }
    }

    private fun FragmentGeneralAllergiesAndChronicDiseasesBinding.setUpAdapter() {
        val chronicDiseases = viewModel.getCurrentMedicationList()
        adapter = CurrentMedicationAdapter(
            chronicDiseases,
            onAddItemClicked = { id ->
                viewModel.addCurrentMedication(CurrentMedicationRequestDto(id, userFamilyId))
            }) { id ->
            viewModel.deleteCurrentMedication(CurrentMedicationRequestDto(id, userFamilyId))
        }
        generalRv.adapter = adapter
    }

    private suspend fun collectOnAddCurrentMedicationResponseState() {
        viewModel.addCurrentMedicationResponseState.collect {
            hideProgressDialog()
            when (it) {
                is State.Error -> it.error.handleHomeResponseError()
                is State.Initial -> {}
                is State.Loading -> showProgressDialog()
                is State.Success -> handelCurrentMedicationRequest()
            }
        }
    }

    private suspend fun collectOnDeleteCurrentMedicationResponseState() {
        viewModel.deleteCurrentMedicationResponseState.collect {
            hideProgressDialog()
            when (it) {
                is State.Error -> it.error.handleHomeResponseError()
                is State.Initial -> {}
                is State.Loading -> showProgressDialog()
                is State.Success -> handelCurrentMedicationRequest()
            }
        }
    }

    private fun handelCurrentMedicationRequest() {
        viewModel.getCurrentMedication()
        viewModel.getCurrentMedicationByUserFamilyId(userFamilyId)
    }

    private fun YabraaError.handleHomeResponseError() {
        val errorMessageUi = ErrorMessageUi(logMessageEn, logMessageAr)
        handleError {
            when (exception) {
                is OperationMessage -> showHomeResponseErrorPopup(errorMessageUi)
            }
        }
    }

    private fun showHomeResponseErrorPopup(errorMessageUi: ErrorMessageUi) {
        val errorMessage = getErrorMessage(errorMessageUi)
        YabraaDialogBuilder(requireActivity())
            .setIcon(R.drawable.ic_vector_error)
            .setTitle(R.string.warning)
            .setMessage(errorMessage)
            .setTopButton(R.string.ok) {}
            .setCancelable(false)
            .show()
    }

    private fun showExpirationDateError() =
        tokenHandler.handleExpirationDate { showExpirationDatePopupError() }
}