package com.yabraa.medical.feature.fragments.notification.notification_hisotry.domain.viemodel

import androidx.lifecycle.ViewModel
import androidx.lifecycle.viewModelScope
import androidx.paging.Pager
import androidx.paging.PagingConfig
import androidx.paging.PagingData
import com.yabraa.medical.core.di.network_sevices.YabraaServices
import com.core.shared.state.State
import com.yabraa.medical.feature.fragments.notification.notification_hisotry.data.model.response.notification_history_response.Notification
import com.yabraa.medical.feature.fragments.notification.notification_hisotry.data.model.response.read_notification_response.ReadNotificationResponseDto
import com.yabraa.medical.feature.fragments.notification.notification_hisotry.data.repository.notification_history_paging_source.NotificationHistoryPagingSource
import com.yabraa.medical.feature.fragments.notification.notification_hisotry.data.repository.notification_history_paging_source.NotificationHistoryPagingSource.Companion.PAGE_SIZE
import com.yabraa.medical.feature.fragments.notification.notification_hisotry.domain.repository.read_notification.ReadNotificationRepository
import dagger.hilt.android.lifecycle.HiltViewModel
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.flow.Flow
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.flowOn
import kotlinx.coroutines.launch
import javax.inject.Inject

@HiltViewModel
class NotificationViewModel @Inject constructor(
    private val yabraaServices: YabraaServices,
    private val readNotificationRepository: ReadNotificationRepository
) :
    ViewModel() {

    //TODO NO NEED COLLECT ON READ NOTIFICATION
    private val _readNotificationResponseState =
        MutableStateFlow<State<ReadNotificationResponseDto>>(State.Initial())
    val readNotificationResponseState: StateFlow<State<ReadNotificationResponseDto>> =
        _readNotificationResponseState

    fun getPaginatedNotification(): Flow<PagingData<Notification>> {
        return Pager(PagingConfig(PAGE_SIZE, 5)) {
            NotificationHistoryPagingSource(yabraaServices)
        }.flow.flowOn(Dispatchers.IO)
    }

    fun readNotification(notificationId: Long) {
        viewModelScope.launch {
            _readNotificationResponseState.emit(State.Loading())
            readNotificationRepository.readNotification(notificationId).collect {
                _readNotificationResponseState.emit(it)
            }
        }
    }
}