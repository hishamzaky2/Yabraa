package com.yabraa.medical.feature.fragments.common.domain.viewmodel

import androidx.lifecycle.LiveData
import androidx.lifecycle.MutableLiveData
import androidx.lifecycle.ViewModel
import androidx.lifecycle.viewModelScope
import com.google.android.gms.maps.model.LatLng
import com.core.shared.state.State
import com.yabraa.medical.feature.fragments.checkout.domain.model.CheckoutPackagesUiModel
import com.yabraa.medical.feature.fragments.common.domain.model.PackagesTransactionModel
import com.yabraa.medical.feature.fragments.home.data.model.response.services_details_response.PackageData
import com.yabraa.medical.feature.fragments.home.data.model.response.services_details_response.ServicesDetailsResponseDto
import com.yabraa.medical.feature.fragments.home.domain.usecase.services_details_usecse.ServicesDetailsUseCase
import com.yabraa.medical.feature.fragments.select_date_and_time.domain.model.NoteUi
import com.yabraa.medical.feature.fragments.select_date_and_time.domain.model.SelectDateAndTimeUi
import com.yabraa.medical.feature.fragments.select_date_and_time.domain.model.SelectPatientsUi
import dagger.hilt.android.lifecycle.HiltViewModel
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.launch
import java.math.BigDecimal
import javax.inject.Inject


@HiltViewModel
class TransactionViewModel @Inject constructor(

    private val servicesDetailsUseCase: ServicesDetailsUseCase
) : ViewModel() {

    private val _servicesDetailsResponseState =
        MutableStateFlow<State<ServicesDetailsResponseDto>>(State.Initial())

    val servicesDetailsResponseState: StateFlow<State<ServicesDetailsResponseDto>> =
        _servicesDetailsResponseState

    private val _addPackageItemsList: MutableList<PackageData> = mutableListOf()
    val addPackageItemsList: List<PackageData> = _addPackageItemsList

    private val _addDatesAndTimeList: MutableList<SelectDateAndTimeUi> = mutableListOf()
    private val addDatesAndTimeList: List<SelectDateAndTimeUi> = _addDatesAndTimeList

    private val _selectDateAndTimeUiLiveList = MutableLiveData<List<SelectDateAndTimeUi>>()
    val selectDateAndTimeUiLiveList: LiveData<List<SelectDateAndTimeUi>> =
        _selectDateAndTimeUiLiveList

    private val _addPatientsList: MutableList<SelectPatientsUi> = mutableListOf()
    private val addPatientsList: List<SelectPatientsUi> = _addPatientsList

    private val _selectPatientUiLiveList = MutableLiveData<List<SelectPatientsUi>>()
    val selectPatientUiLiveList: LiveData<List<SelectPatientsUi>> = _selectPatientUiLiveList

    private val _addNotesList: MutableList<NoteUi> = mutableListOf()
    val addNoteList: List<NoteUi> = _addNotesList

    private val _addPackagesTransactionList: MutableList<PackagesTransactionModel> = mutableListOf()
    val packagesTransactionList: List<PackagesTransactionModel> = _addPackagesTransactionList

    var serviceId: Long? = null
    var serviceTypeName : String? = null
    var serviceTypeId : Long? = null
    var latLng: LatLng? = null


    fun getServicesDetails(serviceTypeId: Long) {
        viewModelScope.launch {
            _servicesDetailsResponseState.emit(State.Loading())
            servicesDetailsUseCase(serviceTypeId).collect {
                _servicesDetailsResponseState.emit(it)
            }
        }
    }

    fun getOneDimensionServices() = servicesDetailsUseCase.getOneDimensionServices()

    fun getOneDimensionServicesByName(searchInput : String) =
        servicesDetailsUseCase.getOneDimensionServicesByName(searchInput)


    fun getServiceNameByServiceId(serviceId: Long) =
        servicesDetailsUseCase.getServiceNameByServiceId(serviceId)

    fun getServiceImageImagePathByServiceId(serviceId: Long) =
        servicesDetailsUseCase.getServiceImagePathByServiceId(serviceId)

    fun getFilterByServicesId(serviceId: Long) =
        servicesDetailsUseCase.getFilterByServicesId(serviceId)


    fun getPackagesByFilterIds(serviceId: Long, filterIds: List<Long>?) =
        servicesDetailsUseCase.getPackagesByFilterIds(serviceId, filterIds)


    fun setPackageItemsList(packageData: PackageData) {
        _addPackageItemsList.filter { packageData.packageId == it.packageId }.forEach { oldItem ->
            _addPackageItemsList.remove(oldItem)
        }
        _addPackageItemsList.add(packageData)
    }

    fun handleRemovePackageItem(packageData: PackageData) {
        val iterator = _addPackageItemsList.iterator()
        while (iterator.hasNext()) {
            if (iterator.next() == packageData) {
                iterator.remove()
            }
        }
    }

    fun setDateAndTimeList(packageId: Long, newItems: SelectDateAndTimeUi) {
        _addDatesAndTimeList.filter { packageId == it.packageId }.forEach { oldItems ->
            _addDatesAndTimeList.remove(oldItems)
        }
        _addDatesAndTimeList.add(newItems)
    }

    fun setSelectedDateAndTimeLiveList() {
        if (addDatesAndTimeList.isNotEmpty()) _selectDateAndTimeUiLiveList.postValue(
            addDatesAndTimeList
        )
    }

    fun setPatientsList(packageId: Long, newItems: SelectPatientsUi) {
        _addPatientsList.filter { packageId == it.packageId }.forEach { oldItems ->
            _addPatientsList.remove(oldItems)
        }
        _addPatientsList.add(newItems)
    }

    fun setSelectedPatientLiveList() {
        if (addPatientsList.isNotEmpty()) _selectPatientUiLiveList.postValue(addPatientsList)
    }

    fun setNotesList(packageId: Long, noteUi: NoteUi) {
        _addNotesList.filter { packageId == it.packageId }.forEach { oldItems ->
            _addNotesList.remove(oldItems)
        }
        _addNotesList.add(noteUi)
    }


    fun addPackagesTransactionList() {
        _addPackageItemsList.forEach { packageData ->
            val dates = getDatesAndTimeByPackageId(packageData.packageId)
            val patients = getPatientsByPackageId(packageData.packageId)
            val notes = getNotesByPackageId(packageData.packageId)
            val transactionUi = PackagesTransactionModel(
                packageData = packageData, dates = dates, patients = patients, notes = notes
            )
            val packagesTransactionModel =
                PackagesTransactionModel().setPackagesTransactionModel(transactionUi)
            packagesTransactionModel.addPackagesTransactionList(packageData.packageId)
        }
    }

    private fun getDatesAndTimeByPackageId(packageId: Long): SelectDateAndTimeUi {
        var datesAndTime = SelectDateAndTimeUi()
        _addDatesAndTimeList.filter { packageId == it.packageId }.forEach { datesAndTime = it }
        return datesAndTime
    }

    private fun getPatientsByPackageId(packageId: Long): SelectPatientsUi {
        var patients = SelectPatientsUi()
        _addPatientsList.filter { packageId == it.packageId }.forEach { patients = it }
        return patients
    }

    private fun getNotesByPackageId(packageId: Long): NoteUi {
        var notes = NoteUi()
        _addNotesList.filter { packageId == it.packageId }.forEach { notes = it }
        return notes
    }

    private fun PackagesTransactionModel.addPackagesTransactionList(packageId: Long) {
        _addPackagesTransactionList.filter { packageId == it.packageData?.packageId }
            .forEach { oldPackages ->
                _addPackagesTransactionList.remove(oldPackages)
            }
        _addPackagesTransactionList.add(this)
    }


    fun removePackageTransactionItem(packageId: Long) {
        if (_addPackagesTransactionList.isEmpty()) return
        _addPackagesTransactionList.filter { packageId == it.packageData?.packageId }
            .forEach { packages ->
                _addPackagesTransactionList.remove(packages)
            }
    }

    fun getPackagesTotalPrice() =
        _addPackagesTransactionList.sumOf { it.packageData?.price ?: BigDecimal(0) }


    fun getCheckoutPackagesList(): MutableList<CheckoutPackagesUiModel> {
        val checkoutPackagesList = arrayListOf<CheckoutPackagesUiModel>()
        packagesTransactionList.forEach { checkoutPackagesList.add(it.setCheckoutPackagesUiModel()) }
        return checkoutPackagesList
    }

    private fun PackagesTransactionModel.setCheckoutPackagesUiModel() = CheckoutPackagesUiModel(
        packageId = packageData?.packageId,
        userFamilyId = patients?.userFamilyId,
        notes = notes?.note,
        price = packageData?.price,
        dateTime = dates?.seDateAndTime()
    )

    private fun SelectDateAndTimeUi.seDateAndTime() =
        "${year}-${monthNumber}-${dayOfMonth}T${time}:00Z"


    fun handleClearAllLists() {
        clearPackageItemsList()
        clearDatesAndTimeList()
        clearPatientsList()
        clearNotesList()
        clearPackagesTransactionList()
        clearLatLng()
    }

    private fun clearPackageItemsList() = _addPackageItemsList.clear()
    private fun clearDatesAndTimeList() = _addDatesAndTimeList.clear()

    private fun clearPatientsList() = _addPatientsList.clear()
    private fun clearNotesList() = _addNotesList.clear()
    private fun clearPackagesTransactionList() = _addPackagesTransactionList.clear()

    private fun clearLatLng(){
        latLng = null
    }

}