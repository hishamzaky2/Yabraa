package com.yabraa.medical.feature.fragments.patients.edit_patients.domain.usecase.edit_patient_usecase

import com.yabraa.medical.feature.fragments.patients.edit_patients.data.model.request.EditPatientRequest
import com.yabraa.medical.feature.fragments.patients.edit_patients.domain.repository.edit_patient_repository.EditPatientRepository
import javax.inject.Inject

class EditPatientUseCase @Inject constructor(private val editPatientRepository: EditPatientRepository) {

    suspend operator fun invoke(editPatientRequest: EditPatientRequest) =
        editPatientRepository.updatePatient(editPatientRequest)
}