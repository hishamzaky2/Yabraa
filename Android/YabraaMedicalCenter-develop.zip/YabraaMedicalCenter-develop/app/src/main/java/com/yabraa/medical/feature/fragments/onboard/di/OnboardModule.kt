package com.yabraa.medical.feature.fragments.onboard.di

import dagger.Module
import dagger.Provides
import dagger.hilt.InstallIn
import dagger.hilt.android.components.ViewModelComponent
import com.yabraa.medical.core.di.network_sevices.SecurityServices
import com.yabraa.medical.feature.fragments.onboard.data.repository.OnboardRepositoryImpl
import com.yabraa.medical.feature.fragments.onboard.domin.repository.OnboardRepository

@Module
@InstallIn(ViewModelComponent::class)
object OnboardModule {

    @Provides
    fun provideOnboardRepository(securityServices: SecurityServices): OnboardRepository =
        OnboardRepositoryImpl(securityServices)
}