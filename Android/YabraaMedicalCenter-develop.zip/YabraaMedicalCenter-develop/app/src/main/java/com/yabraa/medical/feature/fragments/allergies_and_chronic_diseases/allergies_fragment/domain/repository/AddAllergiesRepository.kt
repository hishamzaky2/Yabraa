package com.yabraa.medical.feature.fragments.allergies_and_chronic_diseases.allergies_fragment.domain.repository

import com.core.shared.state.State
import com.yabraa.medical.feature.fragments.allergies_and_chronic_diseases.allergies_fragment.data.model.request.AllergiesRequestDto
import com.yabraa.medical.feature.fragments.allergies_and_chronic_diseases.allergies_fragment.data.model.response.AllergiesResponseDto
import kotlinx.coroutines.flow.Flow

interface AddAllergiesRepository {
    suspend fun addAllergies(requestDto: AllergiesRequestDto): Flow<State<AllergiesResponseDto>>
}