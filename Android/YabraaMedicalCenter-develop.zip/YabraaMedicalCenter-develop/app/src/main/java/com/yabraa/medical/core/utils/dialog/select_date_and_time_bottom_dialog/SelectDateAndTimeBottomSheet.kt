package com.yabraa.medical.core.utils.dialog.select_date_and_time_bottom_dialog

import android.app.Activity
import androidx.core.view.isVisible
import androidx.recyclerview.widget.RecyclerView
import com.google.android.material.bottomsheet.BottomSheetDialog
import com.yabraa.medical.R
import com.yabraa.medical.databinding.LayoutSelectDateAndTimeBottomSheetBinding
import javax.inject.Inject

class SelectDateAndTimeBottomSheet @Inject constructor(activity: Activity) {

    lateinit var binding: LayoutSelectDateAndTimeBottomSheetBinding
    private var bottomSheetDialog: BottomSheetDialog? = null


    init {
        buildBottomSheetDialog(activity)
    }

    private fun buildBottomSheetDialog(activity: Activity): BottomSheetDialog? {
        binding = LayoutSelectDateAndTimeBottomSheetBinding.inflate(activity.layoutInflater)
        bottomSheetDialog = BottomSheetDialog(activity, R.style.date_and_time_bottom_sheet_style)
        bottomSheetDialog?.setContentView(binding.root)
        binding.setOnCloseClicked()
        return bottomSheetDialog
    }

    private fun LayoutSelectDateAndTimeBottomSheetBinding.setOnCloseClicked() =
        closeIvBtn.setOnClickListener {
            bottomSheetDialog?.dismiss()
        }

    fun showSelectAndDateBottomSheetDialog() = bottomSheetDialog?.show()


    fun dismissSelectAndDateBottomSheet() = bottomSheetDialog?.dismiss()

    fun setFirstMonth(firstMonth: String) {
        binding.firstMonthTv.text = firstMonth
    }

    fun setSecondMonth(secondMonth: String? = null) {
        binding.secondMonthTv.isVisible = secondMonth.isNullOrEmpty()
        binding.secondMonthTv.text = secondMonth
    }

    fun setFirstYear(year: Int) {
        binding.firstYearTv.text = "$year"
    }

    fun setLastYear(firstYear: Int, lastYear: Int) {
        if (firstYear == lastYear) return
        binding.lastYearTv.text = "$lastYear"
    }

    fun setDayRecyclerAdapter(adapter: RecyclerView.Adapter<*>) {
        binding.chooseDayRv.adapter = adapter
    }

    fun setTimeRecyclerAdapter(adapter: RecyclerView.Adapter<*>) {
        binding.chooseTimeRv.adapter = adapter
    }

    fun setOnConfirmingDateAndTimeClicked(packageId: Long, action: (Long) -> Unit) {
        binding.confirmingBtn.setOnClickListener { action(packageId) }
    }
}