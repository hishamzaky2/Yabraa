package com.yabraa.medical.feature.fragments.common.domain.viewmodel

import androidx.lifecycle.ViewModel
import androidx.lifecycle.viewModelScope
import dagger.hilt.android.lifecycle.HiltViewModel
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.launch
import com.core.shared.state.State
import com.yabraa.medical.feature.fragments.onboard.data.response.OnboardPagesResponseDto
import com.yabraa.medical.feature.fragments.onboard.domin.usecase.OnboardUseCase
import javax.inject.Inject

@HiltViewModel
class OnboardViewModel @Inject constructor(
    private val onboardUseCase: OnboardUseCase
) : ViewModel() {

    private val _onboardPagesState = MutableStateFlow<State<OnboardPagesResponseDto>>(State.Success(null))
    val onboardPagesState: StateFlow<State<OnboardPagesResponseDto>> = _onboardPagesState

    fun getOnboardPages() {
        viewModelScope.launch {
            _onboardPagesState.emit(State.Loading())
            onboardUseCase().collect {
                _onboardPagesState.emit(it)
            }
        }
    }

   fun getSuccessState() = onboardUseCase.getSuccessState()

    fun getPagesDetails() = onboardUseCase.getPagesDetails()
}