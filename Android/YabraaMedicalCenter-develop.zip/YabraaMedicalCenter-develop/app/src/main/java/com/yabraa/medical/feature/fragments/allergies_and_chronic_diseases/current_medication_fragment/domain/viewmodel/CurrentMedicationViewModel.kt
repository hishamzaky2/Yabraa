package com.yabraa.medical.feature.fragments.allergies_and_chronic_diseases.current_medication_fragment.domain.viewmodel

import androidx.lifecycle.ViewModel
import androidx.lifecycle.viewModelScope
import com.core.shared.state.State
import com.yabraa.medical.feature.fragments.allergies_and_chronic_diseases.current_medication_fragment.data.model.request.CurrentMedicationRequestDto
import com.yabraa.medical.feature.fragments.allergies_and_chronic_diseases.current_medication_fragment.data.model.resopnse.CurrentMedicationResponseDto
import com.yabraa.medical.feature.fragments.allergies_and_chronic_diseases.current_medication_fragment.domain.repository.AddCurrentMedicationRepository
import com.yabraa.medical.feature.fragments.allergies_and_chronic_diseases.current_medication_fragment.domain.repository.DeleteCurrentMedicationRepository
import com.yabraa.medical.feature.fragments.allergies_and_chronic_diseases.current_medication_fragment.domain.usecase.CurrentMedicationUseCase
import dagger.hilt.android.lifecycle.HiltViewModel
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.launch
import javax.inject.Inject

@HiltViewModel
class CurrentMedicationViewModel @Inject constructor(
    private val currentMedicationUseCase: CurrentMedicationUseCase,
    private val addCurrentMedicationRepository: AddCurrentMedicationRepository,
    private val deleteCurrentMedicationRepository: DeleteCurrentMedicationRepository
) : ViewModel() {


    private val _currentMedicationResponseState =
        MutableStateFlow<State<CurrentMedicationResponseDto>>(State.Initial())
    val currentMedicationResponseState: StateFlow<State<CurrentMedicationResponseDto>> =
        _currentMedicationResponseState

    private val _currentMedicationByUserFamilyIdResponseState =
        MutableStateFlow<State<CurrentMedicationResponseDto>>(State.Initial())
    val currentMedicationByUserFamilyIdResponseState: StateFlow<State<CurrentMedicationResponseDto>> =
        _currentMedicationByUserFamilyIdResponseState

    private val _addCurrentMedicationResponseState =
        MutableStateFlow<State<CurrentMedicationResponseDto>>(State.Initial())
    val addCurrentMedicationResponseState: StateFlow<State<CurrentMedicationResponseDto>> =
        _addCurrentMedicationResponseState

    private val _deleteCurrentMedicationResponseState =
        MutableStateFlow<State<CurrentMedicationResponseDto>>(State.Initial())
    val deleteCurrentMedicationResponseState: StateFlow<State<CurrentMedicationResponseDto>> =
        _deleteCurrentMedicationResponseState

    fun getCurrentMedication() {
        viewModelScope.launch {
            _currentMedicationResponseState.emit(State.Loading())
            currentMedicationUseCase().collect {
                _currentMedicationResponseState.emit(it)
            }
        }
    }


    fun getCurrentMedicationByUserFamilyId(userFamilyId: Long) {
        viewModelScope.launch {
            _currentMedicationByUserFamilyIdResponseState.emit(State.Loading())
            currentMedicationUseCase(userFamilyId).collect {
                _currentMedicationByUserFamilyIdResponseState.emit(it)
            }
        }
    }

    fun addCurrentMedication(requestDto: CurrentMedicationRequestDto) {
        viewModelScope.launch {
            _addCurrentMedicationResponseState.emit(State.Loading())
            addCurrentMedicationRepository.addCurrentMedication(requestDto).collect {
                _addCurrentMedicationResponseState.emit(it)
            }
        }
    }


    fun deleteCurrentMedication(requestDto: CurrentMedicationRequestDto) {
        viewModelScope.launch {
            _deleteCurrentMedicationResponseState.emit(State.Loading())
            deleteCurrentMedicationRepository.deleteCurrentMedication(requestDto).collect {
                _deleteCurrentMedicationResponseState.emit(it)
            }
        }
    }

    fun getCurrentMedicationList() = currentMedicationUseCase.getCurrentMedicationList()
}