package com.yabraa.medical.feature.fragments.appointment.my_appointment.di

import com.yabraa.medical.core.di.network_sevices.YabraaServices
import com.yabraa.medical.feature.fragments.appointment.my_appointment.data.repository.MyAppointmentRepositoryImpl
import com.yabraa.medical.feature.fragments.appointment.my_appointment.data.repository.cancel_appointment_repository.CancelAppointmentRepositoryImpl
import com.yabraa.medical.feature.fragments.appointment.my_appointment.domain.repository.MyAppointmentRepository
import com.yabraa.medical.feature.fragments.appointment.my_appointment.domain.repository.cancel_appointment_repository.CancelAppointmentRepository
import dagger.Module
import dagger.Provides
import dagger.hilt.InstallIn
import dagger.hilt.android.components.ViewModelComponent

@Module
@InstallIn(ViewModelComponent::class)
object MyAppointmentModule {

    @Provides
    fun provideMyAppointmentRepository(yabraaServices: YabraaServices): MyAppointmentRepository =
        MyAppointmentRepositoryImpl(yabraaServices)

    @Provides
    fun provideCancelAppointmentRepository(yabraaServices: YabraaServices): CancelAppointmentRepository =
        CancelAppointmentRepositoryImpl(yabraaServices)
}