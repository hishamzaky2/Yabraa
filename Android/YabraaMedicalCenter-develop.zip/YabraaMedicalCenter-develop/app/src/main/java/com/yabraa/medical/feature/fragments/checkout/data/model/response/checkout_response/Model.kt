package com.yabraa.medical.feature.fragments.checkout.data.model.response.checkout_response


import android.icu.math.BigDecimal
import com.google.gson.annotations.SerializedName

data class Model(
    @SerializedName("locationAltitude")
    val locationAltitude: Double? = null,
    @SerializedName("locationLongitude")
    val locationLongitude: Double,
    @SerializedName("locationLatitude")
    val locationLatitude: Double,
    @SerializedName("currency")
    val currency : String,
    @SerializedName("paymentType")
    val paymentType : String,
    @SerializedName("packages")
    val packages: List<Package>,
    @SerializedName("totalPrice")
    val amount: BigDecimal
)