package com.yabraa.medical.feature.fragments.appointment.my_appointment.data.repository.cancel_appointment_repository

import com.yabraa.medical.core.base_repository.BaseRepository
import com.yabraa.medical.core.di.network_sevices.YabraaServices
import com.core.shared.state.State
import com.yabraa.medical.core.utils.getResponseMessageError
import com.yabraa.medical.feature.fragments.appointment.my_appointment.data.model.request.CancelAppointmentRequestDto
import com.yabraa.medical.feature.fragments.appointment.my_appointment.data.model.response.cancel_appointment_response.CancelAppointmentResponseDto
import com.yabraa.medical.feature.fragments.appointment.my_appointment.domain.repository.cancel_appointment_repository.CancelAppointmentRepository
import kotlinx.coroutines.flow.flow
import kotlinx.coroutines.flow.flowOn
import retrofit2.Response
import javax.inject.Inject

const val TAG_CANCEL_APPOINTMENT_RESPONSE = "TAG_CANCEL_APPOINTMENT_RESPONSE"

class CancelAppointmentRepositoryImpl @Inject constructor(private val yabraaServices: YabraaServices) :
    BaseRepository<CancelAppointmentRequestDto, CancelAppointmentResponseDto>(),
    CancelAppointmentRepository {


    override suspend fun cancelAppointment(requestDto: CancelAppointmentRequestDto) = flow {
        emit(getOperationState(requestDto))
    }.flowOn(dispatcher)

    override suspend fun performApiCall(requestDtoo: CancelAppointmentRequestDto): State<CancelAppointmentResponseDto> {
        val response =
            yabraaServices.cancelAppointment(requestDtoo.appointmentId, requestDtoo.firebaseToken)
        return handleCancelAppointmentResponse(response)
    }


    private fun handleCancelAppointmentResponse(response: Response<CancelAppointmentResponseDto>): State<CancelAppointmentResponseDto> {
        val responseBody = response.body()
        val errorMessageEn = responseBody?.errorMessageEn ?: ""
        val errorMessageAr = responseBody?.errorMessageAr ?: ""
        return when {
            response.isSuccessful && responseBody?.cancelAppointmentResponse != null ->
                State.Success(response.body())

            response.isSuccessful && !responseBody?.errorMessageEn.isNullOrEmpty() ->
                getResponseMessageError(
                    errorMessageEn = errorMessageEn,
                    errorMessageAr = errorMessageAr,
                    logTag = TAG_CANCEL_APPOINTMENT_RESPONSE
                )

            else -> getNotSuccessfulResponseState(response)
        }
    }
}