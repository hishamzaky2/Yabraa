package com.yabraa.medical.feature.fragments.forget_password.presentation

import android.annotation.SuppressLint
import android.os.Bundle
import android.view.View
import androidx.annotation.StringRes
import androidx.core.os.bundleOf
import androidx.hilt.navigation.fragment.hiltNavGraphViewModels
import androidx.lifecycle.lifecycleScope
import androidx.navigation.fragment.findNavController
import dagger.hilt.android.AndroidEntryPoint
import kotlinx.coroutines.Job
import kotlinx.coroutines.launch
import com.yabraa.medical.R
import com.yabraa.medical.core.base_fragment.BaseFragment
import com.yabraa.medical.core.base_fragment.navigate
import com.core.shared.error.EmptyPhoneNumber
import com.core.shared.error.OperationMessage
import com.core.shared.error.YabraaError
import com.core.shared.state.State
import com.yabraa.medical.core.utils.dialog.yabraa_dialog.YabraaDialogBuilder
import com.yabraa.medical.core.utils.getErrorMessage
import com.yabraa.medical.databinding.FragmentForgetPasswordBinding
import com.yabraa.medical.feature.fragments.common.domain.model.ErrorMessageUi
import com.yabraa.medical.feature.fragments.common.domain.viewmodel.RegistrationViewModel
import com.yabraa.medical.feature.fragments.forget_password.data.model.response.forget_password_response.ForgetPasswordDataResponse
import com.yabraa.medical.feature.fragments.forget_password.domain.model.ForgetPasswordUiModel

const val FORGET_PASSWORD_FRAGMENT = "FORGET_PASSWORD_FRAGMENT"

@AndroidEntryPoint
class ForgetPasswordFragment : BaseFragment<FragmentForgetPasswordBinding>() {

    override val binding by lazy { FragmentForgetPasswordBinding.inflate(layoutInflater) }
    private val viewModel: RegistrationViewModel by hiltNavGraphViewModels(R.id.loginAndRegisterGraph)
    private var forgetPasswordJob: Job? = null

    override fun onViewCreated(view: View, savedInstanceState: Bundle?) {
        super.onViewCreated(view, savedInstanceState)
        binding.setUpViews()

    }


    override fun onResume() {
        super.onResume()
        showYabraaBar(false)
    }


    private fun FragmentForgetPasswordBinding.setUpViews() {
        setOnBackClicked()
        setOnResetPasswordClicked()
        lifecycleScope.launch { collectOnInputValidationState() }
        forgetPasswordJob = lifecycleScope.launch { collectForgetPasswordResponseStateResponse() }
    }

    private fun FragmentForgetPasswordBinding.setOnBackClicked() {
        backArrowIv.setOnClickListener { findNavController().navigateUp() }
    }


    @SuppressLint("FragmentLiveDataObserve")
    private fun FragmentForgetPasswordBinding.setOnResetPasswordClicked() {
        connectivityManager?.isNetworkConnected?.observe(this@ForgetPasswordFragment) { isConnected ->
            resetPasswordBtn.setOnClickListener {
                if (!isConnected) {
                    showNetworkConnectionErrorPopup()
                    return@setOnClickListener
                }
                val phoneNumber = phoneNumberEt.text.toString()
                viewModel.forgetPassword(ForgetPasswordUiModel(phoneNumber))
            }
        }
    }

    private suspend fun collectOnInputValidationState() {
        viewModel.validationState.collect {
            when (it) {
                is State.Initial -> {}
                is State.Error -> handleError(it)
                is State.Success -> {}
                is State.Loading -> {}
            }
        }
    }

    private fun handleError(errorState: State.Error<*>) {
        errorState.error.handleError {
            when (exception) {
                is EmptyPhoneNumber -> showInputErrorSnackBar(R.string.pleaseEnterPhoneNumber)
            }
        }
    }

    private fun showInputErrorSnackBar(@StringRes message: Int) =
        yabraaSnackBarBuilder.setEndIcon(R.drawable.ic_vector_close).setMessage(message)
            .build(requireView()).show()


    private suspend fun collectForgetPasswordResponseStateResponse() {
        viewModel.forgetPasswordResponseState.collect {
            hideProgressDialog()
            when (it) {
                is State.Initial -> {}
                is State.Error -> it.error.handleForgetPasswordResponseError()
                is State.Loading -> showProgressDialog()
                is State.Success -> navigateToOtpVerificationScreen(it.data?.forgetPasswordDataResponse)
            }
        }
    }


    private fun YabraaError.handleForgetPasswordResponseError() {
        val errorMessageUi =  ErrorMessageUi(logMessageEn, logMessageAr)
        handleError {
            when (exception) {
                is OperationMessage -> showRegisterResponseErrorPopup(errorMessageUi)
            }
        }
    }


    private fun showRegisterResponseErrorPopup(errorMessageUi: ErrorMessageUi) {
        val errorMessage = getErrorMessage(errorMessageUi)
        YabraaDialogBuilder(requireActivity()).setIcon(R.drawable.ic_vector_error)
            .setTitle(R.string.warning)
            .setMessage(errorMessage)
            .setTopButton(R.string.ok) {
                //TODO LOG MESSAGE HERE
            }.setCancelable(false).show()
    }

    private fun navigateToOtpVerificationScreen(forgetPasswordDataResponse: ForgetPasswordDataResponse?) {
        if (forgetPasswordDataResponse == null) return
        forgetPasswordJob?.cancel()
        val bundle = bundleOf(FORGET_PASSWORD_FRAGMENT to true)
        navigate(R.id.actionToOtpVerificationFragment, bundle)
    }
}