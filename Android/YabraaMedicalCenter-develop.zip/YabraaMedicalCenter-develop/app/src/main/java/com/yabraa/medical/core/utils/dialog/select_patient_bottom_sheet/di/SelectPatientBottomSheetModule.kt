package com.yabraa.medical.core.utils.dialog.select_patient_bottom_sheet.di

import android.app.Activity
import dagger.Module
import dagger.Provides
import dagger.hilt.InstallIn
import dagger.hilt.android.components.ActivityComponent
import com.yabraa.medical.core.utils.dialog.select_patient_bottom_sheet.SelectPatientBottomSheet

@Module
@InstallIn(ActivityComponent::class)
object SelectPatientBottomSheetModule {

    @Provides
    fun provideSelectPatientBottomSheet(activity: Activity) = SelectPatientBottomSheet(activity)
}