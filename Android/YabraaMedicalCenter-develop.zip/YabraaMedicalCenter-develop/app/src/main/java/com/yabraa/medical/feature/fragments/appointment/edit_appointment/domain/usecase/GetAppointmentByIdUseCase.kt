package com.yabraa.medical.feature.fragments.appointment.edit_appointment.domain.usecase

import com.core.shared.state.State
import com.yabraa.medical.feature.fragments.appointment.edit_appointment.data.model.response.AppointmentResponse
import com.yabraa.medical.feature.fragments.appointment.edit_appointment.data.model.response.AppointmentResponseDto
import com.yabraa.medical.feature.fragments.appointment.edit_appointment.domain.repository.GetAppointmentByIdRepository
import kotlinx.coroutines.async
import kotlinx.coroutines.flow.Flow
import kotlinx.coroutines.flow.channelFlow
import javax.inject.Inject

class GetAppointmentByIdUseCase @Inject constructor(private val getAppointmentByIdRepository: GetAppointmentByIdRepository) {

    private var appointmentResponse : AppointmentResponse? = null

    suspend operator fun invoke(appointmentId: Long): Flow<State<AppointmentResponseDto>> {
        return channelFlow {
            val appointment =
                async { getAppointmentByIdRepository.getAppointmentById(appointmentId) }
            appointment.await().collect {
                if (it is State.Success) {
                    appointmentResponse = it.data?.appointmentResponse
                }
                send(it)
            }
        }
    }

    fun getAppointmentResponse() = appointmentResponse
}