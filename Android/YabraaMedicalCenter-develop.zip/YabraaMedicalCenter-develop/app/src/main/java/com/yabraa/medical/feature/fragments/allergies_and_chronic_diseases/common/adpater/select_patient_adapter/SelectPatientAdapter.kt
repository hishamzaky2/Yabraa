package com.yabraa.medical.feature.fragments.allergies_and_chronic_diseases.common.adpater.select_patient_adapter

import android.view.LayoutInflater
import android.view.ViewGroup
import androidx.core.view.isVisible
import androidx.recyclerview.widget.RecyclerView
import com.yabraa.medical.databinding.ItemPatientsBinding
import com.yabraa.medical.feature.fragments.patients.patients.data.model.response.PatientResponse

class SelectPatientAdapter(
    private val patients: MutableList<PatientResponse>,
    private val onItemClicked: (Long) -> Unit
) : RecyclerView.Adapter<SelectPatientAdapter.ViewHolder>() {

    override fun onCreateViewHolder(parent: ViewGroup, viewType: Int): ViewHolder {
        val binding =
            ItemPatientsBinding.inflate(LayoutInflater.from(parent.context), parent, false)
        return ViewHolder(binding)
    }

    override fun onBindViewHolder(viewHolder: ViewHolder, position: Int) {
        val item = patients[position]
        viewHolder.bind(item)
    }

    override fun getItemCount() = patients.size

    override fun getItemViewType(position: Int) = position

    inner class ViewHolder(val binding: ItemPatientsBinding) :
        RecyclerView.ViewHolder(binding.root) {
        fun bind(item: PatientResponse) {
            binding.setUpViews(item)
        }

        private fun ItemPatientsBinding.setUpViews(item: PatientResponse) {
            edit.isVisible = false
            root.setOnClickListener { onItemClicked(item.userFamilyId) }
            patientNameTv.text = item.name
        }
    }
}