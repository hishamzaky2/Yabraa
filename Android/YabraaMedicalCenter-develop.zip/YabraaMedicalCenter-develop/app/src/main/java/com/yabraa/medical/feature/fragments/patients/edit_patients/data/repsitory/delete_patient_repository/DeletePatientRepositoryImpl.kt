package com.yabraa.medical.feature.fragments.patients.edit_patients.data.repsitory.delete_patient_repository

import com.yabraa.medical.core.base_repository.BaseRepository
import com.yabraa.medical.core.di.network_sevices.YabraaServices
import com.core.shared.state.State
import com.yabraa.medical.core.utils.getResponseMessageError
import com.yabraa.medical.feature.fragments.patients.edit_patients.data.model.response.delete_patient_response.DeletePatientResponseDto
import com.yabraa.medical.feature.fragments.patients.edit_patients.domain.repository.delete_patient_repository.DeletePatientRepository
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.flow.flow
import kotlinx.coroutines.flow.flowOn
import retrofit2.Response
import javax.inject.Inject

const val DELETE_STATE = "Deleted"
const val TAG_DELETE_PATIENT_RESPONSE = "TAG_DELETE_PATIENT_RESPONSE"
class DeletePatientRepositoryImpl @Inject constructor(private val yabraaServices: YabraaServices) :
    BaseRepository<Long, DeletePatientResponseDto>(), DeletePatientRepository {


    override suspend fun deletePatient(userFamilyId: Long) = flow {
        emit(getOperationState(userFamilyId))
    }.flowOn(Dispatchers.IO)

    override suspend fun performApiCall(requestDto: Long): State<DeletePatientResponseDto> {
        val response = yabraaServices.deletePatient(requestDto)
        return handDeletePatientResponse(response)
    }


    private fun handDeletePatientResponse(response: Response<DeletePatientResponseDto>): State<DeletePatientResponseDto> {
        val responseBody = response.body()
        val errorMessageEn = responseBody?.errorMessageEn ?: ""
        val errorMessageAr = responseBody?.errorMessageAr ?: ""
        return when {
            response.isSuccessful && responseBody?.deleteState == DELETE_STATE -> State.Success(
                response.body()
            )

            response.isSuccessful && !responseBody?.errorMessageEn.isNullOrEmpty() -> getResponseMessageError(
                errorMessageEn = errorMessageEn,
                errorMessageAr = errorMessageAr,
                logTag = TAG_DELETE_PATIENT_RESPONSE
            )

            else -> getNotSuccessfulResponseState(response)
        }
    }
}