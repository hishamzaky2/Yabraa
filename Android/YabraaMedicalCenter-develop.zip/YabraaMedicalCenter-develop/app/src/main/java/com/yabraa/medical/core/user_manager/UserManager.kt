package com.yabraa.medical.core.user_manager

import com.core.shared.storage_manager.StorageManager
import com.core.shared.storage_manager.di.StorageManagerModule.SHARED_PREFERENCE
import com.yabraa.medical.feature.fragments.login.data.model.response.LoginDataResponse
import javax.inject.Inject
import javax.inject.Named

const val USER_DATE = "USER_DATE"

class UserManager @Inject constructor(@Named(SHARED_PREFERENCE) private val sharedPreference: StorageManager) :
    UserHandler {
    override fun saveUserData(loginDataResponse: LoginDataResponse) =
        sharedPreference.setObject(USER_DATE, loginDataResponse)

    override fun getUserData() =
        sharedPreference.getObject(USER_DATE, LoginDataResponse::class.java)

    override fun clearUserDate() = sharedPreference.remove(USER_DATE)
}