package com.yabraa.medical.core.user_manager

import com.yabraa.medical.feature.fragments.login.data.model.response.LoginDataResponse

interface UserHandler {

    fun saveUserData(loginDataResponse: LoginDataResponse)

    fun getUserData() : LoginDataResponse?

    fun clearUserDate()

}