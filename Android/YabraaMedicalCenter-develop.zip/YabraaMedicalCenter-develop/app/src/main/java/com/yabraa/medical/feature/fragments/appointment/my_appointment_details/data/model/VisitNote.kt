package com.yabraa.medical.feature.fragments.appointment.my_appointment_details.data.model


import com.google.gson.annotations.SerializedName

data class VisitNote(
    @SerializedName("createDTs")
    val createDTs: String,
    @SerializedName("description")
    val description: String,
    @SerializedName("title")
    val title: String
)