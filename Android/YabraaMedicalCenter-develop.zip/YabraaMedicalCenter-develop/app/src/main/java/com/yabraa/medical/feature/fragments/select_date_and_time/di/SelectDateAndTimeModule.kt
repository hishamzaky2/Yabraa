package com.yabraa.medical.feature.fragments.select_date_and_time.di

import com.yabraa.medical.core.di.network_sevices.YabraaServices
import com.yabraa.medical.feature.fragments.select_date_and_time.data.repository.DatesArabicRepositoryImpl
import com.yabraa.medical.feature.fragments.select_date_and_time.data.repository.DatesRepositoryImpl
import com.yabraa.medical.feature.fragments.select_date_and_time.domain.repository.DatesArabicRepository
import com.yabraa.medical.feature.fragments.select_date_and_time.domain.repository.DatesRepository
import dagger.Module
import dagger.Provides
import dagger.hilt.InstallIn
import dagger.hilt.android.components.ViewModelComponent

@Module
@InstallIn(ViewModelComponent::class)
object SelectDateAndTimeModule {

    @Provides
    fun provideDatesRepository(yabraaServices: YabraaServices): DatesRepository =
        DatesRepositoryImpl(yabraaServices)

    @Provides
    fun provideDatesArabicRepository(yabraaServices: YabraaServices): DatesArabicRepository =
        DatesArabicRepositoryImpl(yabraaServices)

}