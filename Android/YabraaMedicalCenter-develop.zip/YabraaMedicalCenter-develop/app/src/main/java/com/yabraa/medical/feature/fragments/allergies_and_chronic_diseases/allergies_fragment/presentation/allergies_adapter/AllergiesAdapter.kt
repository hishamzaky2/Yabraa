package com.yabraa.medical.feature.fragments.allergies_and_chronic_diseases.allergies_fragment.presentation.allergies_adapter

import android.view.LayoutInflater
import android.view.ViewGroup
import androidx.core.view.isVisible
import androidx.recyclerview.widget.RecyclerView
import com.core.shared.utils.CommonUtils
import com.yabraa.medical.databinding.ItemGeneralAllergiesAndDiseasesBinding
import com.yabraa.medical.feature.fragments.allergies_and_chronic_diseases.allergies_fragment.domain.model.AllergiesEntityModel

class AllergiesAdapter(
    private val allergiesItems: List<AllergiesEntityModel>,
    private val onAddItemClicked: (Long) -> Unit,
    private val onDeleteItemClicked: (Long) -> Unit
) : RecyclerView.Adapter<AllergiesAdapter.ViewHolder>() {


    override fun onCreateViewHolder(parent: ViewGroup, viewType: Int): ViewHolder {
        val binding = ItemGeneralAllergiesAndDiseasesBinding.inflate(
            LayoutInflater.from(parent.context),
            parent,
            false
        )
        return ViewHolder(binding)
    }

    override fun onBindViewHolder(viewHolder: ViewHolder, position: Int) {
        val allergiesItems = allergiesItems[position]
        viewHolder.bin(allergiesItems)
    }

    override fun getItemCount() = allergiesItems.size

    override fun getItemViewType(position: Int) = position


    inner class ViewHolder(val binding: ItemGeneralAllergiesAndDiseasesBinding) :
        RecyclerView.ViewHolder(binding.root) {
        fun bin(item: AllergiesEntityModel) {
            binding.setUpViews(item)
        }

        private fun ItemGeneralAllergiesAndDiseasesBinding.setUpViews(item: AllergiesEntityModel) {
            addBtn.setOnClickListener { onAddItemClicked(item.allergyId) }
            deleteBtn.setOnClickListener { onDeleteItemClicked(item.allergyId) }
            titleTv.text = CommonUtils.getLocalizedValue(item.titleEN, item.titleAR)
            handleAddBtnVisibility(item.isAdded)
        }

        private fun ItemGeneralAllergiesAndDiseasesBinding.handleAddBtnVisibility(isShow: Boolean) {
            checkIv.isVisible = isShow
            addBtn.isVisible = !isShow
            deleteBtn.isVisible = isShow
        }
    }
}