package com.yabraa.medical.feature.fragments.appointment.edit_appointment.data.model.response


import com.google.gson.annotations.SerializedName

data class AppointmentResponseDto(
    @SerializedName("data")
    val appointmentResponse: AppointmentResponse,
    @SerializedName("errorMessageAr")
    val errorMessageAr: String? = null,
    @SerializedName("errorMessageEn")
    val errorMessageEn: String? = null,
    @SerializedName("statusCode")
    val statusCode: Int
)