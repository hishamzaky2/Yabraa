package com.yabraa.medical.feature.fragments.forget_password.data.model.response.reset_password_response

import com.google.gson.annotations.SerializedName


data class ResetPasswordResponseDto(
    @SerializedName("data")
    val resetPasswordResponse: ResetPasswordResponse,
    @SerializedName("errorMessageAr")
    val errorMessageAr: String? = null,
    @SerializedName("errorMessageEn")
    val errorMessageEn: String? = null,
    @SerializedName("statusCode")
    val statusCode: Int
)