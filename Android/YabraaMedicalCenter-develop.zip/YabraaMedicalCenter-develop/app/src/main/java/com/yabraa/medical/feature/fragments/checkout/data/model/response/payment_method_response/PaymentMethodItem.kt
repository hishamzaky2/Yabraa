package com.yabraa.medical.feature.fragments.checkout.data.model.response.payment_method_response


import com.google.gson.annotations.SerializedName

data class PaymentMethodItem(
    @SerializedName("name")
    val name: String,
    @SerializedName("paymentMethodId")
    val paymentMethodId: Long,
    var isChecked: Boolean = false
)