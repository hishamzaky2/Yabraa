package com.yabraa.medical.feature.fragments.home.data.model.response.services_details_response


import com.google.gson.annotations.SerializedName

data class OneDimensionalService(
    @SerializedName("detailsAR")
    val detailsAR: String? = null,
    @SerializedName("detailsEN")
    val detailsEN: String? = null,
    @SerializedName("filters")
    val filterData: List<FilterData>? = null,
    @SerializedName("imagePath")
    val imagePath: String? = null,
    @SerializedName("nameAR")
    val nameAR: String? = null,
    @SerializedName("nameEN")
    val nameEN: String? = null,
    @SerializedName("serviceId")
    val serviceId: Long? = null
)