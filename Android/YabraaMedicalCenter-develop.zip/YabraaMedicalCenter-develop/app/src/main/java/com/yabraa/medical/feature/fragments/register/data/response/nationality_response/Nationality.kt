package com.yabraa.medical.feature.fragments.register.data.response.nationality_response

import com.google.gson.annotations.SerializedName
import java.util.*


data class Nationality(
    @SerializedName("countryArNationality")
    val countryAr: String? = null,
    @SerializedName("countryCode")
    val countryCode: String? = null,
    @SerializedName("countryEnNationality")
    val countryEn: String? = null
) {
    fun getCountryName(nationality: Nationality) = when (Locale.getDefault().language) {
        "en" -> nationality.countryEn
        else -> nationality.countryAr
    }
}