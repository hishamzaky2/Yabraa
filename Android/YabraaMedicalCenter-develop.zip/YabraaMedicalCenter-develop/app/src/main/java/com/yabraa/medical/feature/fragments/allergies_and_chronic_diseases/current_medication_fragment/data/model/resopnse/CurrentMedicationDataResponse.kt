package com.yabraa.medical.feature.fragments.allergies_and_chronic_diseases.current_medication_fragment.data.model.resopnse


import com.google.gson.annotations.SerializedName

data class CurrentMedicationDataResponse(
    @SerializedName("medicationId")
    val medicationId: Long,
    @SerializedName("titleAR")
    val titleAR: String,
    @SerializedName("titleEN")
    val titleEN: String
)