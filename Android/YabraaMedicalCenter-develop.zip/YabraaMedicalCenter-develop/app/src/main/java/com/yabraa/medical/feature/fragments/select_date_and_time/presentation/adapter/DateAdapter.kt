package com.yabraa.medical.feature.fragments.select_date_and_time.presentation.adapter

import android.annotation.SuppressLint
import android.view.LayoutInflater
import android.view.ViewGroup
import androidx.recyclerview.widget.RecyclerView
import com.yabraa.medical.R
import com.core.shared.utils.CommonUtils
import com.yabraa.medical.core.utils.setBackGroundResource
import com.yabraa.medical.core.utils.setTextViewColor
import com.yabraa.medical.databinding.ItemDateBinding
import com.yabraa.medical.feature.fragments.select_date_and_time.data.response.DatesDataResponse
import com.yabraa.medical.feature.fragments.select_date_and_time.presentation.adapter.DateAdapter.ViewHolder

class DateAdapter(
    private val datesItems: List<DatesDataResponse>,
    private val onItemClicked: (DatesDataResponse) -> Unit
) : RecyclerView.Adapter<ViewHolder>() {

    private var checkedPosition = -1

    override fun onCreateViewHolder(parent: ViewGroup, viewType: Int): ViewHolder {
        val binding = ItemDateBinding.inflate(LayoutInflater.from(parent.context), parent, false)
        return ViewHolder(binding)
    }

    override fun onBindViewHolder(viewHolder: ViewHolder, position: Int) {
        val timeItem = datesItems[position]
        viewHolder.bind(timeItem)
    }

    override fun getItemCount() = datesItems.size

    override fun getItemViewType(position: Int) = position

    inner class ViewHolder(private val binding: ItemDateBinding) :
        RecyclerView.ViewHolder(binding.root) {

        fun bind(date: DatesDataResponse) {
            binding.setUpViews(date)
        }

        private fun ItemDateBinding.setUpViews(date: DatesDataResponse) {
            val englishDay = date.dayName.substring(0, 3)
            val arabicDay = date.dayName
            dayTv.text = CommonUtils.getLocalizedValue(englishDay, arabicDay)
            numberOfDayTv.text = date.dayOfMonth
            setSelectItemClicked(date)
            handleCheckedSelectItem()
        }

        private fun ItemDateBinding.setSelectItemClicked(date: DatesDataResponse) {
            root.setOnClickListener {
                handleSelectedItem()
                if (checkedPosition != absoluteAdapterPosition) {
                    notifyItemChanged(checkedPosition)
                    checkedPosition = absoluteAdapterPosition
                }
                onItemClicked(date)
            }
        }

        @SuppressLint("ResourceAsColor")
        private fun ItemDateBinding.handleCheckedSelectItem() {
            if (checkedPosition == -1) handleUnSelectedItem()
            when (checkedPosition) {
                absoluteAdapterPosition -> handleSelectedItem()
                else -> handleUnSelectedItem()
            }
        }

        private fun ItemDateBinding.handleSelectedItem() {
            dateCLY.setBackGroundResource(R.drawable.select_date_border)
            dayTv.setTextViewColor(binding.root.context, R.color.primaryWhite)
            numberOfDayTv.setTextViewColor(binding.root.context, R.color.primaryWhite)
        }

        private fun ItemDateBinding.handleUnSelectedItem() {
            dateCLY.setBackGroundResource(R.drawable.ic_vector_date_frame)
            dayTv.setTextViewColor(binding.root.context, R.color.black)
            numberOfDayTv.setTextViewColor(binding.root.context, R.color.black)
        }
    }
}