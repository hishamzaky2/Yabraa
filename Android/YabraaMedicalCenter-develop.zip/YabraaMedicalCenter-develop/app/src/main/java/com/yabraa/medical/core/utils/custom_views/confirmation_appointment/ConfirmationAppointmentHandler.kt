package com.yabraa.medical.core.utils.custom_views.confirmation_appointment

import androidx.annotation.StringRes

interface ConfirmationAppointmentHandler {

    fun setConfirmationAppointmentVisibility(isVisible: Boolean)

    fun setOnConfirmationAppointmentClicked(listener: () -> Unit)

    fun handleEnabledConfirmationAppointmentBtn(isEnabled : Boolean)

    fun setTextConfirmationBtn(@StringRes text : Int)

    fun setOnCancelClicked(listener: () -> Unit)

    fun handleEnabledCancelBtn(isEnabled : Boolean)

    fun setTextCancelBtn(@StringRes text : Int)
}