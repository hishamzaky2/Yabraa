package com.yabraa.medical.feature.fragments.home.presentation.adapter

import android.view.LayoutInflater
import android.view.ViewGroup
import androidx.recyclerview.widget.RecyclerView
import com.core.shared.utils.CommonUtils.load
import com.yabraa.medical.databinding.ItemGalleryBinding
import com.yabraa.medical.feature.fragments.home.presentation.adapter.GalleryAdapter.ViewHolder

class GalleryAdapter(
    private val galleryItem: List<String>,
    private val onItemClicked: (String) -> Unit
) :
    RecyclerView.Adapter<ViewHolder>() {
    override fun onCreateViewHolder(parent: ViewGroup, viewType: Int): ViewHolder {
        val binding = ItemGalleryBinding.inflate(LayoutInflater.from(parent.context), parent, false)
        return ViewHolder(binding)
    }

    override fun onBindViewHolder(viewHolder: ViewHolder, position: Int) {
        val galleryItem = galleryItem[position]
        viewHolder.bind(galleryItem)
    }

    override fun getItemCount() = galleryItem.size

    inner class ViewHolder(private val binding: ItemGalleryBinding) :
        RecyclerView.ViewHolder(binding.root) {
        fun bind(gallery: String) {
            binding.root.setOnClickListener { onItemClicked(gallery) }
            binding.galleryIv.load(binding.root.context, gallery)
        }
    }
}