package com.yabraa.medical.feature.fragments.appointment.my_appointment.data.model.response


import com.google.gson.annotations.SerializedName

data class MyAppointmentResponseDto(
    @SerializedName("data")
    val myAppointmentResponse: List<MyAppointmentResponse>,
    @SerializedName("errorMessageAr")
    val errorMessageAr: String? = null,
    @SerializedName("errorMessageEn")
    val errorMessageEn: String? = null,
    @SerializedName("statusCode")
    val statusCode: Int
)