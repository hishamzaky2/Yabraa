package com.yabraa.medical.feature.fragments.register.domain.usecase

import kotlinx.coroutines.async
import kotlinx.coroutines.flow.Flow
import kotlinx.coroutines.flow.channelFlow
import com.core.shared.state.State
import com.yabraa.medical.feature.fragments.register.data.request.RegisterRequestDto
import com.yabraa.medical.feature.fragments.register.data.response.user_input_validation_response.UserInputValidationResponseDto
import com.yabraa.medical.feature.fragments.register.domain.repository.UserInputsValidationRepository
import javax.inject.Inject

class UserInputsValidationUseCase @Inject constructor(private val userInputsValidationRepository: UserInputsValidationRepository) {

    private var responseDto: UserInputValidationResponseDto? = null

    operator fun invoke(registerRequestDto: RegisterRequestDto): Flow<State<UserInputValidationResponseDto>> {
        return channelFlow {
            val userInputValidationResponse =
                async { userInputsValidationRepository.getUserInputValidation(registerRequestDto) }
            userInputValidationResponse.await().collect {
                if (it is State.Success) {
                    responseDto = it.data
                }
                send(it)
            }
        }
    }

    fun getUserValidationResponse() = responseDto?.userInputValidationResponse
}