package com.yabraa.medical.feature.fragments.history_payment.domain.repository

import com.core.shared.state.State
import com.yabraa.medical.feature.fragments.history_payment.data.model.HistoryPaymentResponseDto
import kotlinx.coroutines.flow.Flow

interface HistoryPaymentRepository {
    suspend fun getHistoryPayment(): Flow<State<HistoryPaymentResponseDto>>
}