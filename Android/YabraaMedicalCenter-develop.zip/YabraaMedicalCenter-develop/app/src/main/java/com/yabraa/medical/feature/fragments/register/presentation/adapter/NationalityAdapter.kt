package com.yabraa.medical.feature.fragments.register.presentation.adapter

import android.view.LayoutInflater
import android.view.ViewGroup
import androidx.recyclerview.widget.RecyclerView
import com.yabraa.medical.databinding.ItemNationalityBinding
import com.yabraa.medical.feature.fragments.register.data.response.nationality_response.Nationality
import com.yabraa.medical.feature.fragments.register.presentation.adapter.NationalityAdapter.ViewHolder

class NationalityAdapter(
    private val nationality: List<Nationality>, private val onItemClicked: (Nationality) -> Unit
) : RecyclerView.Adapter<ViewHolder>() {

    override fun onCreateViewHolder(
        parent: ViewGroup, viewType: Int
    ): ViewHolder {
        val binding =
            ItemNationalityBinding.inflate(LayoutInflater.from(parent.context), parent, false)
        return ViewHolder(binding)
    }

    override fun onBindViewHolder(viewHolder: ViewHolder, position: Int) {
        val nationality = nationality[position]
        viewHolder.bind(nationality)
    }

    override fun getItemCount() = nationality.size

    inner class ViewHolder(private val binding: ItemNationalityBinding) :
        RecyclerView.ViewHolder(binding.root) {
        fun bind(nationality: Nationality) {
            binding.setUpViews(nationality, onItemClicked)
        }

        private fun ItemNationalityBinding.setUpViews(
            nationality: Nationality, onItemClicked: (Nationality) -> Unit
        ) {
            root.setOnClickListener { onItemClicked.invoke(nationality) }
            nationalityTv.text = nationality.getCountryName(nationality)
        }
    }
}