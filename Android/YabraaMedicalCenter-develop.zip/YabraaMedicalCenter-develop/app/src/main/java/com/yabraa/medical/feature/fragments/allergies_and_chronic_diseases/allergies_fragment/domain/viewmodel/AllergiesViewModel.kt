package com.yabraa.medical.feature.fragments.allergies_and_chronic_diseases.allergies_fragment.domain.viewmodel

import androidx.lifecycle.ViewModel
import androidx.lifecycle.viewModelScope
import com.core.shared.state.State
import com.yabraa.medical.feature.fragments.allergies_and_chronic_diseases.allergies_fragment.data.model.request.AllergiesRequestDto
import com.yabraa.medical.feature.fragments.allergies_and_chronic_diseases.allergies_fragment.data.model.response.AllergiesResponseDto
import com.yabraa.medical.feature.fragments.allergies_and_chronic_diseases.allergies_fragment.domain.repository.AddAllergiesRepository
import com.yabraa.medical.feature.fragments.allergies_and_chronic_diseases.allergies_fragment.domain.repository.DeleteAllergiesRepository
import com.yabraa.medical.feature.fragments.allergies_and_chronic_diseases.allergies_fragment.domain.usecase.AllergiesUseCase
import dagger.hilt.android.lifecycle.HiltViewModel
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.launch
import javax.inject.Inject

@HiltViewModel
class AllergiesViewModel @Inject constructor(
    private val allergiesUseCase: AllergiesUseCase,
    private val addAllergiesRepository: AddAllergiesRepository,
    private val deleteAllergiesRepository: DeleteAllergiesRepository
) : ViewModel() {

    private val _allergiesResponseState =
        MutableStateFlow<State<AllergiesResponseDto>>(State.Initial())
    val allergiesResponseState: StateFlow<State<AllergiesResponseDto>> =
        _allergiesResponseState

    private val _allergiesByUserFamilyIdResponseState =
        MutableStateFlow<State<AllergiesResponseDto>>(State.Initial())
    val allergiesByUserFamilyIdResponseState: StateFlow<State<AllergiesResponseDto>> =
        _allergiesByUserFamilyIdResponseState

    private val _addAllergiesResponseState =
        MutableStateFlow<State<AllergiesResponseDto>>(State.Initial())
    val addAllergiesResponseState: StateFlow<State<AllergiesResponseDto>> =
        _addAllergiesResponseState

    private val _deleteAllergiesResponseState =
        MutableStateFlow<State<AllergiesResponseDto>>(State.Initial())
    val deleteAllergiesResponseState: StateFlow<State<AllergiesResponseDto>> =
        _deleteAllergiesResponseState

    fun getAllergies() {
        viewModelScope.launch {
            _allergiesResponseState.emit(State.Loading())
            allergiesUseCase().collect {
                _allergiesResponseState.emit(it)
            }
        }
    }


    fun getAllergiesByUserFamilyId(userFamilyId: Long) {
        viewModelScope.launch {
            _allergiesByUserFamilyIdResponseState.emit(State.Loading())
            allergiesUseCase(userFamilyId).collect {
                _allergiesByUserFamilyIdResponseState.emit(it)
            }
        }
    }

    fun addAllergies(requestDto: AllergiesRequestDto) {
        viewModelScope.launch {
            _addAllergiesResponseState.emit(State.Loading())
            addAllergiesRepository.addAllergies(requestDto).collect {
                _addAllergiesResponseState.emit(it)
            }
        }
    }


    fun deleteAllergies(requestDto: AllergiesRequestDto) {
        viewModelScope.launch {
            _deleteAllergiesResponseState.emit(State.Loading())
            deleteAllergiesRepository.deleteAllergies(requestDto).collect {
                _deleteAllergiesResponseState.emit(it)
            }
        }
    }

    fun getAllergiesList() = allergiesUseCase.getAllergiesList()

}