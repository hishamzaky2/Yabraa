package com.yabraa.medical.feature.fragments.connect_with_yabraa.presentation

import android.os.Bundle
import android.view.View
import androidx.hilt.navigation.fragment.hiltNavGraphViewModels
import androidx.navigation.fragment.findNavController
import com.yabraa.medical.R
import com.yabraa.medical.core.base_fragment.BaseFragment
import com.yabraa.medical.core.utils.custom_views.yabraa_bar.YabraaBarHandler
import com.yabraa.medical.databinding.FragmentConnectWithYabraaBinding
import com.yabraa.medical.feature.fragments.setting.domain.viewmodel.SettingViewModel

class ConnectWithYabraaFragment : BaseFragment<FragmentConnectWithYabraaBinding>() {

    override val binding by lazy { FragmentConnectWithYabraaBinding.inflate(layoutInflater) }
    private val viewModel: SettingViewModel by hiltNavGraphViewModels(R.id.setting_graph)

    override fun onViewCreated(view: View, savedInstanceState: Bundle?) {
        super.onViewCreated(view, savedInstanceState)

    }


    override fun onResume() {
        super.onResume()
        yabraaBarView?.setUpYabraaBarView()
        confirmationView?.setConfirmationAppointmentVisibility(false)
        showBottomNavigation(false)
    }

    private fun YabraaBarHandler.setUpYabraaBarView() {
        val barTitle = viewModel.yabraaBarTitle ?: ""
        setYabraaBarVisibility(true)
        setClearAllVisibility(false)
        setBarTitle(barTitle)
        setOnBackArrowClicked { findNavController().popBackStack() }
    }
}