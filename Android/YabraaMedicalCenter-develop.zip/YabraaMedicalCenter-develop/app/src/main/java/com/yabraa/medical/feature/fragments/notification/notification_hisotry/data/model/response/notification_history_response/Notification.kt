package com.yabraa.medical.feature.fragments.notification.notification_hisotry.data.model.response.notification_history_response


import com.google.gson.annotations.SerializedName
import java.io.Serializable

data class Notification(
    @SerializedName("bodyAR")
    val bodyAR: String,
    @SerializedName("bodyEn")
    val bodyEn: String,
    @SerializedName("isRead")
    val isRead: Boolean,
    @SerializedName("notificationId")
    val notificationId: Long,
    @SerializedName("titleAR")
    val titleAR: String,
    @SerializedName("titleEn")
    val titleEn: String
) : Serializable