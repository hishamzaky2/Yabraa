package com.yabraa.medical.feature.fragments.checkout.data.repository.checkout_repository

import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.flow.flow
import kotlinx.coroutines.flow.flowOn
import com.yabraa.medical.core.base_repository.BaseRepository
import com.yabraa.medical.core.di.network_sevices.YabraaServices
import com.core.shared.state.State
import com.yabraa.medical.core.utils.getResponseMessageError
import com.yabraa.medical.feature.fragments.checkout.data.model.request.CheckoutRequestDto
import com.yabraa.medical.feature.fragments.checkout.data.model.response.checkout_response.CheckoutResponseDto
import com.yabraa.medical.feature.fragments.checkout.domain.repository.checkout_repository.CheckoutRepository
import retrofit2.Response
import javax.inject.Inject

const val TAG_CHECKOUT_RESPONSE = "TAG_CHECKOUT_RESPONSE"

class CheckoutRepositoryImpl @Inject constructor(private val yabraaServices: YabraaServices) :
    BaseRepository<CheckoutRequestDto, CheckoutResponseDto>(), CheckoutRepository {

    override suspend fun checkout(checkoutRequestDto: CheckoutRequestDto) = flow {
        emit(getOperationState(checkoutRequestDto))
    }.flowOn(Dispatchers.IO)


    override suspend fun performApiCall(requestDto: CheckoutRequestDto): State<CheckoutResponseDto> {
        val response = yabraaServices.checkout(requestDto)
        return handleCheckoutResponse(response)
    }


    private fun handleCheckoutResponse(response: Response<CheckoutResponseDto>): State<CheckoutResponseDto> {
        val responseBody = response.body()
        val errorMessageEn = responseBody?.errorMessageEn ?: ""
        val errorMessageAr = responseBody?.errorMessageAr ?: ""
        return when {
            response.isSuccessful -> State.Success(response.body())

            response.isSuccessful && !responseBody?.errorMessageEn.isNullOrEmpty() -> getResponseMessageError(
                errorMessageEn = errorMessageEn,
                errorMessageAr = errorMessageAr,
                logTag = TAG_CHECKOUT_RESPONSE
            )

            else -> getNotSuccessfulResponseState(response)
        }
    }
}