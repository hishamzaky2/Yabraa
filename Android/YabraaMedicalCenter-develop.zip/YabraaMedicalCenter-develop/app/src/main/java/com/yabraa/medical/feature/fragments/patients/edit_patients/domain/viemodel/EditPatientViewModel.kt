package com.yabraa.medical.feature.fragments.patients.edit_patients.domain.viemodel

import androidx.lifecycle.ViewModel
import androidx.lifecycle.viewModelScope
import com.core.shared.error.EmptyBirthDate
import com.core.shared.error.EmptyGender
import com.core.shared.error.PatientName
import com.core.shared.error.YabraaError
import com.core.shared.state.State
import com.yabraa.medical.feature.fragments.patients.edit_patients.data.model.response.delete_patient_response.DeletePatientResponseDto
import com.yabraa.medical.feature.fragments.patients.edit_patients.data.model.response.edit_patient_response.EditPatientResponseDto
import com.yabraa.medical.feature.fragments.patients.edit_patients.domain.model.EditPatientUi
import com.yabraa.medical.feature.fragments.patients.edit_patients.domain.usecase.delete_patient_usecase.DeletePatientUseCase
import com.yabraa.medical.feature.fragments.patients.edit_patients.domain.usecase.edit_patient_usecase.EditPatientUseCase
import dagger.hilt.android.lifecycle.HiltViewModel
import kotlinx.coroutines.flow.MutableSharedFlow
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.SharedFlow
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.launch
import javax.inject.Inject

@HiltViewModel
class EditPatientViewModel @Inject constructor(
    private val editPatientUseCase: EditPatientUseCase,
    private val deletePatientUseCase: DeletePatientUseCase
) : ViewModel() {

    private val _validationState = MutableSharedFlow<State<Any?>>()
    val validationState: SharedFlow<State<Any?>> = _validationState

    private val _editPatientResponseState =
        MutableStateFlow<State<EditPatientResponseDto>>(State.Initial())
    val editPatientResponseState: StateFlow<State<EditPatientResponseDto>> =
        _editPatientResponseState


    private val _deletePatientResponseState = MutableSharedFlow<State<DeletePatientResponseDto>>()
    val deletePatientResponseState: SharedFlow<State<DeletePatientResponseDto>> =
        _deletePatientResponseState


    fun validateInput(editPatientUi: EditPatientUi) {
        viewModelScope.launch {
            val isLoadingOrSuccess =
                _editPatientResponseState.value is State.Loading || _editPatientResponseState.value is State.Success
            if (isLoadingOrSuccess) {
                return@launch
            }
            editPatientUi.validateInput()
        }
    }


    private suspend fun EditPatientUi.validateInput() = when {
        name.isEmpty() -> _validationState.emit(getValidationError(PatientName()))
        birthDate.isEmpty() -> _validationState.emit(getValidationError(EmptyBirthDate()))
        gender.isEmpty() -> _validationState.emit(getValidationError(EmptyGender()))
        else -> onValidInput(this)
    }

    private fun <E> getValidationError(error: Exception) =
        State.Error<E>(YabraaError.I(exception = error))


    private suspend fun onValidInput(editPatientUi: EditPatientUi) {
        _validationState.emit(State.Success(null))
        _editPatientResponseState.emit(State.Loading())
        addPatient(editPatientUi)
    }

    private suspend fun addPatient(editPatientUi: EditPatientUi) {
        _editPatientResponseState.emit(State.Loading())
        editPatientUseCase(editPatientUi.toUpdatePatient()).collect {
            _editPatientResponseState.emit(it)
        }
    }


    fun deletePatient(userFamilyId: Long) {
        viewModelScope.launch {
            _deletePatientResponseState.emit(State.Loading())
            deletePatientUseCase(userFamilyId).collect {
                _deletePatientResponseState.emit(it)
            }
        }
    }
}