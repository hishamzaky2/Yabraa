package com.yabraa.medical.feature.fragments.onboard.domin.usecase

import kotlinx.coroutines.async
import kotlinx.coroutines.flow.Flow
import kotlinx.coroutines.flow.channelFlow
import com.core.shared.state.State
import com.yabraa.medical.feature.fragments.onboard.data.response.OnboardPagesResponseDto
import com.yabraa.medical.feature.fragments.onboard.domin.repository.OnboardRepository
import javax.inject.Inject

class OnboardUseCase @Inject constructor(private val onboardRepository: OnboardRepository) {

    private var responseDto: OnboardPagesResponseDto? = null

    operator fun invoke(): Flow<State<OnboardPagesResponseDto>> {
        return channelFlow {
            val onboardPagesResponse = async { onboardRepository.getOnboardPages() }
            onboardPagesResponse.await().collect {
                if (it is State.Success) {
                    responseDto = it.data
                }
                send(it)
            }
        }
    }


    fun getSuccessState() = responseDto?.data.isNullOrEmpty()

    fun getPagesDetails() = responseDto?.data
}