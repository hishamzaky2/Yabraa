package com.yabraa.medical.feature.fragments.patients.patients.domain.viewmodel

import androidx.lifecycle.ViewModel
import androidx.lifecycle.viewModelScope
import dagger.hilt.android.lifecycle.HiltViewModel
import kotlinx.coroutines.launch
import com.core.shared.state.State
import com.yabraa.medical.feature.fragments.patients.patients.data.model.response.PatientResponseDto
import com.yabraa.medical.feature.fragments.patients.patients.domain.usecase.PatientListUseCase
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.StateFlow
import javax.inject.Inject


@HiltViewModel
class PatientListViewModel @Inject constructor(private val patientListUseCase: PatientListUseCase) :
    ViewModel() {


    private val _patientResponseState = MutableStateFlow<State<PatientResponseDto>>(State.Initial())
    val patientResponseState: StateFlow<State<PatientResponseDto>> = _patientResponseState


    fun getPatients() {
        viewModelScope.launch {
            _patientResponseState.emit(State.Loading())
            patientListUseCase().collect {
                _patientResponseState.emit(it)
            }
        }
    }

    fun getPatientList() = patientListUseCase.getPatientList()
}