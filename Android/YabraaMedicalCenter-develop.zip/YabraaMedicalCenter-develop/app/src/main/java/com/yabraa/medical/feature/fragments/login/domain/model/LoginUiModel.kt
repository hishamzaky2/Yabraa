package com.yabraa.medical.feature.fragments.login.domain.model

import com.yabraa.medical.feature.fragments.login.data.model.request.LoginRequestDto

data class LoginUiModel(var phoneNumber: String, var password: String) {
    fun toLogin() = LoginRequestDto(phoneNumber = phoneNumber, password = password)
}