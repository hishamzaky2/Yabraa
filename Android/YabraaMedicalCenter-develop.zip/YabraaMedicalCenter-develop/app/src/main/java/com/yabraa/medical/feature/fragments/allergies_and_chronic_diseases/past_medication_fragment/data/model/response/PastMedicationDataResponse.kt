package com.yabraa.medical.feature.fragments.allergies_and_chronic_diseases.past_medication_fragment.data.model.response


import com.google.gson.annotations.SerializedName

data class PastMedicationDataResponse(
    @SerializedName("medicationId")
    val medicationId: Long,
    @SerializedName("titleAR")
    val titleAR: String,
    @SerializedName("titleEN")
    val titleEN: String
)