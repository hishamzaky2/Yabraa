package com.yabraa.medical.feature.fragments.allergies_and_chronic_diseases.injuries_fragment.domain.usecase

import com.core.shared.state.State
import com.yabraa.medical.feature.fragments.allergies_and_chronic_diseases.injuries_fragment.data.model.response.InjuriesDataResponse
import com.yabraa.medical.feature.fragments.allergies_and_chronic_diseases.injuries_fragment.data.model.response.InjuriesResponseDto
import com.yabraa.medical.feature.fragments.allergies_and_chronic_diseases.injuries_fragment.domain.model.InjuriesEntityModel
import com.yabraa.medical.feature.fragments.allergies_and_chronic_diseases.injuries_fragment.domain.repository.InjuriesByUserFamilyIdRepository
import com.yabraa.medical.feature.fragments.allergies_and_chronic_diseases.injuries_fragment.domain.repository.InjuriesRepository
import kotlinx.coroutines.async
import kotlinx.coroutines.flow.Flow
import kotlinx.coroutines.flow.channelFlow
import javax.inject.Inject

class InjuriesUseCase @Inject constructor(
    private val injuriesRepository: InjuriesRepository,
    private val injuriesByUserFamilyIdRepository: InjuriesByUserFamilyIdRepository
) {


    private var injuriesResponse: List<InjuriesDataResponse>? = null

    private var injuriesByUserFamilyIdResponse: List<InjuriesDataResponse>? = null

    suspend operator fun invoke(): Flow<State<InjuriesResponseDto>> {
        return channelFlow {
            val response = async { injuriesRepository.getInjuries() }
            response.await().collect {
                if (it is State.Success) {
                    injuriesResponse = it.data?.injuriesDataResponse
                }
                send(it)
            }
        }
    }

    suspend operator fun invoke(userFamilyId: Long): Flow<State<InjuriesResponseDto>> {
        return channelFlow {
            val response =
                async {
                    injuriesByUserFamilyIdRepository.getInjuriesByUserFamilyId(userFamilyId)
                }
            response.await().collect {
                if (it is State.Success) {
                    injuriesByUserFamilyIdResponse = it.data?.injuriesDataResponse
                }
                send(it)
            }
        }
    }


    fun getInjuriesList(): List<InjuriesEntityModel> {
        val injuriesEntityMap =
            getInjuriesEntityList().associateBy { it.injuryId }.toMutableMap()
        injuriesByUserFamilyIdResponse?.map { it.injuryId }?.forEach {
            val newInjuriesEntityModel = injuriesEntityMap[it] ?: return@forEach
            injuriesEntityMap[it] = newInjuriesEntityModel.copy(isAdded = true)
        }
        return injuriesEntityMap.values.toList()
    }

    private fun getInjuriesEntityList() = injuriesResponse?.map {
        InjuriesEntityModel(
            injuryId = it.injuryId,
            titleAR = it.titleAR,
            titleEN = it.titleEN
        )
    } ?: emptyList()

}