package com.yabraa.medical.core.utils.custom_views.yabraa_bar

import android.content.Context
import android.util.AttributeSet
import android.view.LayoutInflater
import android.widget.FrameLayout
import com.yabraa.medical.databinding.LayoutYabraaBarBinding

class YabraaBarView @JvmOverloads constructor(
    context: Context, attributes: AttributeSet? = null
) : FrameLayout(context, attributes) {

    val binding = LayoutYabraaBarBinding.inflate(LayoutInflater.from(context), this, true)

    val backArrowIv by lazy { binding.backArrowIv }

    val titleTv by lazy { binding.titleTv }

    val clearAll by lazy { binding.clearTv }

}