package com.yabraa.medical.feature.fragments.allergies_and_chronic_diseases.chronic_diseases_fragment.data.repository

import com.yabraa.medical.core.base_repository.BaseRepository
import com.yabraa.medical.core.di.network_sevices.AllergiesAndChronicDiseasesServices
import com.core.shared.state.State
import com.yabraa.medical.core.utils.getResponseMessageError
import com.yabraa.medical.feature.fragments.allergies_and_chronic_diseases.chronic_diseases_fragment.data.model.response.ChronicDiseasesResponseDto
import com.yabraa.medical.feature.fragments.allergies_and_chronic_diseases.chronic_diseases_fragment.domain.repository.ChronicDiseasesByUserFamilyIdRepository
import kotlinx.coroutines.flow.flow
import kotlinx.coroutines.flow.flowOn
import retrofit2.Response
import javax.inject.Inject

const val TAG_CHRONIC_DISEASES_BY_USER_FAMILY_RESPONSE =
    "TAG_CHRONIC_DISEASES_BY_USER_FAMILY_RESPONSE"

class ChronicDiseasesByUserFamilyIdRepositoryImpl @Inject constructor(private val allergiesAndChronicDiseasesServices: AllergiesAndChronicDiseasesServices) :
    BaseRepository<Long, ChronicDiseasesResponseDto>(),
    ChronicDiseasesByUserFamilyIdRepository {

    override suspend fun getChronicDiseasesByUserFamilyId(userFamilyId: Long) = flow {
        emit(getOperationState(userFamilyId))
    }.flowOn(dispatcher)

    override suspend fun performApiCall(requestDto: Long): State<ChronicDiseasesResponseDto> {
        val response =
            allergiesAndChronicDiseasesServices.getChronicDiseasesByUserFamilyId(requestDto)
        return handleResponse(response)
    }

    fun handleResponse(response: Response<ChronicDiseasesResponseDto>): State<ChronicDiseasesResponseDto> {
        val responseBody = response.body()
        val errorMessageEn = responseBody?.errorMessageEn ?: ""
        val errorMessageAr = responseBody?.errorMessageAr ?: ""
        return when {
            response.isSuccessful -> State.Success(response.body())

            response.isSuccessful && !responseBody?.errorMessageEn.isNullOrEmpty() -> getResponseMessageError(
                errorMessageEn = errorMessageEn,
                errorMessageAr = errorMessageAr,
                logTag = TAG_CHRONIC_DISEASES_BY_USER_FAMILY_RESPONSE
            )

            else -> getNotSuccessfulResponseState(response)
        }
    }
}