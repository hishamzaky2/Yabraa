package com.yabraa.medical.feature.fragments.appointment.my_appointment_details.domain.viewmodel

import androidx.lifecycle.ViewModel
import androidx.lifecycle.viewModelScope
import com.core.shared.state.State
import com.yabraa.medical.feature.fragments.appointment.my_appointment_details.data.model.MyAppointmentDetailsResponseDto
import com.yabraa.medical.feature.fragments.appointment.my_appointment_details.domain.repository.MyAppointmentDetailsRepository
import dagger.hilt.android.lifecycle.HiltViewModel
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.launch
import javax.inject.Inject

@HiltViewModel
class MyAppointmentDetailsViewModel @Inject constructor(private val myAppointmentDetailsRepository: MyAppointmentDetailsRepository) :
    ViewModel() {

    private val _myAppointmentDetailsResponseState =
        MutableStateFlow<State<MyAppointmentDetailsResponseDto>>(State.Initial())

    val myAppointmentDetailsResponseState: StateFlow<State<MyAppointmentDetailsResponseDto>> =
        _myAppointmentDetailsResponseState


    fun getMyAppointmentDetails(id: Long) {
        viewModelScope.launch {
            _myAppointmentDetailsResponseState.emit(State.Loading())
            myAppointmentDetailsRepository.getAppointmentDetails(id).collect {
                _myAppointmentDetailsResponseState.emit(it)
            }
        }
    }
}