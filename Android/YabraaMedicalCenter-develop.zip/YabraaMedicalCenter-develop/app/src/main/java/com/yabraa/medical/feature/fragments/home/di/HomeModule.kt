package com.yabraa.medical.feature.fragments.home.di

import dagger.Module
import dagger.Provides
import dagger.hilt.InstallIn
import dagger.hilt.android.components.ViewModelComponent
import com.yabraa.medical.core.di.network_sevices.YabraaServices
import com.yabraa.medical.feature.fragments.home.data.repository.gallery_repository.GalleryRepositoryImpl
import com.yabraa.medical.feature.fragments.home.data.repository.service_type_repository.ServiceTypeRepositoryImpl
import com.yabraa.medical.feature.fragments.home.data.repository.services_details_repository.ServicesDetailsRepositoryImpl
import com.yabraa.medical.feature.fragments.home.domain.repository.gallery_repository.GalleryRepository
import com.yabraa.medical.feature.fragments.home.domain.repository.service_type_repository.ServiceTypeRepository
import com.yabraa.medical.feature.fragments.home.domain.repository.services_details_repository.ServicesDetailsRepository

@Module
@InstallIn(ViewModelComponent::class)
object HomeModule {

    @Provides
    fun provideGalleryRepository(yabraaServices: YabraaServices): GalleryRepository =
        GalleryRepositoryImpl(yabraaServices)

    @Provides
    fun provideServicesDetailsRepository(yabraaServices: YabraaServices): ServicesDetailsRepository =
        ServicesDetailsRepositoryImpl(yabraaServices)

    @Provides
    fun provideServiceTypeRepository(yabraaServices: YabraaServices) : ServiceTypeRepository = ServiceTypeRepositoryImpl(yabraaServices)
}