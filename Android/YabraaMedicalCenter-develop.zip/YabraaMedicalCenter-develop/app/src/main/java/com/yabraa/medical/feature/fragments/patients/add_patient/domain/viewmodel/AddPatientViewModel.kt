package com.yabraa.medical.feature.fragments.patients.add_patient.domain.viewmodel

import androidx.lifecycle.ViewModel
import androidx.lifecycle.viewModelScope
import dagger.hilt.android.lifecycle.HiltViewModel
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.launch
import com.core.shared.error.EmptyBirthDate
import com.core.shared.error.EmptyGender
import com.core.shared.error.PatientName
import com.core.shared.error.YabraaError
import com.core.shared.state.State
import com.yabraa.medical.feature.fragments.patients.add_patient.data.model.reposne.AddPatientResponseDto
import com.yabraa.medical.feature.fragments.patients.add_patient.domain.model.AddPatientUi
import com.yabraa.medical.feature.fragments.patients.add_patient.domain.usecase.AddPatientUseCase
import javax.inject.Inject

@HiltViewModel
class AddPatientViewModel @Inject constructor(private val addPatientUseCase: AddPatientUseCase) :
    ViewModel() {

    private val _validationState = MutableStateFlow<State<Any?>>(State.Initial())
    val validationState: StateFlow<State<Any?>> = _validationState

    private val _addPatientResponseState =
        MutableStateFlow<State<AddPatientResponseDto>>(State.Initial())
    val addPatientResponseState: StateFlow<State<AddPatientResponseDto>> = _addPatientResponseState


    fun validateInput(addPatientUi: AddPatientUi) {
        viewModelScope.launch {
            val isLoadingOrSuccess =
                _addPatientResponseState.value is State.Loading || _addPatientResponseState.value is State.Success
            if (isLoadingOrSuccess) {
                return@launch
            }
            addPatientUi.validateInput()
        }
    }


    private suspend fun AddPatientUi.validateInput() = when {
        name.isEmpty() -> _validationState.emit(getValidationError(PatientName()))
        birthDate.isEmpty() -> _validationState.emit(getValidationError(EmptyBirthDate()))
        gender.isEmpty() -> _validationState.emit(getValidationError(EmptyGender()))
        else -> onValidInput(this)
    }

    private fun <E> getValidationError(error: Exception) =
        State.Error<E>(YabraaError.I(exception = error))


    private suspend fun onValidInput(addPatientUi: AddPatientUi) {
        _validationState.emit(State.Success(null))
        _addPatientResponseState.emit(State.Loading())
        addPatient(addPatientUi)
    }

    private suspend fun addPatient(addPatientUi: AddPatientUi) {
        _addPatientResponseState.emit(State.Loading())
        addPatientUseCase(addPatientUi.toAddNewPatient()).collect {
            _addPatientResponseState.emit(it)
        }
    }
}