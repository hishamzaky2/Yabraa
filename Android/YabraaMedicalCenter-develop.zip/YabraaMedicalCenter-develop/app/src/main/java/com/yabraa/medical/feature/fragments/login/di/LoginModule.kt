package com.yabraa.medical.feature.fragments.login.di

import dagger.Module
import dagger.Provides
import dagger.hilt.InstallIn
import dagger.hilt.android.components.ViewModelComponent
import com.yabraa.medical.core.di.network_sevices.SecurityServices
import com.yabraa.medical.feature.fragments.login.data.repository.LoginRepositoryImpl
import com.yabraa.medical.feature.fragments.login.domain.repository.LoginRepository

@Module
@InstallIn(ViewModelComponent::class)
object LoginModule {

    @Provides
    fun provideLoginRepository(securityServices: SecurityServices): LoginRepository =
        LoginRepositoryImpl(securityServices)
}