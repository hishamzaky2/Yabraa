package com.yabraa.medical.feature.fragments.filter.presentation

import android.os.Bundle
import android.view.View
import androidx.core.content.ContextCompat.getColorStateList
import androidx.core.view.isVisible
import androidx.hilt.navigation.fragment.hiltNavGraphViewModels
import androidx.lifecycle.MutableLiveData
import androidx.navigation.fragment.findNavController
import com.yabraa.medical.R
import com.yabraa.medical.core.base_fragment.BaseFragment
import com.yabraa.medical.core.base_fragment.navigate
import com.core.shared.utils.CommonUtils.handleExpirationDate
import com.yabraa.medical.core.utils.custom_views.confirmation_appointment.ConfirmationAppointmentHandler
import com.yabraa.medical.core.utils.custom_views.yabraa_bar.YabraaBarHandler
import com.yabraa.medical.databinding.FragmentFilterBinding
import com.yabraa.medical.databinding.ItemPackagesBinding
import com.yabraa.medical.feature.fragments.common.domain.viewmodel.TransactionViewModel
import com.yabraa.medical.feature.fragments.filter.presentation.adapter.FilterAdapter
import com.yabraa.medical.feature.fragments.filter.presentation.adapter.FilterAdapter.FilterAdapterCallback
import com.yabraa.medical.feature.fragments.filter.presentation.adapter.FilterAdapter.OnFilterItemClickListener
import com.yabraa.medical.feature.fragments.filter.presentation.adapter.PackagesAdapter
import com.yabraa.medical.feature.fragments.filter.presentation.adapter.PackagesAdapter.OnPackageClickListener
import com.yabraa.medical.feature.fragments.filter.presentation.adapter.PackagesAdapter.PackageAdapterViewHolder
import com.yabraa.medical.feature.fragments.filter.presentation.adapter.PackagesAdapter.ViewHolder
import com.yabraa.medical.feature.fragments.home.data.model.response.services_details_response.FilterData
import com.yabraa.medical.feature.fragments.home.data.model.response.services_details_response.PackageData
import dagger.hilt.android.AndroidEntryPoint

const val PACKAGE_ITEM = "PACKAGE_ITEM"

@AndroidEntryPoint
class FilterFragment : BaseFragment<FragmentFilterBinding>(), OnFilterItemClickListener,
    FilterAdapterCallback, OnPackageClickListener, PackageAdapterViewHolder {

    override val binding by lazy { FragmentFilterBinding.inflate(layoutInflater) }

    val viewModel: TransactionViewModel by hiltNavGraphViewModels(R.id.mainNavGraph)

    private val serviceId get() = viewModel.serviceId ?: 0L
    private val serviceName get() = viewModel.getServiceNameByServiceId(serviceId)
    private val filterList get() = viewModel.getFilterByServicesId(serviceId)

    private lateinit var packagesAdapter: PackagesAdapter

    private val filterAdapter by lazy { FilterAdapter(filterList) }
    private val selectionIds get() = viewModel.addPackageItemsList.map { it.packageId }

    private var isClearAllClicked = MutableLiveData(false)
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        showExpirationDateError()
    }

    override fun onViewCreated(view: View, savedInstanceState: Bundle?) {
        super.onViewCreated(view, savedInstanceState)
        binding.setUpViews()
    }


    override fun onResume() {
        super.onResume()
        confirmationView?.handleConfirmationAppointment()
        yabraaBarView?.setYabraaBarViews()
        showBottomNavigation(false)
    }


    private fun YabraaBarHandler.setYabraaBarViews() {
        setYabraaBarVisibility(true)
        setBarTitle(serviceName)
        setOnBackArrowClicked()
        setClearAllVisibility(true)
        setOnClearAllClicked()
    }

    private fun YabraaBarHandler.setOnBackArrowClicked() =
        setOnBackArrowClicked { findNavController().popBackStack() }

    private fun YabraaBarHandler.setOnClearAllClicked() = setOnClearAllClicked {
        clearAllItems()
    }


    private fun FragmentFilterBinding.setUpViews() {
        setFilterAdapter()
        setUpPackagesAdapter()
    }


    private fun FragmentFilterBinding.setFilterAdapter() {
        filterAdapter.initializeFilterAdapterCallback()
        filterRV.adapter = filterAdapter
    }

    private fun FilterAdapter.initializeFilterAdapterCallback() {
        setOnSelectedItemClicked(this@FilterFragment)
        setOnUnSelectedItemClicked(this@FilterFragment)
        initializeItemFilterSelected(this@FilterFragment)
    }

    override fun setOnSelectedFilterItemClicked(filterIds: List<Long>) {
        showDelayProgressDialog {
            setUpPackagesAdapter(filterIds)
        }
    }


    override fun setOnUnSelectedFilterItemClicked(filterIds: List<Long>) {
        showDelayProgressDialog {
            when {
                filterIds.isNotEmpty() -> setUpPackagesAdapter(filterIds)

                else -> setUpPackagesAdapter()
            }
        }
    }


    private fun setUpPackagesAdapter(filterId: List<Long>? = null) {
        val packageData = viewModel.getPackagesByFilterIds(serviceId, filterId)
        packagesAdapter = PackagesAdapter(packageData, this)
        packagesAdapter.setUpPackageAdapterCallback()
        binding.packagesRV.adapter = packagesAdapter
        binding.packagesRV.setHasFixedSize(true)
    }

    private fun PackagesAdapter.setUpPackageAdapterCallback() {
        setOnsetOnReadMoreListener(this@FilterFragment)
    }

    override fun setOnReadMoreClicked(packageItem: PackageData) {
        showDelayProgressDialog {
            navigateToPackageDetails(packageItem)
        }
    }


    override fun packageAdapterViewHolder(holder: ViewHolder, item: PackageData, position: Int) {
        holder.binding.setOnMakeAppointmentBtnClicked(item)
        selectionIds.forEach {
            if (item.packageId == it) holder.binding.handleSelectedPackageItem(true)
        }
    }

    private fun ItemPackagesBinding.setOnMakeAppointmentBtnClicked(item: PackageData) {
        makeAppointmentBtn.setOnClickListener {
            navigateToPackageDetails(item)
        }
    }

    private fun ItemPackagesBinding.handleSelectedPackageItem(isSelected: Boolean) {
        setMakeAppointmentBtnBackground(isSelected)
        handleMakeAppointmentBtnText(isSelected)
        handleMakeAppointmentBtnTextColor(isSelected)

    }

    private fun ItemPackagesBinding.setMakeAppointmentBtnBackground(isSelected: Boolean) {
        val selectedDrawable = getColorStateList(requireActivity(), R.color.brandPaletteDark800)
        val unSelectedDrawable = getColorStateList(requireActivity(), R.color.primaryLight100)
        makeAppointmentBtn.backgroundTintList = if (isSelected) selectedDrawable else unSelectedDrawable
        selectedAppointmentIv.isVisible = isSelected

    }

    private fun ItemPackagesBinding.handleMakeAppointmentBtnText(isSelected: Boolean) {
        val text = if (isSelected) R.string.appointmentBooked else R.string.makeAnAppointment
        makeAppointmentBtn.setText(text)
    }

    private fun ItemPackagesBinding.handleMakeAppointmentBtnTextColor(isSelected: Boolean) {
        val selectedColor = getColorStateList(requireActivity(), R.color.primaryWhite)
        val unSelectedColor = getColorStateList(requireActivity(), R.color.black)
        val color = if (isSelected) selectedColor else unSelectedColor
        makeAppointmentBtn.setTextColor(color)
    }


    private fun navigateToPackageDetails(packageItem: PackageData) {
        val bundle = Bundle()
        bundle.putSerializable(PACKAGE_ITEM, packageItem)
        navigate(R.id.actionFilterFragmentToPackageDetailsFragment, bundle)
    }

    private fun ConfirmationAppointmentHandler.handleConfirmationAppointment() {
        if (selectionIds.isEmpty()) {
            handleNavigationBottomAndConfirmationViewVisibility(false)
            return
        }
        handleNavigationBottomAndConfirmationViewVisibility(true)
        handleEnabledConfirmationAppointmentBtn(selectionIds.isNotEmpty())
        setOnConfirmationAppointmentBtnClicked()
        setOnCancelAllPackageItemClicked()
        handleEnabledCancelBtn()
    }

    private fun ConfirmationAppointmentHandler.setOnConfirmationAppointmentBtnClicked() {
        setTextConfirmationBtn(R.string.confirmingAppointments)
        connectivityManager?.isNetworkConnected?.observe(this@FilterFragment) { isConnected ->
            setOnConfirmationAppointmentClicked {
                if (!isConnected) {
                    showNetworkConnectionErrorPopup()
                    return@setOnConfirmationAppointmentClicked
                }
                navigateToSelectDateAndTimeScreen()
            }
        }
    }

    private fun navigateToSelectDateAndTimeScreen() =
        showDelayProgressDialog { navigate(R.id.actionFilterFragmentToSelectTimeAndDateFragment) }


    private fun ConfirmationAppointmentHandler.setOnCancelAllPackageItemClicked() {
        setTextCancelBtn(R.string.cancel)
        setOnCancelClicked { clearAllItems() }
    }

    private fun ConfirmationAppointmentHandler.handleEnabledCancelBtn() {
        handleEnabledCancelBtn(viewModel.addPackageItemsList.isNotEmpty())
    }


    private fun clearAllItems() {
        showDelayProgressDialog {
            binding.setFilterAdapter()
            setUpPackagesAdapter()
            isClearAllClicked.postValue(true)
            viewModel.handleClearAllLists()
            handleNavigationBottomAndConfirmationViewVisibility(false)
        }
    }

    override fun clearAllFilterItemsSelected(
        filterIdsList: MutableList<Long>, filterData: FilterData
    ) {
        isClearAllClicked.observe(requireActivity()) {
            if (!it) return@observe
            isClearAllClicked.postValue(false)
            filterIdsList.clear()
            filterData.setSelected(false)
        }
    }

    private fun handleNavigationBottomAndConfirmationViewVisibility(isVisible: Boolean) {
        confirmationView?.setConfirmationAppointmentVisibility(isVisible)
        //showBottomNavigation(!isVisible)
    }

    private fun showExpirationDateError() =
        tokenHandler.handleExpirationDate { showExpirationDatePopupError() }
}