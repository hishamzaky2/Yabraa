package com.yabraa.medical.feature.fragments.map.presentation

import android.Manifest.permission.ACCESS_COARSE_LOCATION
import android.Manifest.permission.ACCESS_FINE_LOCATION
import android.annotation.SuppressLint
import android.content.Context.LOCATION_SERVICE
import android.content.pm.PackageManager.PERMISSION_GRANTED
import android.location.LocationManager
import android.os.Build
import android.os.Bundle
import android.view.View
import androidx.activity.result.contract.ActivityResultContracts
import androidx.core.content.ContextCompat.checkSelfPermission
import androidx.fragment.app.viewModels
import androidx.hilt.navigation.fragment.hiltNavGraphViewModels
import androidx.lifecycle.lifecycleScope
import androidx.navigation.fragment.findNavController
import com.google.android.gms.common.api.Status
import com.google.android.gms.location.FusedLocationProviderClient
import com.google.android.gms.location.LocationServices
import com.google.android.gms.maps.CameraUpdateFactory.newLatLngZoom
import com.google.android.gms.maps.GoogleMap
import com.google.android.gms.maps.OnMapReadyCallback
import com.google.android.gms.maps.SupportMapFragment
import com.google.android.gms.maps.model.LatLng
import com.google.android.gms.maps.model.MarkerOptions
import com.google.android.libraries.places.api.Places
import com.google.android.libraries.places.api.model.Place
import com.google.android.libraries.places.api.model.Place.Field
import com.google.android.libraries.places.api.net.PlacesClient
import com.google.android.libraries.places.widget.AutocompleteSupportFragment
import com.google.android.libraries.places.widget.listener.PlaceSelectionListener
import com.google.android.libraries.places.widget.model.AutocompleteActivityMode
import com.yabraa.medical.R
import com.yabraa.medical.R.color.brandPaletteDark800
import com.yabraa.medical.R.drawable.ic_vector_maps_markers
import com.yabraa.medical.R.string.confirmation
import com.yabraa.medical.R.string.edit
import com.yabraa.medical.core.base_fragment.BaseFragment
import com.yabraa.medical.core.base_fragment.navigate
import com.core.shared.error.OperationMessage
import com.core.shared.error.PlaceSelectionException
import com.core.shared.error.YabraaError
import com.core.shared.gps_manager.GpsStateManager
import com.core.shared.location_manager.LocationHandler
import com.core.shared.state.State
import com.core.shared.utils.CommonUtils.bitmapFromVector
import com.core.shared.utils.CommonUtils.handleExpirationDate
import com.core.shared.utils.CommonUtils.openTheLocationSetting
import com.core.shared.utils.CommonUtils.startApplicationSetting
import com.yabraa.medical.core.utils.dialog.yabraa_dialog.YabraaButtonStyle
import com.yabraa.medical.core.utils.dialog.yabraa_dialog.YabraaDialogBuilder
import com.yabraa.medical.core.utils.getErrorMessage
import com.yabraa.medical.databinding.FragmentMapsBinding
import com.yabraa.medical.feature.fragments.appointment.edit_appointment.data.model.request.EditAppointmentRequestDto
import com.yabraa.medical.feature.fragments.appointment.edit_appointment.domain.model.EditAppointmentModel
import com.yabraa.medical.feature.fragments.appointment.edit_appointment.domain.viewmodel.EditAppointmentViewModel
import com.yabraa.medical.feature.fragments.appointment.edit_appointment.presentation.EDIT_APPOINTMENT_WAY
import com.yabraa.medical.feature.fragments.common.domain.model.ErrorMessageUi
import com.yabraa.medical.feature.fragments.common.domain.viewmodel.TransactionViewModel
import dagger.hilt.android.AndroidEntryPoint
import kotlinx.coroutines.launch
import javax.inject.Inject


@AndroidEntryPoint
class MapsFragment : BaseFragment<FragmentMapsBinding>(), OnMapReadyCallback {

    override val binding by lazy { FragmentMapsBinding.inflate(layoutInflater) }
    private val viewModel: TransactionViewModel by hiltNavGraphViewModels(R.id.mainNavGraph)
    private val editAppointmentViewModel: EditAppointmentViewModel by viewModels()
    private lateinit var googleMap: GoogleMap
    private lateinit var placesClient: PlacesClient
    private val autoCompleteFragment by lazy {
        childFragmentManager.findFragmentById(R.id.placesSearchFrm) as AutocompleteSupportFragment
    }
    private var locationManager: LocationManager? = null
    private lateinit var fusedLocationClient: FusedLocationProviderClient

    @Inject
    lateinit var gpsStateManager: GpsStateManager

    @Suppress("DEPRECATION")
    private val editAppointmentModel
        get() = run {
            if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.TIRAMISU) {
                arguments?.getSerializable(EDIT_APPOINTMENT_WAY, EditAppointmentModel::class.java)
            } else {
                arguments?.getSerializable(EDIT_APPOINTMENT_WAY)
            }
        } as? EditAppointmentModel

    private val isEditAppointmentWay get() = editAppointmentModel?.isEditAppointmentWay == true

    @Inject
    lateinit var locationHandler: LocationHandler

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        fusedLocationClient = LocationServices.getFusedLocationProviderClient(requireActivity())
        locationManager = context?.getSystemService(LOCATION_SERVICE) as LocationManager?
        showExpirationDateError()
    }

    override fun onViewCreated(view: View, savedInstanceState: Bundle?) {
        super.onViewCreated(view, savedInstanceState)
        binding.setUpViews()
        initGoogleMap()
        handlePermissions()
        initializePlaces()
        setConfirmButtonText()
        checkOnGpsState()
        lifecycleScope.launch { collectOnEditAppointmentResponse() }
    }


    override fun onResume() {
        super.onResume()
        showBottomNavigation(false)
        confirmationView?.setConfirmationAppointmentVisibility(false)
        showYabraaBar(false)
    }


    private fun FragmentMapsBinding.setUpViews() {
        setOnBackClicked()
        setOnGetCurrentLocationClicked()
        autoCompleteFragment.setUpGoogleSearchAutoComplete()
    }


    private fun setOnBackClicked() {
        binding.backArrowBtn.setOnClickListener { findNavController().popBackStack() }
    }

    private fun initGoogleMap() {
        val mapFragment = childFragmentManager.findFragmentById(R.id.map) as SupportMapFragment?
        mapFragment?.getMapAsync(this)
    }

    override fun onMapReady(map: GoogleMap) {
        googleMap = map
        setOnCameraIdleListener()
        googleMap.setGoogleMapSetting()
        val saudiArabia = LatLng(23.8859, 45.0792)
        val bitmapDrawable = bitmapFromVector(requireActivity(), ic_vector_maps_markers)
        val markerOptions =
            MarkerOptions().position(saudiArabia).icon(bitmapDrawable).title("Saudi Arabia")
        googleMap.addMarker(markerOptions)
        googleMap.animateCamera(newLatLngZoom(saudiArabia, 5f))
    }


    private fun setOnCameraIdleListener() = googleMap.setOnCameraIdleListener {
        val selectedLocation = googleMap.cameraPosition.target
        viewModel.latLng = selectedLocation
    }

    private fun GoogleMap.setGoogleMapSetting() {
        uiSettings.isRotateGesturesEnabled = false
        uiSettings.isCompassEnabled = false
        uiSettings.isZoomControlsEnabled = false
        uiSettings.isMyLocationButtonEnabled = false
        mapType = GoogleMap.MAP_TYPE_NORMAL
    }


    private fun handlePermissions() = permissionCallBack.launch(locationPermissions)

    private var locationPermissions = arrayOf(ACCESS_FINE_LOCATION, ACCESS_COARSE_LOCATION)

    private val permissionCallBack =
        registerForActivityResult(ActivityResultContracts.RequestMultiplePermissions()) { permissions ->
            permissions.entries.forEach {
                val isGranted = it.value
                if (isGranted) {
                    handleDefaultLocation()
                } else {
                    showActiveLocationPopup()
                }
            }
        }

    private fun handleDefaultLocation() {
        when {
            isEditAppointmentWay -> handleDefaultEditAppointmentLocation()
            else -> googleMap.getCurrentLocation()
        }
    }

    private fun showActiveLocationPopup() {
        val topBtnStyle = YabraaButtonStyle(brandPaletteDark800)
        YabraaDialogBuilder(requireActivity()).setIcon(R.drawable.ic_vector_location_off)
            .setTitle(R.string.locationNotActivate)
            .setMessage(R.string.pleaseActivateTheLocationFirst)
            .setTopButton(R.string.activate, topBtnStyle) {
                startApplicationSetting(requireActivity())
            }.setCancelable(false)
            .show()
    }

    private fun FragmentMapsBinding.setOnGetCurrentLocationClicked() {
        gpsStateManager.getGpsState { gps ->
            getCurrentLocationIvBtn.setOnClickListener {
                if (!gps) {
                    showLocationIsNotActivePopup()
                    return@setOnClickListener
                }
                googleMap.getCurrentLocation()
            }
        }
    }

    private fun GoogleMap.getCurrentLocation() {
        clear()
        val accessFineLocation = checkSelfPermission(requireActivity(), ACCESS_FINE_LOCATION)
        val accessCoarseLocation = checkSelfPermission(requireActivity(), ACCESS_COARSE_LOCATION)
        if (accessFineLocation != PERMISSION_GRANTED && accessCoarseLocation != PERMISSION_GRANTED) {
            return
        }
        locationHandler.getLastLocation { location ->
            fusedLocationClient.lastLocation.addOnCompleteListener { task ->
                viewModel.latLng = if (task.result == null) {
                    LatLng(location.latitude, location.longitude)
                } else {
                    LatLng(task.result.latitude, task.result.longitude)
                }
                val latLng = viewModel.latLng ?: return@addOnCompleteListener
                val cameraFactory = newLatLngZoom(latLng, 14f)
                animateCamera(cameraFactory)
            }
        }
    }

    private fun handleDefaultEditAppointmentLocation() {
        googleMap.clear()
        val latitude = editAppointmentModel?.locationLatitude ?: 0.0
        val longitude = editAppointmentModel?.locationLongitude ?: 0.0
        viewModel.latLng = LatLng(latitude, longitude)
        val latLng = viewModel.latLng ?: return
        val cameraFactory = newLatLngZoom(latLng, 14f)
        googleMap.animateCamera(cameraFactory)
    }

    private fun initializePlaces() {
        Places.initialize(requireActivity(), getString(R.string.googleMapsKey))
        placesClient = Places.createClient(requireActivity())
    }

    private fun AutocompleteSupportFragment.setUpGoogleSearchAutoComplete() {
        val listPlaceFields = listOf(Field.ID, Field.NAME, Field.LAT_LNG, Field.ADDRESS)
        setPlaceFields(listPlaceFields)
        setActivityMode(AutocompleteActivityMode.OVERLAY)
        setOnPlaceSelectedListener(placeSelectionListener())
    }

    private fun placeSelectionListener() = object : PlaceSelectionListener {
        override fun onPlaceSelected(place: Place) {
            val placeLatLng = place.latLng ?: return
            viewModel.latLng = LatLng(placeLatLng.latitude, placeLatLng.longitude)
            val latLng = viewModel.latLng ?: return
            val cameraUpdate = newLatLngZoom(latLng, 14f)
            googleMap.animateCamera(cameraUpdate)
        }

        override fun onError(place: Status) {
            //TODO HANDLE CRASH KEY HERE
            YabraaError.E(exception = PlaceSelectionException(), logMessageEn = place.statusMessage)
        }
    }

    private fun setConfirmButtonText() {
        binding.confirmationBtn.text =
            if (isEditAppointmentWay) edit.localize() else confirmation.localize()
    }

    private fun checkOnGpsState() = gpsStateManager.getGpsState { setOnConfirmationClicked(it) }


    @SuppressLint("FragmentLiveDataObserve")
    private fun setOnConfirmationClicked(isGpsEnabled: Boolean) {
        connectivityManager?.isNetworkConnected?.observe(this@MapsFragment) { isConnected ->
            binding.confirmationBtn.setOnClickListener {
                if (!isConnected) {
                    showNetworkConnectionErrorPopup()
                    return@setOnClickListener
                } else if (!isGpsEnabled) {
                    showLocationIsNotActivePopup()
                    return@setOnClickListener
                } else if (viewModel.latLng == null) {
                    showSelectLocationPopupError()
                    return@setOnClickListener
                }
                handleEditAppointmentWay()
            }
        }
    }

    private fun showLocationIsNotActivePopup() {
        YabraaDialogBuilder(requireActivity()).setIcon(R.drawable.ic_vector_location_off)
            .setTitle(R.string.locationNotActivate)
            .setMessage(R.string.pleaseActivateTheLocationFirst)
            .setTopButton(R.string.activate) {
                openTheLocationSetting(requireActivity())
            }.setCancelable(false).show()
    }


    private fun showSelectLocationPopupError() {
        YabraaDialogBuilder(requireActivity()).setIcon(R.drawable.ic_vector_location_off)
            .setTitle(R.string.warning)
            .setMessage(R.string.pleaseSelectLocation)
            .setTopButton(R.string.ok) {
                googleMap.getCurrentLocation()
            }.show()
    }


    private fun handleEditAppointmentWay() {
        if (isEditAppointmentWay) {
            editAppointmentViewModel.editAppointment(setEditAppointmentRequest())
        } else {
            navigateToCheckoutScreen()
        }
    }

    private fun setEditAppointmentRequest(): EditAppointmentRequestDto {
        val appointmentNotes =
            if (editAppointmentModel?.notes != null) editAppointmentModel?.notes else null
        val latitude = viewModel.latLng?.latitude ?: editAppointmentModel?.locationLatitude
        val longitude = viewModel.latLng?.longitude ?: editAppointmentModel?.locationLongitude
        return EditAppointmentRequestDto(
            appointmentId = editAppointmentModel?.appointmentId ?: 0L,
            notes = appointmentNotes,
            locationLatitude = latitude ?: 0.0,
            locationLongitude = longitude ?: 0.0,
            serviceTypeId = editAppointmentModel?.serviceTypeId ?: 0L
        )
    }

    private suspend fun collectOnEditAppointmentResponse() {
        editAppointmentViewModel.editAppointmentResponseState.collect {
            hideProgressDialog()
            when (it) {
                is State.Error -> it.error.handleEditAppointmentResponseError()
                is State.Initial -> {}
                is State.Loading -> showProgressDialog()
                is State.Success -> showResetResponseSuccessPopup()
            }
        }
    }

    private fun showResetResponseSuccessPopup() {
        YabraaDialogBuilder(requireActivity()).setIcon(R.drawable.ic_vector_check_circle)
            .setTitle(R.string.success)
            .setTopButton(R.string.ok) {
                findNavController().popBackStack()
            }.setCancelable(false)
            .show()
    }

    private fun YabraaError.handleEditAppointmentResponseError() {
        val errorMessageUi = ErrorMessageUi(logMessageEn, logMessageAr)
        handleError {
            when (exception) {
                is OperationMessage -> showEditAppointmentResponseErrorPopup(errorMessageUi)
            }
        }
    }


    private fun showEditAppointmentResponseErrorPopup(errorMessageUi: ErrorMessageUi) {
        val errorMessage = getErrorMessage(errorMessageUi)
        YabraaDialogBuilder(requireActivity()).setIcon(R.drawable.ic_vector_error)
            .setTitle(R.string.warning)
            .setMessage(errorMessage)
            .setTopButton(R.string.ok) {
                findNavController().popBackStack()
            }.setCancelable(false)
            .show()
    }


    private fun navigateToCheckoutScreen() =
        showDelayProgressDialog { navigate(R.id.actionMapsFragmentToCheckoutFragment) }


    private fun showExpirationDateError() =
        tokenHandler.handleExpirationDate { showExpirationDatePopupError() }

}