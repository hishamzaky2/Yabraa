package com.yabraa.medical.feature.fragments.checkout.presentation.adapter

import android.annotation.SuppressLint
import android.view.LayoutInflater
import android.view.ViewGroup
import androidx.recyclerview.widget.RecyclerView
import com.yabraa.medical.R.string.price
import com.core.shared.utils.CommonUtils.getLocalizedValue
import com.yabraa.medical.databinding.ItemCheckoutBinding
import com.yabraa.medical.feature.fragments.common.domain.model.PackagesTransactionModel
import java.util.Locale.ENGLISH

class CheckoutAdapter(
    private val packageItems: MutableList<PackagesTransactionModel>,
    private val onItemClicked: () -> Unit
) : RecyclerView.Adapter<CheckoutAdapter.ViewHolder>() {

    override fun onCreateViewHolder(parent: ViewGroup, viewType: Int): CheckoutAdapter.ViewHolder {
        val binding =
            ItemCheckoutBinding.inflate(LayoutInflater.from(parent.context), parent, false)
        return ViewHolder(binding)
    }

    override fun onBindViewHolder(viewHolder: CheckoutAdapter.ViewHolder, position: Int) {
        val packageItem = packageItems[position]
        viewHolder.bind(packageItem)
    }

    override fun getItemCount() = packageItems.size

    override fun getItemViewType(position: Int) = position

    inner class ViewHolder(private val binding: ItemCheckoutBinding) :
        RecyclerView.ViewHolder(binding.root) {

        fun bind(item: PackagesTransactionModel) {
            binding.setUpViews(item)
        }

        @SuppressLint("SetTextI18n")
        private fun ItemCheckoutBinding.setUpViews(item: PackagesTransactionModel) {
            val packageData = item.packageData ?: return
            val dates = item.dates ?: return
            val patients = item.patients ?: return
            servicesNameTv.text = getLocalizedValue(packageData.nameEN,packageData.nameAR)
            dateTv.text = "${dates.dayOfMonth} ${dates.monthShortName} ${dates.year}"
            timeTv.text = dates.time
            priceTv.text = String.format(ENGLISH, root.context.getString(price), packageData.price)
            patientNameTv.text = patients.name
            openLocationIv.setOnClickListener { onItemClicked() }
        }
    }
}