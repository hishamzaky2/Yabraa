package com.yabraa.medical.feature.fragments.appointment.edit_appointment.domain.repository

import com.core.shared.state.State
import com.yabraa.medical.feature.fragments.appointment.edit_appointment.data.model.request.EditAppointmentRequestDto
import com.yabraa.medical.feature.fragments.appointment.edit_appointment.data.model.response.AppointmentResponseDto
import kotlinx.coroutines.flow.Flow

interface EditAppointmentRepository {
    suspend fun editAppointment(editAppointmentRequest: EditAppointmentRequestDto): Flow<State<AppointmentResponseDto>>
}