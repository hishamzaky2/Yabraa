package com.yabraa.medical.feature.fragments.notification.notification_hisotry.data.repository.notification_history_paging_source

import androidx.paging.PagingState
import com.yabraa.medical.core.di.network_sevices.YabraaServices
import com.core.shared.error.NotificationListPagingError
import com.core.shared.error.YabraaError
import com.core.shared.error.YabraaException
import com.core.shared.base_paging_source.BasePagingSource
import com.yabraa.medical.feature.fragments.notification.notification_hisotry.data.model.response.notification_history_response.Notification
import com.yabraa.medical.feature.fragments.notification.notification_hisotry.data.model.response.notification_history_response.NotificationHistoryResponseDto
import retrofit2.Response
import timber.log.Timber

class NotificationHistoryPagingSource(private val yabraaServices: YabraaServices) :
    BasePagingSource<Int, Notification>() {


    override suspend fun load(params: LoadParams<Int>): LoadResult<Int, Notification> {
        return try {
            val nextNumber = params.key ?: 1
            val response =
                yabraaServices.getNotifications(pageNumber = nextNumber, pageSize = PAGE_SIZE)
            getNotSuccessfulError(response) ?: LoadResult.Page(
                data = response.body()?.notificationHistoryResponse?.notifications!!,
                prevKey = null,
                nextKey = getNextKey(response)
            )
        } catch (e: Exception) {
            Timber.e(e)
            LoadResult.Error(YabraaException(YabraaError.E(exception = NotificationListPagingError())))
        }
    }

    private fun getNextKey(response: Response<NotificationHistoryResponseDto>): Int? {
        val body = response.body()
        if (body == null || body.notificationHistoryResponse.notifications.isEmpty()) return null
        return body.notificationHistoryResponse.pageNumber + 1
    }

    override fun getRefreshKey(state: PagingState<Int, Notification>): Int? {
        return state.anchorPosition?.let { anchorPosition ->
            val anchorPage = state.closestPageToPosition(anchorPosition)
            anchorPage?.prevKey?.plus(1) ?: anchorPage?.nextKey?.minus(1)
        }
    }

    companion object {
        const val PAGE_SIZE = 10
    }
}