package com.yabraa.medical.feature.fragments.select_date_and_time.presentation.adapter

import android.annotation.SuppressLint
import android.view.LayoutInflater
import android.view.ViewGroup
import androidx.recyclerview.widget.RecyclerView
import com.yabraa.medical.R
import com.yabraa.medical.core.utils.setBackGroundResource
import com.yabraa.medical.core.utils.setTextViewColor
import com.yabraa.medical.databinding.ItemTimeBinding
import com.yabraa.medical.feature.fragments.select_date_and_time.domain.model.TimeUi

class TimeAdapter(
    private val time: MutableList<TimeUi>, private val onItemClicked: (String) -> Unit
) : RecyclerView.Adapter<TimeAdapter.ViewHolder>() {

    private var checkedPosition = -1

    override fun onCreateViewHolder(parent: ViewGroup, viewType: Int): TimeAdapter.ViewHolder {
        val binding = ItemTimeBinding.inflate(LayoutInflater.from(parent.context), parent, false)
        return ViewHolder(binding)
    }

    override fun onBindViewHolder(viewHolder: TimeAdapter.ViewHolder, position: Int) {
        val timeItem = time[position]
        viewHolder.bind(timeItem)
    }

    override fun getItemCount() = time.size

    override fun getItemViewType(position: Int) = position

    inner class ViewHolder(private val binding: ItemTimeBinding) :
        RecyclerView.ViewHolder(binding.root) {

        fun bind(time: TimeUi) {
            binding.setUpViews(time)
        }

        private fun ItemTimeBinding.setUpViews(time: TimeUi) {
            timeTv.text = time.timeValue
            setSelectItemClicked(time)
            handleCheckedSelectItem()
        }

        private fun ItemTimeBinding.setSelectItemClicked(time: TimeUi) {
            root.setOnClickListener {
                handleSelectedItem()
                if (checkedPosition != absoluteAdapterPosition) {
                    notifyItemChanged(checkedPosition)
                    checkedPosition = absoluteAdapterPosition
                }
                onItemClicked(time.timeValue)
            }
        }

        @SuppressLint("ResourceAsColor")
        private fun ItemTimeBinding.handleCheckedSelectItem() {
            if (checkedPosition == -1) handleUnSelectedItem()
            when (checkedPosition) {
                absoluteAdapterPosition -> handleSelectedItem()
                else -> handleUnSelectedItem()
            }
        }

        private fun ItemTimeBinding.handleSelectedItem() {
            timeCLY.setBackGroundResource(R.drawable.select_time_border)
            timeTv.setTextViewColor(binding.root.context,R.color.primaryWhite)
        }

        private fun ItemTimeBinding.handleUnSelectedItem() {
            timeCLY.setBackGroundResource(R.drawable.ic_vector_time_frame)
            timeTv.setTextViewColor(binding.root.context,R.color.black)
        }
    }
}
