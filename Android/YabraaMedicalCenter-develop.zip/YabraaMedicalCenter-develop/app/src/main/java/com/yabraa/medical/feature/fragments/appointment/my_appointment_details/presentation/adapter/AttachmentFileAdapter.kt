package com.yabraa.medical.feature.fragments.appointment.my_appointment_details.presentation.adapter

import android.view.LayoutInflater
import android.view.ViewGroup
import androidx.recyclerview.widget.RecyclerView
import com.yabraa.medical.R
import com.yabraa.medical.databinding.ItemAttachmentFileBinding
import com.yabraa.medical.feature.fragments.appointment.my_appointment_details.data.model.VisitAttachment


class AttachmentFileAdapter(
    private val fileItems: List<VisitAttachment>, private val onItemClicked: (String) -> Unit
) : RecyclerView.Adapter<AttachmentFileAdapter.ViewHolder>() {
    override fun onCreateViewHolder(
        parent: ViewGroup, viewType: Int
    ): AttachmentFileAdapter.ViewHolder {
        val binding =
            ItemAttachmentFileBinding.inflate(LayoutInflater.from(parent.context), parent, false)
        return ViewHolder(binding)
    }

    override fun onBindViewHolder(viewHolder: AttachmentFileAdapter.ViewHolder, position: Int) {
        val item = fileItems[position]
        viewHolder.bind(item)
    }

    override fun getItemCount() = fileItems.size

    override fun getItemViewType(position: Int) = position

    inner class ViewHolder(val binding: ItemAttachmentFileBinding) :
        RecyclerView.ViewHolder(binding.root) {
        fun bind(item: VisitAttachment) {
            binding.setUpViews(item)
        }

        private fun ItemAttachmentFileBinding.setUpViews(item: VisitAttachment) {
            downloadBtn.setOnClickListener { onItemClicked(item.path) }
            handleAttachmentImage(item)
            titleTv.text = item.title
        }

        private fun ItemAttachmentFileBinding.handleAttachmentImage(item: VisitAttachment) {
            val image = when {
                item.path.pathEndWith(".pdf") -> R.drawable.ic_vector_pdf
                item.path.pathEndWith(".docx") -> R.drawable.ic_vector_doc
                item.path.pathEndWith(".jpg") -> R.drawable.ic_vector_jpg
                item.path.pathEndWith(".png") -> R.drawable.ic_vector_png
                else -> R.drawable.ic_vector_document
            }
            attachmentIv.setImageResource(image)
        }

        private fun String.pathEndWith(txt: String) = endsWith(txt)
    }
}