package com.yabraa.medical.feature.fragments.home.domain.repository.gallery_repository

import kotlinx.coroutines.flow.Flow
import com.core.shared.state.State
import com.yabraa.medical.feature.fragments.home.data.model.response.gallery_response.GalleryResponseDto

interface GalleryRepository {
    suspend fun getGallery(): Flow<State<GalleryResponseDto>>
}