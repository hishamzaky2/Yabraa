package com.yabraa.medical.core.utils.dialog.select_patient_bottom_sheet

import android.app.Activity
import androidx.recyclerview.widget.RecyclerView
import com.google.android.material.bottomsheet.BottomSheetDialog
import com.yabraa.medical.R
import com.yabraa.medical.databinding.LayoutSelectPatientBottomSheetBinding
import javax.inject.Inject

class SelectPatientBottomSheet @Inject constructor(activity: Activity) {

    lateinit var binding: LayoutSelectPatientBottomSheetBinding
    private var bottomSheetDialog: BottomSheetDialog? = null

    init {
        buildBottomSheetDialog(activity)
    }

    private fun buildBottomSheetDialog(activity: Activity): BottomSheetDialog? {
        binding = LayoutSelectPatientBottomSheetBinding.inflate(activity.layoutInflater)
        bottomSheetDialog = BottomSheetDialog(activity, R.style.select_patient_bottom_sheet_style)
        bottomSheetDialog?.setContentView(binding.root)
        return bottomSheetDialog
    }

    fun showBottomSheetDialog() = bottomSheetDialog?.show()


    fun dismissBottomSheet() = bottomSheetDialog?.dismiss()


    fun setRecyclerAdapter(adapter: RecyclerView.Adapter<*>) {
        binding.adapterRv.adapter = adapter
    }
}