package com.yabraa.medical.feature.fragments.filter.presentation.adapter

interface ItemSelectedIHandler {

    var isItemSelected : Boolean

    fun setSelected(selected: Boolean)


    fun isSelected(): Boolean
}