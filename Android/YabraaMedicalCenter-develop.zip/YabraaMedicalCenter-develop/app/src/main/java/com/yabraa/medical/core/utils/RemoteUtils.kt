package com.yabraa.medical.core.utils

import com.core.shared.error.OperationMessage
import com.core.shared.error.YabraaError
import com.core.shared.state.State
import com.core.shared.utils.CommonUtils.getLocalizedValue
import com.yabraa.medical.feature.fragments.common.domain.model.ErrorMessageUi


fun getErrorMessage(errorMessageUi: ErrorMessageUi) =
    getLocalizedValue(errorMessageUi.errorMessageEn, errorMessageUi.errorMessageAr)


fun <T> getResponseMessageError(
    errorMessageEn: String,
    errorMessageAr: String,
    logTag: String? = null
) =
    State.Error<T>(
        YabraaError.E(
            exception = OperationMessage(),
            logMessageEn = errorMessageEn,
            logMessageAr = errorMessageAr,
            logTag = logTag
        )
    )

