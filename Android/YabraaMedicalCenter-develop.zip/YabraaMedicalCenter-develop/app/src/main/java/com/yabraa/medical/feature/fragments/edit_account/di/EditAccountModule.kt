package com.yabraa.medical.feature.fragments.edit_account.di

import com.yabraa.medical.core.di.network_sevices.YabraaServices
import com.yabraa.medical.feature.fragments.edit_account.data.repository.EditAccountRepositoryImpl
import com.yabraa.medical.feature.fragments.edit_account.domain.repository.EditAccountRepository
import dagger.Module
import dagger.Provides
import dagger.hilt.InstallIn
import dagger.hilt.android.components.ViewModelComponent

@Module
@InstallIn(ViewModelComponent::class)
object EditAccountModule {

    @Provides
    fun provideEditAccountRepository(yabraaServices: YabraaServices): EditAccountRepository =
        EditAccountRepositoryImpl(yabraaServices)
}
