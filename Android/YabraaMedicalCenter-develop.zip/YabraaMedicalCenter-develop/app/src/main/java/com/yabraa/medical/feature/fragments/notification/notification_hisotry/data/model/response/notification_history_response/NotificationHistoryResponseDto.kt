package com.yabraa.medical.feature.fragments.notification.notification_hisotry.data.model.response.notification_history_response


import com.google.gson.annotations.SerializedName

data class NotificationHistoryResponseDto(
    @SerializedName("data")
    val notificationHistoryResponse: NotificationHistoryResponse,
    @SerializedName("errorMessageAr")
    val errorMessageAr: String? = null,
    @SerializedName("errorMessageEn")
    val errorMessageEn: String? = null,
    @SerializedName("statusCode")
    val statusCode: Int
)