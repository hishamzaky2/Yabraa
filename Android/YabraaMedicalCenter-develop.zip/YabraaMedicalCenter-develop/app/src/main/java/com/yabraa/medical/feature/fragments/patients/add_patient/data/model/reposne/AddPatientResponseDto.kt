package com.yabraa.medical.feature.fragments.patients.add_patient.data.model.reposne


import com.google.gson.annotations.SerializedName

data class AddPatientResponseDto(
    @SerializedName("data")
    val ddPatientResponse: List<AddPatientResponse>,
    @SerializedName("errorMessageAr")
    val errorMessageAr: String? = null,
    @SerializedName("errorMessageEn")
    val errorMessageEn: String? = null,
    @SerializedName("statusCode")
    val statusCode: Int
)