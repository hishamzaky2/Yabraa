package com.yabraa.medical.feature.fragments.forget_password.domain.model

import com.yabraa.medical.feature.fragments.forget_password.data.model.request.ForgetPasswordRequestDto

data class ForgetPasswordUiModel(var phoneNumber: String) {

    fun toForgetPassword() = ForgetPasswordRequestDto(phoneNumber = phoneNumber)

}