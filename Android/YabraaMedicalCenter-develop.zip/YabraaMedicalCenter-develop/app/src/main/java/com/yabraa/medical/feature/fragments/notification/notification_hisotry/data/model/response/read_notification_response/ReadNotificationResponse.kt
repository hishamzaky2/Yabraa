package com.yabraa.medical.feature.fragments.notification.notification_hisotry.data.model.response.read_notification_response


import com.google.gson.annotations.SerializedName

data class ReadNotificationResponse(
    @SerializedName("bodyAR")
    val bodyAR: String,
    @SerializedName("bodyEn")
    val bodyEn: String,
    @SerializedName("isRead")
    val isRead: Boolean,
    @SerializedName("notificationId")
    val notificationId: Int,
    @SerializedName("titleAR")
    val titleAR: String,
    @SerializedName("titleEn")
    val titleEn: String
)