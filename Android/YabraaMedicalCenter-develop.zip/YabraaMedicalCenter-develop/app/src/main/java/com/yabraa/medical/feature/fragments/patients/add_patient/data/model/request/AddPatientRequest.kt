package com.yabraa.medical.feature.fragments.patients.add_patient.data.model.request

data class AddPatientRequest(val name: String, val birthDate: String, val gender: String? = null)