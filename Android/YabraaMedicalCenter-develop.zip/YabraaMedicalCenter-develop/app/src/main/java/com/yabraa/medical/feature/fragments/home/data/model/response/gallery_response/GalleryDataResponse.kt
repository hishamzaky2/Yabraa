package com.yabraa.medical.feature.fragments.home.data.model.response.gallery_response


import com.google.gson.annotations.SerializedName

data class GalleryDataResponse(
    @SerializedName("galleryImages")
    val galleryImages: List<String>
)