package com.yabraa.medical.feature.fragments.allergies_and_chronic_diseases.injuries_fragment.di

import com.yabraa.medical.core.di.network_sevices.AllergiesAndChronicDiseasesServices
import com.yabraa.medical.feature.fragments.allergies_and_chronic_diseases.injuries_fragment.data.repository.AddInjuriesRepositoryImpl
import com.yabraa.medical.feature.fragments.allergies_and_chronic_diseases.injuries_fragment.data.repository.DeleteInjuriesRepositoryImpl
import com.yabraa.medical.feature.fragments.allergies_and_chronic_diseases.injuries_fragment.data.repository.InjuriesByUserFamilyIdRepositoryImpl
import com.yabraa.medical.feature.fragments.allergies_and_chronic_diseases.injuries_fragment.data.repository.InjuriesRepositoryImpl
import com.yabraa.medical.feature.fragments.allergies_and_chronic_diseases.injuries_fragment.domain.repository.AddInjuriesRepository
import com.yabraa.medical.feature.fragments.allergies_and_chronic_diseases.injuries_fragment.domain.repository.DeleteInjuriesRepository
import com.yabraa.medical.feature.fragments.allergies_and_chronic_diseases.injuries_fragment.domain.repository.InjuriesByUserFamilyIdRepository
import com.yabraa.medical.feature.fragments.allergies_and_chronic_diseases.injuries_fragment.domain.repository.InjuriesRepository
import dagger.Module
import dagger.Provides
import dagger.hilt.InstallIn
import dagger.hilt.android.components.ViewModelComponent

@Module
@InstallIn(ViewModelComponent::class)
object InjuriesModule {

    @Provides
    fun provideInjuriesRepositoryImpl(allergiesAndChronicDiseasesServices: AllergiesAndChronicDiseasesServices): InjuriesRepository =
        InjuriesRepositoryImpl(allergiesAndChronicDiseasesServices)

    @Provides
    fun provideInjuriesByUserFamilyIdRepositoryImpl(allergiesAndChronicDiseasesServices: AllergiesAndChronicDiseasesServices): InjuriesByUserFamilyIdRepository =
        InjuriesByUserFamilyIdRepositoryImpl(allergiesAndChronicDiseasesServices)


    @Provides
    fun provideAddInjuriesRepositoryImpl(allergiesAndChronicDiseasesServices: AllergiesAndChronicDiseasesServices): AddInjuriesRepository =
        AddInjuriesRepositoryImpl(allergiesAndChronicDiseasesServices)

    @Provides
    fun provideDeleteInjuriesRepositoryImpl(allergiesAndChronicDiseasesServices: AllergiesAndChronicDiseasesServices): DeleteInjuriesRepository =
        DeleteInjuriesRepositoryImpl(allergiesAndChronicDiseasesServices)
}