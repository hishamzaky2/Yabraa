package com.yabraa.medical.feature.fragments.notification.notification_hisotry.data.repository.notification_status_repository

import com.yabraa.medical.core.base_repository.BaseRepository
import com.yabraa.medical.core.di.network_sevices.YabraaServices
import com.core.shared.state.State
import com.yabraa.medical.core.utils.getResponseMessageError
import com.yabraa.medical.feature.fragments.notification.notification_hisotry.data.model.request.notification_history_request.NotificationHistoryRequestDto
import com.yabraa.medical.feature.fragments.notification.notification_hisotry.data.model.response.notification_history_response.NotificationHistoryResponseDto
import com.yabraa.medical.feature.fragments.notification.notification_hisotry.domain.repository.notification_status_repository.NotificationStatusRepository
import kotlinx.coroutines.flow.flow
import kotlinx.coroutines.flow.flowOn
import retrofit2.Response
import javax.inject.Inject

const val TAG_NOTIFICATION_STATUS_RESPONSE = "TAG_NOTIFICATION_STATUS_RESPONSE"

class NotificationStatusRepositoryImpel @Inject constructor(private val yabraaServices: YabraaServices) :
    BaseRepository<NotificationHistoryRequestDto, NotificationHistoryResponseDto>(),
    NotificationStatusRepository {

    override suspend fun getNotificationStatus(requestDto: NotificationHistoryRequestDto) =
        flow { emit(getOperationState(requestDto)) }.flowOn(dispatcher)


    override suspend fun performApiCall(requestDto: NotificationHistoryRequestDto): State<NotificationHistoryResponseDto> {
        val response = yabraaServices.getNotifications(requestDto.pageNumber, requestDto.pageSize)
        return handleNotificationStatusResponse(response)
    }

    private fun handleNotificationStatusResponse(response: Response<NotificationHistoryResponseDto>): State<NotificationHistoryResponseDto> {
        val responseBody = response.body()
        val errorMessageEn = responseBody?.errorMessageEn ?: ""
        val errorMessageAr = responseBody?.errorMessageAr ?: ""
        return when {
            response.isSuccessful && responseBody?.notificationHistoryResponse != null ->
                State.Success(response.body())

            response.isSuccessful && !responseBody?.errorMessageEn.isNullOrEmpty() -> getResponseMessageError(
                errorMessageEn = errorMessageEn,
                errorMessageAr = errorMessageAr,
                logTag = TAG_NOTIFICATION_STATUS_RESPONSE
            )

            else -> getNotSuccessfulResponseState(response)
        }
    }
}