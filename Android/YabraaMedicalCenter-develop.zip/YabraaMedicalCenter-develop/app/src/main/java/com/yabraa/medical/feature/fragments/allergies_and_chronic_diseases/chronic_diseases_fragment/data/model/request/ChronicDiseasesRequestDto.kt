package com.yabraa.medical.feature.fragments.allergies_and_chronic_diseases.chronic_diseases_fragment.data.model.request

data class ChronicDiseasesRequestDto(var chronicDiseaseId: Long, var userFamilyId: Long)