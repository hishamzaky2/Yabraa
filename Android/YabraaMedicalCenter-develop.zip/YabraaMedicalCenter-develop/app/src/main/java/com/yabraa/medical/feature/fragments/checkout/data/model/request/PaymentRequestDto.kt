package com.yabraa.medical.feature.fragments.checkout.data.model.request

data class PaymentRequestDto(
    var checkoutId: String,
    var paymentMethodId: Long,
    val firebaseToken: String
)