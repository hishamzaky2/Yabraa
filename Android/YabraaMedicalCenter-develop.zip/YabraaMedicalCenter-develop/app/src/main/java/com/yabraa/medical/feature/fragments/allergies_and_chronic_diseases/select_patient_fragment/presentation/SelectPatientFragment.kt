package com.yabraa.medical.feature.fragments.allergies_and_chronic_diseases.select_patient_fragment.presentation

import android.annotation.SuppressLint
import android.os.Bundle
import android.view.View
import androidx.core.view.isVisible
import androidx.fragment.app.viewModels
import androidx.hilt.navigation.fragment.hiltNavGraphViewModels
import androidx.lifecycle.lifecycleScope
import androidx.navigation.fragment.findNavController
import com.yabraa.medical.R
import com.yabraa.medical.core.base_fragment.BaseFragment
import com.yabraa.medical.core.base_fragment.navigate
import com.core.shared.state.State
import com.core.shared.utils.CommonUtils.handleExpirationDate
import com.yabraa.medical.core.utils.custom_views.yabraa_bar.YabraaBarHandler
import com.yabraa.medical.databinding.FragmentSelectPatientFragmentBinding
import com.yabraa.medical.feature.fragments.allergies_and_chronic_diseases.common.adpater.select_patient_adapter.SelectPatientAdapter
import com.yabraa.medical.feature.fragments.patients.patients.domain.viewmodel.PatientListViewModel
import com.yabraa.medical.feature.fragments.setting.domain.viewmodel.SettingViewModel
import dagger.hilt.android.AndroidEntryPoint
import kotlinx.coroutines.launch

const val USER_FAMILY_ID = "USER_FAMILY_ID"

@AndroidEntryPoint
class SelectPatientFragment : BaseFragment<FragmentSelectPatientFragmentBinding>() {


    override val binding by lazy { FragmentSelectPatientFragmentBinding.inflate(layoutInflater) }
    private val settingViewModel: SettingViewModel by hiltNavGraphViewModels(R.id.setting_graph)
    private val patientListViewModel: PatientListViewModel by viewModels()
    private val patientList get() = patientListViewModel.getPatientList()
    private lateinit var patientsAdapter: SelectPatientAdapter

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        showExpirationDateError()
    }

    override fun onViewCreated(view: View, savedInstanceState: Bundle?) {
        super.onViewCreated(view, savedInstanceState)
        handleInternetConnection()
    }

    override fun onResume() {
        super.onResume()
        yabraaBarView?.setUpYabraaBarView()
        confirmationView?.setConfirmationAppointmentVisibility(false)
        showBottomNavigation(false)
    }

    private fun YabraaBarHandler.setUpYabraaBarView() {
        val barTitle = settingViewModel.yabraaBarTitle ?: ""
        setYabraaBarVisibility(true)
        setClearAllVisibility(false)
        setBarTitle(barTitle)
        setOnBackArrowClicked { findNavController().popBackStack() }
    }


    override fun onStart() {
        super.onStart()
        lifecycleScope.launch { collectOnPatientResponse() }
    }

    @SuppressLint("FragmentLiveDataObserve")
    private fun handleInternetConnection() {
        connectivityManager?.isNetworkConnected?.observe(this@SelectPatientFragment) {
            binding.handleConnectionViewVisibility(it)
            if (!it) return@observe
            patientListViewModel.getPatients()
        }
    }

    private fun FragmentSelectPatientFragmentBinding.handleConnectionViewVisibility(isVisible: Boolean) {
        patientsRv.isVisible = isVisible
        binding.selectPatientTv.isVisible = isVisible
        internetConnection.root.isVisible = !isVisible
    }

    private suspend fun collectOnPatientResponse() {
        patientListViewModel.patientResponseState.collect {
            hideProgressDialog()
            when (it) {
                is State.Error -> it.error.handleError { }
                is State.Initial -> {}
                is State.Loading -> showProgressDialog()
                is State.Success -> setPatientsAdapter()
            }
        }
    }

    private fun setPatientsAdapter() {
        patientsAdapter = SelectPatientAdapter(patientList) {
            navigateToNextScreen(it)
        }
        binding.patientsRv.adapter = patientsAdapter
    }

    private fun navigateToNextScreen(userFamilyId: Long) {
        settingViewModel.userFamilyId = userFamilyId
        showDelayProgressDialog {
            navigate(R.id.actionSelectPatientFragmentToSelectAllergiesAndChronicDiseasesFragment)
        }
    }

    private fun showExpirationDateError() =
        tokenHandler.handleExpirationDate { showExpirationDatePopupError() }
}