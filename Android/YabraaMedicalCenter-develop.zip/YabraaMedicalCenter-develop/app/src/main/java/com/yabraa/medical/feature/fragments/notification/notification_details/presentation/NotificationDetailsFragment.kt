package com.yabraa.medical.feature.fragments.notification.notification_details.presentation

import android.os.Build
import android.os.Bundle
import android.view.View
import androidx.navigation.fragment.findNavController
import com.yabraa.medical.core.base_fragment.BaseFragment
import com.core.shared.utils.CommonUtils.getLocalizedValue
import com.yabraa.medical.core.utils.custom_views.yabraa_bar.YabraaBarHandler
import com.yabraa.medical.databinding.FragmentNotificationDetailsBinding
import com.yabraa.medical.feature.fragments.notification.notification_hisotry.data.model.response.notification_history_response.Notification
import com.yabraa.medical.feature.fragments.notification.notification_hisotry.presentation.NOTIFICATION_INFO
import java.util.Locale

class NotificationDetailsFragment : BaseFragment<FragmentNotificationDetailsBinding>() {


    override val binding by lazy { FragmentNotificationDetailsBinding.inflate(layoutInflater) }

    @Suppress("DEPRECATION")
    private val notificationItem
        get() = run {
            if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.TIRAMISU) {
                arguments?.getSerializable(NOTIFICATION_INFO, Notification::class.java)
            } else {
                arguments?.getSerializable(NOTIFICATION_INFO)
            }
        } as? Notification

    override fun onViewCreated(view: View, savedInstanceState: Bundle?) {
        super.onViewCreated(view, savedInstanceState)
        binding.setupViews()
    }

    override fun onResume() {
        super.onResume()
        yabraaBarView?.setUpYabraaBarView()
        confirmationView?.setConfirmationAppointmentVisibility(false)
        showBottomNavigation(false)
    }

    private fun YabraaBarHandler.setUpYabraaBarView() {
        //val title = getLocalizedValue(notificationItem?.titleEn, notificationItem?.titleAR) ?: return
        setYabraaBarVisibility(true)
        setClearAllVisibility(false)
        setBarTitle("")
        setOnBackArrowClicked { findNavController().popBackStack() }
    }


    private fun FragmentNotificationDetailsBinding.setupViews() {
        notificationNoValueTv.text =
            String.format(Locale.ENGLISH, "%d", notificationItem?.notificationId)
        titleTv.text = getLocalizedValue(notificationItem?.titleEn, notificationItem?.titleAR)
        bodyTv.text = getLocalizedValue(notificationItem?.bodyEn, notificationItem?.bodyAR)

    }
}