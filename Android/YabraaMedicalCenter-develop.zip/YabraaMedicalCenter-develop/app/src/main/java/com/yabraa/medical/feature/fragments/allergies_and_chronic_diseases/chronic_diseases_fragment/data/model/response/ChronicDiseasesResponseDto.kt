package com.yabraa.medical.feature.fragments.allergies_and_chronic_diseases.chronic_diseases_fragment.data.model.response


import com.google.gson.annotations.SerializedName

data class ChronicDiseasesResponseDto(
    @SerializedName("data")
    val chronicDiseasesDataResponse: List<ChronicDiseasesDataResponse>,
    @SerializedName("errorMessageAr")
    val errorMessageAr: String? = null,
    @SerializedName("errorMessageEn")
    val errorMessageEn: String? = null,
    @SerializedName("statusCode")
    val statusCode: Int
)