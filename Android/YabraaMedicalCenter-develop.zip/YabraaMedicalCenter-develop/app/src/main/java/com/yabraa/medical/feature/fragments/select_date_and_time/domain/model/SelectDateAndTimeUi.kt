package com.yabraa.medical.feature.fragments.select_date_and_time.domain.model

data class SelectDateAndTimeUi(
    var packageId: Long? = null,
    var time: String? = null,
    val dayName: String? = null,
    var dayOfMonth: String? = null,
    val monthName: String? = null,
    var monthNumber: String? = null,
    val monthShortName: String? = null,
    var year: Int? = null
)