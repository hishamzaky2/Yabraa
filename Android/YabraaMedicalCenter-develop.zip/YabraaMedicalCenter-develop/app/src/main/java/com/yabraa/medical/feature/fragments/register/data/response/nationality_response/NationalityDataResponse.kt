package com.yabraa.medical.feature.fragments.register.data.response.nationality_response


import com.google.gson.annotations.SerializedName


data class NationalityDataResponse(
    @SerializedName("nationalities")
    val nationalities: List<Nationality>
)