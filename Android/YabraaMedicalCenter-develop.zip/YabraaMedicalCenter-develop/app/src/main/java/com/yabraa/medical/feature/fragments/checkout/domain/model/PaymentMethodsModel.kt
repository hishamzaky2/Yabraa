package com.yabraa.medical.feature.fragments.checkout.domain.model

import androidx.annotation.DrawableRes
import androidx.annotation.StringRes

data class PaymentMethodsModel(
    @DrawableRes var icon: Int,
    @StringRes var paymentName: Int,
    var value: PaymentCardUtils,
    var isChecked: Boolean = false
)