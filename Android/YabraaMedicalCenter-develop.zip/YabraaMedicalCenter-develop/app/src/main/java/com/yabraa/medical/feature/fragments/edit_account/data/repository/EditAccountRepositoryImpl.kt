package com.yabraa.medical.feature.fragments.edit_account.data.repository

import com.yabraa.medical.core.base_repository.BaseRepository
import com.yabraa.medical.core.di.network_sevices.YabraaServices
import com.core.shared.state.State
import com.yabraa.medical.core.utils.getResponseMessageError
import com.yabraa.medical.feature.fragments.register.data.request.RegisterRequestDto
import com.yabraa.medical.feature.fragments.edit_account.data.response.edit_account_response.EditAccountResponseDto
import com.yabraa.medical.feature.fragments.edit_account.domain.repository.EditAccountRepository
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.flow.flow
import kotlinx.coroutines.flow.flowOn
import retrofit2.Response
import javax.inject.Inject

const val EDIT_ACCOUNT_STATE = "Done"
const val TAG_EDIT_ACCOUNT_RESPONSE = "TAG_EDIT_ACCOUNT_RESPONSE"

class EditAccountRepositoryImpl @Inject constructor(private val yabraaServices: YabraaServices) :
    BaseRepository<RegisterRequestDto, EditAccountResponseDto>(), EditAccountRepository {

    override suspend fun editAccount(registerRequestDto: RegisterRequestDto) = flow {
        emit(getOperationState(registerRequestDto))
    }.flowOn(Dispatchers.IO)

    override suspend fun performApiCall(requestDto: RegisterRequestDto): State<EditAccountResponseDto> {
        val response = yabraaServices.editAccount(requestDto)
        return handleEditAccountResponse(response)
    }


    private fun handleEditAccountResponse(response: Response<EditAccountResponseDto>): State<EditAccountResponseDto> {
        val responseBody = response.body()
        val errorMessageEn = responseBody?.errorMessageEn ?: ""
        val errorMessageAr = responseBody?.errorMessageAr ?: ""
        return when {
            response.isSuccessful && responseBody?.editState == EDIT_ACCOUNT_STATE ->
                State.Success(response.body())

            response.isSuccessful && !responseBody?.errorMessageEn.isNullOrEmpty() ->
                getResponseMessageError(
                    errorMessageEn = errorMessageEn,
                    errorMessageAr = errorMessageAr,
                    logTag = TAG_EDIT_ACCOUNT_RESPONSE
                )

            else -> getNotSuccessfulResponseState(response)
        }
    }
}