package com.yabraa.medical.feature.fragments.patients.add_patient.data.model.reposne


import com.google.gson.annotations.SerializedName

data class AddPatientResponse(
    @SerializedName("birthDate")
    val birthDate: String,
    @SerializedName("name")
    val name: String,
    @SerializedName("userFamilyId")
    val userFamilyId: Int
)