package com.yabraa.medical.feature.fragments.common.domain.viewmodel

import androidx.lifecycle.ViewModel
import androidx.lifecycle.viewModelScope
import com.core.shared.error.EmptyBirthDate
import com.core.shared.error.EmptyConfirmPassword
import com.core.shared.error.EmptyCountryCode
import com.core.shared.error.EmptyFirstName
import com.core.shared.error.EmptyGender
import com.core.shared.error.EmptyLastName
import com.core.shared.error.EmptyPassword
import com.core.shared.error.EmptyPhoneNumber
import com.core.shared.error.IdOrOrPassport
import com.core.shared.error.InvalidEmail
import com.core.shared.error.PasswordLetThanSixCharacter
import com.core.shared.error.PasswordNotMatched
import com.core.shared.error.YabraaError
import com.core.shared.state.State
import com.yabraa.medical.feature.fragments.forget_password.data.model.request.ForgetPasswordRequestDto
import com.yabraa.medical.feature.fragments.forget_password.data.model.response.forget_password_response.ForgetPasswordResponseDto
import com.yabraa.medical.feature.fragments.forget_password.data.model.response.reset_password_response.ResetPasswordResponseDto
import com.yabraa.medical.feature.fragments.forget_password.domain.model.ForgetPasswordUiModel
import com.yabraa.medical.feature.fragments.forget_password.domain.model.ResetPasswordUiModel
import com.yabraa.medical.feature.fragments.forget_password.domain.usecase.ForgetPasswordUseCase
import com.yabraa.medical.feature.fragments.forget_password.domain.usecase.ResetPasswordUseCase
import com.yabraa.medical.feature.fragments.register.data.request.RegisterRequestDto
import com.yabraa.medical.feature.fragments.edit_account.data.response.edit_account_response.EditAccountResponseDto
import com.yabraa.medical.feature.fragments.register.data.response.nationality_response.NationalityResponseDto
import com.yabraa.medical.feature.fragments.register.data.response.register_response.RegisterResponseDto
import com.yabraa.medical.feature.fragments.register.data.response.user_input_validation_response.UserInputValidationResponseDto
import com.yabraa.medical.feature.fragments.register.domain.model.RegisterUiModel
import com.yabraa.medical.feature.fragments.edit_account.domain.repository.EditAccountRepository
import com.yabraa.medical.feature.fragments.register.domain.usecase.NationalityUseCase
import com.yabraa.medical.feature.fragments.register.domain.usecase.RegisterUseCase
import com.yabraa.medical.feature.fragments.register.domain.usecase.UserInputsValidationUseCase
import dagger.hilt.android.lifecycle.HiltViewModel
import kotlinx.coroutines.flow.MutableSharedFlow
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.SharedFlow
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.launch
import javax.inject.Inject

@HiltViewModel
class RegistrationViewModel @Inject constructor(
    private val nationalityUseCase: NationalityUseCase,
    private val registerUseCase: RegisterUseCase,
    private val editAccountRepository: EditAccountRepository,
    private val userInputsValidationUseCase: UserInputsValidationUseCase,
    private val forgetPasswordUseCase: ForgetPasswordUseCase,
    private val resetPasswordUseCase: ResetPasswordUseCase
) : ViewModel() {

    private val _nationalityListState =
        MutableStateFlow<State<NationalityResponseDto>>(State.Initial())
    val nationalityListState: StateFlow<State<NationalityResponseDto>> = _nationalityListState

    private val _validationState = MutableSharedFlow<State<Any?>>()
    val validationState: SharedFlow<State<Any?>> = _validationState

    private val _userValidationResponseDtoState =
        MutableSharedFlow<State<UserInputValidationResponseDto>>()
    val userValidationResponseDtoState: SharedFlow<State<UserInputValidationResponseDto>> =
        _userValidationResponseDtoState

    private val _resendRegisterNewAccountOtpState =
        MutableStateFlow<State<UserInputValidationResponseDto>>(State.Success(null))
    val resendRegisterNewAccountOtpState: StateFlow<State<UserInputValidationResponseDto>> =
        _resendRegisterNewAccountOtpState

    private val _registerResponseDtoState = MutableSharedFlow<State<RegisterResponseDto>>()
    val registerResponseDtoState: SharedFlow<State<RegisterResponseDto>> = _registerResponseDtoState

    private val _editAccountResponseDtoState = MutableSharedFlow<State<EditAccountResponseDto>>()
    val editAccountResponseDtoState: SharedFlow<State<EditAccountResponseDto>> =
        _editAccountResponseDtoState

    private val _forgetPasswordResponseState = MutableSharedFlow<State<ForgetPasswordResponseDto>>()
    val forgetPasswordResponseState: SharedFlow<State<ForgetPasswordResponseDto>> =
        _forgetPasswordResponseState


    private val _resetPasswordResponseState = MutableSharedFlow<State<ResetPasswordResponseDto>>()
    val resetPasswordResponseState: SharedFlow<State<ResetPasswordResponseDto>> =
        _resetPasswordResponseState

    private val _resendForgetPasswordOtpState =
        MutableStateFlow<State<ForgetPasswordResponseDto>>(State.Success(null))
    val resendForgetPasswordOtpState: StateFlow<State<ForgetPasswordResponseDto>> =
        _resendForgetPasswordOtpState

    var lastOtpRequestTime = 0L

    fun getNationalityList() {
        viewModelScope.launch {
            _nationalityListState.emit(State.Loading())
            nationalityUseCase().collect {
                _nationalityListState.emit(it)
            }
        }
    }


    fun getAllNationalityList() = nationalityUseCase.getNationalityList()

    fun getSearchCountryByName(searchInput : String) =
        nationalityUseCase.getSearchCountryByName(searchInput)


    fun validateUserInputValidationInput(registerUiModel: RegisterUiModel, isEditAccount: Boolean) {
        viewModelScope.launch { registerUiModel.validateUserInputValidationInput(isEditAccount) }
    }

    private suspend fun RegisterUiModel.validateUserInputValidationInput(isEditAccount: Boolean) =
        when {
            firstName.isEmpty() -> _validationState.emit(getValidationError(EmptyFirstName()))
            lastName.isEmpty() -> _validationState.emit(getValidationError(EmptyLastName()))
            !isEditAccount && password.isNullOrEmpty() -> _validationState.emit(getValidationError(
                EmptyPassword()
            ))

            password?.isEmpty() == false && password?.length!! < 6 ->
                _validationState.emit(getValidationError(PasswordLetThanSixCharacter()))

            phoneNumber?.isEmpty() == true ->
                _validationState.emit(getValidationError(EmptyPhoneNumber()))

            birthDate.isEmpty() -> _validationState.emit(getValidationError(EmptyBirthDate()))
            gender.isEmpty() -> _validationState.emit(getValidationError(EmptyGender()))
            countryCode.isEmpty() -> _validationState.emit(getValidationError(EmptyCountryCode()))
            idOrIqamaOrPassport.isNullOrEmpty() -> _validationState.emit(getValidationError(
                IdOrOrPassport()
            ))

            !email.isNullOrEmpty() && email?.isInvalidEmail() == true ->
                _validationState.emit(getValidationError(InvalidEmail()))

            else -> {
                handleRegisterAndEditAccountWay(isEditAccount)
            }
        }

    private suspend fun RegisterUiModel.handleRegisterAndEditAccountWay(isEditAccount: Boolean) =
        if (isEditAccount) {
            editAccount(this)
        } else {
            onUserInputValidationValidInput(this)
        }


    private fun String.isInvalidEmail(): Boolean {
        return !Regex("^[\\w-.]+@([\\w-]+.)+[\\w-]{2,4}$").matches(this)
    }

    private suspend fun onUserInputValidationValidInput(registerUiModel: RegisterUiModel) {
        _validationState.emit(State.Success(null))
        _userValidationResponseDtoState.emit(State.Loading())
        userInputValidation(registerUiModel)
    }

    private suspend fun userInputValidation(registerUiModel: RegisterUiModel) {
        _userValidationResponseDtoState.emit(State.Loading())
        userInputsValidationUseCase(registerUiModel.toRegister()).collect {
            _userValidationResponseDtoState.emit(it)
        }
    }

    fun getUserValidationResponse() = userInputsValidationUseCase.getUserValidationResponse()


    suspend fun resendRegisterNewAccountOtp(registerRequestDto: RegisterRequestDto) {
        _resendRegisterNewAccountOtpState.emit(State.Loading())
        userInputsValidationUseCase(registerRequestDto).collect {
            _resendRegisterNewAccountOtpState.emit(it)
        }
    }


    fun registerNewAccount(registerRequestDto: RegisterRequestDto) {
        viewModelScope.launch {
            _registerResponseDtoState.emit(State.Loading())
            registerUseCase(registerRequestDto).collect {
                _registerResponseDtoState.emit(it)
            }
        }
    }

    private fun editAccount(registerUiModel: RegisterUiModel) {
        viewModelScope.launch {
            _editAccountResponseDtoState.emit(State.Loading())
            editAccountRepository.editAccount(registerUiModel.toRegister()).collect {
                _editAccountResponseDtoState.emit(it)
            }
        }
    }

    fun forgetPassword(forgetPasswordUiModel: ForgetPasswordUiModel) {
        viewModelScope.launch { forgetPasswordUiModel.validateForgetPasswordInput() }
    }

    private suspend fun ForgetPasswordUiModel.validateForgetPasswordInput() = when {
        phoneNumber.isEmpty() -> _validationState.emit(getValidationError(EmptyPhoneNumber()))
        else -> onForgetPasswordValidInput(this)
    }

    private suspend fun onForgetPasswordValidInput(forgetPasswordUiModel: ForgetPasswordUiModel) {
        _validationState.emit(State.Success(null))
        _forgetPasswordResponseState.emit(State.Loading())
        handleForgetPassword(forgetPasswordUiModel)
    }

    private suspend fun handleForgetPassword(forgetPasswordUiModel: ForgetPasswordUiModel) {
        _forgetPasswordResponseState.emit(State.Loading())
        forgetPasswordUseCase(forgetPasswordUiModel.toForgetPassword()).collect {
            _forgetPasswordResponseState.emit(it)
        }
    }


    fun resetPassword(resetPasswordUiModel: ResetPasswordUiModel) {
        viewModelScope.launch { resetPasswordUiModel.validateInputOfResetPassword() }
    }

    private suspend fun ResetPasswordUiModel.validateInputOfResetPassword() = when {
        password.isEmpty() -> _validationState.emit(getValidationError(EmptyPassword()))
        password.length < 6 -> _validationState.emit(getValidationError(PasswordLetThanSixCharacter()))
        confirmPassword.isEmpty() -> _validationState.emit(getValidationError(EmptyConfirmPassword()))
        password != confirmPassword -> _validationState.emit(getValidationError(PasswordNotMatched()))

        else -> onResetPasswordValidInput(this)
    }

    private suspend fun onResetPasswordValidInput(resetPasswordUiModel: ResetPasswordUiModel) {
        _validationState.emit(State.Success(null))
        _forgetPasswordResponseState.emit(State.Loading())
        handleResetPassword(resetPasswordUiModel)
    }

    private suspend fun handleResetPassword(resetPasswordUiModel: ResetPasswordUiModel) {
        _resetPasswordResponseState.emit(State.Loading())
        resetPasswordUseCase(resetPasswordUiModel.toResetPassword()).collect {
            _resetPasswordResponseState.emit(it)
        }
    }


    suspend fun resendForgetPasswordOtp(forgetPasswordRequestDto: ForgetPasswordRequestDto) {
        _resendForgetPasswordOtpState.emit(State.Loading())
        forgetPasswordUseCase(forgetPasswordRequestDto).collect {
            _resendForgetPasswordOtpState.emit(it)
        }
    }

    fun getForgetPasswordResponse() = forgetPasswordUseCase.getForgetPasswordResponse()

    private fun <E> getValidationError(error: Exception) =
        State.Error<E>(YabraaError.I(exception = error))
}