package com.yabraa.medical.feature.fragments.checkout.domain.usecase

import com.core.shared.state.State
import com.yabraa.medical.feature.fragments.checkout.data.model.response.payment_method_response.PaymentMethodResponse
import com.yabraa.medical.feature.fragments.checkout.domain.model.PaymentCardUtils
import com.yabraa.medical.feature.fragments.checkout.domain.repository.payment_method_repository.PaymentMethodRepository
import kotlinx.coroutines.async
import kotlinx.coroutines.flow.channelFlow
import javax.inject.Inject

class PaymentMethodUseCase @Inject constructor(private val paymentMethodRepository: PaymentMethodRepository) {

    private var paymentMethodResponse: PaymentMethodResponse? = null
    operator fun invoke() = channelFlow {
        val response = async { paymentMethodRepository.getPaymentMethods() }
        response.await().collect {
            if (it is State.Success) {
                paymentMethodResponse = it.data?.paymentMethodResponse
            }
            send(it)
        }
    }

    fun getPaymentMethodsList() = paymentMethodResponse?.paymentMethodItem?.filter {
        PaymentCardUtils.Apple_Pay.value != it.name
    }?.toMutableList() ?: mutableListOf()
}