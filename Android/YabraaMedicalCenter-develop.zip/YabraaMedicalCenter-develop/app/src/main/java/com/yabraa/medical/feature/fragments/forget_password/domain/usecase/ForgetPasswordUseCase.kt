package com.yabraa.medical.feature.fragments.forget_password.domain.usecase

import kotlinx.coroutines.async
import kotlinx.coroutines.flow.Flow
import kotlinx.coroutines.flow.channelFlow
import com.core.shared.state.State
import com.yabraa.medical.feature.fragments.forget_password.data.model.request.ForgetPasswordRequestDto
import com.yabraa.medical.feature.fragments.forget_password.data.model.response.forget_password_response.ForgetPasswordResponseDto
import com.yabraa.medical.feature.fragments.forget_password.domain.rposetory.ForgetPasswordRepository
import javax.inject.Inject

class ForgetPasswordUseCase @Inject constructor(private val forgetPasswordRepository: ForgetPasswordRepository) {

    private var responseDto: ForgetPasswordResponseDto? = null

    operator fun invoke(request: ForgetPasswordRequestDto): Flow<State<ForgetPasswordResponseDto>> {
        return channelFlow {
            val userInputValidationResponse =
                async { forgetPasswordRepository.forgetPassword(request) }
            userInputValidationResponse.await().collect {
                if (it is State.Success) {
                    responseDto = it.data
                }
                send(it)
            }
        }
    }

    fun getForgetPasswordResponse() = responseDto?.forgetPasswordDataResponse
}