package com.yabraa.medical.feature.fragments.appointment.edit_appointment.data.repository

import com.yabraa.medical.core.base_repository.BaseRepository
import com.yabraa.medical.core.di.network_sevices.YabraaServices
import com.core.shared.state.State
import com.yabraa.medical.core.utils.getResponseMessageError
import com.yabraa.medical.feature.fragments.appointment.edit_appointment.data.model.request.EditAppointmentRequestDto
import com.yabraa.medical.feature.fragments.appointment.edit_appointment.data.model.response.AppointmentResponseDto
import com.yabraa.medical.feature.fragments.appointment.edit_appointment.domain.repository.EditAppointmentRepository
import kotlinx.coroutines.flow.flow
import retrofit2.Response
import javax.inject.Inject

const val TAG_EDIT_APPOINTMENT_REPOSITORY = "TAG_EDIT_APPOINTMENT_REPOSITORY"

class EditAppointmentRepositoryImpl @Inject constructor(private val yabraaServices: YabraaServices) :
    BaseRepository<EditAppointmentRequestDto, AppointmentResponseDto>(), EditAppointmentRepository {

    override suspend fun editAppointment(editAppointmentRequest: EditAppointmentRequestDto) = flow {
        emit(getOperationState(editAppointmentRequest))
    }

    override suspend fun performApiCall(requestDto: EditAppointmentRequestDto): State<AppointmentResponseDto> {
        val response = yabraaServices.editAppointment(requestDto)
        return handEditAppointmentResponse(response)
    }


    private fun handEditAppointmentResponse(response: Response<AppointmentResponseDto>): State<AppointmentResponseDto> {
        val responseBody = response.body()
        val errorMessageEn = responseBody?.errorMessageEn ?: ""
        val errorMessageAr = responseBody?.errorMessageAr ?: ""
        return when {
            response.isSuccessful && responseBody?.appointmentResponse != null -> State.Success(
                response.body()
            )

            response.isSuccessful && !responseBody?.errorMessageEn.isNullOrEmpty() -> getResponseMessageError(
                errorMessageEn = errorMessageEn,
                errorMessageAr = errorMessageAr,
                logTag = TAG_EDIT_APPOINTMENT_REPOSITORY
            )

            else -> getNotSuccessfulResponseState(response)
        }
    }
}