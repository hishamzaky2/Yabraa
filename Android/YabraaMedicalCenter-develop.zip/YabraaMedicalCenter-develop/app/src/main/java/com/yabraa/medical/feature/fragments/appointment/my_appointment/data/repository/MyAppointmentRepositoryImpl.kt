package com.yabraa.medical.feature.fragments.appointment.my_appointment.data.repository

import com.yabraa.medical.core.base_repository.BaseRepository
import com.yabraa.medical.core.di.network_sevices.YabraaServices
import com.core.shared.state.State
import com.yabraa.medical.core.utils.getResponseMessageError
import com.yabraa.medical.feature.fragments.appointment.my_appointment.data.model.response.MyAppointmentResponseDto
import com.yabraa.medical.feature.fragments.appointment.my_appointment.domain.repository.MyAppointmentRepository
import kotlinx.coroutines.flow.flow
import retrofit2.Response
import javax.inject.Inject

const val TAG_MY_APPOINTMENT_RESPONSE = "TAG_MY_APPOINTMENT_RESPONSE"

class MyAppointmentRepositoryImpl @Inject constructor(private val yabraaServices: YabraaServices) :
    BaseRepository<Any, MyAppointmentResponseDto>(), MyAppointmentRepository {

    override suspend fun getMytAppointment() = flow {
        emit(getOperationState(Any()))
    }

    override suspend fun performApiCall(requestDto: Any): State<MyAppointmentResponseDto> {
        val response = yabraaServices.getMytAppointment()
        return handleGetMyAppointmentResponse(response)
    }


    private fun handleGetMyAppointmentResponse(response: Response<MyAppointmentResponseDto>): State<MyAppointmentResponseDto> {
        val responseBody = response.body()
        val errorMessageEn = responseBody?.errorMessageEn ?: ""
        val errorMessageAr = responseBody?.errorMessageAr ?: ""
        return when {
            response.isSuccessful && responseBody?.myAppointmentResponse != null ->
                State.Success(response.body())

            response.isSuccessful && !responseBody?.errorMessageEn.isNullOrEmpty() ->
                getResponseMessageError(
                    errorMessageEn = errorMessageEn,
                    errorMessageAr = errorMessageAr,
                    logTag = TAG_MY_APPOINTMENT_RESPONSE
                )

            else -> getNotSuccessfulResponseState(response)
        }
    }
}