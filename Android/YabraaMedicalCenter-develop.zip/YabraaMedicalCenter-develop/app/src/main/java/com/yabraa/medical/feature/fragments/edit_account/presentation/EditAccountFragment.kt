package com.yabraa.medical.feature.fragments.edit_account.presentation

import android.annotation.SuppressLint
import android.os.Build
import android.os.Bundle
import android.view.View
import androidx.core.os.bundleOf
import androidx.navigation.fragment.NavHostFragment
import com.yabraa.medical.R
import com.yabraa.medical.core.base_fragment.BaseFragment
import com.yabraa.medical.databinding.FragmentEditAccountBinding
import com.yabraa.medical.feature.fragments.setting.data.model.response.user_information_response.UserInformationResponse
import com.yabraa.medical.feature.fragments.setting.presentation.USER_INFORMATION


class EditAccountFragment: BaseFragment<FragmentEditAccountBinding>() {
    override val binding by lazy { FragmentEditAccountBinding.inflate(layoutInflater) }

    private val navController by lazy {
        val navHostFragment =
            childFragmentManager.findFragmentById(R.id.loginAndRegisterGraph) as NavHostFragment
        navHostFragment.navController
    }

    @Suppress("DEPRECATION")
    private val userInformation
        get() = run {
            if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.TIRAMISU) {
                arguments?.getSerializable(USER_INFORMATION, UserInformationResponse::class.java)
            } else {
                arguments?.getSerializable(USER_INFORMATION)
            }
        }

    override fun onViewCreated(view: View, savedInstanceState: Bundle?) {
        super.onViewCreated(view, savedInstanceState)
        handleStartDestination()
    }

    @SuppressLint("RestrictedApi")
    private fun handleStartDestination() {
        val navGraph = navController.navInflater.inflate(R.navigation.login_and_register_graph)
        navGraph.setStartDestination(R.id.registerFragment)
        val bundle = bundleOf(USER_INFORMATION to userInformation)
        navController.setGraph(navGraph, bundle)
    }

    override fun onResume() {
        super.onResume()
        showYabraaBar(false)
        showBottomNavigation(false)
        confirmationView?.setConfirmationAppointmentVisibility(false)
    }
}