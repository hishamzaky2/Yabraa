package com.yabraa.medical.feature.fragments.filter.presentation.adapter


import android.content.Context
import android.view.LayoutInflater
import android.view.ViewGroup
import androidx.recyclerview.widget.RecyclerView
import com.yabraa.medical.R
import com.core.shared.utils.CommonUtils.getLocalizedValue
import com.core.shared.utils.CommonUtils.load
import com.yabraa.medical.databinding.ItemPackagesBinding
import com.yabraa.medical.feature.fragments.home.data.model.response.services_details_response.PackageData
import java.util.Locale

class PackagesAdapter(
    private val packageItem: MutableList<PackageData>,
    private val packageViewHolder: PackageAdapterViewHolder
) : RecyclerView.Adapter<PackagesAdapter.ViewHolder>() {

    lateinit var setOnReadMoreClicked: OnPackageClickListener

    override fun onCreateViewHolder(parent: ViewGroup, viewType: Int): PackagesAdapter.ViewHolder {
        val binding =
            ItemPackagesBinding.inflate(LayoutInflater.from(parent.context), parent, false)
        return ViewHolder(binding)
    }

    override fun onBindViewHolder(viewHolder: PackagesAdapter.ViewHolder, position: Int) {
        val packageItem = packageItem[position]
        viewHolder.bind(packageItem)
        viewHolder.initialize(viewHolder, packageItem, packageViewHolder)

    }

    override fun getItemCount() = packageItem.size

    override fun getItemViewType(position: Int) = position

    inner class ViewHolder(val binding: ItemPackagesBinding) :
        RecyclerView.ViewHolder(binding.root) {
        val context: Context = binding.root.context
        fun bind(packageItem: PackageData) {
            binding.setUpViews(packageItem)
        }

        fun initialize(holder: ViewHolder, item: PackageData, action: PackageAdapterViewHolder) {
            action.packageAdapterViewHolder(holder, item, absoluteAdapterPosition)
        }

        private fun ItemPackagesBinding.setUpViews(packageItem: PackageData) {
            val imagePath = packageItem.imagePath ?: R.drawable.default_image
            packageIv.load(context, imagePath)
            packageNameTv.text = getLocalizedValue(packageItem.nameEN, packageItem.nameAR)
            subTitleTv.text = getLocalizedValue(packageItem.subTitleEN, packageItem.subTitleAR)
            totalFeesValueTv.text =
                String.format(Locale.ENGLISH, context.getString(R.string.price), packageItem.price)
            setOnReadMoreClicked(packageItem)
        }

        private fun ItemPackagesBinding.setOnReadMoreClicked(packageItem: PackageData) {
            readMoreView.setOnClickListener { setOnReadMoreClicked.setOnReadMoreClicked(packageItem) }
        }
    }

    fun setOnsetOnReadMoreListener(listener: OnPackageClickListener) {
        setOnReadMoreClicked = listener
    }

    interface OnPackageClickListener {
        fun setOnReadMoreClicked(packageItem: PackageData)
    }

    interface PackageAdapterViewHolder {
        fun packageAdapterViewHolder(holder: ViewHolder, item: PackageData, position: Int)
    }
}