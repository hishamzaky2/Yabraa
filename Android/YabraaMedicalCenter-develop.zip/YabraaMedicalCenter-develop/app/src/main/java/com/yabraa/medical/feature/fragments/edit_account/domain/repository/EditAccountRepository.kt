package com.yabraa.medical.feature.fragments.edit_account.domain.repository

import com.core.shared.state.State
import com.yabraa.medical.feature.fragments.register.data.request.RegisterRequestDto
import com.yabraa.medical.feature.fragments.edit_account.data.response.edit_account_response.EditAccountResponseDto
import kotlinx.coroutines.flow.Flow

interface EditAccountRepository {
    suspend fun editAccount(registerRequestDto: RegisterRequestDto) : Flow<State<EditAccountResponseDto>>
}