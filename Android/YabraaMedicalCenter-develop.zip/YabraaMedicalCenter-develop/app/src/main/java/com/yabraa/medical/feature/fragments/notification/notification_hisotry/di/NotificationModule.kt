package com.yabraa.medical.feature.fragments.notification.notification_hisotry.di

import com.yabraa.medical.core.di.network_sevices.YabraaServices
import com.yabraa.medical.feature.fragments.notification.notification_hisotry.data.repository.notification_status_repository.NotificationStatusRepositoryImpel
import com.yabraa.medical.feature.fragments.notification.notification_hisotry.data.repository.read_notification_repository.ReadNotificationRepositoryImpl
import com.yabraa.medical.feature.fragments.notification.notification_hisotry.domain.repository.notification_status_repository.NotificationStatusRepository
import com.yabraa.medical.feature.fragments.notification.notification_hisotry.domain.repository.read_notification.ReadNotificationRepository
import dagger.Module
import dagger.Provides
import dagger.hilt.InstallIn
import dagger.hilt.android.components.ViewModelComponent

@Module
@InstallIn(ViewModelComponent::class)
object NotificationModule {

    @Provides
    fun provideNotificationStatusRepository(yabraaServices: YabraaServices): NotificationStatusRepository =
        NotificationStatusRepositoryImpel(yabraaServices)

    @Provides
    fun provideReadNotificationRepository(yabraaServices: YabraaServices): ReadNotificationRepository =
        ReadNotificationRepositoryImpl(yabraaServices)
}