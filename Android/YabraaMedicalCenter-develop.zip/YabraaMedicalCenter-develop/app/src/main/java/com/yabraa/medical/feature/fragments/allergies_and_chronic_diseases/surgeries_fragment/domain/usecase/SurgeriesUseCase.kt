package com.yabraa.medical.feature.fragments.allergies_and_chronic_diseases.surgeries_fragment.domain.usecase

import com.core.shared.state.State
import com.yabraa.medical.feature.fragments.allergies_and_chronic_diseases.surgeries_fragment.data.model.response.SurgeriesDataResponse
import com.yabraa.medical.feature.fragments.allergies_and_chronic_diseases.surgeries_fragment.data.model.response.SurgeriesResponseDto
import com.yabraa.medical.feature.fragments.allergies_and_chronic_diseases.surgeries_fragment.domain.model.SurgeriesEntityModel
import com.yabraa.medical.feature.fragments.allergies_and_chronic_diseases.surgeries_fragment.domain.repository.SurgeriesByUserFamilyIdRepository
import com.yabraa.medical.feature.fragments.allergies_and_chronic_diseases.surgeries_fragment.domain.repository.SurgeriesRepository
import kotlinx.coroutines.async
import kotlinx.coroutines.flow.Flow
import kotlinx.coroutines.flow.channelFlow
import javax.inject.Inject

class SurgeriesUseCase @Inject constructor(
    private val surgeriesRepository: SurgeriesRepository,
    private val surgeriesByUserFamilyIdRepository: SurgeriesByUserFamilyIdRepository
) {


    private var surgeriesResponse: List<SurgeriesDataResponse>? = null

    private var surgeriesByUserFamilyIdResponse: List<SurgeriesDataResponse>? = null

    suspend operator fun invoke(): Flow<State<SurgeriesResponseDto>> {
        return channelFlow {
            val response = async { surgeriesRepository.getSurgeries() }
            response.await().collect {
                if (it is State.Success) {
                    surgeriesResponse = it.data?.surgeriesDataResponse
                }
                send(it)
            }
        }
    }

    suspend operator fun invoke(userFamilyId: Long): Flow<State<SurgeriesResponseDto>> {
        return channelFlow {
            val response =
                async {
                    surgeriesByUserFamilyIdRepository.getSurgeriesByUserFamilyId(
                        userFamilyId
                    )
                }
            response.await().collect {
                if (it is State.Success) {
                    surgeriesByUserFamilyIdResponse = it.data?.surgeriesDataResponse
                }
                send(it)
            }
        }
    }


    fun getSurgeriesList(): List<SurgeriesEntityModel> {
        val surgeriesEntityMap =
            getSurgeriesEntityList().associateBy { it.surgeryId }.toMutableMap()
        surgeriesByUserFamilyIdResponse?.map { it.surgeryId }?.forEach {
            val newSurgeriesEntityModel = surgeriesEntityMap[it] ?: return@forEach
            surgeriesEntityMap[it] = newSurgeriesEntityModel.copy(isAdded = true)
        }
        return surgeriesEntityMap.values.toList()
    }

    private fun getSurgeriesEntityList() = surgeriesResponse?.map {
        SurgeriesEntityModel(
            surgeryId = it.surgeryId,
            titleAR = it.titleAR,
            titleEN = it.titleEN
        )
    } ?: emptyList()

}