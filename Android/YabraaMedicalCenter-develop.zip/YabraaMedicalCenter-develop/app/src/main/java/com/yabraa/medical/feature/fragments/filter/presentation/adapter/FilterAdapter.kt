package com.yabraa.medical.feature.fragments.filter.presentation.adapter

import android.view.LayoutInflater
import android.view.ViewGroup
import androidx.core.content.ContextCompat
import androidx.core.view.isVisible
import androidx.recyclerview.widget.RecyclerView
import com.yabraa.medical.R
import com.core.shared.utils.CommonUtils.getLocalizedValue
import com.yabraa.medical.databinding.ItemFilterBinding
import com.yabraa.medical.feature.fragments.home.data.model.response.services_details_response.FilterData

class FilterAdapter(
    private val filterItem: List<FilterData>
) : RecyclerView.Adapter<FilterAdapter.ViewHolder>() {

    lateinit var setOnSelectFilterItemClicked: OnFilterItemClickListener
    lateinit var setOnUnSelectedFilterItemClicked: OnFilterItemClickListener

    lateinit var setFilterItemSelectedCallback: FilterAdapterCallback

    private var filterIdsList = mutableListOf<Long>()

    override fun onCreateViewHolder(parent: ViewGroup, viewType: Int): FilterAdapter.ViewHolder {
        val binding = ItemFilterBinding.inflate(LayoutInflater.from(parent.context), parent, false)
        return ViewHolder(binding)
    }

    override fun onBindViewHolder(viewHolder: FilterAdapter.ViewHolder, position: Int) {
        val filterItem = filterItem[position]
        viewHolder.bind(filterItem)

    }

    override fun getItemCount() = filterItem.size

    override fun getItemViewType(position: Int) = position


    inner class ViewHolder(private val binding: ItemFilterBinding) :
        RecyclerView.ViewHolder(binding.root) {
        val context = binding.root.context
        fun bind(filterData: FilterData) {
            binding.setUpViews(filterData)
        }

        private fun ItemFilterBinding.setUpViews(filterData: FilterData) {
            setOnRootClicked(filterData)
            filterTitleTv.text = getLocalizedValue(filterData.nameEN, filterData.nameAR)
            setFilterItemSelectedCallback.clearAllFilterItemsSelected(filterIdsList,filterData)
        }

        private fun ItemFilterBinding.setOnRootClicked(filterData: FilterData) {
            root.setOnClickListener {
                filterData.setSelected(!filterData.isSelected())
                handleSelectItem(filterData)
                setRootBackground(filterData.isSelected())
                handleSelectedViewColor(filterData.isSelected())
                handleCloseIvVisibility(filterData.isSelected())
            }
        }

        private fun ItemFilterBinding.setRootBackground(isSelected: Boolean) {
            val selectedDrawable =
                ContextCompat.getDrawable(context, R.drawable.selected_filter_border)
            val unSelectedDrawable =
                ContextCompat.getDrawable(context, R.drawable.un_selected_filter_border)
            root.background =
                if (isSelected) selectedDrawable else unSelectedDrawable
        }

        private fun ItemFilterBinding.handleSelectedViewColor(isSelected: Boolean) {
            val selectedColor = ContextCompat.getColorStateList(context, R.color.primaryWhite)
            val unSelectedColor = ContextCompat.getColorStateList(context, R.color.black)
            val color = if (isSelected) selectedColor else unSelectedColor
            filterTitleTv.setTextColor(color)
            closeIv.backgroundTintList = color
        }

        private fun ItemFilterBinding.handleCloseIvVisibility(isSelected: Boolean) {
            closeIv.isVisible = isSelected
        }

        private fun handleSelectItem(filterData: FilterData) {
            filterItem.forEach {
                if (filterData.isSelected() && filterData.filterId == it.filterId) {
                    filterIdsList.add(it.filterId)
                    setOnSelectFilterItemClicked.setOnSelectedFilterItemClicked(filterIdsList)
                } else if (filterData.filterId == it.filterId) {
                    filterIdsList.remove(it.filterId)
                    setOnUnSelectedFilterItemClicked.setOnUnSelectedFilterItemClicked(filterIdsList)
                }
            }
        }
    }


    fun setOnSelectedItemClicked(listener: OnFilterItemClickListener) {
        setOnSelectFilterItemClicked = listener
    }

    fun setOnUnSelectedItemClicked(listener: OnFilterItemClickListener) {
        setOnUnSelectedFilterItemClicked = listener
    }

    interface OnFilterItemClickListener {
        fun setOnSelectedFilterItemClicked(filterIds: List<Long>)
        fun setOnUnSelectedFilterItemClicked(filterIds: List<Long>)
    }

    fun initializeItemFilterSelected(callback: FilterAdapterCallback) {
        setFilterItemSelectedCallback = callback
    }

    interface FilterAdapterCallback {
        fun clearAllFilterItemsSelected(filterIdsList: MutableList<Long>, filterData: FilterData)
    }
}