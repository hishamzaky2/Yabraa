package com.yabraa.medical.feature.fragments.allergies_and_chronic_diseases.past_medication_fragment.data.model.response


import com.google.gson.annotations.SerializedName

data class PastMedicationResponseDto(
    @SerializedName("data")
    val pastMedicationDataResponse: List<PastMedicationDataResponse>,
    @SerializedName("errorMessageAr")
    val errorMessageAr: String? = null,
    @SerializedName("errorMessageEn")
    val errorMessageEn: String? = null,
    @SerializedName("statusCode")
    val statusCode: Int
)