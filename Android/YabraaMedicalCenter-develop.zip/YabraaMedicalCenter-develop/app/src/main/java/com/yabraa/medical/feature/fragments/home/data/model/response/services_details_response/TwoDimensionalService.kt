package com.yabraa.medical.feature.fragments.home.data.model.response.services_details_response


import com.google.gson.annotations.SerializedName

data class TwoDimensionalService(
    @SerializedName("firstService")
    val serviceData: ServiceData,
    @SerializedName("parentService")
    val parentServiceData: ServiceData,
    @SerializedName("secondService")
    val secondServiceData: ServiceData
)