package com.yabraa.medical.feature.fragments.otp_verification.presentation

import android.annotation.SuppressLint
import android.os.Bundle
import android.view.View
import androidx.annotation.StringRes
import androidx.core.view.isVisible
import androidx.core.widget.doAfterTextChanged
import androidx.hilt.navigation.fragment.hiltNavGraphViewModels
import androidx.lifecycle.lifecycleScope
import androidx.navigation.fragment.findNavController
import dagger.hilt.android.AndroidEntryPoint
import kotlinx.coroutines.Job
import kotlinx.coroutines.delay
import kotlinx.coroutines.launch
import com.yabraa.medical.R
import com.yabraa.medical.core.base_fragment.BaseFragment
import com.core.shared.error.EmptyConfirmPassword
import com.core.shared.error.EmptyPassword
import com.core.shared.error.OperationMessage
import com.core.shared.error.PasswordLetThanSixCharacter
import com.core.shared.error.PasswordNotMatched
import com.core.shared.error.YabraaError
import com.core.shared.state.State
import com.yabraa.medical.core.utils.dialog.yabraa_dialog.YabraaDialogBuilder
import com.yabraa.medical.core.utils.getErrorMessage
import com.yabraa.medical.databinding.FragmentOtpVerificationBinding
import com.yabraa.medical.feature.fragments.common.domain.model.ErrorMessageUi
import com.yabraa.medical.feature.fragments.common.domain.viewmodel.RegistrationViewModel
import com.yabraa.medical.feature.fragments.forget_password.data.model.request.ForgetPasswordRequestDto
import com.yabraa.medical.feature.fragments.forget_password.data.model.response.forget_password_response.ForgetPasswordDataResponse
import com.yabraa.medical.feature.fragments.forget_password.data.model.response.reset_password_response.ResetPasswordResponse
import com.yabraa.medical.feature.fragments.forget_password.domain.model.ResetPasswordUiModel
import com.yabraa.medical.feature.fragments.forget_password.presentation.FORGET_PASSWORD_FRAGMENT
import com.yabraa.medical.feature.fragments.register.data.request.RegisterRequestDto
import com.yabraa.medical.feature.fragments.register.data.response.register_response.RegisterDataResponse
import com.yabraa.medical.feature.fragments.register.data.response.user_input_validation_response.UserInputValidationResponse
import com.yabraa.medical.feature.fragments.register.presentation.REGISTER_FRAGMENT
import java.util.Calendar
import java.util.concurrent.TimeUnit

@AndroidEntryPoint
class OtpVerificationFragment : BaseFragment<FragmentOtpVerificationBinding>() {

    override val binding by lazy { FragmentOtpVerificationBinding.inflate(layoutInflater) }

    private val viewModel: RegistrationViewModel by hiltNavGraphViewModels(R.id.loginAndRegisterGraph)
    private val isRegisterNewAccount get() = arguments?.getBoolean(REGISTER_FRAGMENT) == true
    private val isForgetPassword get() = arguments?.getBoolean(FORGET_PASSWORD_FRAGMENT) == true

    private var otpJop: Job? = null

    override fun onViewCreated(view: View, savedInstanceState: Bundle?) {
        super.onViewCreated(view, savedInstanceState)
        binding.setUpViews()
    }

    override fun onResume() {
        super.onResume()
        showYabraaBar(false)
        otpJop?.cancel()
        otpJop = lifecycleScope.launch { handleOtpSendSuccessfully() }
    }

    private fun FragmentOtpVerificationBinding.setUpViews() {
        setOnBackClicked()
        setUpInputOtp()
        operationsOfRegisterNewAccount()
        operationsOfResetPassword()
    }

    private fun FragmentOtpVerificationBinding.setOnBackClicked() {
        backArrowIv.setOnClickListener { findNavController().navigateUp() }
    }

    private fun FragmentOtpVerificationBinding.setUpInputOtp() {
        val otpList = listOf(otp1Et, otp2Et, otp3Et, otp4Et)
        otpInputEt.doAfterTextChanged {
            val otp = it?.toString()
            otpList.forEachIndexed { index, editText ->
                editText.setText(otp?.getOrNull(index)?.toString() ?: "")
            }
        }

        otpList.forEach { editText ->
            editText.setOnClickListener {
                editText.clearFocus()
                otpInputEt.requestFocus()
                showKeyboard(otpInputEt)
            }
        }
    }

    private fun FragmentOtpVerificationBinding.operationsOfRegisterNewAccount() {
        if (isRegisterNewAccount) {
            lifecycleScope.launch { collectOnRegisterResponse() }
            lifecycleScope.launch { collectOnResendRegisterNewAccountOtpResponse() }
            setOnVerifyBtnClicked()
        }
    }


    private fun FragmentOtpVerificationBinding.operationsOfResetPassword() {
        if (isForgetPassword) {
            lifecycleScope.launch { collectOnCreateNewPasswordInputValidationState() }
            lifecycleScope.launch { collectOnResetPassword() }
            lifecycleScope.launch { collectOnResendResetPasswordOtpResponse() }
            setOnVerifyBtnClicked()
        }
    }


    @SuppressLint("FragmentLiveDataObserve")
    private fun FragmentOtpVerificationBinding.setOnVerifyBtnClicked() {
        connectivityManager?.isNetworkConnected?.observe(this@OtpVerificationFragment) { isConnected ->
            verifyBtn.setOnClickListener {
                if (!isConnected) {
                    showNetworkConnectionErrorPopup()
                    return@setOnClickListener
                }
                validateOtpInput()
            }
        }
    }


    private fun FragmentOtpVerificationBinding.validateOtpInput() {
        val otpRegisterAccount = viewModel.getUserValidationResponse()?.verificationCode
        val otpForgetPassword = viewModel.getForgetPasswordResponse()?.verificationCode
        val inputLength = otpInputEt.text?.length ?: 0
        when {
            otpInputEt.text.isNullOrEmpty() -> {
                showOtpIsEmptySnackBr(R.string.pleaseEnterOtp)
                return
            }

            inputLength < 4 -> {
                showOtpIsEmptySnackBr(R.string.otpLLessThanFourDigit)
                return
            }

            (otpInputEt.text.toString() != otpRegisterAccount && !otpRegisterAccount.isNullOrEmpty()) -> {
                showOtpIsEmptySnackBr(R.string.pleaseEnterTheCorrectOtp)
                return
            }

            (otpInputEt.text.toString() != otpForgetPassword && !otpForgetPassword.isNullOrEmpty()) -> {
                showOtpIsEmptySnackBr(R.string.pleaseEnterTheCorrectOtp)
                return
            }

            else -> handleVerificationWay()
        }
    }

    private fun showOtpIsEmptySnackBr(@StringRes message: Int) {
        yabraaSnackBarBuilder.setEndIcon(R.drawable.ic_vector_close)
            .setMessage(message)
            .build(requireView()).show()
    }

    private fun FragmentOtpVerificationBinding.handleVerificationWay() {
        if (isRegisterNewAccount) {
            createNewAccount()
        }
        handleCreateNewPasswordGroupVisibility()
    }


    private fun getOtpTimeDifferance(): Long {
        val timeNowInMillis = Calendar.getInstance().timeInMillis
        return timeNowInMillis - viewModel.lastOtpRequestTime
    }

    /* ------------------------ Reset password section ------------------------------ */

    private fun FragmentOtpVerificationBinding.handleCreateNewPasswordGroupVisibility() {
        if (isForgetPassword) {
            verifyGroup.isVisible = false
            createNewPasswordGroup.isVisible = true
            setOnCreateNewPasswordClicked()
        }
    }

    private fun FragmentOtpVerificationBinding.setOnCreateNewPasswordClicked() {
        confirmationBtn.setOnClickListener {
            viewModel.resetPassword(setResetPasswordUiModel())
        }
    }

    private fun FragmentOtpVerificationBinding.setResetPasswordUiModel() = ResetPasswordUiModel(
        phoneNumber = viewModel.getForgetPasswordResponse()?.phoneNumber ?: "",
        token = viewModel.getForgetPasswordResponse()?.token ?: "",
        verificationCode = viewModel.getForgetPasswordResponse()?.verificationCode ?: "",
        password = passwordEt.text.toString(),
        confirmPassword = confirmPasswordEt.text.toString()
    )

    private suspend fun collectOnCreateNewPasswordInputValidationState() {
        viewModel.validationState.collect {
            when (it) {
                is State.Initial -> {}
                is State.Error -> handleError(it)
                is State.Success -> {}
                is State.Loading -> {}
            }
        }
    }

    private fun handleError(errorState: State.Error<*>) {
        errorState.error.handleError {
            when (exception) {
                is EmptyPassword -> showInputErrorSnackBar(R.string.pleaseEnterPassword)
                is PasswordLetThanSixCharacter -> showInputErrorSnackBar(R.string.passwordsMustBeAtLeastSixCharacters)
                is EmptyConfirmPassword -> showInputErrorSnackBar(R.string.pleaseConfirmPassword)
                is PasswordNotMatched -> showInputErrorSnackBar(R.string.passwordDoesNoMatch)
            }
        }
    }


    private fun showInputErrorSnackBar(@StringRes message: Int) =
        yabraaSnackBarBuilder.setEndIcon(R.drawable.ic_vector_close).setMessage(message)
            .build(requireView()).show()

    private suspend fun collectOnResetPassword() {
        viewModel.resetPasswordResponseState.collect {
            hideProgressDialog()
            when (it) {
                is State.Initial -> {}
                is State.Error -> it.error.handleResponseError()
                is State.Loading -> showProgressDialog()
                is State.Success -> handleResetPasswordSuccess(it.data?.resetPasswordResponse)
            }
        }
    }

    private fun handleResetPasswordSuccess(response: ResetPasswordResponse?) {
        if (response == null) return
        response.showResetResponseSuccessPopup()
    }

    private fun ResetPasswordResponse.showResetResponseSuccessPopup() {
        val message = getErrorMessage(ErrorMessageUi(messageEn, messageAr))
        YabraaDialogBuilder(requireActivity()).setIcon(R.drawable.ic_vector_check_circle)
            .setTitle(R.string.success)
            .setMessage(message)
            .setTopButton(R.string.ok) {
                popupToLoginFragment()
            }.setCancelable(false)
            .show()
    }


    private suspend fun collectOnResendResetPasswordOtpResponse() {
        viewModel.resendForgetPasswordOtpState.collect {
            hideProgressDialog()
            when (it) {
                is State.Initial -> {}
                is State.Error -> it.error.handleResponseError()
                is State.Loading -> showProgressDialog()
                is State.Success ->
                    handleResendResetPasswordOtpSuccess(it.data?.forgetPasswordDataResponse)
            }
        }
    }

    private fun handleResendResetPasswordOtpSuccess(response: ForgetPasswordDataResponse?) {
        if (response == null) return
        handleOtpSendSuccessfully()
    }

    /* ------------------------ Register new account section ------------------------ */
    private fun createNewAccount() {
        viewModel.registerNewAccount(setRegisterRequest())
    }

    private fun setRegisterRequest(): RegisterRequestDto {
        val registerModel = viewModel.getUserValidationResponse()
        return RegisterRequestDto(
            firstName = registerModel?.firstName ?: "",
            lastName = registerModel?.lastName ?: "",
            password = registerModel?.password ?: "",
            phoneNumber = registerModel?.phoneNumber ?: "",
            birthDate = registerModel?.birthDate ?: "",
            gender = registerModel?.gender ?: "",
            countryCode = registerModel?.countryCode ?: "",
            idOrIqamaOrPassport = registerModel?.idOrIqamaOrPassport,
            email = registerModel?.email
        )
    }


    private suspend fun collectOnRegisterResponse() {
        viewModel.registerResponseDtoState.collect {
            hideProgressDialog()
            when (it) {
                is State.Initial -> {}
                is State.Error -> it.error.handleResponseError()
                is State.Loading -> showProgressDialog()
                is State.Success -> handleRegisterNewAccountResponseSuccess(it.data?.registerDataResponse)
            }
        }
    }

    private fun handleRegisterNewAccountResponseSuccess(response: RegisterDataResponse?) {
        if (response == null) return
        showRegisterResponseSuccessPopup()
    }

    private fun YabraaError.handleResponseError() {
        val errorMessageUi =  ErrorMessageUi(logMessageEn, logMessageAr)
        handleError {
            when (exception) {
                is OperationMessage -> showRegisterResponseErrorPopup(errorMessageUi)
            }
        }
    }


    private fun showRegisterResponseErrorPopup(errorMessageUi: ErrorMessageUi) {
        val errorMessage = getErrorMessage(errorMessageUi)
        YabraaDialogBuilder(requireActivity()).setIcon(R.drawable.ic_vector_error).setTitle(R.string.warning)
            .setMessage(errorMessage).setTopButton(R.string.ok) {
                //TODO LOG MESSAGE HERE
            }.setCancelable(false).show()
    }


    private fun showRegisterResponseSuccessPopup() {
        YabraaDialogBuilder(requireActivity()).setIcon(R.drawable.ic_vector_check_circle)
            .setTitle(R.string.success)
            .setMessage(R.string.registerAccountHaBeenSuccess)
            .setTopButton(R.string.ok) {
                popupToLoginFragment()
            }.setCancelable(false)
            .show()
    }

    private fun popupToLoginFragment() = findNavController().popBackStack(R.id.loginFragment, false)


    private suspend fun collectOnResendRegisterNewAccountOtpResponse() {
        viewModel.resendRegisterNewAccountOtpState.collect {
            hideProgressDialog()
            when (it) {
                is State.Initial -> {}
                is State.Error -> it.error.handleResponseError()
                is State.Loading -> showProgressDialog()
                is State.Success ->
                    handleResendRegisterNewAccountOtpSuccess(it.data?.userInputValidationResponse)
            }
        }
    }

    private fun handleResendRegisterNewAccountOtpSuccess(userInputValidationResponse: UserInputValidationResponse?) {
        if (userInputValidationResponse == null) return
        handleOtpSendSuccessfully()
    }


    private fun handleOtpSendSuccessfully() {
        binding.otpInputEt.setText("")
        viewModel.lastOtpRequestTime = Calendar.getInstance().timeInMillis
        otpJop = lifecycleScope.launch { handleResendOtp() }
    }

    private suspend fun handleResendOtp() {
        val resendTimeDifference = getOtpTimeDifferance()
        val remainingTime = OTP_INTERVAL_IN_Millis - resendTimeDifference
        if (remainingTime < 0) {
            setTextToResetPin()
            return
        }
        showResetPinTimer(remainingTime)

    }

    private suspend fun showResetPinTimer(remainingTime: Long) {
        val resendOtpBtn = binding.resendOtpTv
        resendOtpBtn.isEnabled = false
        for (i in TimeUnit.MILLISECONDS.toSeconds(remainingTime) downTo 0) {
            binding.timeTv.text = getRemainingTimeString(i)
            delay(TimeUnit.SECONDS.toMillis(1))
        }
        setTextToResetPin()
    }

    private fun getRemainingTimeString(timeInSeconds: Long): String {
        val remainingMinutes = TimeUnit.SECONDS.toMinutes(timeInSeconds)
        val remainingSeconds = timeInSeconds - TimeUnit.MINUTES.toSeconds(remainingMinutes)
        return String.format("%02d:%02d", remainingMinutes, remainingSeconds)
    }

    private fun setTextToResetPin() {
        val resendOtpBtn = binding.resendOtpTv
        resendOtpBtn.text = R.string.resendPin.localize()
        resendOtpBtn.isEnabled = true
        resendOtpBtn.setOnClickListener { lifecycleScope.launch { sendOtp() } }
    }

    private suspend fun sendOtp() {
        if (getOtpTimeDifferance() - OTP_INTERVAL_IN_Millis < 0) return
        resendRegisterOtp()
        resendForgetPasswordOtp()
    }

    private suspend fun resendRegisterOtp() {
        if (isRegisterNewAccount) viewModel.resendRegisterNewAccountOtp(setRegisterRequest())
    }

    private suspend fun resendForgetPasswordOtp() {
        val phoneNumber = viewModel.getForgetPasswordResponse()?.phoneNumber ?: ""
        if (isForgetPassword) viewModel.resendForgetPasswordOtp(ForgetPasswordRequestDto(phoneNumber))
    }


    companion object {
        private const val OTP_INTERVAL_IN_Millis = 120000
    }
}