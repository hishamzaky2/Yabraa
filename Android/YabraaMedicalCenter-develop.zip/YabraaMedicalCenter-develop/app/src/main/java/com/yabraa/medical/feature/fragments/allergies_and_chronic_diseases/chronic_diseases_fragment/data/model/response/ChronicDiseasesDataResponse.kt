package com.yabraa.medical.feature.fragments.allergies_and_chronic_diseases.chronic_diseases_fragment.data.model.response


import com.google.gson.annotations.SerializedName

data class ChronicDiseasesDataResponse(
    @SerializedName("chronicDiseaseId")
    val chronicDiseaseId: Long,
    @SerializedName("titleAR")
    val titleAR: String,
    @SerializedName("titleEN")
    val titleEN: String
)