package com.yabraa.medical.feature.fragments.allergies_and_chronic_diseases.current_medication_fragment.domain.usecase

import com.core.shared.state.State
import com.yabraa.medical.feature.fragments.allergies_and_chronic_diseases.current_medication_fragment.data.model.resopnse.CurrentMedicationDataResponse
import com.yabraa.medical.feature.fragments.allergies_and_chronic_diseases.current_medication_fragment.data.model.resopnse.CurrentMedicationResponseDto
import com.yabraa.medical.feature.fragments.allergies_and_chronic_diseases.current_medication_fragment.domain.model.CurrentMedicationEntityModel
import com.yabraa.medical.feature.fragments.allergies_and_chronic_diseases.current_medication_fragment.domain.repository.CurrentMedicationByUserFamilyIdRepository
import com.yabraa.medical.feature.fragments.allergies_and_chronic_diseases.current_medication_fragment.domain.repository.CurrentMedicationRepository
import kotlinx.coroutines.async
import kotlinx.coroutines.flow.Flow
import kotlinx.coroutines.flow.channelFlow
import javax.inject.Inject

class CurrentMedicationUseCase @Inject constructor(
    private val currentMedicationRepository: CurrentMedicationRepository,
    private val currentMedicationByUserFamilyIdRepository: CurrentMedicationByUserFamilyIdRepository
) {


    private var currentMedicationResponse: List<CurrentMedicationDataResponse>? = null

    private var currentMedicationByUserFamilyIdResponse: List<CurrentMedicationDataResponse>? = null

    suspend operator fun invoke(): Flow<State<CurrentMedicationResponseDto>> {
        return channelFlow {
            val response = async { currentMedicationRepository.getCurrentMedication() }
            response.await().collect {
                if (it is State.Success) {
                    currentMedicationResponse = it.data?.currentMedicationDataResponse
                }
                send(it)
            }
        }
    }

    suspend operator fun invoke(userFamilyId: Long): Flow<State<CurrentMedicationResponseDto>> {
        return channelFlow {
            val response =
                async {
                    currentMedicationByUserFamilyIdRepository.getCurrentMedicationByUserFamilyId(
                        userFamilyId
                    )
                }
            response.await().collect {
                if (it is State.Success) {
                    currentMedicationByUserFamilyIdResponse =
                        it.data?.currentMedicationDataResponse
                }
                send(it)
            }
        }
    }


    fun getCurrentMedicationList(): List<CurrentMedicationEntityModel> {
        val currentMedicationEntityMap =
            getCurrentMedicationEntityList().associateBy { it.medicationId }.toMutableMap()
        currentMedicationByUserFamilyIdResponse?.map { it.medicationId }?.forEach {
            val newCurrentMedicationEntityModel = currentMedicationEntityMap[it] ?: return@forEach
            currentMedicationEntityMap[it] = newCurrentMedicationEntityModel.copy(isAdded = true)
        }
        return currentMedicationEntityMap.values.toList()
    }

    private fun getCurrentMedicationEntityList() = currentMedicationResponse?.map {
        CurrentMedicationEntityModel(
            medicationId = it.medicationId,
            titleAR = it.titleAR,
            titleEN = it.titleEN
        )
    } ?: emptyList()

}