package com.yabraa.medical.core.utils.dialog.snack_bar


import android.app.Activity
import android.graphics.Color
import android.view.View
import android.view.ViewGroup
import androidx.annotation.StringRes
import com.google.android.material.snackbar.Snackbar
import com.yabraa.medical.R
import com.yabraa.medical.databinding.LayoutYabraaSnackbarBinding
import javax.inject.Inject


class YabraaSnackBarBuilder @Inject constructor(private val activity: Activity) {

    lateinit var binding: LayoutYabraaSnackbarBinding
    private var message: Int? = null
    private var messageInfo: String? = null
    private var startIcon: Int? = null
    private var endIcon: Int? = null
    private var duration: Int? = null
    private var startActionButton: (View) -> Unit = {}
    private var endActionButton: (View) -> Unit = {}

    fun build(view: View): Snackbar {

        val inflater = activity.layoutInflater
        binding = LayoutYabraaSnackbarBinding.inflate(inflater)

        val snackBar = Snackbar.make(view, "", Snackbar.LENGTH_LONG)

        message?.let { binding.messageTv.text = activity.resources.getString(it) }

        messageInfo?.let { binding.messageTv.text = it }

        binding.initializeStartActionBtn(snackBar)
        startIcon?.let { binding.initializeStartIcon(it) }

        binding.initializeEndActionBtn(snackBar)
        endIcon?.let { binding.initializeEndIcon(it) }

        duration?.let { snackBar.duration = it }

        snackBar.setSnackBarView()
        return snackBar
    }

    fun setMessage(@StringRes message: Int): YabraaSnackBarBuilder {
        this.message = message
        return this
    }

    fun setMessageInfo(messageInfo: String): YabraaSnackBarBuilder {
        this.messageInfo = messageInfo
        return this
    }

    fun setStartActionBtn(startActionBtn: (View) -> Unit = {}): YabraaSnackBarBuilder {
        this.startActionButton = startActionBtn
        return this
    }

    private fun LayoutYabraaSnackbarBinding.initializeStartActionBtn(snackBar: Snackbar) {
        startActionBtn.setOnClickListener {
            startActionButton.invoke(it)
            snackBar.dismiss()
        }
    }

    fun setStartIcon(startIcon: Int): YabraaSnackBarBuilder {
        this.startIcon = startIcon
        return this
    }

    private fun LayoutYabraaSnackbarBinding.initializeStartIcon(startIcon: Int?) {
        startIcon?.let {
            startActionBtn.visibility = View.VISIBLE
            startActionBtn.setImageResource(it)
        }
    }

    fun setEndActionBtn(endActionBtn: (View) -> Unit = {}): YabraaSnackBarBuilder {
        this.endActionButton = endActionBtn
        return this
    }

    private fun LayoutYabraaSnackbarBinding.initializeEndActionBtn(snackBar: Snackbar) {
        endActionBtn.setOnClickListener {
            endActionButton.invoke(it)
            snackBar.dismiss()
        }
    }

    fun setEndIcon(endIcon: Int): YabraaSnackBarBuilder {
        this.endIcon = endIcon
        return this
    }

    private fun LayoutYabraaSnackbarBinding.initializeEndIcon(endIcon: Int?) {
        endIcon?.let {
            endActionBtn.visibility = View.VISIBLE
            endActionBtn.setImageResource(it)
        }
    }

    fun setDuration(duration: Int): YabraaSnackBarBuilder {
        this.duration = duration
        return this
    }

    private fun Snackbar.setSnackBarView() {
        val snackBarLayout = view as? Snackbar.SnackbarLayout
        snackBarLayout?.apply {
            setBackgroundColor(Color.TRANSPARENT)
            view.layoutParams.width = ViewGroup.LayoutParams.MATCH_PARENT
            setPadding(
                snackBarLayout.context.resources.getDimension(R.dimen.xsml).toInt(),
                0,
                snackBarLayout.context.resources.getDimension(R.dimen.xsml).toInt(),
                0
            )
            addView(binding.root, 0)
        }
    }
}
