package com.yabraa.medical.feature.fragments.home.presentation.adapter

import android.view.LayoutInflater
import android.view.ViewGroup
import androidx.recyclerview.widget.RecyclerView
import com.yabraa.medical.R
import com.core.shared.utils.CommonUtils.getLocalizedValue
import com.core.shared.utils.CommonUtils.load
import com.yabraa.medical.databinding.ItemServicesBinding
import com.yabraa.medical.feature.fragments.home.data.model.response.services_details_response.OneDimensionalService

class ServicesDetailsAdapter(
    private val oneDimensionalService: List<OneDimensionalService>,
    private val onItemClicked: (Long) -> Unit
) : RecyclerView.Adapter<ServicesDetailsAdapter.ViewHolder>() {
    override fun onCreateViewHolder(parent: ViewGroup, viewType: Int): ViewHolder {
        val binding =
            ItemServicesBinding.inflate(LayoutInflater.from(parent.context), parent, false)
        return ViewHolder(binding)
    }

    override fun onBindViewHolder(viewHolder: ViewHolder, position: Int) {
        val galleryItem = oneDimensionalService[position]
        viewHolder.bind(galleryItem)
    }

    override fun getItemCount() = oneDimensionalService.size

    inner class ViewHolder(private val binding: ItemServicesBinding) :
        RecyclerView.ViewHolder(binding.root) {


        fun bind(oneDimensionalService: OneDimensionalService) {
            binding.setUpViews(oneDimensionalService)
        }

        private fun ItemServicesBinding.setUpViews(oneDimensionalService: OneDimensionalService) {
            binding.root.setOnClickListener { onItemClicked(oneDimensionalService.serviceId ?: 0L) }
            val imagePath = oneDimensionalService.imagePath ?: R.drawable.default_image
            servicesDetailsIv.load(root.context, imagePath)
            servicesNameTv.text = oneDimensionalService.getServicesName()
            //servicesDetailsTv.text = oneDimensionalService.getServicesDetails()
        }

        private fun OneDimensionalService.getServicesName() = getLocalizedValue(nameEN, nameAR)

        private fun OneDimensionalService.getServicesDetails() =
            getLocalizedValue(detailsEN, detailsAR)
    }
}