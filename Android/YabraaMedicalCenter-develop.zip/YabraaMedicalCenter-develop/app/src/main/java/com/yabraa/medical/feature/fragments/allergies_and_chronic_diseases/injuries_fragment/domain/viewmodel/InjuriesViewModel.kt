package com.yabraa.medical.feature.fragments.allergies_and_chronic_diseases.injuries_fragment.domain.viewmodel

import androidx.lifecycle.ViewModel
import androidx.lifecycle.viewModelScope
import com.core.shared.state.State
import com.yabraa.medical.feature.fragments.allergies_and_chronic_diseases.injuries_fragment.data.model.request.InjuriesRequestDto
import com.yabraa.medical.feature.fragments.allergies_and_chronic_diseases.injuries_fragment.data.model.response.InjuriesResponseDto
import com.yabraa.medical.feature.fragments.allergies_and_chronic_diseases.injuries_fragment.domain.repository.AddInjuriesRepository
import com.yabraa.medical.feature.fragments.allergies_and_chronic_diseases.injuries_fragment.domain.repository.DeleteInjuriesRepository
import com.yabraa.medical.feature.fragments.allergies_and_chronic_diseases.injuries_fragment.domain.usecase.InjuriesUseCase
import dagger.hilt.android.lifecycle.HiltViewModel
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.launch
import javax.inject.Inject

@HiltViewModel
class InjuriesViewModel @Inject constructor(
    private val injuriesUseCase: InjuriesUseCase,
    private val addInjuriesRepository: AddInjuriesRepository,
    private val deleteInjuriesRepository: DeleteInjuriesRepository
) : ViewModel() {


    private val _injuriesResponseState =
        MutableStateFlow<State<InjuriesResponseDto>>(State.Initial())
    val injuriesResponseState: StateFlow<State<InjuriesResponseDto>> =
        _injuriesResponseState

    private val _injuriesByUserFamilyIdResponseState =
        MutableStateFlow<State<InjuriesResponseDto>>(State.Initial())
    val injuriesByUserFamilyIdResponseState: StateFlow<State<InjuriesResponseDto>> =
        _injuriesByUserFamilyIdResponseState

    private val _addInjuriesResponseState =
        MutableStateFlow<State<InjuriesResponseDto>>(State.Initial())
    val addInjuriesResponseState: StateFlow<State<InjuriesResponseDto>> =
        _addInjuriesResponseState

    private val _deleteInjuriesResponseState =
        MutableStateFlow<State<InjuriesResponseDto>>(State.Initial())
    val deleteInjuriesResponseState: StateFlow<State<InjuriesResponseDto>> =
        _deleteInjuriesResponseState

    fun getInjuries() {
        viewModelScope.launch {
            _injuriesResponseState.emit(State.Loading())
            injuriesUseCase().collect {
                _injuriesResponseState.emit(it)
            }
        }
    }


    fun getInjuriesByUserFamilyId(userFamilyId: Long) {
        viewModelScope.launch {
            _injuriesByUserFamilyIdResponseState.emit(State.Loading())
            injuriesUseCase(userFamilyId).collect {
                _injuriesByUserFamilyIdResponseState.emit(it)
            }
        }
    }

    fun addInjuries(requestDto: InjuriesRequestDto) {
        viewModelScope.launch {
            _addInjuriesResponseState.emit(State.Loading())
            addInjuriesRepository.addInjuries(requestDto).collect {
                _addInjuriesResponseState.emit(it)
            }
        }
    }


    fun deleteInjuries(requestDto: InjuriesRequestDto) {
        viewModelScope.launch {
            _deleteInjuriesResponseState.emit(State.Loading())
            deleteInjuriesRepository.deleteInjuries(requestDto).collect {
                _deleteInjuriesResponseState.emit(it)
            }
        }
    }

    fun getInjuriesList() = injuriesUseCase.getInjuriesList()
}