package com.yabraa.medical.feature.fragments.appointment.my_appointment_details.presentation


import android.net.Uri
import android.os.Build
import android.os.Bundle
import android.view.View
import androidx.core.view.isVisible
import androidx.fragment.app.viewModels
import androidx.lifecycle.MutableLiveData
import androidx.lifecycle.lifecycleScope
import androidx.navigation.fragment.findNavController
import com.yabraa.medical.core.base_fragment.BaseFragment
import com.yabraa.medical.core.base_fragment.setOnGoToConnectionSettingClicked
import com.core.shared.state.State
import com.core.shared.utils.CommonUtils.getLocalizedValue
import com.core.shared.utils.CommonUtils.openFileWithActionView
import com.yabraa.medical.core.utils.custom_views.yabraa_bar.YabraaBarHandler
import com.yabraa.medical.databinding.FragmentMyAppointmentDetailsBinding
import com.yabraa.medical.feature.fragments.appointment.my_appointment.data.model.response.MyAppointmentResponse
import com.yabraa.medical.feature.fragments.appointment.my_appointment.presentation.MY_APPOINTMENT
import com.yabraa.medical.feature.fragments.appointment.my_appointment_details.data.model.MyAppointmentDetailsResponse
import com.yabraa.medical.feature.fragments.appointment.my_appointment_details.data.model.VisitAttachment
import com.yabraa.medical.feature.fragments.appointment.my_appointment_details.data.model.VisitNote
import com.yabraa.medical.feature.fragments.appointment.my_appointment_details.domain.viewmodel.MyAppointmentDetailsViewModel
import com.yabraa.medical.feature.fragments.appointment.my_appointment_details.presentation.adapter.AttachmentFileAdapter
import com.yabraa.medical.feature.fragments.appointment.my_appointment_details.presentation.adapter.MedicalInstructionsAdapter
import dagger.hilt.android.AndroidEntryPoint
import kotlinx.coroutines.launch


@AndroidEntryPoint
class MyAppointmentDetailsFragment : BaseFragment<FragmentMyAppointmentDetailsBinding>() {

    override val binding by lazy { FragmentMyAppointmentDetailsBinding.inflate(layoutInflater) }

    private val viewModel: MyAppointmentDetailsViewModel by viewModels()

    private lateinit var attachmentFileAdapter: AttachmentFileAdapter
    private lateinit var medicalInstructionsAdapter: MedicalInstructionsAdapter

    @Suppress("DEPRECATION")
    private val myAppointment
        get() = run {
            if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.TIRAMISU) {
                arguments?.getSerializable(MY_APPOINTMENT, MyAppointmentResponse::class.java)
            } else {
                arguments?.getSerializable(MY_APPOINTMENT)
            }
        } as MyAppointmentResponse

    private var myAppointmentDetailsResponse = MutableLiveData<MyAppointmentDetailsResponse?>()
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        binding.handleNetworkConnection()
    }

    override fun onViewCreated(view: View, savedInstanceState: Bundle?) {
        binding.internetConnection.goToSettingBtn.setOnGoToConnectionSettingClicked(requireActivity())
        lifecycleScope.launch { collectOnMyAppointmentResponseState() }
    }


    override fun onResume() {
        super.onResume()
        yabraaBarView?.setUpYabraaBarView()
        confirmationView?.setConfirmationAppointmentVisibility(false)
        showBottomNavigation(false)
    }

    private fun YabraaBarHandler.setUpYabraaBarView() {
        val barTitle = getLocalizedValue(myAppointment.packageNameEN, myAppointment.packageNameAR)
        setYabraaBarVisibility(true)
        setClearAllVisibility(false)
        setBarTitle(barTitle)
        setOnBackArrowClicked { findNavController().popBackStack() }
    }

    private fun FragmentMyAppointmentDetailsBinding.handleNetworkConnection() {
        connectivityManager?.isNetworkConnected?.observe(this@MyAppointmentDetailsFragment) {
            handleConnectionViewVisibility(it)
            handleNoAppointmentGroupVisibility(it)
            if (!it) return@observe
            viewModel.getMyAppointmentDetails(myAppointment.appointmentId)
        }
    }

    private fun FragmentMyAppointmentDetailsBinding.handleConnectionViewVisibility(isVisible: Boolean) {
        contentRoot.isVisible = isVisible
        internetConnection.root.isVisible = !isVisible
    }


    private suspend fun collectOnMyAppointmentResponseState() {
        viewModel.myAppointmentDetailsResponseState.collect {
            hideProgressDialog()
            when (it) {
                is State.Error -> it.error.handleError { }
                is State.Initial -> {}
                is State.Loading -> showProgressDialog()
                is State.Success -> {
                    val response = it.data?.myAppointmentDetailsResponse
                    myAppointmentDetailsResponse.postValue(response)
                    setAttachmentAdapter(response?.visitAttachments)
                    setMedicalInstructionsAdapter(response?.visitNotes)
                }
            }
        }
    }

    private fun setAttachmentAdapter(filesItems: List<VisitAttachment>?) {
        val files = filesItems ?: return
        binding.documentGroup.isVisible = files.isNotEmpty()
        attachmentFileAdapter = AttachmentFileAdapter(files) {
            val fileUri = Uri.parse(it)
            openFileWithActionView(requireActivity(), fileUri)
        }
        binding.attachmentFileRv.adapter = attachmentFileAdapter
    }


    private fun setMedicalInstructionsAdapter(instructionsItems: List<VisitNote>?) {
        val instructions = instructionsItems ?: return
        binding.medicalPrescriptionGroup.isVisible = instructions.isNotEmpty()
        medicalInstructionsAdapter = MedicalInstructionsAdapter(instructions)
        binding.medicalInstructionsRV.adapter = medicalInstructionsAdapter
    }

    private fun FragmentMyAppointmentDetailsBinding.handleNoAppointmentGroupVisibility(isVisible: Boolean) {
        myAppointmentDetailsResponse.observe(this@MyAppointmentDetailsFragment) { response ->
            if (response?.visitAttachments.isNullOrEmpty() && response?.visitNotes.isNullOrEmpty()) {
                documentGroup.isVisible = !isVisible
                medicalPrescriptionGroup.isVisible = !isVisible
                noAppointmentGroup.isVisible = isVisible
            }
        }
    }
}