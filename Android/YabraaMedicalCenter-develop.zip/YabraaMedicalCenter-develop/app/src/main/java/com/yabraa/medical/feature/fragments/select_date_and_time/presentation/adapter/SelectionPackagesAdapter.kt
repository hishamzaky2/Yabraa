package com.yabraa.medical.feature.fragments.select_date_and_time.presentation.adapter

import android.view.LayoutInflater
import android.view.ViewGroup
import android.widget.EditText
import android.widget.TextView
import androidx.core.widget.doAfterTextChanged
import androidx.recyclerview.widget.RecyclerView
import com.yabraa.medical.R
import com.core.shared.utils.CommonUtils.getLocalizedValue
import com.yabraa.medical.databinding.ItemSelectDateAndTimeBinding
import com.yabraa.medical.feature.fragments.home.data.model.response.services_details_response.PackageData
import com.yabraa.medical.feature.fragments.select_date_and_time.presentation.adapter.SelectionPackagesAdapter.ViewHolder
import java.util.Locale

class SelectionPackagesAdapter(
    private val packagesList: MutableList<PackageData>,
    private val onItemClicked: (Long) -> Unit
) :
    RecyclerView.Adapter<ViewHolder>() {

    lateinit var setOnSelectPatientCallback: SelectionPackagesListener

    lateinit var dateValueCallback: SelectionPackagesCallback

    lateinit var patientValueCallback: SelectionPackagesCallback

    lateinit var optionalNotesCallback: SelectionPackagesCallback

    lateinit var optionalNotesValueCallback: SelectionPackagesCallback

    override fun onCreateViewHolder(parent: ViewGroup, viewType: Int): ViewHolder {
        val binding =
            ItemSelectDateAndTimeBinding.inflate(LayoutInflater.from(parent.context), parent, false)
        return ViewHolder(binding)
    }

    override fun onBindViewHolder(holder: ViewHolder, position: Int) {
        val item = packagesList[position]
        holder.bind(item)
    }

    override fun getItemCount() = packagesList.size

    override fun getItemViewType(position: Int) = position


    inner class ViewHolder(private val binding: ItemSelectDateAndTimeBinding) :
        RecyclerView.ViewHolder(binding.root) {

        fun bind(item: PackageData) {
            binding.setUpViews(item)
        }

        private fun ItemSelectDateAndTimeBinding.setUpViews(item: PackageData) {
            setOnSelectDateAndTimeClicked(item)
            setOnSelectPatientClicked(item)
            setServiceNameTv(item)
            setServicePriceTv(item)
            setDateValue(item)
            setPatientValue(item)
            setNoteValue(item)
            addOptionalNotes(item)
        }


        private fun ItemSelectDateAndTimeBinding.setOnSelectDateAndTimeClicked(item: PackageData) {
            selectDateAndTimeView.setOnClickListener { onItemClicked(item.packageId) }
        }

        private fun ItemSelectDateAndTimeBinding.setOnSelectPatientClicked(item: PackageData) {
            selectPatientView.setOnClickListener {
                setOnSelectPatientCallback.setOnSelectPatientClicked(item.packageId)
            }
        }

        private fun ItemSelectDateAndTimeBinding.setServiceNameTv(item: PackageData) {
            serviceNameTv.text = getLocalizedValue(item.nameEN, item.nameAR)
        }

        private fun ItemSelectDateAndTimeBinding.setServicePriceTv(item: PackageData) {
            servicePriceTv.text =
                String.format(Locale.ENGLISH, root.context.getString(R.string.price), item.price)
        }

        private fun ItemSelectDateAndTimeBinding.setDateValue(item: PackageData) =
            dateValueCallback.setDateValue(item.packageId, selectDateAndTimeTv)


        private fun ItemSelectDateAndTimeBinding.setPatientValue(item: PackageData) =
            patientValueCallback.setPatientValue(item.packageId, selectPatientTv)

        private fun ItemSelectDateAndTimeBinding.setNoteValue(item: PackageData) =
            optionalNotesValueCallback.setNoteValue(item.packageId, addNoteEt)


        private fun ItemSelectDateAndTimeBinding.addOptionalNotes(item: PackageData) {
            addNoteEt.doAfterTextChanged {
                if (it.isNullOrEmpty()) it?.clear()
                optionalNotesCallback.addOptionalNotes(item.packageId, it.toString())
            }
        }
    }

    fun initializeSetOnSelectPatientCallback(callback: SelectionPackagesListener) {
        setOnSelectPatientCallback = callback
    }

    fun initializeSetDateValueCallback(callback: SelectionPackagesCallback) {
        dateValueCallback = callback
    }

    fun initializeSetPatientValueCallback(callback: SelectionPackagesCallback) {
        patientValueCallback = callback
    }

    fun initializeAddOptionalNotesCallback(callback: SelectionPackagesCallback) {
        optionalNotesCallback = callback
    }

    fun initializeSeOptionalNotesValueCallback(callback: SelectionPackagesCallback) {
        optionalNotesValueCallback = callback
    }

    interface SelectionPackagesListener {
        fun setOnSelectPatientClicked(packageId: Long)
    }

    interface SelectionPackagesCallback {
        fun setDateValue(packageId: Long, selectDateAndTimeTv: TextView)
        fun setPatientValue(packageId: Long, patientTv: TextView)
        fun addOptionalNotes(packageId: Long, notes: String)
        fun setNoteValue(packageId: Long, noteEt: EditText)
    }
}