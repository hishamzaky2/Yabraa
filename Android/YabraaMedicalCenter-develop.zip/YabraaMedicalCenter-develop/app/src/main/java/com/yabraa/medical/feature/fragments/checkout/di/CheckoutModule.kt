package com.yabraa.medical.feature.fragments.checkout.di

import com.yabraa.medical.core.di.network_sevices.YabraaServices
import com.yabraa.medical.feature.fragments.checkout.data.repository.checkout_repository.CheckoutRepositoryImpl
import com.yabraa.medical.feature.fragments.checkout.data.repository.complete_payment_repository.CompletePaymentRepositoryImpl
import com.yabraa.medical.feature.fragments.checkout.data.repository.payment_method_repository.PaymentMethodRepositoryImpl
import com.yabraa.medical.feature.fragments.checkout.domain.repository.checkout_repository.CheckoutRepository
import com.yabraa.medical.feature.fragments.checkout.domain.repository.complete_payment_repository.CompletePaymentRepository
import com.yabraa.medical.feature.fragments.checkout.domain.repository.payment_method_repository.PaymentMethodRepository
import dagger.Module
import dagger.Provides
import dagger.hilt.InstallIn
import dagger.hilt.android.components.ViewModelComponent

@Module
@InstallIn(ViewModelComponent::class)
object CheckoutModule {

    @Provides
    fun provideCheckoutRepository(yabraaServices: YabraaServices): CheckoutRepository =
        CheckoutRepositoryImpl(yabraaServices)

    @Provides
    fun provideCompletePaymentRepository(yabraaServices: YabraaServices): CompletePaymentRepository =
        CompletePaymentRepositoryImpl(yabraaServices)


    @Provides
    fun providePaymentMethodsRepository(yabraaServices: YabraaServices): PaymentMethodRepository =
        PaymentMethodRepositoryImpl(yabraaServices)
}