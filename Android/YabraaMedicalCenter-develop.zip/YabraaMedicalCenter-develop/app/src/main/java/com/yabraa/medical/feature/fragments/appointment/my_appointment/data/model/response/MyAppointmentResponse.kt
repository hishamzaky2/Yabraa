package com.yabraa.medical.feature.fragments.appointment.my_appointment.data.model.response


import com.google.gson.annotations.SerializedName
import java.io.Serializable

data class MyAppointmentResponse(
    @SerializedName("packageNameAR")
    val packageNameAR: String,
    @SerializedName("packageNameEN")
    val packageNameEN: String,
    @SerializedName("price")
    val price: Double,
    @SerializedName("serviceAR")
    val serviceAR: String,
    @SerializedName("serviceEN")
    val serviceEN: String,
    @SerializedName("status")
    val status: String,
    @SerializedName("userFamilyName")
    val userFamilyName: String,
    @SerializedName("visitDT")
    val visitDT: String,
    @SerializedName("visitTime")
    val visitTime: String,
    @SerializedName("appointmentId")
    val appointmentId: Long,
    @SerializedName("serviceTypeId")
    val serviceTypeId: Long
) : Serializable