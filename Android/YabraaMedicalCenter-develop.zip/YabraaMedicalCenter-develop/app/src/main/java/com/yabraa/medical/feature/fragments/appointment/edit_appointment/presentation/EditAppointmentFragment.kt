package com.yabraa.medical.feature.fragments.appointment.edit_appointment.presentation

import android.annotation.SuppressLint
import android.os.Build
import android.os.Bundle
import android.view.View
import androidx.core.view.isVisible
import androidx.core.widget.doAfterTextChanged
import androidx.fragment.app.viewModels
import androidx.lifecycle.lifecycleScope
import androidx.navigation.fragment.findNavController
import com.yabraa.medical.R
import com.yabraa.medical.core.base_fragment.BaseFragment
import com.yabraa.medical.core.base_fragment.navigate
import com.yabraa.medical.core.base_fragment.setOnGoToConnectionSettingClicked
import com.core.shared.error.OperationMessage
import com.core.shared.error.YabraaError
import com.core.shared.state.State
import com.core.shared.utils.CommonUtils.decodeDateString
import com.core.shared.utils.CommonUtils.getLocalizedValue
import com.core.shared.utils.CommonUtils.handleExpirationDate
import com.yabraa.medical.core.utils.custom_views.yabraa_bar.YabraaBarHandler
import com.yabraa.medical.core.utils.dialog.yabraa_dialog.YabraaDialogBuilder
import com.yabraa.medical.core.utils.getErrorMessage
import com.yabraa.medical.databinding.FragmentEditAppointmentBinding
import com.yabraa.medical.feature.fragments.appointment.edit_appointment.data.model.request.EditAppointmentRequestDto
import com.yabraa.medical.feature.fragments.appointment.edit_appointment.data.model.response.AppointmentResponse
import com.yabraa.medical.feature.fragments.appointment.edit_appointment.domain.model.EditAppointmentModel
import com.yabraa.medical.feature.fragments.appointment.edit_appointment.domain.model.ServiceTypeIds
import com.yabraa.medical.feature.fragments.appointment.edit_appointment.domain.viewmodel.EditAppointmentViewModel
import com.yabraa.medical.feature.fragments.appointment.my_appointment.data.model.response.MyAppointmentResponse
import com.yabraa.medical.feature.fragments.appointment.my_appointment.presentation.MY_APPOINTMENT
import com.yabraa.medical.feature.fragments.common.domain.model.ErrorMessageUi
import dagger.hilt.android.AndroidEntryPoint
import kotlinx.coroutines.launch
import java.util.Locale

const val EDIT_APPOINTMENT_WAY = "EDIT_APPOINTMENT_WAY"

@AndroidEntryPoint
class EditAppointmentFragment : BaseFragment<FragmentEditAppointmentBinding>() {

    override val binding by lazy { FragmentEditAppointmentBinding.inflate(layoutInflater) }
    private val viewModel: EditAppointmentViewModel by viewModels()

    @Suppress("DEPRECATION")
    private val myAppointment
        get() = run {
            if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.TIRAMISU) {
                arguments?.getSerializable(MY_APPOINTMENT, MyAppointmentResponse::class.java)
            } else {
                arguments?.getSerializable(MY_APPOINTMENT)
            }
        } as MyAppointmentResponse

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        showExpirationDateError()
        binding.handleNetworkConnection()
    }

    override fun onViewCreated(view: View, savedInstanceState: Bundle?) {
        super.onViewCreated(view, savedInstanceState)
        binding.internetConnection.goToSettingBtn.setOnGoToConnectionSettingClicked(requireActivity())
        lifecycleScope.launch { collectOnGetAppointmentByIdResponse() }
        lifecycleScope.launch { collectOnEditAppointmentResponse() }
    }

    override fun onResume() {
        super.onResume()
        yabraaBarView?.setUpYabraaBarView()
        showBottomNavigation(false)
        confirmationView?.setConfirmationAppointmentVisibility(false)
    }

    private fun YabraaBarHandler.setUpYabraaBarView() {
        val barTitle = getLocalizedValue(myAppointment.packageNameEN, myAppointment.packageNameAR)
        setYabraaBarVisibility(true)
        setClearAllVisibility(false)
        setBarTitle(barTitle)
        setOnBackArrowClicked { findNavController().popBackStack() }
    }

    private fun FragmentEditAppointmentBinding.handleNetworkConnection() {
        connectivityManager?.isNetworkConnected?.observe(this@EditAppointmentFragment) {
            handleConnectionViewVisibility(it)
            if (!it) return@observe
            viewModel.getAppointmentById(myAppointment.appointmentId)
        }
    }

    private fun FragmentEditAppointmentBinding.handleConnectionViewVisibility(isVisible: Boolean) {
        editAppointmentGroup.isVisible = isVisible
        internetConnection.root.isVisible = !isVisible
    }

    private suspend fun collectOnGetAppointmentByIdResponse() {
        viewModel.appointmentByIdResponseState.collect {
            hideProgressDialog()
            when (it) {
                is State.Error -> it.error.handleError { }
                is State.Initial -> {}
                is State.Loading -> showProgressDialog()
                is State.Success -> binding.setUpViews(it.data?.appointmentResponse)
            }
        }
    }

    @SuppressLint("SetTextI18n")
    private fun FragmentEditAppointmentBinding.setUpViews(responseDto: AppointmentResponse?) {
        if (responseDto == null) return
        val packageName = getLocalizedValue(responseDto.packageNameEN, responseDto.packageNameAR)
        val visitDT = decodeDateString(responseDto.visitDT, "yyyy-MM-dd")
        val visitTime = decodeDateString(responseDto.visitTime, "HH:mm")
        serviceNameTv.text = packageName
        servicePriceTv.text =
            String.format(Locale.ENGLISH, root.context.getString(R.string.price), responseDto.price)
        selectPatientTv.text = responseDto.userFamilyName
        selectDateAndTimeTv.text = "$visitDT - $visitTime"
        addNoteEt.setText(responseDto.notes)
        handleAddNotes()
        setOnEditAppointmentClicked(responseDto)
    }


    private fun FragmentEditAppointmentBinding.handleAddNotes() {
        viewModel.appointmentNotes =
            if (addNoteEt.text.isNullOrEmpty()) null else addNoteEt.text.toString()
        addNoteEt.doAfterTextChanged {
            viewModel.appointmentNotes = if (it.isNullOrEmpty()) null else addNoteEt.text.toString()
        }
    }


    private fun FragmentEditAppointmentBinding.setOnEditAppointmentClicked(responseDto: AppointmentResponse?) =
        editAppointmentBtn.setOnClickListener {
            showAskEditAppointmentPopup(responseDto)
        }

    private fun showAskEditAppointmentPopup(responseDto: AppointmentResponse?) {
        val request = responseDto?.setEditAppointmentRequest() ?: return
        val serviceTypeId = responseDto.serviceTypeId
        val isNormalType = serviceTypeId == ServiceTypeIds.NORMAL.serviceTypeId
        val isVirtualType = serviceTypeId == ServiceTypeIds.VIRTUAL.serviceTypeId
        YabraaDialogBuilder(requireActivity()).setIcon(R.drawable.ic_vector_edit_location)
            .setTitle(R.string.doYouWantEditTheLocation)
            .setTopButton(R.string.editLocation, topButtonVisibility = isNormalType) {
                navigateToMapFragment(responseDto)
            }.setBottomButton(
                bottomButtonText = R.string.editTheCurrentInfo,
                bottomButtonVisibility = viewModel.appointmentNotes != null || isVirtualType
            ) {
                viewModel.editAppointment(request)
            }.show()
    }

    private fun navigateToMapFragment(responseDto: AppointmentResponse) {
        val editAppointmentModel = EditAppointmentModel(
            isEditAppointmentWay = true,
            appointmentId = responseDto.appointmentId,
            notes = viewModel.appointmentNotes,
            locationLatitude = responseDto.locationLatitude,
            locationLongitude = responseDto.locationLongitude,
            serviceTypeId = responseDto.serviceTypeId
        )
        val bundle = Bundle()
        bundle.putSerializable(EDIT_APPOINTMENT_WAY, editAppointmentModel)
        navigate(R.id.actionEditAppointmentFragmentToMapsFragment, bundle)
    }

    private fun AppointmentResponse.setEditAppointmentRequest(): EditAppointmentRequestDto {
        val appointmentNotes =
            if (viewModel.appointmentNotes != null) viewModel.appointmentNotes else null
        return EditAppointmentRequestDto(
            appointmentId = myAppointment.appointmentId,
            notes = appointmentNotes,
            locationLatitude = locationLatitude,
            locationLongitude = locationLongitude,
            serviceTypeId = serviceTypeId
        )
    }

    private suspend fun collectOnEditAppointmentResponse() {
        viewModel.editAppointmentResponseState.collect {
            hideProgressDialog()
            when (it) {
                is State.Error -> it.error.handleEditAppointmentResponseError()
                is State.Initial -> {}
                is State.Loading -> showProgressDialog()
                is State.Success -> showResetResponseSuccessPopup()
            }
        }
    }

    private fun showResetResponseSuccessPopup() {
        YabraaDialogBuilder(requireActivity()).setIcon(R.drawable.ic_vector_check_circle)
            .setTitle(R.string.success)
            .setTopButton(R.string.ok) {
                findNavController().popBackStack()
            }.setCancelable(false)
            .show()
    }

    private fun YabraaError.handleEditAppointmentResponseError() {
        val errorMessageUi = ErrorMessageUi(logMessageEn, logMessageAr)
        handleError {
            when (exception) {
                is OperationMessage -> showEditAppointmentResponseErrorPopup(errorMessageUi)
            }
        }
    }


    private fun showEditAppointmentResponseErrorPopup(errorMessageUi: ErrorMessageUi) {
        val errorMessage = getErrorMessage(errorMessageUi)
        YabraaDialogBuilder(requireActivity()).setIcon(R.drawable.ic_vector_error)
            .setTitle(R.string.warning)
            .setMessage(errorMessage)
            .setTopButton(R.string.ok) {
                findNavController().popBackStack()
            }.setCancelable(false)
            .show()
    }

    private fun showExpirationDateError() =
        tokenHandler.handleExpirationDate { showExpirationDatePopupError() }
}