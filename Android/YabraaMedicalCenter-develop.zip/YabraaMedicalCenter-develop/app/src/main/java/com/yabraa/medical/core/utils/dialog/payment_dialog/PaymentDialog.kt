package com.yabraa.medical.core.utils.dialog.payment_dialog

import android.app.Activity
import android.app.Dialog
import android.view.LayoutInflater
import androidx.annotation.StyleRes
import androidx.appcompat.app.AlertDialog
import androidx.core.view.isVisible
import androidx.recyclerview.widget.RecyclerView
import com.google.android.material.dialog.MaterialAlertDialogBuilder
import com.yabraa.medical.R
import com.core.shared.utils.CommonUtils.setLayoutParams
import com.yabraa.medical.core.utils.localize
import com.yabraa.medical.databinding.LayoutPaymentMthodsBinding

class PaymentDialog(activity: Activity, @StyleRes style: Int = R.style.CustomDialogTheme) :
    MaterialAlertDialogBuilder(activity, style) {

    lateinit var binding: LayoutPaymentMthodsBinding
    private var topButtonText: String? = null
    private var topButtonAction: (() -> Unit)? = null
    private var topButtonActionDismiss: Boolean? = null
    private var adapter: RecyclerView.Adapter<*>? = null


    override fun create(): AlertDialog {
        binding = LayoutPaymentMthodsBinding.inflate(LayoutInflater.from(context))
        setView(binding.root)
        val dialog = super.create()
        setLayoutParams(dialog)
        binding.setUpViews(dialog)
        return dialog

    }

    private fun LayoutPaymentMthodsBinding.setUpViews(dialog: Dialog) {
        handleAdapter()
        handleTopButton(dialog)
    }

    fun setPayAdapter(adapter: RecyclerView.Adapter<*>): PaymentDialog {
        this.adapter = adapter
        return this
    }

    private fun LayoutPaymentMthodsBinding.handleAdapter() {
        adapterRv.adapter = adapter
    }

    fun setTopButton(
        topButtonText: Int,
        topButtonActionDismiss: Boolean = true,
        topButton: () -> Unit
    ): PaymentDialog {
        this.topButtonText = context.localize(topButtonText)
        this.topButtonActionDismiss = topButtonActionDismiss
        this.topButtonAction = topButton
        return this
    }

    private fun LayoutPaymentMthodsBinding.handleTopButton(dialog: Dialog) {
        topButton.isVisible = topButtonText != null
        topButton.text = topButtonText
        setOnTopButtonClicked(dialog)
    }

    private fun LayoutPaymentMthodsBinding.setOnTopButtonClicked(dialog: Dialog) {
        topButton.setOnClickListener {
            topButtonAction?.invoke()
            if (topButtonActionDismiss == true) {
                dialog.dismiss()
            }
        }
    }
}

