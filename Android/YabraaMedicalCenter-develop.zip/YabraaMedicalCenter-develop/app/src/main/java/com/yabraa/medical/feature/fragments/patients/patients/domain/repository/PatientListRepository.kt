package com.yabraa.medical.feature.fragments.patients.patients.domain.repository

import kotlinx.coroutines.flow.Flow
import com.core.shared.state.State
import com.yabraa.medical.feature.fragments.patients.patients.data.model.response.PatientResponseDto

interface PatientListRepository {
    suspend fun getPatientList(): Flow<State<PatientResponseDto>>
}