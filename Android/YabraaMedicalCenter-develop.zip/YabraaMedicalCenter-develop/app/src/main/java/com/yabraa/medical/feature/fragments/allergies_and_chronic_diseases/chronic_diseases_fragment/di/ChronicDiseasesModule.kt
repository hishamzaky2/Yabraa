package com.yabraa.medical.feature.fragments.allergies_and_chronic_diseases.chronic_diseases_fragment.di

import com.yabraa.medical.core.di.network_sevices.AllergiesAndChronicDiseasesServices
import com.yabraa.medical.feature.fragments.allergies_and_chronic_diseases.chronic_diseases_fragment.data.repository.AddChronicDiseasesRepositoryImpl
import com.yabraa.medical.feature.fragments.allergies_and_chronic_diseases.chronic_diseases_fragment.data.repository.ChronicDiseasesByUserFamilyIdRepositoryImpl
import com.yabraa.medical.feature.fragments.allergies_and_chronic_diseases.chronic_diseases_fragment.data.repository.ChronicDiseasesRepositoryImpl
import com.yabraa.medical.feature.fragments.allergies_and_chronic_diseases.chronic_diseases_fragment.data.repository.DeleteChronicDiseasesRepositoryImpl
import com.yabraa.medical.feature.fragments.allergies_and_chronic_diseases.chronic_diseases_fragment.domain.repository.AddChronicDiseasesRepository
import com.yabraa.medical.feature.fragments.allergies_and_chronic_diseases.chronic_diseases_fragment.domain.repository.ChronicDiseasesByUserFamilyIdRepository
import com.yabraa.medical.feature.fragments.allergies_and_chronic_diseases.chronic_diseases_fragment.domain.repository.ChronicDiseasesRepository
import com.yabraa.medical.feature.fragments.allergies_and_chronic_diseases.chronic_diseases_fragment.domain.repository.DeleteChronicDiseasesRepository
import dagger.Module
import dagger.Provides
import dagger.hilt.InstallIn
import dagger.hilt.android.components.ViewModelComponent

@Module
@InstallIn(ViewModelComponent::class)
object ChronicDiseasesModule {


    @Provides
    fun provideChronicDiseasesRepositoryImpl(allergiesAndChronicDiseasesServices: AllergiesAndChronicDiseasesServices): ChronicDiseasesRepository =
        ChronicDiseasesRepositoryImpl(allergiesAndChronicDiseasesServices)

    @Provides
    fun provideChronicDiseasesByUserFamilyIdRepositoryImpl(allergiesAndChronicDiseasesServices: AllergiesAndChronicDiseasesServices): ChronicDiseasesByUserFamilyIdRepository =
        ChronicDiseasesByUserFamilyIdRepositoryImpl(allergiesAndChronicDiseasesServices)


    @Provides
    fun provideAddChronicDiseasesRepositoryImpl(allergiesAndChronicDiseasesServices: AllergiesAndChronicDiseasesServices): AddChronicDiseasesRepository =
        AddChronicDiseasesRepositoryImpl(allergiesAndChronicDiseasesServices)

    @Provides
    fun provideDeleteChronicDiseasesRepositoryImpl(allergiesAndChronicDiseasesServices: AllergiesAndChronicDiseasesServices): DeleteChronicDiseasesRepository =
        DeleteChronicDiseasesRepositoryImpl(allergiesAndChronicDiseasesServices)
}