package com.yabraa.medical.feature.fragments.patients.edit_patients.domain.repository.delete_patient_repository

import com.core.shared.state.State
import com.yabraa.medical.feature.fragments.patients.edit_patients.data.model.response.delete_patient_response.DeletePatientResponseDto
import kotlinx.coroutines.flow.Flow

interface DeletePatientRepository {
    suspend fun deletePatient(userFamilyId: Long): Flow<State<DeletePatientResponseDto>>
}