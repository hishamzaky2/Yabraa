package com.yabraa.medical.feature.fragments.allergies_and_chronic_diseases.chronic_diseases_fragment.domain.model

data class ChronicDiseasesEntityModel (
    val chronicDiseaseId: Long,
    val titleAR: String,
    val titleEN: String,
    var isAdded : Boolean = false
)