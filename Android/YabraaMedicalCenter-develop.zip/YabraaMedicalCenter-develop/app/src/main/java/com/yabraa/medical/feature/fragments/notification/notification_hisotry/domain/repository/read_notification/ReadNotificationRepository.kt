package com.yabraa.medical.feature.fragments.notification.notification_hisotry.domain.repository.read_notification

import com.core.shared.state.State
import com.yabraa.medical.feature.fragments.notification.notification_hisotry.data.model.response.read_notification_response.ReadNotificationResponseDto
import kotlinx.coroutines.flow.Flow

interface ReadNotificationRepository {

    suspend fun readNotification(notificationId: Long): Flow<State<ReadNotificationResponseDto>>
}