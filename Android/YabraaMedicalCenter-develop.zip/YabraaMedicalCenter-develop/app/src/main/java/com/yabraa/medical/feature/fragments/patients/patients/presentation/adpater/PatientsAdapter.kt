package com.yabraa.medical.feature.fragments.patients.patients.presentation.adpater

import android.view.LayoutInflater
import android.view.ViewGroup
import androidx.core.view.isVisible
import androidx.recyclerview.widget.RecyclerView
import com.yabraa.medical.databinding.ItemPatientsBinding
import com.yabraa.medical.feature.fragments.patients.patients.data.model.response.PatientResponse

class PatientsAdapter(
    private val patients: MutableList<PatientResponse>,
    private val onItemClicked: (PatientResponse) -> Unit
) : RecyclerView.Adapter<PatientsAdapter.ViewHolder>() {

    override fun onCreateViewHolder(parent: ViewGroup, viewType: Int): PatientsAdapter.ViewHolder {
        val binding =
            ItemPatientsBinding.inflate(LayoutInflater.from(parent.context), parent, false)
        return ViewHolder(binding)
    }

    override fun onBindViewHolder(viewHolder: PatientsAdapter.ViewHolder, position: Int) {
        val item = patients[position]
        viewHolder.bind(item)
    }

    override fun getItemCount() = patients.size

    override fun getItemViewType(position: Int) = position

    inner class ViewHolder(val binding: ItemPatientsBinding) :
        RecyclerView.ViewHolder(binding.root) {
        fun bind(item: PatientResponse) {
            binding.setUpViews(item)
        }

        private fun ItemPatientsBinding.setUpViews(item: PatientResponse) {
            edit.isVisible = !item.isOwner
            edit.setOnClickListener { onItemClicked(item) }
            patientNameTv.text = item.name
        }
    }
}