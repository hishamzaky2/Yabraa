package com.yabraa.medical.core.base_repository

import com.core.shared.error.GeneralException
import com.core.shared.error.IoException
import com.core.shared.error.ResponseError
import com.core.shared.error.ResponseUnAuthorizedError
import com.core.shared.error.YabraaError
import kotlinx.coroutines.CoroutineDispatcher
import kotlinx.coroutines.Dispatchers
import com.core.shared.state.State
import okio.IOException
import retrofit2.Response
import java.util.concurrent.CancellationException


abstract class BaseRepository<RequestDto, ResponseDto> {

    var dispatcher: CoroutineDispatcher = Dispatchers.IO

    suspend fun getOperationState(requestDto: RequestDto): State<ResponseDto> {
        return try {
            performApiCall(requestDto)
        } catch (e: IOException) {
            State.Error(getIoExceptionError(e))
        } catch (e: Exception) {
            if (e is CancellationException) throw e
            State.Error(getGeneralExceptionError(e))
        }
    }

    abstract suspend fun performApiCall(requestDto: RequestDto): State<ResponseDto>

    fun <T> getNotSuccessfulResponseState(response: Response<*>): State<T> {
        return when {
            response.code() == 401 -> State.Error(getUnauthorizedError(response))
            else -> State.Error(getNotSuccessfulResponseError(response))
        }
    }

    private fun getIoExceptionError(e: IOException) = YabraaError.E(
        exception = IoException(cause = e),
        logMessageEn = "Failed to load data from Api with IOException:",
    )

    private fun getGeneralExceptionError(e: Exception) = YabraaError.E(
        exception = GeneralException(cause = e),
        logMessageEn = "Failed to load data from Api with General exception",
    )

    private fun getNotSuccessfulResponseError(response: Response<*>) = YabraaError.E(
        exception = ResponseError(),
        logMessageEn = "Api request to url: ${response.raw().request.url}: failed with code ${response.code()}",
        extraData = response
    )

    private fun getUnauthorizedError(response: Response<*>) = YabraaError.E(
        exception = ResponseUnAuthorizedError(),
        logMessageEn = "Api request to url: ${response.raw().request.url}: failed with code ${response.code()}",
        extraData = response
    )


    companion object {
        const val REFRESH_TOKEN_NOT_FOUND = "SEC_RTNF"
    }
}