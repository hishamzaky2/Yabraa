package com.yabraa.medical.feature.fragments.allergies_and_chronic_diseases.current_medication_fragment.data.model.request

data class CurrentMedicationRequestDto(var medicationId: Long, var userFamilyId: Long)