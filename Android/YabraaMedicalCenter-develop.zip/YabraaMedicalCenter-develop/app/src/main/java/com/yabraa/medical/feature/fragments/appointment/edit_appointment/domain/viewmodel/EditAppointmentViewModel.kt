package com.yabraa.medical.feature.fragments.appointment.edit_appointment.domain.viewmodel

import androidx.lifecycle.ViewModel
import androidx.lifecycle.viewModelScope
import com.core.shared.state.State
import com.yabraa.medical.feature.fragments.appointment.edit_appointment.data.model.request.EditAppointmentRequestDto
import com.yabraa.medical.feature.fragments.appointment.edit_appointment.data.model.response.AppointmentResponseDto
import com.yabraa.medical.feature.fragments.appointment.edit_appointment.domain.repository.EditAppointmentRepository
import com.yabraa.medical.feature.fragments.appointment.edit_appointment.domain.usecase.GetAppointmentByIdUseCase
import dagger.hilt.android.lifecycle.HiltViewModel
import kotlinx.coroutines.flow.MutableSharedFlow
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.SharedFlow
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.launch
import javax.inject.Inject

@HiltViewModel
class EditAppointmentViewModel @Inject constructor(
    private val getAppointmentByIdUseCase: GetAppointmentByIdUseCase,
    private val editAppointmentRepository: EditAppointmentRepository
) : ViewModel() {

    private val _appointmentByIdResponseState = MutableStateFlow<State<AppointmentResponseDto>>(
        State.Initial())
    val appointmentByIdResponseState: StateFlow<State<AppointmentResponseDto>> =
        _appointmentByIdResponseState

    private val _editAppointmentResponseState = MutableSharedFlow<State<AppointmentResponseDto>>()
    val editAppointmentResponseState: SharedFlow<State<AppointmentResponseDto>> =
        _editAppointmentResponseState

    var appointmentNotes: String? = null

    fun getAppointmentById(appointmentId: Long) {
        viewModelScope.launch {
            _appointmentByIdResponseState.emit(State.Loading())
            getAppointmentByIdUseCase(appointmentId).collect {
                _appointmentByIdResponseState.emit(it)
            }
        }
    }

    fun getAppointmentResponse() = getAppointmentByIdUseCase.getAppointmentResponse()

    fun editAppointment(requestDto: EditAppointmentRequestDto) {
        viewModelScope.launch {
            _editAppointmentResponseState.emit(State.Loading())
            editAppointmentRepository.editAppointment(requestDto).collect {
                _editAppointmentResponseState.emit(it)
            }
        }
    }
}