package com.yabraa.medical.feature.fragments.package_details.presentation

import android.os.Build
import android.os.Bundle
import android.view.View
import androidx.hilt.navigation.fragment.hiltNavGraphViewModels
import androidx.navigation.fragment.findNavController
import com.yabraa.medical.R
import com.yabraa.medical.core.base_fragment.BaseFragment
import com.core.shared.utils.CommonUtils.getLocalizedValue
import com.core.shared.utils.CommonUtils.handleExpirationDate
import com.core.shared.utils.CommonUtils.load
import com.yabraa.medical.core.utils.custom_views.confirmation_appointment.ConfirmationAppointmentHandler
import com.yabraa.medical.core.utils.custom_views.yabraa_bar.YabraaBarHandler
import com.yabraa.medical.databinding.FragmentPackageDetailsBinding
import com.yabraa.medical.feature.fragments.common.domain.viewmodel.TransactionViewModel
import com.yabraa.medical.feature.fragments.filter.presentation.PACKAGE_ITEM
import com.yabraa.medical.feature.fragments.home.data.model.response.services_details_response.PackageData
import dagger.hilt.android.AndroidEntryPoint
import java.util.Locale

@AndroidEntryPoint
class PackageDetailsFragment : BaseFragment<FragmentPackageDetailsBinding>() {

    override val binding by lazy { FragmentPackageDetailsBinding.inflate(layoutInflater) }

    val viewModel: TransactionViewModel by hiltNavGraphViewModels(R.id.mainNavGraph)

    @Suppress("DEPRECATION")
    private val packageItem
        get() = run {
            if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.TIRAMISU) {
                arguments?.getSerializable(PACKAGE_ITEM, PackageData::class.java)
            } else {
                arguments?.getSerializable(PACKAGE_ITEM)
            }
        } as? PackageData

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        showExpirationDateError()
    }

    override fun onViewCreated(view: View, savedInstanceState: Bundle?) {
        super.onViewCreated(view, savedInstanceState)
        binding.setUpViews()
    }

    override fun onResume() {
        super.onResume()
        yabraaBarView?.setYabraaBarViews()
        showBottomNavigation(false)
    }

    private fun YabraaBarHandler.setYabraaBarViews() {
        val serviceNameTv = getLocalizedValue(packageItem?.nameEN, packageItem?.nameAR)
        setYabraaBarVisibility(true)
        serviceNameTv?.let { setBarTitle(it) }
        setOnBackArrowClicked()
        setClearAllVisibility(false)
    }

    private fun YabraaBarHandler.setOnBackArrowClicked() = setOnBackArrowClicked { navigateUp() }


    private fun FragmentPackageDetailsBinding.setUpViews() {
        setServicesImage()
        setServicesCrdView()
        setInstructionCardView()
        setServiceDescriptionCardView()
        confirmationView?.setConfirmationView()
    }

    private fun FragmentPackageDetailsBinding.setServicesImage() =
        packageItem?.imagePath?.let { servicesImageIv.load(requireActivity(), it) }

    private fun FragmentPackageDetailsBinding.setServicesCrdView() {
        serviceNameTv.text = getLocalizedValue(packageItem?.nameEN, packageItem?.nameAR)
        servicePriceTv.text =
            String.format(Locale.ENGLISH, R.string.price.localize(), packageItem?.price)
    }


    private fun FragmentPackageDetailsBinding.setInstructionCardView() {
        instructionDetailsTv.text =
            getLocalizedValue(packageItem?.instructionEN, packageItem?.instructionAR)
    }

    private fun FragmentPackageDetailsBinding.setServiceDescriptionCardView() {
        serviceDescriptionDetailsTv.text =
            getLocalizedValue(packageItem?.detailsEN, packageItem?.detailsAR)
    }


    private fun ConfirmationAppointmentHandler.setConfirmationView() {
        setConfirmationAppointmentVisibility(true)
        handleEnabledConfirmationAppointmentBtn()
        setOnConfirmationAppointmentClicked()
        handleEnabledCancelBtn()
        setOnCancelClicked()
    }

    private fun ConfirmationAppointmentHandler.handleEnabledConfirmationAppointmentBtn() {
        handleEnabledConfirmationAppointmentBtn(true)
        setTextConfirmationBtn(R.string.makeAnAppointmentInPackages)
        viewModel.addPackageItemsList.forEach {
            if (it.packageId == packageItem?.packageId) {
                setTextConfirmationBtn(R.string.thisPackageAlreadyAdded)
                handleEnabledConfirmationAppointmentBtn(false)
            }
        }
    }


    private fun ConfirmationAppointmentHandler.setOnConfirmationAppointmentClicked() {
        setOnConfirmationAppointmentClicked {
            showDelayProgressDialog { addPackageItem() }
        }
    }

    private fun addPackageItem() {
        packageItem?.let { viewModel.setPackageItemsList(it) }
        navigateUp()
    }


    private fun ConfirmationAppointmentHandler.handleEnabledCancelBtn() {
        handleEnabledCancelBtn(false)
        viewModel.addPackageItemsList.forEach {
            if (packageItem?.packageId == it.packageId) {
                handleEnabledCancelBtn(true)
            }
        }
    }

    private fun ConfirmationAppointmentHandler.setOnCancelClicked() {
        setTextCancelBtn(R.string.remove)
        setOnCancelClicked {
            packageItem?.let { handleRemoveItem(it) }
            navigateUp()
        }
    }

    private fun handleRemoveItem(packageData: PackageData) {
        viewModel.handleRemovePackageItem(packageData)
        viewModel.removePackageTransactionItem(packageData.packageId)
    }

    private fun navigateUp() = findNavController().navigateUp()

    private fun showExpirationDateError() =
        tokenHandler.handleExpirationDate { showExpirationDatePopupError() }
}