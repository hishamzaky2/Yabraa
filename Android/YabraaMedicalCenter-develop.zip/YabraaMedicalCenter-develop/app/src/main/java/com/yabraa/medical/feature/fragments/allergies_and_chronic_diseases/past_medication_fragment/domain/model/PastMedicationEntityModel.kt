package com.yabraa.medical.feature.fragments.allergies_and_chronic_diseases.past_medication_fragment.domain.model

data class PastMedicationEntityModel (
    val medicationId: Long,
    val titleAR: String,
    val titleEN: String,
    var isAdded : Boolean = false
)