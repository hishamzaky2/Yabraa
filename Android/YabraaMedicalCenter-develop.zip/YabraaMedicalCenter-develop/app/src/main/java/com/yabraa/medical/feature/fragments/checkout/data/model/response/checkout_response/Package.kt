package com.yabraa.medical.feature.fragments.checkout.data.model.response.checkout_response


import com.google.gson.annotations.SerializedName

data class Package(
    @SerializedName("dateTime")
    val dateTime: String,
    @SerializedName("notes")
    val notes: String,
    @SerializedName("packageId")
    val packageId: Int,
    @SerializedName("price")
    val price: Int,
    @SerializedName("userFamilyId")
    val userFamilyId: Int
)