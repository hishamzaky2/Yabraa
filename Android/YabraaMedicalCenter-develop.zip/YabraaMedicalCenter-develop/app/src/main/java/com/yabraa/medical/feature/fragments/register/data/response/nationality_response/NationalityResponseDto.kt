package com.yabraa.medical.feature.fragments.register.data.response.nationality_response


import com.google.gson.annotations.SerializedName

data class NationalityResponseDto(
    @SerializedName("data")
    val nationalityDataResponse: NationalityDataResponse,
    @SerializedName("errorMessageAr")
    val errorMessageAr: String? = null,
    @SerializedName("errorMessageEn")
    val errorMessageEn: String? = null,
    @SerializedName("statusCode")
    val statusCode: Int
)