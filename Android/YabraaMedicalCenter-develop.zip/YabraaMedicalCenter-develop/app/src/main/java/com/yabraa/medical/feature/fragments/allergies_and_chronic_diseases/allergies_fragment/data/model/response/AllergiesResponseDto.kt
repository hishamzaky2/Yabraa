package com.yabraa.medical.feature.fragments.allergies_and_chronic_diseases.allergies_fragment.data.model.response


import com.google.gson.annotations.SerializedName

data class AllergiesResponseDto(
    @SerializedName("data")
    val allergiesDataResponse: List<AllergiesDataResponse>,
    @SerializedName("errorMessageAr")
    val errorMessageAr: String? = null,
    @SerializedName("errorMessageEn")
    val errorMessageEn: String? = null,
    @SerializedName("statusCode")
    val statusCode: Int
)