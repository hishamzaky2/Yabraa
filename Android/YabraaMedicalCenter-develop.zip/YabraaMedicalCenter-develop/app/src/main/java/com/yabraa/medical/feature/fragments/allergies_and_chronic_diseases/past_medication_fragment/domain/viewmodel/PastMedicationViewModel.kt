package com.yabraa.medical.feature.fragments.allergies_and_chronic_diseases.past_medication_fragment.domain.viewmodel

import androidx.lifecycle.ViewModel
import androidx.lifecycle.viewModelScope
import com.core.shared.state.State
import com.yabraa.medical.feature.fragments.allergies_and_chronic_diseases.past_medication_fragment.data.model.request.PastMedicationRequestDto
import com.yabraa.medical.feature.fragments.allergies_and_chronic_diseases.past_medication_fragment.data.model.response.PastMedicationResponseDto
import com.yabraa.medical.feature.fragments.allergies_and_chronic_diseases.past_medication_fragment.domain.repository.AddPastMedicationRepository
import com.yabraa.medical.feature.fragments.allergies_and_chronic_diseases.past_medication_fragment.domain.repository.DeletePastMedicationRepository
import com.yabraa.medical.feature.fragments.allergies_and_chronic_diseases.past_medication_fragment.domain.usecase.PastMedicationUseCase
import dagger.hilt.android.lifecycle.HiltViewModel
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.launch
import javax.inject.Inject

@HiltViewModel
class PastMedicationViewModel @Inject constructor(
    private val pastMedicationUseCase: PastMedicationUseCase,
    private val addPastMedicationRepository: AddPastMedicationRepository,
    private val deletePastMedicationRepository: DeletePastMedicationRepository
) : ViewModel() {


    private val _pastMedicationResponseState =
        MutableStateFlow<State<PastMedicationResponseDto>>(State.Initial())
    val pastMedicationResponseState: StateFlow<State<PastMedicationResponseDto>> =
        _pastMedicationResponseState

    private val _pastMedicationByUserFamilyIdResponseState =
        MutableStateFlow<State<PastMedicationResponseDto>>(State.Initial())
    val pastMedicationByUserFamilyIdResponseState: StateFlow<State<PastMedicationResponseDto>> =
        _pastMedicationByUserFamilyIdResponseState

    private val _addPastMedicationResponseState =
        MutableStateFlow<State<PastMedicationResponseDto>>(State.Initial())
    val addPastMedicationResponseState: StateFlow<State<PastMedicationResponseDto>> =
        _addPastMedicationResponseState

    private val _deletePastMedicationResponseState =
        MutableStateFlow<State<PastMedicationResponseDto>>(State.Initial())
    val deletePastMedicationResponseState: StateFlow<State<PastMedicationResponseDto>> =
        _deletePastMedicationResponseState

    fun getPastMedication() {
        viewModelScope.launch {
            _pastMedicationResponseState.emit(State.Loading())
            pastMedicationUseCase().collect {
                _pastMedicationResponseState.emit(it)
            }
        }
    }


    fun getPastMedicationByUserFamilyId(userFamilyId: Long) {
        viewModelScope.launch {
            _pastMedicationByUserFamilyIdResponseState.emit(State.Loading())
            pastMedicationUseCase(userFamilyId).collect {
                _pastMedicationByUserFamilyIdResponseState.emit(it)
            }
        }
    }

    fun addPastMedication(requestDto: PastMedicationRequestDto) {
        viewModelScope.launch {
            _addPastMedicationResponseState.emit(State.Loading())
            addPastMedicationRepository.addPastMedication(requestDto).collect {
                _addPastMedicationResponseState.emit(it)
            }
        }
    }


    fun deletePastMedication(requestDto: PastMedicationRequestDto) {
        viewModelScope.launch {
            _deletePastMedicationResponseState.emit(State.Loading())
            deletePastMedicationRepository.deletePastMedication(requestDto).collect {
                _deletePastMedicationResponseState.emit(it)
            }
        }
    }

    fun getPastMedicationList() = pastMedicationUseCase.getPastMedicationList()

}