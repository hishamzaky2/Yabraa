package com.yabraa.medical.feature.fragments.history_payment.data.model


import com.google.gson.annotations.SerializedName

data class PackageItem(
    @SerializedName("packageNameAR")
    val packageNameAR: String,
    @SerializedName("packageNameEN")
    val packageNameEN: String,
    @SerializedName("price")
    val price: Double,
    @SerializedName("serviceAR")
    val serviceAR: String,
    @SerializedName("serviceEN")
    val serviceEN: String,
    @SerializedName("status")
    val status: String,
    @SerializedName("visitDT")
    val visitDT: String
)