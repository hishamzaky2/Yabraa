package com.yabraa.medical.feature.fragments.home.domain.usecase.services_type_usecase

import com.core.shared.state.State
import com.yabraa.medical.feature.fragments.home.data.model.response.service_type_response.ServiceTypeResponse
import com.yabraa.medical.feature.fragments.home.data.model.response.service_type_response.ServiceTypeResponseDto
import com.yabraa.medical.feature.fragments.home.domain.repository.service_type_repository.ServiceTypeRepository
import kotlinx.coroutines.async
import kotlinx.coroutines.flow.Flow
import kotlinx.coroutines.flow.channelFlow
import javax.inject.Inject

class ServiceTypeUseCase @Inject constructor(private val serviceTypeRepository: ServiceTypeRepository) {

    private var serviceTypeResponse: List<ServiceTypeResponse>? = null
    operator fun invoke(): Flow<State<ServiceTypeResponseDto>> {
        return channelFlow {
            val response = async { serviceTypeRepository.getServiceType() }
            response.await().collect {
                if (it is State.Success) {
                    serviceTypeResponse = it.data?.serviceTypeResponse
                }
                send(it)
            }
        }
    }

    fun getServiceTypeId(serviceName: String) =
        serviceTypeResponse?.filter { serviceName == it.name }?.map { it.serviceTypeId }
            ?.firstOrNull() ?: 0L
}