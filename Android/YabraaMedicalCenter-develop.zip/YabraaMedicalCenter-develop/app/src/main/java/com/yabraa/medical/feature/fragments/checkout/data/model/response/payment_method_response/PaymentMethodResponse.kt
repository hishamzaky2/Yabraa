package com.yabraa.medical.feature.fragments.checkout.data.model.response.payment_method_response


import com.google.gson.annotations.SerializedName

data class PaymentMethodResponse(
    @SerializedName("result")
    val paymentMethodItem: List<PaymentMethodItem>
)