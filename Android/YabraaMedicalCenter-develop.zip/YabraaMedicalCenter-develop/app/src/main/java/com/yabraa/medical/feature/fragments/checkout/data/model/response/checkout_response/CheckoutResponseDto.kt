package com.yabraa.medical.feature.fragments.checkout.data.model.response.checkout_response


import com.google.gson.annotations.SerializedName

data class CheckoutResponseDto(
    @SerializedName("data")
    val checkoutResponse: CheckoutResponse,
    @SerializedName("errorMessageAr")
    val errorMessageAr: String? = null,
    @SerializedName("errorMessageEn")
    val errorMessageEn: String? = null,
    @SerializedName("statusCode")
    val statusCode: Int
)