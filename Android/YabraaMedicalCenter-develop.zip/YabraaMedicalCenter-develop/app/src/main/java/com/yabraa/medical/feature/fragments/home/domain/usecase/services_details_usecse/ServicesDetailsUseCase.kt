package com.yabraa.medical.feature.fragments.home.domain.usecase.services_details_usecse

import kotlinx.coroutines.async
import kotlinx.coroutines.flow.Flow
import kotlinx.coroutines.flow.channelFlow
import com.core.shared.state.State
import com.core.shared.utils.CommonUtils.getLocalizedValue
import com.yabraa.medical.feature.fragments.home.data.model.response.services_details_response.PackageData
import com.yabraa.medical.feature.fragments.home.data.model.response.services_details_response.ServicesDetailsResponseDto
import com.yabraa.medical.feature.fragments.home.domain.repository.services_details_repository.ServicesDetailsRepository
import javax.inject.Inject

class ServicesDetailsUseCase @Inject constructor(private val servicesDetailsRepository: ServicesDetailsRepository) {


    private var responseDto: ServicesDetailsResponseDto? = null

    operator fun invoke(serviceTypeId: Long): Flow<State<ServicesDetailsResponseDto>> {
        return channelFlow {
            val userInputValidationResponse =
                async { servicesDetailsRepository.getServicesDetails(serviceTypeId) }
            userInputValidationResponse.await().collect {
                if (it is State.Success) {
                    responseDto = it.data
                }
                send(it)
            }
        }
    }

    fun getOneDimensionServices() =
        responseDto?.servicesDataResponse?.oneDimensionalService ?: emptyList()

    fun getOneDimensionServicesByName(searchInput : String) =
        responseDto?.servicesDataResponse?.oneDimensionalService?.filter {
            it.nameAR?.startsWith(searchInput,ignoreCase = true) == true ||
                    it.nameEN?.startsWith(searchInput ,ignoreCase = true) == true
        }  ?: emptyList()

    fun getServiceNameByServiceId(serviceId: Long) =
        responseDto?.servicesDataResponse?.oneDimensionalService?.filter { serviceId == it.serviceId }
            ?.map { getLocalizedValue(it.nameEN, it.nameAR) }?.last { !it.isNullOrEmpty() } ?: ""

    fun getServiceImagePathByServiceId(serviceId: Long) =
        responseDto?.servicesDataResponse?.oneDimensionalService?.filter { serviceId == it.serviceId }
            ?.map { it.imagePath }?.last { !it.isNullOrEmpty() } ?: ""

    fun getFilterByServicesId(serviceId: Long) =
        responseDto?.servicesDataResponse?.oneDimensionalService?.filter { serviceId == it.serviceId }
            ?.flatMap { it.filterData ?: emptyList() } ?: emptyList()


    private fun getPackageDataResponse(serviceId: Long) =
        responseDto?.servicesDataResponse?.oneDimensionalService?.flatMap {
            it.filterData ?: emptyList()
        }
            ?.flatMap { it.packageData ?: emptyList() }?.filter { serviceId == it.serviceId }

    fun getPackagesByFilterIds(serviceId: Long, filterIds: List<Long>?): MutableList<PackageData> {
        var packageData = mutableListOf<PackageData>()
        val responseData = getPackageDataResponse(serviceId)
        when {
            !filterIds.isNullOrEmpty() -> filterIds.forEach { ids ->
                getPackagesByFilterIds(ids, responseData, packageData)
            }

            else -> responseData?.toMutableList()?.let { packageData = it }
        }
        return packageData
    }

    private fun getPackagesByFilterIds(
        id: Long, responseData: List<PackageData>?, packageData: MutableList<PackageData>
    ) {
        responseData?.forEach {
            if (id == it.filterId) packageData.add(it)
        }
    }
}