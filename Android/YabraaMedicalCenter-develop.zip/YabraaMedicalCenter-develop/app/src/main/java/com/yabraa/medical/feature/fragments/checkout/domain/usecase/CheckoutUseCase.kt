package com.yabraa.medical.feature.fragments.checkout.domain.usecase

import com.core.shared.state.State
import com.yabraa.medical.feature.fragments.checkout.data.model.request.CheckoutRequestDto
import com.yabraa.medical.feature.fragments.checkout.data.model.response.checkout_response.CheckoutResponseDto
import com.yabraa.medical.feature.fragments.checkout.domain.repository.checkout_repository.CheckoutRepository
import kotlinx.coroutines.async
import kotlinx.coroutines.flow.Flow
import kotlinx.coroutines.flow.channelFlow
import javax.inject.Inject

class CheckoutUseCase @Inject constructor(private val checkoutRepository: CheckoutRepository) {

    private var checkoutResponseDto: CheckoutResponseDto? = null
    suspend operator fun invoke(checkoutRequestDto: CheckoutRequestDto): Flow<State<CheckoutResponseDto>> {
        return channelFlow {
            val requestDto = async { checkoutRepository.checkout(checkoutRequestDto) }
            requestDto.await().collect {
                if (it is State.Success) {
                    checkoutResponseDto = it.data
                }
                send(it)
            }
        }
    }


    fun getCheckoutId() = checkoutResponseDto?.checkoutResponse?.checkoutId ?: ""
}


