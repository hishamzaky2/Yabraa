package com.yabraa.medical.feature.fragments.allergies_and_chronic_diseases.chronic_diseases_fragment.domain.repository

import com.core.shared.state.State
import com.yabraa.medical.feature.fragments.allergies_and_chronic_diseases.chronic_diseases_fragment.data.model.response.ChronicDiseasesResponseDto
import kotlinx.coroutines.flow.Flow

interface ChronicDiseasesByUserFamilyIdRepository {
    suspend fun getChronicDiseasesByUserFamilyId(userFamilyId: Long): Flow<State<ChronicDiseasesResponseDto>>

}