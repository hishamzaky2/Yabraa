package com.yabraa.medical.feature.fragments.allergies_and_chronic_diseases.injuries_fragment.domain.repository

import com.core.shared.state.State
import com.yabraa.medical.feature.fragments.allergies_and_chronic_diseases.injuries_fragment.data.model.request.InjuriesRequestDto
import com.yabraa.medical.feature.fragments.allergies_and_chronic_diseases.injuries_fragment.data.model.response.InjuriesResponseDto
import kotlinx.coroutines.flow.Flow

interface AddInjuriesRepository {
    suspend fun addInjuries(requestDto: InjuriesRequestDto): Flow<State<InjuriesResponseDto>>
}