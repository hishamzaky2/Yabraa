package com.yabraa.medical.feature.fragments.login.data.model.request


data class LoginRequestDto(
    val password: String,
    val phoneNumber: String
)