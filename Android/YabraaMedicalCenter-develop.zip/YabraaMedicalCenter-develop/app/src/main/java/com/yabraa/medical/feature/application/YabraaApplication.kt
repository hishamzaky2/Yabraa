package com.yabraa.medical.feature.application

import android.content.ComponentName
import android.content.pm.PackageManager
import com.google.firebase.FirebaseApp
import com.google.firebase.ktx.Firebase
import com.google.firebase.messaging.ktx.messaging
import com.instacart.truetime.time.TrueTimeImpl
import com.core.shared.base_application.BaseApplication
import com.core.shared.crash_reporting.CrashReportingManager
import com.core.shared.crash_reporting.crash_reporting_key.YabraaCrashReportingKeys.YabraaGaugeKeys.TOKEN
import com.core.shared.crash_reporting.crash_reporting_tools.FirebaseCrashReportingTool
import com.yabraa.medical.core.firebase_cloud_messaging.MessagingService
import com.core.shared.token_utils.TokenHandler
import dagger.hilt.android.HiltAndroidApp
import javax.inject.Inject

@HiltAndroidApp
class YabraaApplication : BaseApplication() {

    @Inject
    lateinit var firebaseCrashReportingTool: FirebaseCrashReportingTool

    @Inject
    lateinit var tokenHandler: TokenHandler

    override fun onCreate() {
        super.onCreate()
        FirebaseApp.initializeApp(this)
        initFirebaseMassagingServices()
        enableMessagingServices()
        syncTrueTime()
    }


    private fun enableMessagingServices() {
        val componentName = ComponentName(applicationContext, MessagingService::class.java)
        applicationContext.packageManager.setComponentEnabledSetting(
            componentName,
            PackageManager.COMPONENT_ENABLED_STATE_ENABLED,
            PackageManager.DONT_KILL_APP
        )
    }

    private fun initFirebaseMassagingServices() {
        Firebase.messaging.isAutoInitEnabled = true
    }


    override fun addCrashReportingTools(crashReportingManager: CrashReportingManager?) {
        if (this::firebaseCrashReportingTool.isInitialized) return
        crashReportingManager?.registerCrashReportingTool(firebaseCrashReportingTool)
    }


    override fun getPreLogKeys() = listOf(TOKEN to tokenHandler.getToken())


    override fun getRemoteDebuggerPort() = 9091


    private fun syncTrueTime() = trueTime.sync()

    companion object {
        val trueTime = TrueTimeImpl()
    }

}