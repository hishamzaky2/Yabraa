package com.yabraa.medical.feature.fragments.forget_password.data.model.request

data class ForgetPasswordRequestDto(var phoneNumber: String)