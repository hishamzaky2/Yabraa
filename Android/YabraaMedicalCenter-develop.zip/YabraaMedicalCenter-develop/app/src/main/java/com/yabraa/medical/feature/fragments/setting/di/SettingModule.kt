package com.yabraa.medical.feature.fragments.setting.di

import com.yabraa.medical.core.di.network_sevices.YabraaServices
import com.yabraa.medical.feature.fragments.setting.data.repository.delete_account_repository.DeleteAccountRepositoryImpl
import com.yabraa.medical.feature.fragments.setting.data.repository.get_user_information_repository.GetUserInformationRepositoryImpl
import com.yabraa.medical.feature.fragments.setting.domain.repository.delete_account_repository.DeleteAccountRepository
import com.yabraa.medical.feature.fragments.setting.domain.repository.get_user_information_repository.GetUserInformationRepository
import dagger.Module
import dagger.Provides
import dagger.hilt.InstallIn
import dagger.hilt.android.components.ViewModelComponent

@Module
@InstallIn(ViewModelComponent::class)
object SettingModule {

    @Provides
    fun provideGetUserInformationRepository(yabraaServices: YabraaServices) : GetUserInformationRepository = GetUserInformationRepositoryImpl(yabraaServices)

    @Provides
    fun provideDeleteRepository(yabraaServices: YabraaServices) : DeleteAccountRepository = DeleteAccountRepositoryImpl(yabraaServices)
}