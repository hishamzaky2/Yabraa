package com.yabraa.medical.feature.fragments.checkout.data.model.request


import com.google.gson.annotations.SerializedName
import com.yabraa.medical.feature.fragments.checkout.domain.model.CheckoutPackagesUiModel
import java.math.BigDecimal

data class CheckoutRequestDto(
    @SerializedName("ServiceTypeId")
    val serviceTypeId: Long,
    @SerializedName("locationLongitude")
    val locationLongitude: Double? = null,
    @SerializedName("locationLatitude")
    val locationLatitude: Double? = null,
    @SerializedName("locationAltitude")
    val locationAltitude: Double? = null,
    @SerializedName("amount")
    val amount: BigDecimal,
    @SerializedName("currency")
    val currency: String = "SAR",
    @SerializedName("PaymentMethodId")
    val paymentMethodId: Long,
    @SerializedName("packages")
    val packages: MutableList<CheckoutPackagesUiModel>
)