package com.yabraa.medical.feature.fragments.notification.notification_hisotry.presentation

import android.annotation.SuppressLint
import android.os.Bundle
import android.view.View
import androidx.core.view.isVisible
import androidx.fragment.app.viewModels
import androidx.lifecycle.MutableLiveData
import androidx.lifecycle.lifecycleScope
import androidx.navigation.fragment.findNavController
import androidx.paging.CombinedLoadStates
import androidx.paging.LoadState
import androidx.recyclerview.widget.ConcatAdapter
import androidx.recyclerview.widget.DiffUtil
import androidx.recyclerview.widget.LinearLayoutManager
import com.yabraa.medical.R
import com.yabraa.medical.core.base_fragment.BaseFragment
import com.yabraa.medical.core.base_fragment.navigate
import com.yabraa.medical.core.base_fragment.setOnGoToConnectionSettingClicked
import com.core.shared.error.YabraaException
import com.core.shared.utils.CommonUtils.handleExpirationDate
import com.core.shared.utils.YabraaListStateAdapter
import com.yabraa.medical.core.utils.custom_views.yabraa_bar.YabraaBarHandler
import com.yabraa.medical.databinding.FragmentNotificationHistoryBinding
import com.yabraa.medical.feature.fragments.notification.notification_hisotry.data.model.response.notification_history_response.Notification
import com.yabraa.medical.feature.fragments.notification.notification_hisotry.domain.viemodel.NotificationViewModel
import com.yabraa.medical.feature.fragments.notification.notification_hisotry.presentation.adapter.NotificationHistoryAdapter
import dagger.hilt.android.AndroidEntryPoint
import kotlinx.coroutines.flow.collectLatest
import kotlinx.coroutines.launch

const val NOTIFICATION_INFO = "NOTIFICATION_INFO"

@AndroidEntryPoint
class NotificationHistoryFragment : BaseFragment<FragmentNotificationHistoryBinding>() {

    override val binding by lazy { FragmentNotificationHistoryBinding.inflate(layoutInflater) }
    private val viewModel: NotificationViewModel by viewModels()

    private var notificationHistoryCount = MutableLiveData<Boolean>()

    private val notificationPagingAdapter by lazy {
        NotificationHistoryAdapter(getNotificationItemDiffCallback()) {
            if (connectivityManager?.isNetworkConnected?.value == false) {
                showNetworkConnectionErrorPopup()
                return@NotificationHistoryAdapter
            }
            navigateToNotificationDetails(it)
        }
    }

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        showExpirationDateError()
    }


    override fun onViewCreated(view: View, savedInstanceState: Bundle?) {
        super.onViewCreated(view, savedInstanceState)
        binding.handleNetworkConnection()
        binding.setUpViews()
    }


    override fun onResume() {
        super.onResume()
        yabraaBarView?.setUpYabraaBarView()
        confirmationView?.setConfirmationAppointmentVisibility(false)
        showBottomNavigation(false)
    }

    private fun YabraaBarHandler.setUpYabraaBarView() {
        setYabraaBarVisibility(true)
        setClearAllVisibility(false)
        setBarTitle(R.string.notifications.localize())
        setOnBackArrowClicked { findNavController().popBackStack() }
    }


    private fun FragmentNotificationHistoryBinding.handleNetworkConnection() {
        connectivityManager?.isNetworkConnected?.observe(viewLifecycleOwner) {
            handleConnectionViewVisibility(it)
            handleEmptyStateWithInternetGroupVisibility(it)
            if (!it) return@observe
            lifecycleScope.launch { collectOnPaginatedNotificationsList() }
        }
    }

    private fun FragmentNotificationHistoryBinding.handleConnectionViewVisibility(isVisible: Boolean) {
        notificationRv.isVisible = isVisible
        internetConnection.root.isVisible = !isVisible
    }


    private fun navigateToNotificationDetails(notification: Notification) {
        if (!notification.isRead) viewModel.readNotification(notification.notificationId)
        val bundle = Bundle()
        bundle.putSerializable(NOTIFICATION_INFO, notification)
        navigate(R.id.actionNotificationHistoryFragmentToNotificationDetailsFragment, bundle)
    }

    private fun FragmentNotificationHistoryBinding.setUpViews() {
        internetConnection.goToSettingBtn.setOnGoToConnectionSettingClicked(requireActivity())
    }


    private suspend fun FragmentNotificationHistoryBinding.collectOnPaginatedNotificationsList() {
        setupNotificationRecyclerView()
        viewModel.getPaginatedNotification().collectLatest {
            notificationPagingAdapter.submitData(it)
        }
    }

    private fun FragmentNotificationHistoryBinding.setupNotificationRecyclerView() {
        notificationRv.layoutManager = LinearLayoutManager(requireContext())
        notificationRv.adapter = getConcatLoadingAdapter()
    }

    private fun getConcatLoadingAdapter(): ConcatAdapter {
        val footerAdapter =
            YabraaListStateAdapter(onLoadStateError = { handleLoadStateError(it) }) { notificationPagingAdapter.retry() }
        val headerAdapter =
            YabraaListStateAdapter(onLoadStateError = { handleLoadStateError(it) }) { notificationPagingAdapter.retry() }
        notificationPagingAdapter.addLoadStateListener { loadState ->
            headerAdapter.loadState = loadState.refresh
            footerAdapter.loadState = loadState.append
            handleNotificationHistoryEmptyState(loadState)
        }
        return ConcatAdapter(headerAdapter, notificationPagingAdapter, footerAdapter)
    }

    private fun handleLoadStateError(loadState: LoadState.Error) =
        (loadState.error as? YabraaException)?.yabraaError?.handleError { }

    private fun getNotificationItemDiffCallback() = object : DiffUtil.ItemCallback<Notification>() {
        override fun areItemsTheSame(
            oldItem: Notification,
            newItem: Notification
        ) = oldItem.notificationId == newItem.notificationId


        override fun areContentsTheSame(
            oldItem: Notification,
            newItem: Notification
        ) = oldItem == newItem
    }

    private fun handleNotificationHistoryEmptyState(loadState: CombinedLoadStates) {
        if (!loadState.append.endOfPaginationReached) return
        val isHasItemCount = notificationPagingAdapter.itemCount > 0
        binding.handleEmptyStateVisibility(isHasItemCount)
        notificationHistoryCount.postValue(!isHasItemCount)
    }

    private fun FragmentNotificationHistoryBinding.handleEmptyStateVisibility(isVisible: Boolean) {
        notificationRv.isVisible = isVisible
        noNotificationGroup.isVisible = !isVisible
    }

    @SuppressLint("FragmentLiveDataObserve")
    private fun FragmentNotificationHistoryBinding.handleEmptyStateWithInternetGroupVisibility(
        isVisible: Boolean
    ) {
        notificationHistoryCount.observe(this@NotificationHistoryFragment) { isHasItemCount ->
            if (!isHasItemCount) return@observe
            notificationRv.isVisible = !isVisible
            noNotificationGroup.isVisible = isVisible
        }
    }


    private fun showExpirationDateError() =
        tokenHandler.handleExpirationDate { showExpirationDatePopupError() }
}