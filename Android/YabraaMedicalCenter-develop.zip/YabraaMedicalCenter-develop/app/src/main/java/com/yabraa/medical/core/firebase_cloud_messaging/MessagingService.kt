package com.yabraa.medical.core.firebase_cloud_messaging


import android.app.NotificationChannel
import android.app.NotificationManager
import android.app.NotificationManager.IMPORTANCE_DEFAULT
import android.app.PendingIntent
import android.media.RingtoneManager
import android.os.Build
import androidx.core.app.NotificationCompat
import androidx.navigation.NavDeepLinkBuilder
import com.google.firebase.messaging.FirebaseMessagingService
import com.google.firebase.messaging.RemoteMessage
import com.yabraa.medical.R
import com.core.shared.utils.CommonUtils.getLocalizedValue


const val CHANNEL_ID = "YABRAA_MEDICAL_CENTER"
const val CHANNEL_NAME = "Yabraa Medical Center"

const val TITLE_EN = "titleEn"
const val TITLE_AR = "titleAr"
const val BODY_EN = "bodyEn"
const val BODY_AR = "bodyAr"

class MessagingService : FirebaseMessagingService() {

    override fun onMessageReceived(remoteMessage: RemoteMessage) {
        val titleEn = remoteMessage.data[TITLE_EN]
        val titleAr = remoteMessage.data[TITLE_AR]
        val bodyEn = remoteMessage.data[BODY_EN]
        val bodyAr = remoteMessage.data[BODY_AR]
        val title = getLocalizedValue(titleEn, titleAr)
        val body = getLocalizedValue(bodyEn, bodyAr)
        sendNotification(title, body)
    }

    private fun sendNotification(title: String?, body: String?) {
        val defaultSoundUri = RingtoneManager.getDefaultUri(RingtoneManager.TYPE_NOTIFICATION)
        val notificationBuilder =
            NotificationCompat.Builder(this, CHANNEL_ID)
                .setSmallIcon(R.mipmap.ic_launcher)
                .setContentTitle(title).setContentText(body)
                .setAutoCancel(true)
                .setSound(defaultSoundUri)
                .setContentIntent(getPendingIntent())

        val notificationManager = getSystemService(NOTIFICATION_SERVICE) as NotificationManager
        createNotificationChannel(notificationManager)
        notificationManager.notify(0 /* ID of notification */, notificationBuilder.build())
    }

    private fun createNotificationChannel(notificationManager: NotificationManager) {
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) {
            val channel = NotificationChannel(CHANNEL_ID, CHANNEL_NAME, IMPORTANCE_DEFAULT)
            notificationManager.createNotificationChannel(channel)
        }
    }

    private fun getPendingIntent(): PendingIntent {
        return NavDeepLinkBuilder(this)
            .setGraph(R.navigation.main_graph)
            .setDestination(R.id.notificationHistoryFragment)
            .createPendingIntent()
    }

    override fun onNewToken(token: String) {
        //TODO NO NEED HANDLE REQUEST HERE
    }
}