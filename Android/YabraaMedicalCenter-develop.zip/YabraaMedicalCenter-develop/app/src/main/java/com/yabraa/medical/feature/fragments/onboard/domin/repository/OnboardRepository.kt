package com.yabraa.medical.feature.fragments.onboard.domin.repository

import kotlinx.coroutines.flow.Flow
import com.core.shared.state.State
import com.yabraa.medical.feature.fragments.onboard.data.response.OnboardPagesResponseDto

interface OnboardRepository {
    suspend fun getOnboardPages(): Flow<State<OnboardPagesResponseDto>>
}