package com.yabraa.medical.feature.fragments.onboard.presentation

import android.os.Bundle
import android.view.View
import androidx.fragment.app.Fragment
import androidx.hilt.navigation.fragment.hiltNavGraphViewModels
import dagger.hilt.android.AndroidEntryPoint
import com.yabraa.medical.R
import com.yabraa.medical.core.base_fragment.BaseFragment
import com.yabraa.medical.databinding.FragmentViewPagerBinding
import com.yabraa.medical.feature.activits.mainactivity.MainActivity
import com.yabraa.medical.feature.fragments.common.domain.viewmodel.OnboardViewModel
import com.yabraa.medical.feature.fragments.onboard.presentation.adapter.ViewPagerAdapter

@AndroidEntryPoint
class ViewPagerFragment : BaseFragment<FragmentViewPagerBinding>() {

    override val binding by lazy { FragmentViewPagerBinding.inflate(layoutInflater) }
    private val viewPagerAdapter by lazy {
        val fragmentManager = (activity as MainActivity).getCurrentFragment()?.childFragmentManager
        fragmentManager?.let { ViewPagerAdapter(listOfOnboardFragments(), it, lifecycle) }
    }

    private val viewModel: OnboardViewModel by hiltNavGraphViewModels(R.id.nav_graph)

    override fun onViewCreated(view: View, savedInstanceState: Bundle?) {
        super.onViewCreated(view, savedInstanceState)
        viewModel.getOnboardPages()
        binding.setUpViews()

    }

    private fun FragmentViewPagerBinding.setUpViews() {
        setUpViewPagerAdapter()
    }

    private fun FragmentViewPagerBinding.setUpViewPagerAdapter() {
        viewPager.adapter = viewPagerAdapter
    }

    private fun listOfOnboardFragments() = arrayListOf<Fragment>(
        FirstOnboardFragment(), SecondOnboardFragment(), ThirdOnboardFragment()
    )
}