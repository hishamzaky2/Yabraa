package com.yabraa.medical.feature.fragments.allergies_and_chronic_diseases.past_medication_fragment.data.model.request

data class PastMedicationRequestDto(var medicationId: Long, var userFamilyId: Long)