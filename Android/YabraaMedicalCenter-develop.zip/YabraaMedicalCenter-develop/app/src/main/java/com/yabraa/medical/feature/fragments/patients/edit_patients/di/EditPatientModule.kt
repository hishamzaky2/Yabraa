package com.yabraa.medical.feature.fragments.patients.edit_patients.di

import com.yabraa.medical.core.di.network_sevices.YabraaServices
import com.yabraa.medical.feature.fragments.patients.edit_patients.data.repsitory.delete_patient_repository.DeletePatientRepositoryImpl
import com.yabraa.medical.feature.fragments.patients.edit_patients.data.repsitory.edit_patient_repository.EditPatientRepositoryImpl
import com.yabraa.medical.feature.fragments.patients.edit_patients.domain.repository.delete_patient_repository.DeletePatientRepository
import com.yabraa.medical.feature.fragments.patients.edit_patients.domain.repository.edit_patient_repository.EditPatientRepository
import dagger.Module
import dagger.Provides
import dagger.hilt.InstallIn
import dagger.hilt.android.components.ViewModelComponent


@Module
@InstallIn(ViewModelComponent::class)
object EditPatientModule {

    @Provides
    fun provideEditPatientRepository(yabraaServices: YabraaServices): EditPatientRepository =
        EditPatientRepositoryImpl(yabraaServices)


    @Provides
    fun provideDeletePatientRepository(yabraaServices: YabraaServices) : DeletePatientRepository = DeletePatientRepositoryImpl(yabraaServices)
}