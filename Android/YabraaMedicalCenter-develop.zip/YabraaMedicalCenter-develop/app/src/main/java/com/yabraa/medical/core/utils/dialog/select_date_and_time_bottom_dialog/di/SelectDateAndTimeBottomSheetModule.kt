package com.yabraa.medical.core.utils.dialog.select_date_and_time_bottom_dialog.di

import android.app.Activity
import dagger.Module
import dagger.Provides
import dagger.hilt.InstallIn
import dagger.hilt.android.components.ActivityComponent
import com.yabraa.medical.core.utils.dialog.select_date_and_time_bottom_dialog.SelectDateAndTimeBottomSheet

@Module
@InstallIn(ActivityComponent::class)
class SelectDateAndTimeBottomSheetModule {

    @Provides
    fun provideSelectDateAndTimeBottomSheet(activity: Activity) =
        SelectDateAndTimeBottomSheet(activity)
}