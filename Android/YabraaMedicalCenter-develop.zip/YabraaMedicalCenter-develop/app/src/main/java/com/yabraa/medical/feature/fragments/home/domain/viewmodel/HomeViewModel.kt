package com.yabraa.medical.feature.fragments.home.domain.viewmodel

import androidx.lifecycle.ViewModel
import androidx.lifecycle.viewModelScope
import com.core.shared.state.State
import com.yabraa.medical.feature.fragments.home.data.model.response.gallery_response.GalleryResponseDto
import com.yabraa.medical.feature.fragments.home.data.model.response.service_type_response.ServiceTypeResponseDto
import com.yabraa.medical.feature.fragments.home.domain.usecase.gallery_usecase.GalleryUseCase
import com.yabraa.medical.feature.fragments.home.domain.usecase.notification_status_usecase.NotificationStatusUseCase
import com.yabraa.medical.feature.fragments.home.domain.usecase.services_type_usecase.ServiceTypeUseCase
import com.yabraa.medical.feature.fragments.notification.notification_hisotry.data.model.request.notification_history_request.NotificationHistoryRequestDto
import com.yabraa.medical.feature.fragments.notification.notification_hisotry.data.model.response.notification_history_response.NotificationHistoryResponseDto
import dagger.hilt.android.lifecycle.HiltViewModel
import kotlinx.coroutines.flow.MutableSharedFlow
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.SharedFlow
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.launch
import javax.inject.Inject

@HiltViewModel
class HomeViewModel @Inject constructor(
    private val galleryUseCase: GalleryUseCase,
    private val serviceTypeUseCase: ServiceTypeUseCase,
    private val notificationStatusUseCase: NotificationStatusUseCase
) :
    ViewModel() {

    private val _galleryResponseStat = MutableStateFlow<State<GalleryResponseDto>>(State.Initial())
    val galleryResponseState: StateFlow<State<GalleryResponseDto>> = _galleryResponseStat

    private val _serviceTypeResponseState =
        MutableStateFlow<State<ServiceTypeResponseDto>>(State.Initial())
    val serviceTypeResponseState: StateFlow<State<ServiceTypeResponseDto>> =
        _serviceTypeResponseState


    private val _notificationStatusResponse =
        MutableSharedFlow<State<NotificationHistoryResponseDto>>()
    val notificationStatusResponse: SharedFlow<State<NotificationHistoryResponseDto>> =
        _notificationStatusResponse


    fun getGallery() {
        viewModelScope.launch {
            _galleryResponseStat.emit(State.Loading())
            galleryUseCase().collect {
                _galleryResponseStat.emit(it)
            }
        }
    }

    fun getServiceType() {
        viewModelScope.launch {
            _serviceTypeResponseState.emit(State.Loading())
            serviceTypeUseCase().collect {
                _serviceTypeResponseState.emit(it)
            }
        }
    }

    fun getServiceTypeId(serviceName: String) = serviceTypeUseCase.getServiceTypeId(serviceName)


    fun getNotificationStatus(requestDto: NotificationHistoryRequestDto) {
        viewModelScope.launch {
            _notificationStatusResponse.emit(State.Loading())
            notificationStatusUseCase(requestDto).collect {
                _notificationStatusResponse.emit(it)
            }
        }
    }

    fun isReadAllNotification() = notificationStatusUseCase.isReadAllNotification()
}