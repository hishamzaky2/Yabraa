package com.yabraa.medical.feature.fragments.allergies_and_chronic_diseases.select_allergies_and_chronic_diseases_fragment.presentation

import android.os.Bundle
import android.view.View
import androidx.core.os.bundleOf
import androidx.hilt.navigation.fragment.hiltNavGraphViewModels
import androidx.navigation.fragment.findNavController
import com.yabraa.medical.R
import com.yabraa.medical.core.base_fragment.BaseFragment
import com.yabraa.medical.core.base_fragment.navigate
import com.core.shared.utils.CommonUtils.handleExpirationDate
import com.yabraa.medical.core.utils.custom_views.yabraa_bar.YabraaBarHandler
import com.yabraa.medical.databinding.FragmentSelectAllergiesAndChronicDiseasesBinding
import com.yabraa.medical.feature.fragments.setting.domain.viewmodel.SettingViewModel
import dagger.hilt.android.AndroidEntryPoint

const val USER_FAMILY_ID = "USER_FAMILY_ID"

@AndroidEntryPoint
class SelectAllergiesAndChronicDiseasesFragment :
    BaseFragment<FragmentSelectAllergiesAndChronicDiseasesBinding>() {

    override val binding by lazy {
        FragmentSelectAllergiesAndChronicDiseasesBinding.inflate(
            layoutInflater
        )
    }

    private val settingViewModel: SettingViewModel by hiltNavGraphViewModels(R.id.setting_graph)

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        showExpirationDateError()
    }


    override fun onViewCreated(view: View, savedInstanceState: Bundle?) {
        super.onViewCreated(view, savedInstanceState)
        binding.setUpViews()
    }

    override fun onResume() {
        super.onResume()
        yabraaBarView?.setUpYabraaBarView()
        confirmationView?.setConfirmationAppointmentVisibility(false)
        showBottomNavigation(false)
    }

    private fun YabraaBarHandler.setUpYabraaBarView() {
        setYabraaBarVisibility(true)
        setClearAllVisibility(false)
        setBarTitle(R.string.medicalProfile.localize())
        setOnBackArrowClicked { findNavController().popBackStack() }
    }


    private fun FragmentSelectAllergiesAndChronicDiseasesBinding.setUpViews() {
        setOnAllergiesClicked()
        setOnChronicDiseasesClicked()
        setOnCurrentMedicationClicked()
        setOnInjuries()
        setOnPastMedicationClicked()
        setOnSurgeriesClicked()
    }

    private fun FragmentSelectAllergiesAndChronicDiseasesBinding.setOnAllergiesClicked() {
        allergiesCV.setOnClickListener {
            navigateToNextScreen(R.id.actionSelectAllergiesAndChronicDiseasesFragmentToAllergiesFragment)
        }
    }

    private fun FragmentSelectAllergiesAndChronicDiseasesBinding.setOnChronicDiseasesClicked() {
        chronicDiseasesCV.setOnClickListener {
            navigateToNextScreen(R.id.actionSelectAllergiesAndChronicDiseasesFragmenttoChronicDiseasesFragmentFragment)
        }
    }

    private fun FragmentSelectAllergiesAndChronicDiseasesBinding.setOnCurrentMedicationClicked() {
        currentMedicationCV.setOnClickListener {
            navigateToNextScreen(R.id.actionSelectAllergiesAndChronicDiseasesFragmentToCurrentMedicationFragment)
        }
    }

    private fun FragmentSelectAllergiesAndChronicDiseasesBinding.setOnInjuries() {
        injuriesCV.setOnClickListener {
            navigateToNextScreen(R.id.actionSelectAllergiesAndChronicDiseasesFragmentToInjuriesFragment)
        }
    }

    private fun FragmentSelectAllergiesAndChronicDiseasesBinding.setOnPastMedicationClicked() {
        pastMedicationCV.setOnClickListener {
            navigateToNextScreen(R.id.actionSelectAllergiesAndChronicDiseasesFragmentToPastMedicationFragment)
        }
    }

    private fun FragmentSelectAllergiesAndChronicDiseasesBinding.setOnSurgeriesClicked() {
        surgeriesCV.setOnClickListener {
            navigateToNextScreen(R.id.actionSelectAllergiesAndChronicDiseasesFragmentToSurgeriesFragment)
        }
    }

    private fun navigateToNextScreen(direction: Int) {
        val bundle = bundleOf(USER_FAMILY_ID to settingViewModel.userFamilyId)
        showDelayProgressDialog { navigate(direction, bundle) }
    }

    private fun showExpirationDateError() =
        tokenHandler.handleExpirationDate { showExpirationDatePopupError() }
}