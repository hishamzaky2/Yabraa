package com.yabraa.medical.feature.fragments.login.data.model.response

import com.google.gson.annotations.SerializedName


data class LoginResponseDto(
    @SerializedName("data")
    val loginData: LoginDataResponse,
    @SerializedName("errorMessageAr")
    val errorMessageAr: String? = null,
    @SerializedName("errorMessageEn")
    val errorMessageEn: String? = null,
    @SerializedName("statusCode")
    val statusCode: Int
)