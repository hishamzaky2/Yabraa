package com.yabraa.medical.feature.fragments.patients.edit_patients.data.model.response.edit_patient_response


import com.google.gson.annotations.SerializedName

data class EditPatientResponse(
    @SerializedName("birthDate")
    val birthDate: String,
    @SerializedName("gender")
    val gender: String,
    @SerializedName("name")
    val name: String,
    @SerializedName("userFamilyId")
    val userFamilyId: Int
)