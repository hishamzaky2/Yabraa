package com.yabraa.medical.feature.fragments.appointment.my_appointment_details.data.model


import com.google.gson.annotations.SerializedName

data class MyAppointmentDetailsResponseDto(
    @SerializedName("data")
    val myAppointmentDetailsResponse: MyAppointmentDetailsResponse,
    @SerializedName("errorMessageAr")
    val errorMessageAr: String? = null,
    @SerializedName("errorMessageEn")
    val errorMessageEn: String? = null,
    @SerializedName("statusCode")
    val statusCode: Int
)