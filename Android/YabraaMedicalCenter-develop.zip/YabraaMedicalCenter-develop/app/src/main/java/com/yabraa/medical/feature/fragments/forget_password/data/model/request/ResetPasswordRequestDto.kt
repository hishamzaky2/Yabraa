package com.yabraa.medical.feature.fragments.forget_password.data.model.request

data class ResetPasswordRequestDto(
    var phoneNumber: String,
    var token: String,
    var verificationCode: String,
    var password: String,
    var confirmPassword: String
)