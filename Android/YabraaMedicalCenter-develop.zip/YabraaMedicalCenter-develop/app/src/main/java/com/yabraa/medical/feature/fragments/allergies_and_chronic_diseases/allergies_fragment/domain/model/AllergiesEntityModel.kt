package com.yabraa.medical.feature.fragments.allergies_and_chronic_diseases.allergies_fragment.domain.model

data class AllergiesEntityModel (
    val allergyId: Long,
    val titleAR: String,
    val titleEN: String,
    var isAdded : Boolean = false
)