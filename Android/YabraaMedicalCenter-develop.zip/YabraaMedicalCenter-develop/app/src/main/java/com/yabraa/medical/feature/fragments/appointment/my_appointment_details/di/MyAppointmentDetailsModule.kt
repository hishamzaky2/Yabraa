package com.yabraa.medical.feature.fragments.appointment.my_appointment_details.di

import com.yabraa.medical.core.di.network_sevices.YabraaServices
import com.yabraa.medical.feature.fragments.appointment.my_appointment_details.data.repository.MyAppointmentDetailsRepositoryImpl
import com.yabraa.medical.feature.fragments.appointment.my_appointment_details.domain.repository.MyAppointmentDetailsRepository
import dagger.Module
import dagger.Provides
import dagger.hilt.InstallIn
import dagger.hilt.android.components.ViewModelComponent

@Module
@InstallIn(ViewModelComponent::class)
object MyAppointmentDetailsModule {

    @Provides
    fun provideMyAppointmentDetailsRepository(yabraaServices: YabraaServices): MyAppointmentDetailsRepository =
        MyAppointmentDetailsRepositoryImpl(yabraaServices)
}