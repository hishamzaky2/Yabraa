package com.yabraa.medical.feature.fragments.allergies_and_chronic_diseases.injuries_fragment.presentation

import android.os.Bundle
import android.view.View
import androidx.core.view.isVisible
import androidx.fragment.app.viewModels
import androidx.lifecycle.lifecycleScope
import androidx.navigation.fragment.findNavController
import com.yabraa.medical.R
import com.yabraa.medical.core.base_fragment.BaseFragment
import com.core.shared.error.OperationMessage
import com.core.shared.error.YabraaError
import com.core.shared.state.State
import com.core.shared.utils.CommonUtils.handleExpirationDate
import com.yabraa.medical.core.utils.custom_views.yabraa_bar.YabraaBarHandler
import com.yabraa.medical.core.utils.dialog.yabraa_dialog.YabraaDialogBuilder
import com.yabraa.medical.core.utils.getErrorMessage
import com.yabraa.medical.databinding.FragmentGeneralAllergiesAndChronicDiseasesBinding
import com.yabraa.medical.feature.fragments.allergies_and_chronic_diseases.injuries_fragment.data.model.request.InjuriesRequestDto
import com.yabraa.medical.feature.fragments.allergies_and_chronic_diseases.injuries_fragment.domain.viewmodel.InjuriesViewModel
import com.yabraa.medical.feature.fragments.allergies_and_chronic_diseases.injuries_fragment.presentation.adapter.InjuriesAdapter
import com.yabraa.medical.feature.fragments.allergies_and_chronic_diseases.select_patient_fragment.presentation.USER_FAMILY_ID
import com.yabraa.medical.feature.fragments.common.domain.model.ErrorMessageUi
import dagger.hilt.android.AndroidEntryPoint
import kotlinx.coroutines.launch

@AndroidEntryPoint
class InjuriesFragment : BaseFragment<FragmentGeneralAllergiesAndChronicDiseasesBinding>() {

    override val binding by lazy {
        FragmentGeneralAllergiesAndChronicDiseasesBinding.inflate(
            layoutInflater
        )
    }

    private val viewModel: InjuriesViewModel by viewModels()
    lateinit var adapter: InjuriesAdapter
    private val userFamilyId get() = arguments?.getLong(USER_FAMILY_ID) ?: 0L


    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        showExpirationDateError()
    }


    override fun onViewCreated(view: View, savedInstanceState: Bundle?) {
        super.onViewCreated(view, savedInstanceState)
        handleInternetConnection()
        lifecycleScope.apply {
            launch { collectOnInjuriesResponseState() }
            launch { collectOnAddInjuriesResponseState() }
            launch { collectOnDeleteInjuriesResponseState() }
        }
    }

    override fun onResume() {
        super.onResume()
        yabraaBarView?.setUpYabraaBarView()
        confirmationView?.setConfirmationAppointmentVisibility(false)
        showBottomNavigation(false)
    }

    private fun YabraaBarHandler.setUpYabraaBarView() {
        setYabraaBarVisibility(true)
        setClearAllVisibility(false)
        setBarTitle(R.string.injuries.localize())
        setOnBackArrowClicked { findNavController().popBackStack() }
    }

    private fun handleInternetConnection() {
        connectivityManager?.isNetworkConnected?.observe(viewLifecycleOwner) {
            binding.handleConnectionViewVisibility(it)
            if (!it) return@observe
            handelInjuriesRequest()
        }
    }

    private fun FragmentGeneralAllergiesAndChronicDiseasesBinding.handleConnectionViewVisibility(
        isVisible: Boolean
    ) {
        generalRv.isVisible = isVisible
        internetConnection.root.isVisible = !isVisible
    }

    private suspend fun collectOnInjuriesResponseState() {
        viewModel.injuriesResponseState.collect {
            hideProgressDialog()
            when (it) {
                is State.Error -> it.error.handleHomeResponseError()
                is State.Initial -> {}
                is State.Loading -> showProgressDialog()
                is State.Success -> collectOnChronicDiseasesByUserFamilyIdState()
            }
        }
    }

    private suspend fun collectOnChronicDiseasesByUserFamilyIdState() {
        viewModel.injuriesByUserFamilyIdResponseState.collect {
            hideProgressDialog()
            when (it) {
                is State.Error -> it.error.handleHomeResponseError()
                is State.Initial -> {}
                is State.Loading -> showProgressDialog()
                is State.Success -> binding.setUpAdapter()
            }
        }
    }

    private fun FragmentGeneralAllergiesAndChronicDiseasesBinding.setUpAdapter() {
        val chronicDiseases = viewModel.getInjuriesList()
        adapter = InjuriesAdapter(
            chronicDiseases,
            onAddItemClicked = { id ->
                viewModel.addInjuries(InjuriesRequestDto(id, userFamilyId))
            }) { id ->
            viewModel.deleteInjuries(InjuriesRequestDto(id, userFamilyId))
        }
        generalRv.adapter = adapter
    }

    private suspend fun collectOnAddInjuriesResponseState() {
        viewModel.addInjuriesResponseState.collect {
            hideProgressDialog()
            when (it) {
                is State.Error -> it.error.handleHomeResponseError()
                is State.Initial -> {}
                is State.Loading -> showProgressDialog()
                is State.Success -> handelInjuriesRequest()
            }
        }
    }

    private suspend fun collectOnDeleteInjuriesResponseState() {
        viewModel.deleteInjuriesResponseState.collect {
            hideProgressDialog()
            when (it) {
                is State.Error -> it.error.handleHomeResponseError()
                is State.Initial -> {}
                is State.Loading -> showProgressDialog()
                is State.Success -> handelInjuriesRequest()
            }
        }
    }

    private fun handelInjuriesRequest() {
        viewModel.getInjuries()
        viewModel.getInjuriesByUserFamilyId(userFamilyId)
    }

    private fun YabraaError.handleHomeResponseError() {
        val errorMessageUi = ErrorMessageUi(logMessageEn, logMessageAr)
        handleError {
            when (exception) {
                is OperationMessage -> showHomeResponseErrorPopup(errorMessageUi)
            }
        }
    }

    private fun showHomeResponseErrorPopup(errorMessageUi: ErrorMessageUi) {
        val errorMessage = getErrorMessage(errorMessageUi)
        YabraaDialogBuilder(requireActivity())
            .setIcon(R.drawable.ic_vector_error)
            .setTitle(R.string.warning)
            .setMessage(errorMessage)
            .setTopButton(R.string.ok) {}
            .setCancelable(false)
            .show()
    }

    private fun showExpirationDateError() =
        tokenHandler.handleExpirationDate { showExpirationDatePopupError() }
}