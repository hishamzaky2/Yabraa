package com.yabraa.medical.feature.fragments.checkout.domain.viewmodel

import androidx.lifecycle.ViewModel
import androidx.lifecycle.viewModelScope
import com.core.shared.state.State
import com.yabraa.medical.feature.fragments.checkout.data.model.request.CheckoutRequestDto
import com.yabraa.medical.feature.fragments.checkout.data.model.request.PaymentRequestDto
import com.yabraa.medical.feature.fragments.checkout.data.model.response.checkout_response.CheckoutResponseDto
import com.yabraa.medical.feature.fragments.checkout.data.model.response.payment_method_response.PaymentMethodResponseDto
import com.yabraa.medical.feature.fragments.checkout.data.model.response.payment_response.PaymentResponseDto
import com.yabraa.medical.feature.fragments.checkout.domain.usecase.CheckoutUseCase
import com.yabraa.medical.feature.fragments.checkout.domain.usecase.CompletePaymentUseCase
import com.yabraa.medical.feature.fragments.checkout.domain.usecase.PaymentMethodUseCase
import dagger.hilt.android.lifecycle.HiltViewModel
import kotlinx.coroutines.flow.MutableSharedFlow
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.SharedFlow
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.launch
import javax.inject.Inject

@HiltViewModel
class CheckoutViewModel @Inject constructor(
    private val paymentMethodUseCase: PaymentMethodUseCase,
    private val checkoutUseCase: CheckoutUseCase,
    private val completePaymentUseCase: CompletePaymentUseCase
) : ViewModel() {

    private val _paymentMethodResponseState =
        MutableStateFlow<State<PaymentMethodResponseDto>>(State.Initial())
    val paymentMethodResponseState: StateFlow<State<PaymentMethodResponseDto>> =
        _paymentMethodResponseState

    private val _checkoutResponseState = MutableSharedFlow<State<CheckoutResponseDto>>()
    val checkoutResponseState: SharedFlow<State<CheckoutResponseDto>> = _checkoutResponseState

    private val _completePaymentState = MutableSharedFlow<State<PaymentResponseDto>>()
    val completePaymentState: SharedFlow<State<PaymentResponseDto>> = _completePaymentState

    fun getPaymentMethod() {
        viewModelScope.launch {
            _paymentMethodResponseState.emit(State.Loading())
            paymentMethodUseCase().collect {
                _paymentMethodResponseState.emit(it)
            }
        }
    }


    fun checkout(checkoutRequestDto: CheckoutRequestDto) {
        viewModelScope.launch {
            _checkoutResponseState.emit(State.Loading())
            checkoutUseCase(checkoutRequestDto).collect {
                _checkoutResponseState.emit(it)
            }
        }
    }

    fun completePayment(paymentRequestDto: PaymentRequestDto) {
        viewModelScope.launch {
            _completePaymentState.emit(State.Loading())
            completePaymentUseCase(paymentRequestDto).collect {
                _completePaymentState.emit(it)
            }

        }
    }

    fun getPaymentMethodsList() = paymentMethodUseCase.getPaymentMethodsList()

    fun getCheckoutId() = checkoutUseCase.getCheckoutId()


}