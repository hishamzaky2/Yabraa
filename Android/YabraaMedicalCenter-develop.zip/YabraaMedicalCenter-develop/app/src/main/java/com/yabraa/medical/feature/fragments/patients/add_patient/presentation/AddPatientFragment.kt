package com.yabraa.medical.feature.fragments.patients.add_patient.presentation

import android.annotation.SuppressLint
import android.os.Bundle
import android.view.View
import androidx.annotation.StringRes
import androidx.core.content.ContextCompat
import androidx.fragment.app.viewModels
import androidx.lifecycle.lifecycleScope
import androidx.navigation.fragment.findNavController
import com.yabraa.medical.R
import com.yabraa.medical.core.base_fragment.BaseFragment
import com.core.shared.error.EmptyBirthDate
import com.core.shared.error.EmptyGender
import com.core.shared.error.OperationMessage
import com.core.shared.error.PatientName
import com.core.shared.error.YabraaError
import com.core.shared.state.State
import com.core.shared.utils.CommonUtils.handleExpirationDate
import com.yabraa.medical.core.utils.custom_views.yabraa_bar.YabraaBarHandler
import com.yabraa.medical.core.utils.dialog.yabraa_date_picker_dialog.YabraaDatePickerDialog
import com.yabraa.medical.core.utils.dialog.yabraa_dialog.YabraaDialogBuilder
import com.yabraa.medical.core.utils.getErrorMessage
import com.yabraa.medical.databinding.FragmentAddPatientBinding
import com.yabraa.medical.feature.fragments.common.domain.model.ErrorMessageUi
import com.yabraa.medical.feature.fragments.patients.add_patient.domain.model.AddPatientUi
import com.yabraa.medical.feature.fragments.patients.add_patient.domain.viewmodel.AddPatientViewModel
import com.yabraa.medical.feature.fragments.register.data.request.GenderType.FEMALE
import com.yabraa.medical.feature.fragments.register.data.request.GenderType.MALE
import dagger.hilt.android.AndroidEntryPoint
import kotlinx.coroutines.launch
import javax.inject.Inject

@AndroidEntryPoint
class AddPatientFragment : BaseFragment<FragmentAddPatientBinding>() {

    override val binding by lazy { FragmentAddPatientBinding.inflate(layoutInflater) }
    private val vieModel: AddPatientViewModel by viewModels()

    @Inject
    lateinit var yabraaDatePickerDialog: YabraaDatePickerDialog

    private var birthDate: String? = null
    private var genderType: String? = null


    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        showExpirationDateError()
    }


    override fun onViewCreated(view: View, savedInstanceState: Bundle?) {
        super.onViewCreated(view, savedInstanceState)
        lifecycleScope.launch { collectOnValidateInput() }
        lifecycleScope.launch { collectOnAddNewPatientResponseState() }
        binding.setUpViews()
    }


    override fun onResume() {
        super.onResume()
        yabraaBarView?.setUpYabraaBarView()
        confirmationView?.setConfirmationAppointmentVisibility(false)
        showBottomNavigation(false)
    }

    private fun YabraaBarHandler.setUpYabraaBarView() {
        val barTitle = R.string.addNewPatient.localize()
        setYabraaBarVisibility(true)
        setClearAllVisibility(false)
        setBarTitle(barTitle)
        setOnBackArrowClicked { findNavController().popBackStack() }
    }


    private fun FragmentAddPatientBinding.setUpViews() {
        setOnDateOfBirthViewClicked()
        setOnGenderSelectedClicked()
        setOnAddNewPatientCLicked()
    }


    private suspend fun collectOnValidateInput() {
        vieModel.validationState.collect {
            when (it) {
                is State.Error -> handleError(it)
                is State.Initial -> {}
                is State.Loading -> {}
                is State.Success -> {}
            }
        }
    }

    private fun handleError(errorState: State.Error<*>) {
        errorState.error.handleError {
            when (exception) {
                is PatientName -> showInputErrorSnackBar(R.string.pleaseEnterPatientName)
                is EmptyBirthDate -> showInputErrorSnackBar(R.string.pleaseEnterYourBirthDate)
                is EmptyGender -> showInputErrorSnackBar(R.string.pleaseSelectSex)
            }
        }
    }


    private fun FragmentAddPatientBinding.setOnDateOfBirthViewClicked() {
        dateOfBirthView.setOnClickListener { setDateOfBirthView() }
    }


    private fun FragmentAddPatientBinding.setDateOfBirthView() {
        val dateOfBirthTvColor =
            ContextCompat.getColorStateList(requireContext(), R.color.primaryDark900)
        yabraaDatePickerDialog.datePickerDialog(requireActivity()) {
            if (it.isEmpty()) return@datePickerDialog
            dateOfBirthTv.setTextColor(dateOfBirthTvColor)
            dateOfBirthTv.text = it
            birthDate = it
        }?.show()
    }


    private fun FragmentAddPatientBinding.setOnGenderSelectedClicked() {
        radioBtnGroup.setOnCheckedChangeListener { _, checkedId ->
            when (checkedId) {
                R.id.maleBtn -> genderType = MALE.genderValue
                R.id.femaleBtn -> genderType = FEMALE.genderValue
            }
        }
    }


    private fun showInputErrorSnackBar(@StringRes message: Int) =
        yabraaSnackBarBuilder.setEndIcon(R.drawable.ic_vector_close).setMessage(message)
            .build(requireView()).show()


    @SuppressLint("FragmentLiveDataObserve")
    private fun FragmentAddPatientBinding.setOnAddNewPatientCLicked() {
        connectivityManager?.isNetworkConnected?.observe(this@AddPatientFragment) { isConnected ->
            addNewPatientBtn.setOnClickListener {
                if (!isConnected) {
                    showNetworkConnectionErrorPopup()
                    return@setOnClickListener
                }
                vieModel.validateInput(setAddPatientRequest())
            }
        }
    }

    private fun FragmentAddPatientBinding.setAddPatientRequest(): AddPatientUi {
        return AddPatientUi(
            name = patientNameEt.text.toString(),
            birthDate = birthDate ?: "",
            gender = genderType ?: ""
        )
    }

    private suspend fun collectOnAddNewPatientResponseState() {
        vieModel.addPatientResponseState.collect {
            hideProgressDialog()
            when (it) {
                is State.Error -> it.error.handleAddNewPatientResponseError()
                is State.Initial -> {}
                is State.Loading -> showProgressDialog()
                is State.Success -> showAddNewPatientResponseSuccessPopup()
            }
        }
    }

    private fun YabraaError.handleAddNewPatientResponseError() {
        val errorMessageUi =  ErrorMessageUi(logMessageEn, logMessageAr)
        handleError {
            when (exception) {
                is OperationMessage -> showAddNewPatientResponseErrorPopup(errorMessageUi)
            }
        }
    }


    private fun showAddNewPatientResponseErrorPopup(errorMessageUi: ErrorMessageUi) {
        val errorMessage = getErrorMessage(errorMessageUi)
        YabraaDialogBuilder(requireActivity()).setIcon(R.drawable.ic_vector_error)
            .setTitle(R.string.warning).setMessage(errorMessage).setTopButton(R.string.ok) {
                //TODO LOG MESSAGE HERE
            }.setCancelable(false).show()
    }


    private fun showAddNewPatientResponseSuccessPopup() {
        YabraaDialogBuilder(requireActivity()).setIcon(R.drawable.ic_vector_check_circle)
            .setTitle(R.string.success).setMessage(R.string.addPatientHasBeenSuccess)
            .setTopButton(R.string.ok) {
                findNavController().popBackStack()
            }.setCancelable(false).show()
    }

    private fun showExpirationDateError() =
        tokenHandler.handleExpirationDate { showExpirationDatePopupError() }
}