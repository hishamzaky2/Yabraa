package com.yabraa.medical.feature.fragments.allergies_and_chronic_diseases.past_medication_fragment.domain.repository

import com.core.shared.state.State
import com.yabraa.medical.feature.fragments.allergies_and_chronic_diseases.past_medication_fragment.data.model.request.PastMedicationRequestDto
import com.yabraa.medical.feature.fragments.allergies_and_chronic_diseases.past_medication_fragment.data.model.response.PastMedicationResponseDto
import kotlinx.coroutines.flow.Flow

interface AddPastMedicationRepository {
    suspend fun addPastMedication(requestDto: PastMedicationRequestDto): Flow<State<PastMedicationResponseDto>>
}