package com.yabraa.medical.feature.fragments.register.data.repository

import kotlinx.coroutines.flow.flow
import kotlinx.coroutines.flow.flowOn
import com.yabraa.medical.core.base_repository.BaseRepository
import com.yabraa.medical.core.di.network_sevices.SecurityServices
import com.core.shared.state.State
import com.yabraa.medical.core.utils.getResponseMessageError
import com.yabraa.medical.feature.fragments.register.data.request.RegisterRequestDto
import com.yabraa.medical.feature.fragments.register.data.response.register_response.RegisterResponseDto
import com.yabraa.medical.feature.fragments.register.domain.repository.RegisterRepository
import retrofit2.Response
import javax.inject.Inject

const val TAG_REGISTER_RESPONSE = "TAG_REGISTER_RESPONSE"

class RegisterRepositoryImpl @Inject constructor(private val securityServices: SecurityServices) :
    BaseRepository<RegisterRequestDto, RegisterResponseDto>(), RegisterRepository {


    override suspend fun registerNewAccount(request: RegisterRequestDto) = flow {
        emit(getOperationState(request))
    }.flowOn(dispatcher)

    override suspend fun performApiCall(requestDto: RegisterRequestDto): State<RegisterResponseDto> {
        val response = securityServices.registerNewAccount(requestDto)
        return handleRegisterResponse(response)
    }

    private fun handleRegisterResponse(response: Response<RegisterResponseDto>): State<RegisterResponseDto> {
        val responseBody = response.body()
        val errorMessageEn = responseBody?.errorMessageEn ?: ""
        val errorMessageAr = responseBody?.errorMessageAr ?: ""
        return when {
            response.isSuccessful && responseBody?.registerDataResponse != null ->
                State.Success(response.body())

            response.isSuccessful && !responseBody?.errorMessageEn.isNullOrEmpty() ->
                getResponseMessageError(
                    errorMessageEn = errorMessageEn,
                    errorMessageAr = errorMessageAr,
                    logTag = TAG_REGISTER_RESPONSE
                )

            else -> getNotSuccessfulResponseState(response)
        }
    }
}