package com.yabraa.medical.feature.fragments.splash_screen.presentation

import android.annotation.SuppressLint
import android.app.Activity
import android.os.Bundle
import android.view.View
import androidx.activity.result.contract.ActivityResultContracts
import androidx.lifecycle.Lifecycle
import com.google.android.play.core.appupdate.AppUpdateInfo
import com.google.android.play.core.appupdate.AppUpdateManager
import com.google.android.play.core.appupdate.AppUpdateManagerFactory
import com.google.android.play.core.appupdate.AppUpdateOptions
import com.google.android.play.core.install.model.AppUpdateType
import com.google.android.play.core.install.model.UpdateAvailability
import com.google.firebase.messaging.FirebaseMessaging
import com.jakewharton.processphoenix.ProcessPhoenix
import com.yabraa.medical.BuildConfig
import com.yabraa.medical.R
import com.yabraa.medical.core.base_fragment.BaseFragment
import com.yabraa.medical.core.base_fragment.SKIP_ONBOARD_SCREEN
import com.yabraa.medical.core.base_fragment.navigate
import com.yabraa.medical.core.base_fragment.repeatOnLifecycleScope
import com.yabraa.medical.core.utils.dialog.yabraa_dialog.YabraaDialogBuilder
import com.yabraa.medical.databinding.FragmentSplashScreenBinding
import dagger.hilt.android.AndroidEntryPoint
import kotlinx.coroutines.delay
import timber.log.Timber

const val FIREBASE_CLOUD_MESSAGING_TOKEN = "FIREBASE_CLOUD_MESSAGING_TOKEN"

@AndroidEntryPoint
@SuppressLint("CustomSplashScreen")
class SplashScreenFragment : BaseFragment<FragmentSplashScreenBinding>() {

    override val binding by lazy { FragmentSplashScreenBinding.inflate(layoutInflater) }
    private val isSkipOnboardScreen by lazy {
        sharedPreference.getBoolean(SKIP_ONBOARD_SCREEN, false)
    }

    private val appUpdateManager by lazy { AppUpdateManagerFactory.create(requireContext()) }
    private val appUpdateInfoTask by lazy { appUpdateManager.appUpdateInfo }

    override fun onViewCreated(view: View, savedInstanceState: Bundle?) {
        super.onViewCreated(view, savedInstanceState)
        getFirebaseCloudMessagingToken()
        binding.setUpViews()
        repeatOnLifecycleScope(Lifecycle.State.STARTED) {
            delay(1000)
            checkForAppUpdate()
        }
    }

    private fun getFirebaseCloudMessagingToken() {
        FirebaseMessaging.getInstance().token.addOnCompleteListener { task ->
            if (task.isSuccessful && task.result != null) {
                val token = task.result
                sharedPreference.setString(FIREBASE_CLOUD_MESSAGING_TOKEN,token)
            }
        }
    }


    private fun FragmentSplashScreenBinding.setUpViews() {
        setAppVersion()
    }


    @SuppressLint("SetTextI18n")
    private fun FragmentSplashScreenBinding.setAppVersion() {
        val version = try {
            BuildConfig.VERSION_NAME.split(".").map { String.format("%d", it.toInt()) }
                .reduce { acc, s -> "$acc.$s" }
        } catch (e: Exception) {/* handle error here */
            BuildConfig.VERSION_NAME
        }
        appVersionTv.text = String.format(R.string.buildVersion.localize(), version)
    }


    private fun checkForAppUpdate() {
        if (BuildConfig.DEBUG) {
            handleNavigateToNextScreen()
            return
        }
        handleAddOnAppUpdateSuccess()
        handleAddOnFailureAppUpdate()
    }

    private fun handleAddOnAppUpdateSuccess() {
        appUpdateInfoTask.addOnSuccessListener { appUpdateInfo ->
            if (appUpdateInfo.updateAvailability() == UpdateAvailability.UPDATE_AVAILABLE && appUpdateInfo.isUpdateTypeAllowed(
                    AppUpdateType.IMMEDIATE
                )
            ) {
                requestAppUpdate(appUpdateManager, appUpdateInfo)
            } else {
                handleNavigateToNextScreen()
            }
        }
    }

    private fun handleAddOnFailureAppUpdate() {
        appUpdateInfoTask.addOnFailureListener {
            Timber.e(it)
            handleNavigateToNextScreen()
        }
    }

    override fun onResume() {
        super.onResume()
        showYabraaBar(false)
        if (BuildConfig.DEBUG) {
            handleNavigateToNextScreen()
            return
        }
        appUpdateManager.appUpdateInfo.addOnSuccessListener { appUpdateInfo ->
            if (appUpdateInfo.updateAvailability() == UpdateAvailability.DEVELOPER_TRIGGERED_UPDATE_IN_PROGRESS) {
                requestAppUpdate(appUpdateManager, appUpdateInfo)
            }
        }
        appUpdateManager.appUpdateInfo.addOnFailureListener {
            Timber.e(it)
        }
    }


    private fun requestAppUpdate(appUpdateManager: AppUpdateManager, appUpdateInfo: AppUpdateInfo) {
        appUpdateManager.startUpdateFlowForResult(
            appUpdateInfo,
            activityResultLauncher,
            AppUpdateOptions.newBuilder(AppUpdateType.IMMEDIATE).build()
        )
    }


    private val activityResultLauncher =
        registerForActivityResult(ActivityResultContracts.StartIntentSenderForResult()) { result ->
            when (result.resultCode) {
                Activity.RESULT_OK -> handleNavigateToNextScreen()
                Activity.RESULT_CANCELED -> showUpdateFailedPopup()
                else -> showUpdateFailedPopup()
            }
        }


    private fun showUpdateFailedPopup() {
        YabraaDialogBuilder(requireActivity()).setTitle(R.string.updateFailed)
            .setMessage(R.string.updateFailedMessage).setIcon(R.drawable.ic_vector_error)
            .setTopButton(R.string.ok) { restartApp() }.setCancelable(false).show()
    }

    private fun restartApp() = ProcessPhoenix.triggerRebirth(requireContext())


    private fun handleNavigateToNextScreen() {
        if (isSkipOnboardScreen) { //TODO WILL BE HANDLE USER LOGIN AND LOGIN AS GUEST HERE
            navigate(R.id.actionSplashScreenFragmentToLoginFragment)
        } else {
            navigate(R.id.actionSplashScreenFragmentToViewPagerFragment)
        }
    }
}