package com.yabraa.medical.feature.fragments.select_date_and_time.domain.viemodel

import androidx.lifecycle.ViewModel
import androidx.lifecycle.viewModelScope
import com.core.shared.state.State
import com.yabraa.medical.feature.fragments.select_date_and_time.data.response.DatesResponseDto
import com.yabraa.medical.feature.fragments.select_date_and_time.domain.usecase.DatesArabicUseCase
import com.yabraa.medical.feature.fragments.select_date_and_time.domain.usecase.DatesUseCase
import dagger.hilt.android.lifecycle.HiltViewModel
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.launch
import javax.inject.Inject

@HiltViewModel
class DatesViewModel @Inject constructor(
    private val datesUseCase: DatesUseCase,
    private val datesArabicUseCase: DatesArabicUseCase
) : ViewModel() {


    private val _datesResponseState = MutableStateFlow<State<DatesResponseDto>>(State.Initial())
    val datesResponseState: StateFlow<State<DatesResponseDto>> = _datesResponseState


    private val _datesArabicResponseState =
        MutableStateFlow<State<DatesResponseDto>>(State.Initial())
    val datesArabicResponseState: StateFlow<State<DatesResponseDto>> = _datesArabicResponseState

    fun getDates() {
        viewModelScope.launch {
            _datesResponseState.emit(State.Loading())
            datesUseCase().collect {
                _datesResponseState.emit(it)
            }
        }
    }

    fun getDatesArabic() {
        viewModelScope.launch {
            _datesArabicResponseState.emit(State.Loading())
            datesArabicUseCase().collect {
                _datesArabicResponseState.emit(it)
            }
        }
    }

    fun getDatesDataResponse() = datesUseCase.getDatesDataResponse()

    fun getFirstMonth() = datesUseCase.getFirstMonth()
    fun getSecondMonth() = datesUseCase.getSecondMonth()

    fun getFirstYear() = datesUseCase.getFirstYear()
    fun getLastYear() = datesUseCase.getLastYear()


    fun getDatesArabicDataResponse() = datesArabicUseCase.getDatesArabicDataResponse()

    fun getFirstMonthArabic() = datesArabicUseCase.getFirstMonthArabic()
    fun getSecondMonthArabic() = datesArabicUseCase.getSecondMonthArabic()

    fun getFirstYearArabic() = datesArabicUseCase.getFirstYearArabic()
    fun getLastYearArabic() = datesArabicUseCase.getLastYearArabic()


}