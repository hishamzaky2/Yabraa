package com.yabraa.medical.feature.fragments.notification.notification_hisotry.data.model.response.read_notification_response


import com.google.gson.annotations.SerializedName

data class ReadNotificationResponseDto(
    @SerializedName("data")
    val readNotificationResponse: ReadNotificationResponse,
    @SerializedName("errorMessageAr")
    val errorMessageAr: String? = null,
    @SerializedName("errorMessageEn")
    val errorMessageEn: String? = null,
    @SerializedName("statusCode")
    val statusCode: Int
)