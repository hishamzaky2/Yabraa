package com.yabraa.medical.core.di.network_sevices

import com.yabraa.medical.feature.fragments.appointment.edit_appointment.data.model.request.EditAppointmentRequestDto
import com.yabraa.medical.feature.fragments.appointment.edit_appointment.data.model.response.AppointmentResponseDto
import com.yabraa.medical.feature.fragments.appointment.my_appointment.data.model.response.MyAppointmentResponseDto
import com.yabraa.medical.feature.fragments.appointment.my_appointment.data.model.response.cancel_appointment_response.CancelAppointmentResponseDto
import com.yabraa.medical.feature.fragments.appointment.my_appointment_details.data.model.MyAppointmentDetailsResponseDto
import com.yabraa.medical.feature.fragments.checkout.data.model.request.CheckoutRequestDto
import com.yabraa.medical.feature.fragments.checkout.data.model.response.checkout_response.CheckoutResponseDto
import com.yabraa.medical.feature.fragments.checkout.data.model.response.payment_method_response.PaymentMethodResponseDto
import com.yabraa.medical.feature.fragments.checkout.data.model.response.payment_response.PaymentResponseDto
import com.yabraa.medical.feature.fragments.edit_account.data.response.edit_account_response.EditAccountResponseDto
import com.yabraa.medical.feature.fragments.history_payment.data.model.HistoryPaymentResponseDto
import com.yabraa.medical.feature.fragments.home.data.model.response.gallery_response.GalleryResponseDto
import com.yabraa.medical.feature.fragments.home.data.model.response.service_type_response.ServiceTypeResponseDto
import com.yabraa.medical.feature.fragments.home.data.model.response.services_details_response.ServicesDetailsResponseDto
import com.yabraa.medical.feature.fragments.notification.notification_hisotry.data.model.response.notification_history_response.NotificationHistoryResponseDto
import com.yabraa.medical.feature.fragments.notification.notification_hisotry.data.model.response.read_notification_response.ReadNotificationResponseDto
import com.yabraa.medical.feature.fragments.patients.add_patient.data.model.reposne.AddPatientResponseDto
import com.yabraa.medical.feature.fragments.patients.add_patient.data.model.request.AddPatientRequest
import com.yabraa.medical.feature.fragments.patients.edit_patients.data.model.request.EditPatientRequest
import com.yabraa.medical.feature.fragments.patients.edit_patients.data.model.response.delete_patient_response.DeletePatientResponseDto
import com.yabraa.medical.feature.fragments.patients.edit_patients.data.model.response.edit_patient_response.EditPatientResponseDto
import com.yabraa.medical.feature.fragments.patients.patients.data.model.response.PatientResponseDto
import com.yabraa.medical.feature.fragments.register.data.request.RegisterRequestDto
import com.yabraa.medical.feature.fragments.select_date_and_time.data.response.DatesResponseDto
import com.yabraa.medical.feature.fragments.setting.data.model.response.delete_account_response.DeleteAccountResponseDto
import com.yabraa.medical.feature.fragments.setting.data.model.response.user_information_response.UserInformationResponseDto
import retrofit2.Response
import retrofit2.http.Body
import retrofit2.http.DELETE
import retrofit2.http.GET
import retrofit2.http.POST
import retrofit2.http.PUT
import retrofit2.http.Path
import retrofit2.http.Query

interface YabraaServices {

    @GET("api/services/GetServiceTypes")
    suspend fun getServiceType(): Response<ServiceTypeResponseDto>

    @GET("api/Gallery")
    suspend fun getGallery(): Response<GalleryResponseDto>

    @GET("api/services/servicesDetails")
    suspend fun getServicesDetails(@Query("serviceTypeId") serviceTypeId: Long): Response<ServicesDetailsResponseDto>

    @GET("api/Services/getDates")
    suspend fun getDates(): Response<DatesResponseDto>

    @GET("api/Services/getDatesAr")
    suspend fun getDatesArabic(): Response<DatesResponseDto>

    @POST("api/UserFamily")
    suspend fun addPatient(@Body addPatientRequest: AddPatientRequest): Response<AddPatientResponseDto>

    @GET("api/UserFamily")
    suspend fun getPatient(): Response<PatientResponseDto>

    @PUT("api/UserFamily")
    suspend fun updatePatient(@Body editPatientRequest: EditPatientRequest): Response<EditPatientResponseDto>

    @DELETE("api/UserFamily/{userFamilyId}")
    suspend fun deletePatient(@Path("userFamilyId") userFamilyId: Long): Response<DeletePatientResponseDto>

    @POST("api/Payment/GetCheckoutId")
    suspend fun checkout(@Body checkoutRequestDto: CheckoutRequestDto): Response<CheckoutResponseDto>

    @GET("api/Payment/GetPaymentMethods")
    suspend fun getPaymentMethods(): Response<PaymentMethodResponseDto>

    @GET("api/Payment/GetCheckoutStatus")
    suspend fun completePayment(
        @Query("CheckoutId") checkoutId: String,
        @Query("PaymentMethodId") paymentMethodId: Long,
        @Query("FirebaseToken") firebaseToken: String
    ): Response<PaymentResponseDto>

    @GET("api/Appointment/CancelAppointment")
    suspend fun cancelAppointment(
        @Query("AppointmentId") appointmentId: Long,
        @Query("FirebaseToken") firebaseToken: String
    ): Response<CancelAppointmentResponseDto>

    @GET("api/auth/GetUserInformation")
    suspend fun getUserInformation(): Response<UserInformationResponseDto>

    @PUT("api/auth/EditeAccount")
    suspend fun editAccount(@Body registerRequestDto: RegisterRequestDto): Response<EditAccountResponseDto>

    @DELETE("api/Auth/DeleteAccount")
    suspend fun deleteAccount(): Response<DeleteAccountResponseDto>

    @GET("api/Appointment/GetAppointmentsByUser")
    suspend fun getMytAppointment(): Response<MyAppointmentResponseDto>

    @GET("api/Appointment/GetAppointmentDetailsByAppointmentId")
    suspend fun getAppointmentById(@Query("AppointmentId") appointmentId: Long): Response<AppointmentResponseDto>

    @PUT("api/Appointment/Edit")
    suspend fun editAppointment(@Body editAppointmentRequestDto: EditAppointmentRequestDto): Response<AppointmentResponseDto>

    @GET("api/Payment/HistoryPayment")
    suspend fun getHistoryPayment(): Response<HistoryPaymentResponseDto>

    @GET("api/Appointment/GetAppointmentDetailsByAppointmentId")
    suspend fun getMyAppointmentDetailsByAppointmentId(@Query("AppointmentId") id: Long): Response<MyAppointmentDetailsResponseDto>


    @GET("api/Notification/GetNotifications")
    suspend fun getNotifications(
        @Query("pageNumber") pageNumber: Int,
        @Query("pageSize") pageSize: Int
    ): Response<NotificationHistoryResponseDto>

    @GET("api/Notification/ReadNotification")
    suspend fun readNotification(@Query("notificationId") notificationId: Long): Response<ReadNotificationResponseDto>
}