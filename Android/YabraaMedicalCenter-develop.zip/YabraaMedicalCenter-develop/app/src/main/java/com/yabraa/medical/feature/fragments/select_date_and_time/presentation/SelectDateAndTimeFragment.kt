package com.yabraa.medical.feature.fragments.select_date_and_time.presentation

import android.annotation.SuppressLint
import android.os.Bundle
import android.view.View
import android.widget.EditText
import android.widget.TextView
import androidx.annotation.StringRes
import androidx.fragment.app.viewModels
import androidx.hilt.navigation.fragment.hiltNavGraphViewModels
import androidx.lifecycle.lifecycleScope
import androidx.navigation.fragment.findNavController
import com.core.shared.state.State
import com.core.shared.utils.CommonUtils.getCurrentDate
import com.core.shared.utils.CommonUtils.getLocalizedValue
import com.core.shared.utils.CommonUtils.handleExpirationDate
import com.core.shared.utils.CommonUtils.load
import com.yabraa.medical.R
import com.yabraa.medical.R.drawable.ic_vector_orange_error
import com.yabraa.medical.R.id.actionSelectTimeAndDateFragmentToMapsFragment
import com.yabraa.medical.R.string.confirmingAppointments
import com.yabraa.medical.R.string.ok
import com.yabraa.medical.R.string.pleaseSelectDateOfPackage
import com.yabraa.medical.R.string.pleaseSelectPatientOfPackage
import com.yabraa.medical.R.string.warning
import com.yabraa.medical.R.string.wrong
import com.yabraa.medical.core.base_fragment.BaseFragment
import com.yabraa.medical.core.base_fragment.navigate
import com.yabraa.medical.core.utils.custom_views.confirmation_appointment.ConfirmationAppointmentHandler
import com.yabraa.medical.core.utils.custom_views.yabraa_bar.YabraaBarHandler
import com.yabraa.medical.core.utils.dialog.select_date_and_time_bottom_dialog.SelectDateAndTimeBottomSheet
import com.yabraa.medical.core.utils.dialog.select_patient_bottom_sheet.SelectPatientBottomSheet
import com.yabraa.medical.core.utils.dialog.yabraa_dialog.YabraaButtonStyle
import com.yabraa.medical.core.utils.dialog.yabraa_dialog.YabraaDialogBuilder
import com.yabraa.medical.databinding.FragmentSelectDateAndTimeBinding
import com.yabraa.medical.feature.fragments.common.domain.viewmodel.TransactionViewModel
import com.yabraa.medical.feature.fragments.home.domain.model.ServiceTypeName
import com.yabraa.medical.feature.fragments.patients.patients.data.model.response.PatientResponse
import com.yabraa.medical.feature.fragments.patients.patients.domain.viewmodel.PatientListViewModel
import com.yabraa.medical.feature.fragments.select_date_and_time.data.response.DatesDataResponse
import com.yabraa.medical.feature.fragments.select_date_and_time.domain.model.NoteUi
import com.yabraa.medical.feature.fragments.select_date_and_time.domain.model.SelectDateAndTimeUi
import com.yabraa.medical.feature.fragments.select_date_and_time.domain.model.SelectPatientsUi
import com.yabraa.medical.feature.fragments.select_date_and_time.domain.model.TimeUi
import com.yabraa.medical.feature.fragments.select_date_and_time.domain.model.TimeUi.TWENTY_FOUR
import com.yabraa.medical.feature.fragments.select_date_and_time.domain.model.getAllTimeList
import com.yabraa.medical.feature.fragments.select_date_and_time.domain.model.getGreaterThanOrCurrentTimeList
import com.yabraa.medical.feature.fragments.select_date_and_time.domain.viemodel.DatesViewModel
import com.yabraa.medical.feature.fragments.select_date_and_time.presentation.adapter.DateAdapter
import com.yabraa.medical.feature.fragments.select_date_and_time.presentation.adapter.SelectPatientAdapter
import com.yabraa.medical.feature.fragments.select_date_and_time.presentation.adapter.SelectPatientAdapter.PatientListener
import com.yabraa.medical.feature.fragments.select_date_and_time.presentation.adapter.SelectionPackagesAdapter
import com.yabraa.medical.feature.fragments.select_date_and_time.presentation.adapter.SelectionPackagesAdapter.SelectionPackagesCallback
import com.yabraa.medical.feature.fragments.select_date_and_time.presentation.adapter.SelectionPackagesAdapter.SelectionPackagesListener
import com.yabraa.medical.feature.fragments.select_date_and_time.presentation.adapter.TimeAdapter
import dagger.hilt.android.AndroidEntryPoint
import kotlinx.coroutines.launch
import java.util.Locale
import javax.inject.Inject

const val MIDNIGHT = "00:00"

@AndroidEntryPoint
class SelectDateAndTimeFragment : BaseFragment<FragmentSelectDateAndTimeBinding>(),
    SelectionPackagesCallback, SelectionPackagesListener, PatientListener {

    override val binding by lazy { FragmentSelectDateAndTimeBinding.inflate(layoutInflater) }
    private val transactionViewModel: TransactionViewModel by hiltNavGraphViewModels(R.id.mainNavGraph)
    private val patientViewModel: PatientListViewModel by viewModels()
    private val datesViewModel: DatesViewModel by viewModels()

    @Inject
    lateinit var selectPatientBottomSheet: SelectPatientBottomSheet

    @Inject
    lateinit var selectDateAndTimeBottomSheet: SelectDateAndTimeBottomSheet
    private val serviceId get() = transactionViewModel.serviceId ?: 0L

    private val patientList get() = patientViewModel.getPatientList()
    private var patientsValues: PatientResponse? = null
    private var packagePatientId: Long = 0
    private val selectPatientAdapter by lazy { SelectPatientAdapter(patientList) }

    private val firstMonth
        get() = getLocalizedValue(
            datesViewModel.getFirstMonth(), datesViewModel.getFirstMonthArabic()
        )

    private val secondMonth
        get() = getLocalizedValue(
            datesViewModel.getSecondMonth(), datesViewModel.getSecondMonthArabic()
        )

    private val firstYear
        get() = getLocalizedValue(
            datesViewModel.getFirstYear(),
            datesViewModel.getFirstYearArabic()
        )

    private val lastYear
        get() = getLocalizedValue(datesViewModel.getLastYear(), datesViewModel.getLastYearArabic())

    private val dates
        get() = getLocalizedValue(
            datesViewModel.getDatesDataResponse(), datesViewModel.getDatesArabicDataResponse()
        )

    private val packagesList get() = transactionViewModel.addPackageItemsList.toMutableList()
    private var selectDateAndTimeUi: SelectDateAndTimeUi? = null
    private var dateValues: DatesDataResponse? = null
    private var timeValue: String? = null
    private var timeList: MutableList<TimeUi>? = null
    private lateinit var dateAdapter: DateAdapter
    private lateinit var timeAdapter: TimeAdapter

    private val isInternetConnection get() = connectivityManager?.isNetworkConnected?.value == false

    private val selectionPackagesAdapter by lazy {
        SelectionPackagesAdapter(packagesList) {
            if (isInternetConnection) {
                showNetworkConnectionErrorPopup()
                return@SelectionPackagesAdapter
            }
            selectDateAndTimeBottomSheet.setOnShowSelectTimeAndDateBottomSheet()
            selectDateAndTimeBottomSheet.setOnConfirmingDateAndTimeSelect(it)
        }
    }

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        showExpirationDateError()
        handleInternetConnection()
    }

    override fun onViewCreated(view: View, savedInstanceState: Bundle?) {
        super.onViewCreated(view, savedInstanceState)
        binding.setUpViews()
        transactionViewModel.setSelectedPatientLiveList()
        transactionViewModel.setSelectedDateAndTimeLiveList()
        lifecycleScope.apply {
            launch { collectOnPatientResponse() }
            launch { collectOnDatesResponseState() }
            launch { collectOnDatesArabicResponseState() }
        }
    }

    override fun onResume() {
        super.onResume()
        yabraaBarView?.setYabraaBarViews()
        confirmationView?.setConfirmationView()
        showBottomNavigation(false)
    }

    private fun YabraaBarHandler.setYabraaBarViews() {
        val serviceName = transactionViewModel.getServiceNameByServiceId(serviceId)
        setYabraaBarVisibility(true)
        setBarTitle(serviceName)
        setOnBackArrowClicked()
        setClearAllVisibility(false)
    }

    private fun YabraaBarHandler.setOnBackArrowClicked() =
        setOnBackArrowClicked { findNavController().popBackStack(R.id.filterFragment, false) }


    private fun FragmentSelectDateAndTimeBinding.setUpViews() {
        setServiceImagePathView()
    }

    private fun FragmentSelectDateAndTimeBinding.setServiceImagePathView() {
        val serviceImagePath =
            transactionViewModel.getServiceImageImagePathByServiceId(serviceId)
        servicesImageIv.load(requireActivity(), serviceImagePath)
    }

    private fun handleInternetConnection() {
        connectivityManager?.isNetworkConnected?.observe(this@SelectDateAndTimeFragment) {
            if (!it) return@observe
            patientViewModel.getPatients()
            handleGetDatesRequest()
        }
    }

    private fun handleGetDatesRequest() = when ((Locale.getDefault().language)) {
        "en" -> datesViewModel.getDates()
        else -> datesViewModel.getDatesArabic()
    }

    /* ----------------------------- Selection patients section  -----------------------------------*/
    private suspend fun collectOnPatientResponse() {
        patientViewModel.patientResponseState.collect {
            hideProgressDialog()
            when (it) {
                is State.Error -> it.error.handleError { }
                is State.Initial -> {}
                is State.Loading -> showProgressDialog()
                is State.Success -> handleDefaultPatient()
            }
        }
    }

    private fun handleDefaultPatient() {
        if (patientList.size > 1) return
        setDefaultPatientValue()
        transactionViewModel.handleSelectDefaultPatientUi()
        transactionViewModel.setSelectedPatientLiveList()
    }


    private fun setDefaultPatientValue() {
        patientList.forEach { patients ->
            patientsValues = patients
        }
    }

    private fun TransactionViewModel.handleSelectDefaultPatientUi() {
        addPackageItemsList.forEach { packages ->
            patientsValues?.setSelectPatientsUi(packageId = packages.packageId)?.let {
                setPatientsList(packages.packageId, it)
            }
        }
    }

    override fun setOnSelectPatientClicked(packageId: Long) {
        if (patientList.size == 1) return
        handleOnSelectPatientViewClicked(packageId)
    }

    private fun handleOnSelectPatientViewClicked(packageId: Long) {
        if (isInternetConnection) {
            showNetworkConnectionErrorPopup()
            return
        }
        selectPatientBottomSheet.showBottomSheetDialog()
        setPatientAdapter()
        packagePatientId = packageId
    }

    override fun setOnSelectPatientClicked(patientResponse: PatientResponse) {
        patientsValues = patientResponse
        patientsValues?.setSelectPatientsUi(packageId = packagePatientId)?.let {
            transactionViewModel.setPatientsList(packagePatientId, it)
        }
        transactionViewModel.setSelectedPatientLiveList()
        selectPatientBottomSheet.dismissBottomSheet()
    }

    private fun setPatientAdapter() {
        selectPatientAdapter.initializeSetOnPatientCallback(this)
        selectPatientBottomSheet.setRecyclerAdapter(selectPatientAdapter)
    }


    override fun setPatientValue(packageId: Long, patientTv: TextView) {
        transactionViewModel.selectPatientUiLiveList.observe(requireActivity()) { selectPatientUiList ->
            selectPatientUiList.filter { packageId == it.packageId }.forEach {
                patientTv.text = it.name
            }
        }
    }

    private fun PatientResponse.setSelectPatientsUi(packageId: Long): SelectPatientsUi {
        return SelectPatientsUi(
            packageId = packageId,
            userFamilyId = userFamilyId,
            birthDate = birthDate,
            name = name
        )
    }

    /* ----------------------------- Selection date and time section  -----------------------------------*/

    private suspend fun collectOnDatesResponseState() {
        datesViewModel.datesResponseState.collect {
            hideProgressDialog()
            when (it) {
                is State.Error -> it.error.handleError { }
                is State.Initial -> {}
                is State.Loading -> showProgressDialog()
                is State.Success -> selectionPackagesAdapter.setSelectionTimeAndDateAdapter()

            }
        }
    }

    private suspend fun collectOnDatesArabicResponseState() {
        datesViewModel.datesArabicResponseState.collect {
            hideProgressDialog()
            when (it) {
                is State.Error -> it.error.handleError { }
                is State.Initial -> {}
                is State.Loading -> showProgressDialog()
                is State.Success -> selectionPackagesAdapter.setSelectionTimeAndDateAdapter()

            }
        }
    }


    private fun SelectionPackagesAdapter.setSelectionTimeAndDateAdapter() {
        initializeSelectionPackagesAdapterCallback()
        binding.packagesRv.adapter = this
    }


    private fun SelectionPackagesAdapter.initializeSelectionPackagesAdapterCallback() {
        initializeSetOnSelectPatientCallback(this@SelectDateAndTimeFragment)
        initializeSetDateValueCallback(this@SelectDateAndTimeFragment)
        initializeSetPatientValueCallback(this@SelectDateAndTimeFragment)
        initializeAddOptionalNotesCallback(this@SelectDateAndTimeFragment)
        initializeSeOptionalNotesValueCallback(this@SelectDateAndTimeFragment)
    }

    private fun SelectDateAndTimeBottomSheet.setOnShowSelectTimeAndDateBottomSheet() {
        showSelectAndDateBottomSheetDialog()
        setDateAdapter()
        setTimeAdapter()
        setFirstMonthTv()
        setSecondMonthTv()
        setFirstYearTv()
        setLastYearTv()
    }


    private fun SelectDateAndTimeBottomSheet.setDateAdapter() {
        dateAdapter = DateAdapter(dates) {
            setOnSelectDateClicked(it)
        }
        setDayRecyclerAdapter(dateAdapter)
    }

    private fun setOnSelectDateClicked(dates: DatesDataResponse) {
        timeValue = null
        handleShowTimeList(dates)
        selectDateAndTimeBottomSheet.setTimeAdapter()
        dateValues = dates
    }

    private fun handleShowTimeList(dates: DatesDataResponse) {
        val selectionDate = "${dates.year}-${dates.monthNumber}-${dates.dayOfMonth}"
        val currentDate = getCurrentDate()
        timeList = when (selectionDate) {
            currentDate -> getGreaterThanOrCurrentTimeList()
            else -> getAllTimeList()
        }
    }


    private fun SelectDateAndTimeBottomSheet.setTimeAdapter() {
        val timeList = timeList ?: getAllTimeList()
        timeAdapter = TimeAdapter(timeList) {
            timeValue = if (it == TWENTY_FOUR.timeValue) MIDNIGHT else it
        }
        setTimeRecyclerAdapter(timeAdapter)
    }


    private fun SelectDateAndTimeBottomSheet.setFirstMonthTv() = setFirstMonth(firstMonth)
    private fun SelectDateAndTimeBottomSheet.setSecondMonthTv() = setSecondMonth(secondMonth)
    private fun SelectDateAndTimeBottomSheet.setFirstYearTv() = setFirstYear(firstYear)

    private fun SelectDateAndTimeBottomSheet.setLastYearTv() = setLastYear(firstYear, lastYear)


    private fun SelectDateAndTimeBottomSheet.setOnConfirmingDateAndTimeSelect(packageId: Long) {
        setOnConfirmingDateAndTimeClicked(packageId) { id ->
            selectDateAndTimeUi = setDateAndTimeUi(id)
            if (isDateAndTimeEmpty()) return@setOnConfirmingDateAndTimeClicked
            selectDateAndTimeUi?.let { transactionViewModel.setDateAndTimeList(id, it) }
            transactionViewModel.setSelectedDateAndTimeLiveList()
            dismissSelectAndDateBottomSheet()
        }
    }

    private fun isDateAndTimeEmpty(): Boolean {
        if (selectDateAndTimeUi?.dayOfMonth.isNullOrEmpty()) {
            showSelectDateAndTimeErrorPopup(R.string.pleaseSelectDate)
            return true
        } else if (selectDateAndTimeUi?.time.isNullOrEmpty()) {
            showSelectDateAndTimeErrorPopup(R.string.pleaseSelectTime)
            return true
        }
        return false
    }

    private fun setDateAndTimeUi(packageId: Long) = SelectDateAndTimeUi(
        packageId = packageId,
        time = timeValue,
        dayName = dateValues?.dayName,
        dayOfMonth = dateValues?.dayOfMonth,
        monthName = dateValues?.monthName,
        monthNumber = dateValues?.monthNumber,
        monthShortName = dateValues?.monthShortName,
        year = dateValues?.year
    )


    @SuppressLint("SetTextI18n")
    override fun setDateValue(packageId: Long, selectDateAndTimeTv: TextView) {
        transactionViewModel.selectDateAndTimeUiLiveList.observe(requireActivity()) { dateAndTimeList ->
            dateAndTimeList.filter { packageId == it.packageId }.forEach { date ->
                selectDateAndTimeTv.text =
                    "${date.dayOfMonth}/${date.monthNumber}/${date.year} - ${date.time}"
            }
        }
    }


    override fun addOptionalNotes(packageId: Long, notes: String) {
        transactionViewModel.addPackageItemsList.forEach {
            if (packageId == it.packageId) {
                transactionViewModel.setNotesList(packageId, NoteUi(packageId, notes))
            }
        }
    }

    override fun setNoteValue(packageId: Long, noteEt: EditText) {
        transactionViewModel.addNoteList.filter { packageId == it.packageId }.forEach {
            noteEt.setText(it.note)
        }
    }

    private fun showSelectDateAndTimeErrorPopup(@StringRes errorText: Int) {
        val topBtnStyle = YabraaButtonStyle(R.color.brandPaletteDark800)
        YabraaDialogBuilder(requireActivity()).setIcon(R.drawable.ic_vector_error).setTitle(wrong)
            .setMessage(errorText).setTopButton(ok, topBtnStyle) {}.show()
    }

    private fun ConfirmationAppointmentHandler.setConfirmationView() {
        setConfirmationAppointmentVisibility(true)
        setOnConfirmationAppointmentClicked()
        setOnCancelClicked()
    }


    @Suppress("LABEL_NAME_CLASH")
    private fun ConfirmationAppointmentHandler.setOnConfirmationAppointmentClicked() {
        setTextConfirmationBtn(confirmingAppointments)
        connectivityManager?.isNetworkConnected?.observe(this@SelectDateAndTimeFragment) { isConnected ->
            setOnConfirmationAppointmentClicked {
                if (!isConnected) {
                    showNetworkConnectionErrorPopup()
                    return@setOnConfirmationAppointmentClicked
                }
                transactionViewModel.addPackagesTransactionList()
                transactionViewModel.handleSelectPatientAndDateValidation()
            }
        }
    }

    private fun TransactionViewModel.handleSelectPatientAndDateValidation() {
        addPackageItemsList.map { it.packageId }.forEach { packageId ->
            packagesTransactionList.forEach {
                val packageName =
                    getLocalizedValue(it.packageData?.nameEN, it.packageData?.nameAR) ?: ""
                val isPackageIdMatched = packageId == it.packageData?.packageId
                if (isPackageIdMatched && it.patients?.userFamilyId == null) {
                    showSelectPatientAndDatePopupError(pleaseSelectPatientOfPackage, packageName)
                    handleEnabledConfirmationAppointmentBtn(false)
                    return
                } else if (isPackageIdMatched && it.dates?.dayOfMonth == null) {
                    showSelectPatientAndDatePopupError(pleaseSelectDateOfPackage, packageName)
                    handleEnabledConfirmationAppointmentBtn(false)
                    return
                }
            }
        }
        navigateToNextScreen()
    }

    private fun showSelectPatientAndDatePopupError(message: Int, packageName: String) {
        val topBtnStyle = YabraaButtonStyle(R.color.brandPaletteDark800)
        YabraaDialogBuilder(requireActivity()).setIcon(ic_vector_orange_error)
            .setTitle(warning)
            .setMessageStringFormat(message, packageName)
            .setTopButton(ok, topBtnStyle) {
                handleEnabledConfirmationAppointmentBtn(true)
            }.setCancelable(false)
            .show()
    }

    private fun handleEnabledConfirmationAppointmentBtn(isEnabled: Boolean) =
        confirmationView?.handleEnabledConfirmationAppointmentBtn(isEnabled)


    private fun navigateToNextScreen() {
        showDelayProgressDialog {
            if (transactionViewModel.serviceTypeName == ServiceTypeName.NORMAL.typeValue) {
                navigate(actionSelectTimeAndDateFragmentToMapsFragment)
                return@showDelayProgressDialog
            }
            navigate(R.id.actionSelectTimeAndDateFragmentToCheckoutFragment)
        }
    }

    private fun ConfirmationAppointmentHandler.setOnCancelClicked() {
        setTextCancelBtn(R.string.cancel)
        setOnCancelClicked { handleClearData() }
    }

    private fun handleClearData() = showDelayProgressDialog {
        transactionViewModel.handleClearAllLists()
        if (transactionViewModel.serviceTypeName == ServiceTypeName.NORMAL.typeValue) {
            findNavController().popBackStack(R.id.homeFragment, false)
            return@showDelayProgressDialog
        }
        findNavController().popBackStack(R.id.remoteVisitFragment, false)
    }


    private fun showExpirationDateError() =
        tokenHandler.handleExpirationDate { showExpirationDatePopupError() }
}