package com.yabraa.medical.feature.fragments.allergies_and_chronic_diseases.allergies_fragment.di

import com.yabraa.medical.core.di.network_sevices.AllergiesAndChronicDiseasesServices
import com.yabraa.medical.feature.fragments.allergies_and_chronic_diseases.allergies_fragment.data.repository.AddAllergiesRepositoryImpl
import com.yabraa.medical.feature.fragments.allergies_and_chronic_diseases.allergies_fragment.data.repository.AllergiesByUserFamilyIdRepositoryImpl
import com.yabraa.medical.feature.fragments.allergies_and_chronic_diseases.allergies_fragment.data.repository.AllergiesRepositoryImpl
import com.yabraa.medical.feature.fragments.allergies_and_chronic_diseases.allergies_fragment.data.repository.DeleteAllergiesRepositoryImpl
import com.yabraa.medical.feature.fragments.allergies_and_chronic_diseases.allergies_fragment.domain.repository.AddAllergiesRepository
import com.yabraa.medical.feature.fragments.allergies_and_chronic_diseases.allergies_fragment.domain.repository.AllergiesByUserFamilyIdRepository
import com.yabraa.medical.feature.fragments.allergies_and_chronic_diseases.allergies_fragment.domain.repository.AllergiesRepository
import com.yabraa.medical.feature.fragments.allergies_and_chronic_diseases.allergies_fragment.domain.repository.DeleteAllergiesRepository
import dagger.Module
import dagger.Provides
import dagger.hilt.InstallIn
import dagger.hilt.android.components.ViewModelComponent

@Module
@InstallIn(ViewModelComponent::class)
object AllergiesModule {

    @Provides
    fun provideAllergiesRepositoryImpl(allergiesAndChronicDiseasesServices: AllergiesAndChronicDiseasesServices): AllergiesRepository =
        AllergiesRepositoryImpl(allergiesAndChronicDiseasesServices)

    @Provides
    fun provideAllergiesByUserFamilyIdRepositoryImpl(allergiesAndChronicDiseasesServices: AllergiesAndChronicDiseasesServices): AllergiesByUserFamilyIdRepository =
        AllergiesByUserFamilyIdRepositoryImpl(allergiesAndChronicDiseasesServices)


    @Provides
    fun provideAddAllergiesRepositoryImpl(allergiesAndChronicDiseasesServices: AllergiesAndChronicDiseasesServices): AddAllergiesRepository =
        AddAllergiesRepositoryImpl(allergiesAndChronicDiseasesServices)

    @Provides
    fun provideDeleteAllergiesRepositoryImpl(allergiesAndChronicDiseasesServices: AllergiesAndChronicDiseasesServices): DeleteAllergiesRepository =
        DeleteAllergiesRepositoryImpl(allergiesAndChronicDiseasesServices)
}