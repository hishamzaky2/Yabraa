package com.yabraa.medical.feature.fragments.allergies_and_chronic_diseases.past_medication_fragment.domain.usecase

import com.core.shared.state.State
import com.yabraa.medical.feature.fragments.allergies_and_chronic_diseases.past_medication_fragment.data.model.response.PastMedicationDataResponse
import com.yabraa.medical.feature.fragments.allergies_and_chronic_diseases.past_medication_fragment.data.model.response.PastMedicationResponseDto
import com.yabraa.medical.feature.fragments.allergies_and_chronic_diseases.past_medication_fragment.domain.model.PastMedicationEntityModel
import com.yabraa.medical.feature.fragments.allergies_and_chronic_diseases.past_medication_fragment.domain.repository.PastMedicationByUserFamilyIdRepository
import com.yabraa.medical.feature.fragments.allergies_and_chronic_diseases.past_medication_fragment.domain.repository.PastMedicationRepository
import kotlinx.coroutines.async
import kotlinx.coroutines.flow.Flow
import kotlinx.coroutines.flow.channelFlow
import javax.inject.Inject

class PastMedicationUseCase @Inject constructor(
    private val pastMedicationRepository: PastMedicationRepository,
    private val pastMedicationByUserFamilyIdRepository: PastMedicationByUserFamilyIdRepository
) {


    private var pastMedicationResponse: List<PastMedicationDataResponse>? = null

    private var pastMedicationByUserFamilyIdResponse: List<PastMedicationDataResponse>? = null

    suspend operator fun invoke(): Flow<State<PastMedicationResponseDto>> {
        return channelFlow {
            val response = async { pastMedicationRepository.getPastMedication() }
            response.await().collect {
                if (it is State.Success) {
                    pastMedicationResponse = it.data?.pastMedicationDataResponse
                }
                send(it)
            }
        }
    }

    suspend operator fun invoke(userFamilyId: Long): Flow<State<PastMedicationResponseDto>> {
        return channelFlow {
            val response =
                async {
                    pastMedicationByUserFamilyIdRepository.getPastMedicationByUserFamilyId(
                        userFamilyId
                    )
                }
            response.await().collect {
                if (it is State.Success) {
                    pastMedicationByUserFamilyIdResponse = it.data?.pastMedicationDataResponse
                }
                send(it)
            }
        }
    }


    fun getPastMedicationList(): List<PastMedicationEntityModel> {
        val pastMedicationEntityMap =
            getPastMedicationEntityList().associateBy { it.medicationId }.toMutableMap()
        pastMedicationByUserFamilyIdResponse?.map { it.medicationId }?.forEach {
            val newPastMedicationEntityModel = pastMedicationEntityMap[it] ?: return@forEach
            pastMedicationEntityMap[it] = newPastMedicationEntityModel.copy(isAdded = true)
        }
        return pastMedicationEntityMap.values.toList()
    }

    private fun getPastMedicationEntityList() = pastMedicationResponse?.map {
        PastMedicationEntityModel(
            medicationId = it.medicationId,
            titleAR = it.titleAR,
            titleEN = it.titleEN
        )
    } ?: emptyList()

}