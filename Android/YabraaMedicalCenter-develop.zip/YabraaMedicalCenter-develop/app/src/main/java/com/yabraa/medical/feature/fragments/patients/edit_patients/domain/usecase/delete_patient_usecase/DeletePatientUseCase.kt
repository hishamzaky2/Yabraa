package com.yabraa.medical.feature.fragments.patients.edit_patients.domain.usecase.delete_patient_usecase

import com.yabraa.medical.feature.fragments.patients.edit_patients.domain.repository.delete_patient_repository.DeletePatientRepository
import javax.inject.Inject

class DeletePatientUseCase @Inject constructor(private val deletePatientRepository: DeletePatientRepository) {


    suspend operator fun invoke(userFamilyId: Long) =
        deletePatientRepository.deletePatient(userFamilyId)
}