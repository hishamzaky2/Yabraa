package com.yabraa.medical.feature.fragments.login.domain.viewmodel

import androidx.lifecycle.ViewModel
import androidx.lifecycle.viewModelScope
import dagger.hilt.android.lifecycle.HiltViewModel
import kotlinx.coroutines.flow.MutableSharedFlow
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.SharedFlow
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.launch
import com.core.shared.error.EmptyPassword
import com.core.shared.error.EmptyPhoneNumber
import com.core.shared.error.YabraaError
import com.core.shared.state.State
import com.yabraa.medical.feature.fragments.login.data.model.response.LoginResponseDto
import com.yabraa.medical.feature.fragments.login.domain.model.LoginUiModel
import com.yabraa.medical.feature.fragments.login.domain.usecase.LoginUseCase
import javax.inject.Inject

@HiltViewModel
class LoginViewModel @Inject constructor(private val loginUseCase: LoginUseCase) : ViewModel() {

    private val _validationState = MutableSharedFlow<State<Any?>>()
    val validationState: SharedFlow<State<Any?>> = _validationState

    private val _loginResponseState = MutableStateFlow<State<LoginResponseDto>>(State.Initial())
    val loginResponse: StateFlow<State<LoginResponseDto>> = _loginResponseState


    fun validateInput(loginUiModel: LoginUiModel) {
        viewModelScope.launch {
            val isLoadingOrSuccess =
                loginResponse.value is State.Loading || loginResponse.value is State.Success
            if (isLoadingOrSuccess) {
                return@launch
            }
            loginUiModel.validateInput()
        }
    }

    private suspend fun LoginUiModel.validateInput() = when {
        phoneNumber.isEmpty() -> _validationState.emit(getValidationError(EmptyPhoneNumber()))
        password.isEmpty() -> _validationState.emit(getValidationError(EmptyPassword()))
        else -> onValidInput(this)
    }

    private fun <E> getValidationError(error: Exception) =
        State.Error<E>(YabraaError.I(exception = error))


    private suspend fun onValidInput(loginUiModel: LoginUiModel) {
        _validationState.emit(State.Success(null))
        _loginResponseState.emit(State.Loading())

        userLogin(loginUiModel)
    }

    private suspend fun userLogin(loginUiModel: LoginUiModel) {
        _loginResponseState.emit(State.Loading())
        loginUseCase(loginUiModel.toLogin()).collect {
            _loginResponseState.emit(it)
        }

    }
}