package com.yabraa.medical.feature.fragments.common.domain.model

import com.yabraa.medical.feature.fragments.home.data.model.response.services_details_response.PackageData
import com.yabraa.medical.feature.fragments.select_date_and_time.domain.model.NoteUi
import com.yabraa.medical.feature.fragments.select_date_and_time.domain.model.SelectDateAndTimeUi
import com.yabraa.medical.feature.fragments.select_date_and_time.domain.model.SelectPatientsUi

data class PackagesTransactionModel(
    val packageData: PackageData? = null,
    val dates: SelectDateAndTimeUi? = null,
    val patients: SelectPatientsUi? = null,
    val notes: NoteUi? = null
) {
    fun setPackagesTransactionModel(packagesTransactionModel: PackagesTransactionModel) =
        packagesTransactionModel

}