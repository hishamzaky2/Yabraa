package com.yabraa.medical.feature.fragments.onboard.data.response

import com.google.gson.annotations.SerializedName


data class StartPageDataResponse(
    @SerializedName("id")
    val id: Int,
    @SerializedName("titleEn")
    val titleEn: String,
    @SerializedName("subTitleEn")
    val subTitleEn: String,
    @SerializedName("titleAr")
    val titleAr: String,
    @SerializedName("subTitleAr")
    val subTitleAr: String,
    @SerializedName("path")
    val path: String
)