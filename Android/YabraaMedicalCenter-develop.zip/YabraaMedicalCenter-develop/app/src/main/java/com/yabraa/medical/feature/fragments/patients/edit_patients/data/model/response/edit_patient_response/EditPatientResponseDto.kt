package com.yabraa.medical.feature.fragments.patients.edit_patients.data.model.response.edit_patient_response


import com.google.gson.annotations.SerializedName

data class EditPatientResponseDto(
    @SerializedName("data")
    val editPatientResponse: EditPatientResponse,
    @SerializedName("errorMessageAr")
    val errorMessageAr: String? = null,
    @SerializedName("errorMessageEn")
    val errorMessageEn: String? = null,
    @SerializedName("statusCode")
    val statusCode: Int
)