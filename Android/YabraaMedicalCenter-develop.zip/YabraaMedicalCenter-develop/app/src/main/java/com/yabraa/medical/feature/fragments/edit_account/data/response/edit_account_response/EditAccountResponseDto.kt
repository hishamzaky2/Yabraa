package com.yabraa.medical.feature.fragments.edit_account.data.response.edit_account_response


import com.google.gson.annotations.SerializedName

data class EditAccountResponseDto(
    @SerializedName("data")
    val editState: String,
    @SerializedName("errorMessageAr")
    val errorMessageAr: String? = null,
    @SerializedName("errorMessageEn")
    val errorMessageEn: String? = null,
    @SerializedName("statusCode")
    val statusCode: Int
)