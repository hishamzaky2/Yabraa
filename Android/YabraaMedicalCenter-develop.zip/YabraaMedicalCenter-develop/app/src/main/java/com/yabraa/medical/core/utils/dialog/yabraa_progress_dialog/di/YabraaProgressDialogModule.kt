package com.yabraa.medical.core.utils.dialog.yabraa_progress_dialog.di

import android.app.Activity
import dagger.Module
import dagger.Provides
import dagger.hilt.InstallIn
import dagger.hilt.android.components.ActivityComponent
import com.yabraa.medical.core.utils.dialog.yabraa_progress_dialog.YabraaProgressDialog

@Module
@InstallIn(ActivityComponent::class)
object YabraaProgressDialogModule {

    @Provides
    fun provideYabraaProgressDialog(activity: Activity) = YabraaProgressDialog(activity)
}