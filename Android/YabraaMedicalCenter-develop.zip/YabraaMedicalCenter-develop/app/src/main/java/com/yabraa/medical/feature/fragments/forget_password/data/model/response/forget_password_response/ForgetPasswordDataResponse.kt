package com.yabraa.medical.feature.fragments.forget_password.data.model.response.forget_password_response

import com.google.gson.annotations.SerializedName


data class ForgetPasswordDataResponse(
    @SerializedName("phoneNumber")
    val phoneNumber: String,
    @SerializedName("token")
    val token: String,
    @SerializedName("verificationCode")
    val verificationCode: String
)