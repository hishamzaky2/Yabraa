package com.yabraa.medical.feature.fragments.checkout.domain.model

enum class PaymentCardUtils(val value: String) {
    Apple_Pay("Apple_Pay"), VISA("VISA"), MASTER("MASTER"), MADA("MADA"), STC_PAY("STC")
}