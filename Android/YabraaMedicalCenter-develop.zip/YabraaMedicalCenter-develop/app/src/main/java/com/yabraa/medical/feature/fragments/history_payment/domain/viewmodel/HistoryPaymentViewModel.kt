package com.yabraa.medical.feature.fragments.history_payment.domain.viewmodel

import androidx.lifecycle.ViewModel
import androidx.lifecycle.viewModelScope
import com.core.shared.state.State
import com.yabraa.medical.feature.fragments.history_payment.data.model.HistoryPaymentResponseDto
import com.yabraa.medical.feature.fragments.history_payment.domain.usecase.HistoryPaymentUseCse
import dagger.hilt.android.lifecycle.HiltViewModel
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.launch
import javax.inject.Inject

@HiltViewModel
class HistoryPaymentViewModel @Inject constructor(private val historyPaymentUseCse: HistoryPaymentUseCse) :
    ViewModel() {


    private val _historyPaymentResponseState =
        MutableStateFlow<State<HistoryPaymentResponseDto>>(State.Initial())
    val historyPaymentResponseState: StateFlow<State<HistoryPaymentResponseDto>> =
        _historyPaymentResponseState

    fun getHistoryPayment() {
        viewModelScope.launch {
            _historyPaymentResponseState.emit(State.Loading())
            historyPaymentUseCse().collect {
                _historyPaymentResponseState.emit(it)
            }
        }
    }


    fun getHistoryPaymentList() = historyPaymentUseCse.getHistoryPaymentList()
}