package com.yabraa.medical.feature.fragments.forget_password.domain.model

import com.yabraa.medical.feature.fragments.forget_password.data.model.request.ResetPasswordRequestDto

data class ResetPasswordUiModel(
    var phoneNumber: String,
    var token: String,
    var verificationCode: String,
    var password: String,
    var confirmPassword: String
) {
    fun toResetPassword() = ResetPasswordRequestDto(
        phoneNumber = phoneNumber,
        token = token,
        verificationCode = verificationCode,
        password = password,
        confirmPassword = confirmPassword
    )
}