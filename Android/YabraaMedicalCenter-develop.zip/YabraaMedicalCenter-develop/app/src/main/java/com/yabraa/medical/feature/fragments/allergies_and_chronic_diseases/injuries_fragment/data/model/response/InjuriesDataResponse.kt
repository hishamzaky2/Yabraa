package com.yabraa.medical.feature.fragments.allergies_and_chronic_diseases.injuries_fragment.data.model.response


import com.google.gson.annotations.SerializedName

data class InjuriesDataResponse(
    @SerializedName("injuryId")
    val injuryId: Long,
    @SerializedName("titleAR")
    val titleAR: String,
    @SerializedName("titleEN")
    val titleEN: String
)