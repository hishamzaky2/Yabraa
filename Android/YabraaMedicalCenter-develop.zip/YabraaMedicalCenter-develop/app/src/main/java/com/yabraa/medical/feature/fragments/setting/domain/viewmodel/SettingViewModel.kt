package com.yabraa.medical.feature.fragments.setting.domain.viewmodel

import androidx.lifecycle.ViewModel
import androidx.lifecycle.viewModelScope
import com.core.shared.state.State
import com.yabraa.medical.feature.fragments.setting.data.model.response.delete_account_response.DeleteAccountResponseDto
import com.yabraa.medical.feature.fragments.setting.data.model.response.user_information_response.UserInformationResponseDto
import com.yabraa.medical.feature.fragments.setting.domain.repository.delete_account_repository.DeleteAccountRepository
import com.yabraa.medical.feature.fragments.setting.domain.usecase.UserInformationUseCase
import dagger.hilt.android.lifecycle.HiltViewModel
import kotlinx.coroutines.flow.MutableSharedFlow
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.SharedFlow
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.launch
import javax.inject.Inject

@HiltViewModel
class SettingViewModel @Inject constructor(
    private val deleteAccountRepository: DeleteAccountRepository,
    private val getUserInformationUseCase: UserInformationUseCase
) : ViewModel() {

    var yabraaBarTitle: String? = null
    var userFamilyId : Long? = null

    private val _deleteAccountResponseState = MutableSharedFlow<State<DeleteAccountResponseDto>>()
    val deleteAccountResponseState: SharedFlow<State<DeleteAccountResponseDto>> =
        _deleteAccountResponseState

    private val _getUserInformationResponseState =
        MutableStateFlow<State<UserInformationResponseDto>>(State.Initial())
    val getUserInformationResponseState: StateFlow<State<UserInformationResponseDto>> =
        _getUserInformationResponseState

    fun deleteAccount() {
        viewModelScope.launch {
            _deleteAccountResponseState.emit(State.Loading())
            deleteAccountRepository.deleteAccount().collect {
                _deleteAccountResponseState.emit(it)
            }
        }
    }

    fun getUserInformation() {
        viewModelScope.launch {
            _getUserInformationResponseState.emit(State.Loading())
            getUserInformationUseCase().collect {
                _getUserInformationResponseState.emit(it)
            }
        }
    }

    fun getUserInfo() = getUserInformationUseCase.getUserInformation()
}