package com.yabraa.medical.feature.fragments.allergies_and_chronic_diseases.chronic_diseases_fragment.domain.usecase

import com.core.shared.state.State
import com.yabraa.medical.feature.fragments.allergies_and_chronic_diseases.chronic_diseases_fragment.data.model.response.ChronicDiseasesDataResponse
import com.yabraa.medical.feature.fragments.allergies_and_chronic_diseases.chronic_diseases_fragment.domain.repository.ChronicDiseasesByUserFamilyIdRepository
import com.yabraa.medical.feature.fragments.allergies_and_chronic_diseases.chronic_diseases_fragment.domain.repository.ChronicDiseasesRepository
import com.yabraa.medical.feature.fragments.allergies_and_chronic_diseases.chronic_diseases_fragment.data.model.response.ChronicDiseasesResponseDto
import com.yabraa.medical.feature.fragments.allergies_and_chronic_diseases.chronic_diseases_fragment.domain.model.ChronicDiseasesEntityModel
import kotlinx.coroutines.async
import kotlinx.coroutines.flow.Flow
import kotlinx.coroutines.flow.channelFlow
import javax.inject.Inject


class ChronicDiseasesUseCase @Inject constructor(
    private val chronicDiseasesRepository: ChronicDiseasesRepository,
    private val chronicDiseasesByUserFamilyIdRepository: ChronicDiseasesByUserFamilyIdRepository
) {


    private var chronicDiseasesResponse: List<ChronicDiseasesDataResponse>? = null

    private var chronicDiseasesByUserFamilyIdResponse: List<ChronicDiseasesDataResponse>? = null

    suspend operator fun invoke(): Flow<State<ChronicDiseasesResponseDto>> {
        return channelFlow {
            val response = async { chronicDiseasesRepository.getChronicDiseases() }
            response.await().collect {
                if (it is State.Success) {
                    chronicDiseasesResponse = it.data?.chronicDiseasesDataResponse
                }
                send(it)
            }
        }
    }

    suspend operator fun invoke(userFamilyId: Long): Flow<State<ChronicDiseasesResponseDto>> {
        return channelFlow {
            val response =
                async {
                    chronicDiseasesByUserFamilyIdRepository.getChronicDiseasesByUserFamilyId(
                        userFamilyId
                    )
                }
            response.await().collect {
                if (it is State.Success) {
                    chronicDiseasesByUserFamilyIdResponse =
                        it.data?.chronicDiseasesDataResponse
                }
                send(it)
            }
        }
    }


    fun getChronicDiseasesList(): List<ChronicDiseasesEntityModel> {
        val chronicDiseasesEntityMap =
            getChronicDiseasesEntityList().associateBy { it.chronicDiseaseId }.toMutableMap()
        chronicDiseasesByUserFamilyIdResponse?.map { it.chronicDiseaseId }?.forEach {
            val newChronicDiseasesEntityModel = chronicDiseasesEntityMap[it] ?: return@forEach
            chronicDiseasesEntityMap[it] = newChronicDiseasesEntityModel.copy(isAdded = true)
        }
        return chronicDiseasesEntityMap.values.toList()
    }

    private fun getChronicDiseasesEntityList() = chronicDiseasesResponse?.map {
        ChronicDiseasesEntityModel(
            chronicDiseaseId = it.chronicDiseaseId,
            titleAR = it.titleAR,
            titleEN = it.titleEN
        )
    } ?: emptyList()
}