package com.yabraa.medical.feature.fragments.checkout.data.model.response.payment_response

import com.google.gson.annotations.SerializedName


data class PaymentResponse(
    @SerializedName("code")
    val code: String,
    @SerializedName("description")
    val description: String
)