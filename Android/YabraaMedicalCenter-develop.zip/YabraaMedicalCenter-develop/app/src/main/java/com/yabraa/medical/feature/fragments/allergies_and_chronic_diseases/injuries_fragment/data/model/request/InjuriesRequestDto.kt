package com.yabraa.medical.feature.fragments.allergies_and_chronic_diseases.injuries_fragment.data.model.request

data class InjuriesRequestDto(var injuryId: Long, var userFamilyId: Long)