package com.yabraa.medical.feature.fragments.patients.add_patient.data.repository

import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.flow.flow
import kotlinx.coroutines.flow.flowOn
import com.yabraa.medical.core.base_repository.BaseRepository
import com.yabraa.medical.core.di.network_sevices.YabraaServices
import com.core.shared.state.State
import com.yabraa.medical.core.utils.getResponseMessageError
import com.yabraa.medical.feature.fragments.patients.add_patient.data.model.reposne.AddPatientResponseDto
import com.yabraa.medical.feature.fragments.patients.add_patient.data.model.request.AddPatientRequest
import com.yabraa.medical.feature.fragments.patients.add_patient.domain.repository.AddPatientRepository
import retrofit2.Response
import javax.inject.Inject

const val TAG_ADD_PATIENT_RESPONSE = "TAG_ADD_PATIENT_RESPONSE"

class AddPatientRepositoryImpl @Inject constructor(private val yabraaServices: YabraaServices) :
    BaseRepository<AddPatientRequest, AddPatientResponseDto>(), AddPatientRepository {


    override suspend fun addPatient(addPatientRequest: AddPatientRequest) = flow {
        emit(getOperationState(addPatientRequest))
    }.flowOn(Dispatchers.IO)


    override suspend fun performApiCall(requestDto: AddPatientRequest): State<AddPatientResponseDto> {
        val response = yabraaServices.addPatient(requestDto)
        return handAddPatientResponse(response)
    }


    private fun handAddPatientResponse(response: Response<AddPatientResponseDto>): State<AddPatientResponseDto> {
        val responseBody = response.body()
        val errorMessageEn = responseBody?.errorMessageEn ?: ""
        val errorMessageAr = responseBody?.errorMessageAr ?: ""
        return when {
            response.isSuccessful && responseBody?.ddPatientResponse != null ->
                State.Success(response.body())

            response.isSuccessful && !responseBody?.errorMessageEn.isNullOrEmpty() -> getResponseMessageError(
                errorMessageEn = errorMessageEn,
                errorMessageAr = errorMessageAr,
                logTag = TAG_ADD_PATIENT_RESPONSE
            )

            else -> getNotSuccessfulResponseState(response)
        }
    }
}