package com.yabraa.medical.feature.fragments.appointment.my_appointment.presentation.adapter

import android.annotation.SuppressLint
import android.content.res.ColorStateList
import android.graphics.Color
import android.view.LayoutInflater
import android.view.ViewGroup
import androidx.core.content.ContextCompat.getColorStateList
import androidx.core.view.isVisible
import androidx.recyclerview.widget.RecyclerView
import com.yabraa.medical.R
import com.yabraa.medical.R.color.primaryLight100
import com.yabraa.medical.R.color.primaryLight400
import com.yabraa.medical.R.string.price
import com.core.shared.utils.CommonUtils.decodeDateString
import com.core.shared.utils.CommonUtils.getDatePlusTwentyFourHour
import com.core.shared.utils.CommonUtils.getLocalizedValue
import com.core.shared.utils.CommonUtils.sendPhoneNumberToDial
import com.yabraa.medical.databinding.ItemMyAppointmentBinding
import com.yabraa.medical.feature.fragments.appointment.my_appointment.data.model.response.MyAppointmentResponse
import com.yabraa.medical.feature.fragments.appointment.my_appointment.domain.model.MyAppointmentStatus
import java.util.Locale

class MyAppointmentAdapter(
    private val items: MutableList<MyAppointmentResponse>,
    private val onItemClicked: (MyAppointmentResponse) -> Unit
) :
    RecyclerView.Adapter<MyAppointmentAdapter.ViewHolder>() {

    lateinit var setOnAppointmentCallback: MyAppointmentListener
    override fun onCreateViewHolder(parent: ViewGroup, viewType: Int): ViewHolder {
        val binding =
            ItemMyAppointmentBinding.inflate(LayoutInflater.from(parent.context), parent, false)
        return ViewHolder(binding)
    }

    override fun onBindViewHolder(viewHolder: ViewHolder, position: Int) {
        val item = items[position]
        viewHolder.bind(item)
    }

    override fun getItemCount() = items.size

    override fun getItemViewType(position: Int) = position


    inner class ViewHolder(private val binding: ItemMyAppointmentBinding) :
        RecyclerView.ViewHolder(binding.root) {
        fun bind(item: MyAppointmentResponse) {
            binding.setUpViews(item)
        }


        private fun ItemMyAppointmentBinding.setUpViews(item: MyAppointmentResponse) {
            handleAppointmentStatus(item)
            servicesNameTv.text = getLocalizedValue(item.packageNameEN, item.packageNameAR)
            dateTv.text = decodeDateString(item.visitDT, "yyyy-MM-dd")
            timeTv.text = decodeDateString(item.visitTime, "hh:mm")
            priceTv.text = String.format(Locale.ENGLISH, root.context.getString(price), item.price)
            patientNameTv.text = item.userFamilyName
            openLocationIv.setOnClickListener { onItemClicked(item) }
            appointmentBtn.setOnClickListener {
                setOnAppointmentCallback.setOnAppointmentClicked(item)
            }
            setOnPhoneNumberClicked()
        }

        @SuppressLint("ResourceAsColor")
        private fun ItemMyAppointmentBinding.handleAppointmentStatus(item: MyAppointmentResponse) {
            when (item.status) {
                MyAppointmentStatus.PENDING.value -> {
                    handleUiCancelButton(item)
                    setCardBackGroundColor("#771104")
                }

                MyAppointmentStatus.REJECTED.value -> {
                    setCardBackGroundColor("#292D32")
                }

                MyAppointmentStatus.DONE.value -> {
                    handleAppointmentDetailsVisibilityState(true)
                    setCardBackGroundColor("#AEB8C2")
                }

                MyAppointmentStatus.CANCELED.value -> {
                    setCardBackGroundColor("#292D32")
                    handleCancelAppointmentVisibilityState(true)
                }
            }
        }


        private fun ItemMyAppointmentBinding.handleUiCancelButton(item: MyAppointmentResponse) {
            appointmentBtn.setText(R.string.canceledThisAppointment)
            appointmentBtn.setTextColor(Color.parseColor("#771104"))
            appointmentBtn.rippleColor = getColorStateList(binding.root.context, primaryLight400)
            appointmentBtn.backgroundTintList =
                getColorStateList(binding.root.context, primaryLight100)
            handleCancelAppointmentVisibility(item)
        }

        private fun ItemMyAppointmentBinding.handleCancelAppointmentVisibility(item: MyAppointmentResponse) {
            val pattern = "yyyy-MM-dd'T'HH:mm:ss"
            val datePlusTwentyFourHour = getDatePlusTwentyFourHour(pattern)
            val appointmentDate = decodeDateString(item.visitDT, pattern) ?: ""
            val isCanceledAppointment = appointmentDate <= datePlusTwentyFourHour
            handleCancelAppointmentVisibilityState(isCanceledAppointment)
        }

        private fun ItemMyAppointmentBinding.setCardBackGroundColor(color: String) =
            itemCard.setCardBackgroundColor(ColorStateList.valueOf(Color.parseColor(color)))
    }

    private fun ItemMyAppointmentBinding.handleAppointmentDetailsVisibilityState(isVisible: Boolean) {
        openLocationIv.isVisible = !isVisible
        appointmentBtn.isVisible = isVisible
    }

    private fun ItemMyAppointmentBinding.handleCancelAppointmentVisibilityState(isVisible: Boolean) {
        openLocationIv.isVisible = !isVisible
        appointmentBtn.isVisible = !isVisible
        cancelAppointmentGroup.isVisible = !isVisible
    }


    private fun ItemMyAppointmentBinding.setOnPhoneNumberClicked() =
        phoneNumberTv.setOnClickListener {
            sendPhoneNumberToDial(root.context, root.context.getString(R.string.yabraaPhone))
        }

    fun initializeSetOnAppointmentDetailsCallback(callback: MyAppointmentListener) {
        setOnAppointmentCallback = callback
    }

    interface MyAppointmentListener {
        fun setOnAppointmentClicked(item: MyAppointmentResponse)
    }
}