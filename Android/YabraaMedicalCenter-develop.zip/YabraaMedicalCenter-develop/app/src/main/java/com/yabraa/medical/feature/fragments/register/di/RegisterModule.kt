package com.yabraa.medical.feature.fragments.register.di

import dagger.Module
import dagger.Provides
import dagger.hilt.InstallIn
import dagger.hilt.android.components.ViewModelComponent
import com.yabraa.medical.core.di.network_sevices.SecurityServices
import com.yabraa.medical.feature.fragments.register.data.repository.NationalityRepositoryImpl
import com.yabraa.medical.feature.fragments.register.data.repository.RegisterRepositoryImpl
import com.yabraa.medical.feature.fragments.register.data.repository.UserInputsValidationRepositoryImpl
import com.yabraa.medical.feature.fragments.register.domain.repository.NationalityRepository
import com.yabraa.medical.feature.fragments.register.domain.repository.RegisterRepository
import com.yabraa.medical.feature.fragments.register.domain.repository.UserInputsValidationRepository


@Module
@InstallIn(ViewModelComponent::class)
object RegisterModule {

    @Provides
    fun provideUserInputValidationRepository(securityServices: SecurityServices) : UserInputsValidationRepository = UserInputsValidationRepositoryImpl(securityServices)

    @Provides
    fun provideRegisterRepository(securityServices: SecurityServices): RegisterRepository =
        RegisterRepositoryImpl(securityServices)

    @Provides
    fun provideNationalityRepository(securityServices: SecurityServices): NationalityRepository =
        NationalityRepositoryImpl(securityServices)

}