package com.yabraa.medical.feature.fragments.notification.notification_hisotry.domain.repository.notification_status_repository

import com.core.shared.state.State
import com.yabraa.medical.feature.fragments.notification.notification_hisotry.data.model.request.notification_history_request.NotificationHistoryRequestDto
import com.yabraa.medical.feature.fragments.notification.notification_hisotry.data.model.response.notification_history_response.NotificationHistoryResponseDto
import kotlinx.coroutines.flow.Flow

interface NotificationStatusRepository {

    suspend fun getNotificationStatus(requestDto : NotificationHistoryRequestDto): Flow<State<NotificationHistoryResponseDto>>
}