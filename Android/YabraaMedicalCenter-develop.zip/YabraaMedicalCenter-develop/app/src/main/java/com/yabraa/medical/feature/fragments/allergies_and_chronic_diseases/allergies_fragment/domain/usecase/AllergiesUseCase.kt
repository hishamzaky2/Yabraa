package com.yabraa.medical.feature.fragments.allergies_and_chronic_diseases.allergies_fragment.domain.usecase

import com.core.shared.state.State
import com.yabraa.medical.feature.fragments.allergies_and_chronic_diseases.allergies_fragment.data.model.response.AllergiesDataResponse
import com.yabraa.medical.feature.fragments.allergies_and_chronic_diseases.allergies_fragment.data.model.response.AllergiesResponseDto
import com.yabraa.medical.feature.fragments.allergies_and_chronic_diseases.allergies_fragment.domain.model.AllergiesEntityModel
import com.yabraa.medical.feature.fragments.allergies_and_chronic_diseases.allergies_fragment.domain.repository.AllergiesByUserFamilyIdRepository
import com.yabraa.medical.feature.fragments.allergies_and_chronic_diseases.allergies_fragment.domain.repository.AllergiesRepository
import kotlinx.coroutines.async
import kotlinx.coroutines.flow.Flow
import kotlinx.coroutines.flow.channelFlow
import javax.inject.Inject

class AllergiesUseCase @Inject constructor(
    private val allergiesRepository: AllergiesRepository,
    private val allergiesByUserFamilyIdRepository: AllergiesByUserFamilyIdRepository
) {

    private var allergiesResponse: List<AllergiesDataResponse>? = null

    private var allergiesByUserFamilyIdResponse: List<AllergiesDataResponse>? = null
    suspend operator fun invoke(): Flow<State<AllergiesResponseDto>> {
        return channelFlow {
            val response = async { allergiesRepository.getAllergies() }
            response.await().collect {
                if (it is State.Success) {
                    allergiesResponse = it.data?.allergiesDataResponse
                }
                send(it)
            }
        }
    }

    suspend operator fun invoke(userFamilyId: Long): Flow<State<AllergiesResponseDto>> {
        return channelFlow {
            val response =
                async { allergiesByUserFamilyIdRepository.getAllergiesByUserFamilyId(userFamilyId) }
            response.await().collect {
                if (it is State.Success) {
                    allergiesByUserFamilyIdResponse =
                        it.data?.allergiesDataResponse
                }
                send(it)
            }
        }
    }


    fun getAllergiesList(): List<AllergiesEntityModel> {
        val allergiesEntityMap =
            getAllergiesEntityList().associateBy { it.allergyId }.toMutableMap()
        allergiesByUserFamilyIdResponse?.map { it.allergyId }?.forEach {
            val newAllergiesEntityModel = allergiesEntityMap[it] ?: return@forEach
            allergiesEntityMap[it] = newAllergiesEntityModel.copy(isAdded = true)
        }
        return allergiesEntityMap.values.toList()
    }

    private fun getAllergiesEntityList() = allergiesResponse?.map {
        AllergiesEntityModel(allergyId = it.allergyId, titleAR = it.titleAR, titleEN = it.titleEN)
    } ?: emptyList()
}
