package com.yabraa.medical.feature.fragments.register.data.request

enum class GenderType(val genderValue: String) {
    MALE("Male"), FEMALE("Female")
}