package com.yabraa.medical.core.base_fragment

import android.content.Context
import android.net.Network
import android.os.Bundle
import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import android.view.inputmethod.InputMethodManager
import android.widget.Toast
import androidx.databinding.ViewDataBinding
import androidx.fragment.app.Fragment
import androidx.lifecycle.lifecycleScope
import com.jakewharton.processphoenix.ProcessPhoenix
import com.core.shared.error.GeneralException
import com.core.shared.error.IoException
import com.core.shared.error.ResponseError
import com.core.shared.error.ResponseUnAuthorizedError
import com.core.shared.error.YabraaError
import com.core.shared.error.YabraaErrorHandler
import com.yabraa.medical.R
import com.core.shared.connectivity.connectivity_manager.NetworkAwareComponent
import com.core.shared.local_helper.LocaleHelper
import com.core.shared.storage_manager.StorageManager
import com.core.shared.storage_manager.di.StorageManagerModule.SHARED_PREFERENCE
import com.core.shared.token_utils.TokenHandler
import com.yabraa.medical.core.utils.custom_views.confirmation_appointment.ConfirmationAppointmentHandler
import com.yabraa.medical.core.utils.custom_views.yabraa_bar.YabraaBarHandler
import com.yabraa.medical.core.utils.dialog.snack_bar.YabraaSnackBarBuilder
import com.yabraa.medical.core.utils.dialog.yabraa_dialog.YabraaDialogBuilder
import com.yabraa.medical.core.utils.dialog.yabraa_progress_dialog.YabraaProgressDialog
import com.yabraa.medical.core.utils.showToast
import com.yabraa.medical.feature.activits.mainactivity.MainActivity
import com.yabraa.medical.feature.fragments.main.BottomNavigationStatus
import kotlinx.coroutines.delay
import kotlinx.coroutines.launch
import javax.inject.Inject
import javax.inject.Named

const val SKIP_ONBOARD_SCREEN = "SKIP_ONBOARD_SCREEN"

abstract class BaseFragment<dataBinding : ViewDataBinding> : Fragment(), NetworkAwareComponent {

    abstract val binding: dataBinding

    protected val connectivityManager get() = (activity as? MainActivity)?.connectivityManager

    @Inject
    lateinit var localeHelper: LocaleHelper

    @Inject
    @Named(SHARED_PREFERENCE)
    lateinit var sharedPreference: StorageManager

    @Inject
    lateinit var yabraaProgressDialog: YabraaProgressDialog


    @Inject
    lateinit var yabraaSnackBarBuilder: YabraaSnackBarBuilder

    protected val yabraaBarView get() = (activity as? YabraaBarHandler)
    protected val confirmationView get() = (parentFragment?.parentFragment as? ConfirmationAppointmentHandler)

    protected val inputMethodManager
        get() = context?.getSystemService(Context.INPUT_METHOD_SERVICE) as? InputMethodManager


    @Inject
    protected lateinit var tokenHandler: TokenHandler


    override fun onCreateView(
        inflater: LayoutInflater, container: ViewGroup?, savedInstanceState: Bundle?
    ): View? {
        return binding.root
    }

    fun Int.localize() = getString(this)

    fun Int.localize(vararg args: Any) = getString(this, *args)

    fun Int.showShortToast() = requireActivity().showToast(localize(), Toast.LENGTH_SHORT)

    fun showShortToast(message: String) = requireActivity().showToast(message, Toast.LENGTH_SHORT)

    fun Int.showLongToast() = showLongToast(localize())

    fun showLongToast(message: String) = requireActivity().showToast(message)


    fun showProgressDialog() = yabraaProgressDialog.show()

    fun hideProgressDialog() = yabraaProgressDialog.dismiss()


    override fun onNetworkAvailable(network: Network) {

    }

    override fun onNetworkLost(network: Network) {
        //TODO NO NEED SHOW ANY MESSAGE HERE
    }


    protected fun showKeyboard(view: View) {
        inputMethodManager?.showSoftInput(view, InputMethodManager.SHOW_IMPLICIT)
    }

    protected fun hideKeyboard(view: View) {
        inputMethodManager?.hideSoftInputFromWindow(view.windowToken, 0)
    }

    fun handleSkipOnboardScreen() {
        sharedPreference.setBoolean(SKIP_ONBOARD_SCREEN, true)
        navigate(R.id.actionviewPagerFragmentToLoginFragment)
    }


    protected fun showDelayProgressDialog(callbackAction: () -> Unit) {
        lifecycleScope.launch {
            showProgressDialog()
            delay(400)
            callbackAction()
            hideProgressDialog()
        }
    }


    protected fun showNetworkConnectionErrorPopup() {
        YabraaDialogBuilder(requireActivity()).setIcon(R.drawable.ic_vector_no_internet_connection)
            .setTitle(R.string.noInternetConnection)
            .setMessage(R.string.doNotHaveConnectionWithInternet).setTopButton(R.string.ok) { }
            .setCancelable(false).show()
    }


    protected fun showExpirationDatePopupError() {
        YabraaDialogBuilder(requireActivity()).setIcon(R.drawable.ic_vector_error)
            .setTitle(R.string.loginHasExpired)
            .setMessage(R.string.goToLoginAgain)
            .setTopButton(R.string.login) { handleApplicationRestart() }.setCancelable(false).show()
    }

    protected fun handleApplicationRestart() = ProcessPhoenix.triggerRebirth(requireActivity())

    fun YabraaError.handleError(callback: YabraaError.() -> Unit) {
        (activity as? YabraaErrorHandler)?.handleError(this) {
            when (exception) {
                is GeneralException -> handleGeneralExceptionError()
                is IoException -> handleIoExceptionError()
                is ResponseError -> handleGeneralResponseError()
                is ResponseUnAuthorizedError -> handleUnauthorizedError()
                else -> handleOtherErrors(this)
            }
        }
        callback()
    }


    protected open fun handleOtherErrors(error: YabraaError): YabraaError {
        return error
    }

    protected open fun handleGeneralExceptionError() {
        showShortToast(R.string.genericErrorMessage.localize())
    }

    protected open fun handleIoExceptionError() {
        showShortToast(R.string.genericErrorMessage.localize())
    }

    protected open fun handleGeneralResponseError() {
        showShortToast(R.string.genericErrorMessage.localize())
    }

    protected open fun handleUnauthorizedError() {
        showShortToast(R.string.genericErrorMessage.localize())
    }

    protected open fun showBottomNavigation(show: Boolean) {
        (parentFragment?.parentFragment as? BottomNavigationStatus)?.showBottomNavigation(show)
    }

    protected fun showYabraaBar(show: Boolean) =
        (activity as? YabraaBarHandler)?.setYabraaBarVisibility(show)
}