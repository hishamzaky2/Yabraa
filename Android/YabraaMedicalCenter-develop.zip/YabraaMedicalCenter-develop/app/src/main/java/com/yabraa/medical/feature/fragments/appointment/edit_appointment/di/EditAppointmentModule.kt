package com.yabraa.medical.feature.fragments.appointment.edit_appointment.di

import com.yabraa.medical.core.di.network_sevices.YabraaServices
import com.yabraa.medical.feature.fragments.appointment.edit_appointment.data.repository.EditAppointmentRepositoryImpl
import com.yabraa.medical.feature.fragments.appointment.edit_appointment.data.repository.GetAppointmentByIdRepositoryImp
import com.yabraa.medical.feature.fragments.appointment.edit_appointment.domain.repository.EditAppointmentRepository
import com.yabraa.medical.feature.fragments.appointment.edit_appointment.domain.repository.GetAppointmentByIdRepository
import dagger.Module
import dagger.Provides
import dagger.hilt.InstallIn
import dagger.hilt.android.components.ViewModelComponent

@Module
@InstallIn(ViewModelComponent::class)
object EditAppointmentModule {


    @Provides
    fun provideGetAppointmentByIdRepository(yabraaServices: YabraaServices): GetAppointmentByIdRepository =
        GetAppointmentByIdRepositoryImp(yabraaServices)

    @Provides
    fun provideEditAppointmentRepository(yabraaServices: YabraaServices): EditAppointmentRepository =
        EditAppointmentRepositoryImpl(yabraaServices)
}