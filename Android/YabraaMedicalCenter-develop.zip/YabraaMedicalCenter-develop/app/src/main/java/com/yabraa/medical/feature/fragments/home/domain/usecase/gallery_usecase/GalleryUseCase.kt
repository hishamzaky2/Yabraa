package com.yabraa.medical.feature.fragments.home.domain.usecase.gallery_usecase

import com.yabraa.medical.feature.fragments.home.domain.repository.gallery_repository.GalleryRepository
import javax.inject.Inject

class GalleryUseCase @Inject constructor(private val galleryRepository: GalleryRepository) {

    suspend operator fun invoke() = galleryRepository.getGallery()
}