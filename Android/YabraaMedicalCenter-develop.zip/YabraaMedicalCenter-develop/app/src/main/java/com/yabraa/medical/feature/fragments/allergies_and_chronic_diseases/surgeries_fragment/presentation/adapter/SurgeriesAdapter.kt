package com.yabraa.medical.feature.fragments.allergies_and_chronic_diseases.surgeries_fragment.presentation.adapter

import android.view.LayoutInflater
import android.view.ViewGroup
import androidx.core.view.isVisible
import androidx.recyclerview.widget.RecyclerView
import com.core.shared.utils.CommonUtils
import com.yabraa.medical.databinding.ItemGeneralAllergiesAndDiseasesBinding
import com.yabraa.medical.feature.fragments.allergies_and_chronic_diseases.surgeries_fragment.domain.model.SurgeriesEntityModel

class SurgeriesAdapter(
    private val surgeriesItems: List<SurgeriesEntityModel>,
    private val onAddItemClicked: (Long) -> Unit,
    private val onDeleteItemClicked: (Long) -> Unit
) : RecyclerView.Adapter<SurgeriesAdapter.ViewHolder>() {


    override fun onCreateViewHolder(parent: ViewGroup, viewType: Int): ViewHolder {
        val binding = ItemGeneralAllergiesAndDiseasesBinding.inflate(
            LayoutInflater.from(parent.context),
            parent,
            false
        )
        return ViewHolder(binding)
    }

    override fun onBindViewHolder(viewHolder: ViewHolder, position: Int) {
        val surgeriesItems = surgeriesItems[position]
        viewHolder.bin(surgeriesItems)
    }

    override fun getItemCount() = surgeriesItems.size

    override fun getItemViewType(position: Int) = position


    inner class ViewHolder(val binding: ItemGeneralAllergiesAndDiseasesBinding) :
        RecyclerView.ViewHolder(binding.root) {
        fun bin(item: SurgeriesEntityModel) {
            binding.setUpViews(item)
        }

        private fun ItemGeneralAllergiesAndDiseasesBinding.setUpViews(item: SurgeriesEntityModel) {
            addBtn.setOnClickListener { onAddItemClicked(item.surgeryId) }
            deleteBtn.setOnClickListener { onDeleteItemClicked(item.surgeryId) }
            titleTv.text = CommonUtils.getLocalizedValue(item.titleEN, item.titleAR)
            handleAddBtnVisibility(item.isAdded)
        }

        private fun ItemGeneralAllergiesAndDiseasesBinding.handleAddBtnVisibility(isShow: Boolean) {
            checkIv.isVisible = isShow
            addBtn.isVisible = !isShow
            deleteBtn.isVisible = isShow
        }
    }
}