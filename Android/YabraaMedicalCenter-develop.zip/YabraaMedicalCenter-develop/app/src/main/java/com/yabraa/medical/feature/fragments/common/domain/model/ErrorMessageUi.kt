package com.yabraa.medical.feature.fragments.common.domain.model

data class ErrorMessageUi(var errorMessageEn: String? = null, var errorMessageAr: String? = null)