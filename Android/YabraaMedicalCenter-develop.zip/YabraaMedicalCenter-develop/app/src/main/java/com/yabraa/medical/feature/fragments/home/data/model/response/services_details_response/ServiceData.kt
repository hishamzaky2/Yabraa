package com.yabraa.medical.feature.fragments.home.data.model.response.services_details_response


import com.google.gson.annotations.SerializedName

data class ServiceData(
    @SerializedName("detailsAR")
    val detailsAR: String,
    @SerializedName("detailsEN")
    val detailsEN: String,
    @SerializedName("filters")
    val filterData: List<FilterData>,
    @SerializedName("imagePath")
    val imagePath: String,
    @SerializedName("nameAR")
    val nameAR: String,
    @SerializedName("nameEN")
    val nameEN: String,
    @SerializedName("serviceId")
    val serviceId: Long
)