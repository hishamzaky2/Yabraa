package com.yabraa.medical.feature.fragments.appointment.my_appointment_details.data.model


import com.google.gson.annotations.SerializedName

data class MyAppointmentDetailsResponse(
    @SerializedName("appointmentId")
    val appointmentId: Long,
    @SerializedName("locationAltitude")
    val locationAltitude: Double,
    @SerializedName("locationLatitude")
    val locationLatitude: Double,
    @SerializedName("locationLongitude")
    val locationLongitude: Double,
    @SerializedName("notes")
    val notes: String,
    @SerializedName("packageNameAR")
    val packageNameAR: String,
    @SerializedName("packageNameEN")
    val packageNameEN: String,
    @SerializedName("price")
    val price: Double,
    @SerializedName("serviceAR")
    val serviceAR: String,
    @SerializedName("serviceEN")
    val serviceEN: String,
    @SerializedName("status")
    val status: String,
    @SerializedName("userFamilyName")
    val userFamilyName: String,
    @SerializedName("visitAttachments")
    val visitAttachments: List<VisitAttachment>,
    @SerializedName("visitDT")
    val visitDT: String,
    @SerializedName("visitNotes")
    val visitNotes: List<VisitNote>,
    @SerializedName("visitTime")
    val visitTime: String
)