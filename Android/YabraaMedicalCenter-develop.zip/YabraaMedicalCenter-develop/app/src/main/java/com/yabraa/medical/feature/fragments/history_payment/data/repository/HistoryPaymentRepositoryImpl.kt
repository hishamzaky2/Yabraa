package com.yabraa.medical.feature.fragments.history_payment.data.repository

import com.yabraa.medical.core.base_repository.BaseRepository
import com.yabraa.medical.core.di.network_sevices.YabraaServices
import com.core.shared.state.State
import com.yabraa.medical.core.utils.getResponseMessageError
import com.yabraa.medical.feature.fragments.history_payment.data.model.HistoryPaymentResponseDto
import com.yabraa.medical.feature.fragments.history_payment.domain.repository.HistoryPaymentRepository
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.flow.flow
import kotlinx.coroutines.flow.flowOn
import retrofit2.Response
import javax.inject.Inject

const val TAG_HISTORY_PAYMENT_RESPONSE = "TAG_HISTORY_PAYMENT_RESPONSE"

class HistoryPaymentRepositoryImpl @Inject constructor(private val yabraaServices: YabraaServices) :
    BaseRepository<Any, HistoryPaymentResponseDto>(), HistoryPaymentRepository {


    override suspend fun getHistoryPayment() = flow {
        emit(getOperationState(Any()))
    }.flowOn(Dispatchers.IO)

    override suspend fun performApiCall(requestDto: Any): State<HistoryPaymentResponseDto> {
        val response = yabraaServices.getHistoryPayment()
        return handleHistoryPaymentResponse(response)
    }


    private fun handleHistoryPaymentResponse(response: Response<HistoryPaymentResponseDto>): State<HistoryPaymentResponseDto> {
        val responseBody = response.body()
        val errorMessageEn = responseBody?.errorMessageEn ?: ""
        val errorMessageAr = responseBody?.errorMessageAr ?: ""
        return when {
            response.isSuccessful && responseBody?.historyPaymentResponse != null ->
                State.Success(response.body())

            response.isSuccessful && !responseBody?.errorMessageEn.isNullOrEmpty() -> getResponseMessageError(
                errorMessageEn = errorMessageEn,
                errorMessageAr = errorMessageAr,
                logTag = TAG_HISTORY_PAYMENT_RESPONSE
            )

            else -> getNotSuccessfulResponseState(response)
        }
    }
}