package com.yabraa.medical.feature.fragments.forget_password.domain.rposetory

import kotlinx.coroutines.flow.Flow
import com.core.shared.state.State
import com.yabraa.medical.feature.fragments.forget_password.data.model.request.ForgetPasswordRequestDto
import com.yabraa.medical.feature.fragments.forget_password.data.model.response.forget_password_response.ForgetPasswordResponseDto

interface ForgetPasswordRepository {

    suspend fun forgetPassword(forgetPasswordRequestDto: ForgetPasswordRequestDto): Flow<State<ForgetPasswordResponseDto>>
}