package com.yabraa.medical.feature.fragments.home.data.model.response.services_details_response


import com.google.gson.annotations.SerializedName
import com.yabraa.medical.feature.fragments.filter.presentation.adapter.ItemSelectedIHandler

data class FilterData(
    @SerializedName("filterId")
    val filterId: Long,
    @SerializedName("nameAR")
    val nameAR: String,
    @SerializedName("nameEN")
    val nameEN: String,
    @SerializedName("serviceId")
    val serviceId: Long,
    @SerializedName("parentServiceId")
    val parentServiceId: Long? = null,
    @SerializedName("packages")
    val packageData: List<PackageData>? = null
) : ItemSelectedIHandler {

    override var isItemSelected = false

    override fun setSelected(selected: Boolean) {
        isItemSelected = selected
    }

    override fun isSelected() = isItemSelected
}