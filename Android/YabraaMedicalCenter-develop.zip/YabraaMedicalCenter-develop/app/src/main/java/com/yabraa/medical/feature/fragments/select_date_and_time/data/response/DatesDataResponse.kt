package com.yabraa.medical.feature.fragments.select_date_and_time.data.response


import com.google.gson.annotations.SerializedName

data class DatesDataResponse(
    @SerializedName("dayName")
    val dayName: String,
    @SerializedName("dayOfMonth")
    val dayOfMonth: String,
    @SerializedName("monthName")
    val monthName: String,
    @SerializedName("monthNumber")
    val monthNumber: String,
    @SerializedName("monthShortName")
    val monthShortName: String,
    @SerializedName("year")
    val year: Int
)