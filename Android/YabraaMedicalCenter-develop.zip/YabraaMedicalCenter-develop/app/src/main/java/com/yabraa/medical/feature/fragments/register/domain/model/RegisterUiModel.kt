package com.yabraa.medical.feature.fragments.register.domain.model

import com.yabraa.medical.feature.fragments.register.data.request.RegisterRequestDto

data class RegisterUiModel(
    var firstName: String,
    var lastName: String,
    var password: String? = null,
    var phoneNumber: String? = null,
    var birthDate: String,
    var gender: String,
    var countryCode: String,
    var idOrIqamaOrPassport: String? = null,
    var email: String? = null
) {
    fun toRegister() = RegisterRequestDto(
        firstName = firstName,
        lastName = lastName,
        password = password,
        phoneNumber = phoneNumber,
        birthDate = birthDate,
        gender = gender,
        countryCode = countryCode,
        idOrIqamaOrPassport = idOrIqamaOrPassport,
        email = email,
    )
}