package com.yabraa.medical.core.di.network_sevices

import com.yabraa.medical.feature.fragments.allergies_and_chronic_diseases.allergies_fragment.data.model.response.AllergiesResponseDto
import com.yabraa.medical.feature.fragments.allergies_and_chronic_diseases.chronic_diseases_fragment.data.model.response.ChronicDiseasesResponseDto
import com.yabraa.medical.feature.fragments.allergies_and_chronic_diseases.current_medication_fragment.data.model.resopnse.CurrentMedicationResponseDto
import com.yabraa.medical.feature.fragments.allergies_and_chronic_diseases.injuries_fragment.data.model.response.InjuriesResponseDto
import com.yabraa.medical.feature.fragments.allergies_and_chronic_diseases.past_medication_fragment.data.model.response.PastMedicationResponseDto
import com.yabraa.medical.feature.fragments.allergies_and_chronic_diseases.surgeries_fragment.data.model.response.SurgeriesResponseDto
import retrofit2.Response
import retrofit2.http.DELETE
import retrofit2.http.GET
import retrofit2.http.POST
import retrofit2.http.Query

interface AllergiesAndChronicDiseasesServices {

    @GET("api/Allergies/GetAllergies")
    suspend fun getAllergies(): Response<AllergiesResponseDto>

    @POST("api/Allergies/AddAllergyUser")
    suspend fun addAllergies(
        @Query("AllergyId") allergyId: Long, @Query("UserFamilyId") userFamilyId: Long
    ): Response<AllergiesResponseDto>

    @GET("api/Allergies/GetAllergiesUser")
    suspend fun getAllergiesByUserFamilyId(@Query("UserFamilyId") userFamilyId: Long): Response<AllergiesResponseDto>

    @DELETE("api/Allergies/DeleteAllergyUser")
    suspend fun deleteAllergiesByUserFamilyId(
        @Query("AllergyId") allergyId: Long, @Query("UserFamilyId") userFamilyId: Long
    ): Response<AllergiesResponseDto>


    @GET("api/ChronicDiseases/GetChronicDiseases")
    suspend fun getChronicDiseases(): Response<ChronicDiseasesResponseDto>

    @POST("api/ChronicDiseases/AddChronicDiseaseUser")
    suspend fun addChronicDiseases(
        @Query("ChronicDiseaseId") chronicDiseaseId: Long, @Query("UserFamilyId") userFamilyId: Long
    ): Response<ChronicDiseasesResponseDto>

    @GET("api/ChronicDiseases/GetChronicDiseasesUser")
    suspend fun getChronicDiseasesByUserFamilyId(@Query("UserFamilyId") userFamilyId: Long): Response<ChronicDiseasesResponseDto>

    @DELETE("api/ChronicDiseases/DeleteChronicDiseaseUser")
    suspend fun deleteChronicDiseasesByUserFamilyId(
        @Query("ChronicDiseaseId") chronicDiseaseId: Long, @Query("UserFamilyId") userFamilyId: Long
    ): Response<ChronicDiseasesResponseDto>

    @GET("api/Medication/GetMedications")
    suspend fun getMedications(): Response<CurrentMedicationResponseDto>

    @POST("api/Medication/AddCurrentMedicationUser")
    suspend fun addCurrentMedication(
        @Query("MedicationId") medicationId: Long, @Query("UserFamilyId") userFamilyId: Long
    ): Response<CurrentMedicationResponseDto>

    @GET("api/Medication/GetCurrentMedicationsUser")
    suspend fun getCurrentMedicationsByUserFamilyId(@Query("UserFamilyId") userFamilyId: Long): Response<CurrentMedicationResponseDto>

    @DELETE("api/Medication/DeleteCurrentMedicationUser")
    suspend fun deleteCurrentMedicationUserByUserFamilyId(
        @Query("MedicationId") medicationId: Long, @Query("UserFamilyId") userFamilyId: Long
    ): Response<CurrentMedicationResponseDto>


    @GET("api/Injuries/GetInjuries")
    suspend fun getInjuries(): Response<InjuriesResponseDto>

    @POST("api/Injuries/AddInjuryUser")
    suspend fun addInjuries(
        @Query("InjuryId") injuryId: Long, @Query("UserFamilyId") userFamilyId: Long
    ): Response<InjuriesResponseDto>

    @GET("api/Injuries/GetInjuriesUser")
    suspend fun getInjuriesByUserFamilyId(@Query("UserFamilyId") userFamilyId: Long): Response<InjuriesResponseDto>

    @DELETE("api/Injuries/DeleteInjuryUser")
    suspend fun deleteInjuryUserByUserFamilyId(
        @Query("InjuryId") injuryId: Long, @Query("UserFamilyId") userFamilyId: Long
    ): Response<InjuriesResponseDto>


    @GET("api/Medication/GetMedications")
    suspend fun getPastMedications(): Response<PastMedicationResponseDto>

    @POST("api/Medication/AddPastMedicationUser")
    suspend fun addPastMedication(
        @Query("MedicationId") medicationId: Long, @Query("UserFamilyId") userFamilyId: Long
    ): Response<PastMedicationResponseDto>

    @GET("api/Medication/GetPastMedicationsUser")
    suspend fun getPastMedicationsByUserFamilyId(@Query("UserFamilyId") userFamilyId: Long): Response<PastMedicationResponseDto>

    @DELETE("api/Medication/DeletePastMedicationUser")
    suspend fun deletePastMedicationUserByUserFamilyId(
        @Query("MedicationId") medicationId: Long, @Query("UserFamilyId") userFamilyId: Long
    ): Response<PastMedicationResponseDto>

    @GET("api/Surgeries/GetSurgeries")
    suspend fun getSurgeries(): Response<SurgeriesResponseDto>

    @POST("api/Surgeries/AddSurgeryUser")
    suspend fun addSurgery(
        @Query("SurgeryId") surgeryId: Long, @Query("UserFamilyId") userFamilyId: Long
    ): Response<SurgeriesResponseDto>

    @GET("api/Surgeries/GetSurgeriesUser")
    suspend fun getSurgeriesByUserFamilyId(@Query("UserFamilyId") userFamilyId: Long): Response<SurgeriesResponseDto>

    @DELETE("api/Surgeries/DeleteSurgeryUser")
    suspend fun deleteSurgeryByUserFamilyId(
        @Query("SurgeryId") surgeryId: Long, @Query("UserFamilyId") userFamilyId: Long
    ): Response<SurgeriesResponseDto>

}