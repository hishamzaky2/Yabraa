package com.yabraa.medical.feature.fragments.setting.presentation

import android.annotation.SuppressLint
import android.os.Bundle
import android.view.View
import androidx.core.content.res.ResourcesCompat
import androidx.core.view.isVisible
import androidx.hilt.navigation.fragment.hiltNavGraphViewModels
import androidx.lifecycle.lifecycleScope
import com.yabraa.medical.R
import com.yabraa.medical.core.base_fragment.BaseFragment
import com.yabraa.medical.core.base_fragment.navigate
import com.yabraa.medical.core.base_fragment.setOnGoToConnectionSettingClicked
import com.core.shared.state.State
import com.core.shared.utils.CommonUtils.handleExpirationDate
import com.yabraa.medical.core.utils.dialog.yabraa_dialog.YabraaButtonStyle
import com.yabraa.medical.core.utils.dialog.yabraa_dialog.YabraaDialogBuilder
import com.yabraa.medical.databinding.FragmentSettingBinding
import com.yabraa.medical.feature.activits.mainactivity.MainActivity
import com.yabraa.medical.feature.fragments.setting.domain.viewmodel.SettingViewModel
import dagger.hilt.android.AndroidEntryPoint
import kotlinx.coroutines.launch

const val USER_INFORMATION = "USER_INFORMATION"

@AndroidEntryPoint
class SettingFragment : BaseFragment<FragmentSettingBinding>() {

    override val binding by lazy { FragmentSettingBinding.inflate(layoutInflater) }
    private val viewModel: SettingViewModel by hiltNavGraphViewModels(R.id.setting_graph)
    private val userInfo get() = viewModel.getUserInfo()
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        showExpirationDateError()
        binding.handleNetworkConnection()
    }

    override fun onViewCreated(view: View, savedInstanceState: Bundle?) {
        super.onViewCreated(view, savedInstanceState)
        binding.setUpViews()
    }

    override fun onResume() {
        super.onResume()
        showYabraaBar(false)
        confirmationView?.setConfirmationAppointmentVisibility(false)
        showBottomNavigation(true)
    }


    private fun FragmentSettingBinding.handleNetworkConnection() {
        connectivityManager?.isNetworkConnected?.observe(this@SettingFragment) {
            handleConnectionViewVisibility(it)
            if (!it) return@observe
            viewModel.getUserInformation()
        }
    }


    private fun FragmentSettingBinding.handleConnectionViewVisibility(isVisible: Boolean) {
        settingGroup.isVisible = isVisible
        internetConnection.root.isVisible = !isVisible
    }


    private fun FragmentSettingBinding.setUpViews() {
        internetConnection.goToSettingBtn.setOnGoToConnectionSettingClicked(requireActivity())
        setOnEditProfileClicked()
        setOnAllergiesAndChronicDiseasesClicked()
        setOnMyAppointmentClicked()
        setOnHistoryPaymentClicked()
        setOnAddPatientClicked()
        setOnConnectWithYabraaClicked()
        setOnLogoutClicked()
        setOnDeleteAccountClicked()
        lifecycleScope.launch { collectOnDeleteAccountState() }
        lifecycleScope.launch { collectOnGetUserInformationState() }
    }

    private fun FragmentSettingBinding.setOnEditProfileClicked() {
        editProfileTv.setOnClickListener {
            val bundle = Bundle()
            bundle.putSerializable(USER_INFORMATION, userInfo)
            showDelayProgressDialog { navigate(R.id.actionSettingFragmentToEditFragment, bundle) }
        }
    }

    private suspend fun FragmentSettingBinding.collectOnGetUserInformationState() {
        viewModel.getUserInformationResponseState.collect {
            hideProgressDialog()
            when (it) {
                is State.Error -> it.error.handleError { }
                is State.Initial -> {}
                is State.Loading -> showProgressDialog()
                is State.Success -> setUserNameTv()
            }
        }
    }

    @SuppressLint("SetTextI18n")
    private fun FragmentSettingBinding.setUserNameTv() {
        val firstName = userInfo?.firstName
        val lastName = userInfo?.lastName
        userNameTv.text = "$firstName $lastName"
    }

    private fun FragmentSettingBinding.setOnAllergiesAndChronicDiseasesClicked(){
        allergiesAndChronicDiseasesBtn.setOnClickListener {
            viewModel.yabraaBarTitle = R.string.selectPatient.localize()
            showDelayProgressDialog { navigate(R.id.actionSettingFragmentToSelectPatientFragmentFragment) }

        }
    }

    private fun FragmentSettingBinding.setOnMyAppointmentClicked() {
        myAppointmentsBtn.setOnClickListener {
            viewModel.yabraaBarTitle = R.string.myAppointments.localize()
            showDelayProgressDialog { navigate(R.id.actionSettingFragmentToMyAppointmentFragment) }
        }
    }

    private fun FragmentSettingBinding.setOnHistoryPaymentClicked() {
        historyPaymentBtn.setOnClickListener {
            viewModel.yabraaBarTitle = R.string.paymentHistory.localize()
            showDelayProgressDialog { navigate(R.id.actionSettingFragmentToHistoryPaymentFragment) }
        }
    }


    private fun FragmentSettingBinding.setOnAddPatientClicked() {
        addPatientBtn.setOnClickListener {
            viewModel.yabraaBarTitle = R.string.addPatient.localize()
            showDelayProgressDialog { navigate(R.id.actionSettingFragmentToPatientsFragment) }
        }
    }

    private fun FragmentSettingBinding.setOnConnectWithYabraaClicked() {
        connectWithYabraaBtn.setOnClickListener {
            viewModel.yabraaBarTitle = R.string.connectUs.localize()
            showDelayProgressDialog { navigate(R.id.actionSettingFragmentConnectWithYabraaFragment) }
        }
    }

    private fun FragmentSettingBinding.setOnLogoutClicked() =
        logoutBtn.setOnClickListener { showLogoutPopup() }


    private fun showLogoutPopup() {
        YabraaDialogBuilder(requireActivity()).setIcon(R.drawable.ic_vector_error)
            .setTitle(R.string.doYouWantToLogout)
            .setTopButton(R.string.yes) {
                showDelayProgressDialog { handleLogout() }
            }
            .setBottomButton(R.string.no) {}
            .setCancelable(false).show()
    }


    @SuppressLint("FragmentLiveDataObserve")
    private fun FragmentSettingBinding.setOnDeleteAccountClicked() {
        connectivityManager?.isNetworkConnected?.observe(this@SettingFragment) { isConnected ->
            deleteAccountBtn.setOnClickListener {
                if (!isConnected) {
                    showNetworkConnectionErrorPopup()
                    return@setOnClickListener
                }
                showDeleteAccountPopup()
            }
        }
    }


    private fun showDeleteAccountPopup() {
        val topBtnStyle = YabraaButtonStyle(
            backGround = R.color.primaryLight100,
            textColor = ResourcesCompat.getColor(resources, R.color.primaryDark900, null)
        )
        YabraaDialogBuilder(requireActivity()).setIcon(R.drawable.ic_vector_error)
            .setTitle(R.string.doYouWantDeleteYourAccount)
            .setTopButton(R.string.yes, topBtnStyle) { viewModel.deleteAccount() }
            .setBottomButton(R.string.no) {}
            .setCancelable(false).show()
    }

    private suspend fun collectOnDeleteAccountState() {
        viewModel.deleteAccountResponseState.collect {
            hideProgressDialog()
            when (it) {
                is State.Error -> it.error.handleError { }
                is State.Initial -> {}
                is State.Loading -> showProgressDialog()
                is State.Success -> handleLogout()
            }
        }
    }

    private fun handleLogout() {
        tokenHandler.clearToken()
        (activity as MainActivity).restartActivity()
    }

    private fun showExpirationDateError() =
        tokenHandler.handleExpirationDate { showExpirationDatePopupError() }
}