package com.yabraa.medical.feature.fragments.notification.notification_hisotry.data.repository.read_notification_repository

import com.yabraa.medical.core.base_repository.BaseRepository
import com.yabraa.medical.core.di.network_sevices.YabraaServices
import com.core.shared.state.State
import com.yabraa.medical.core.utils.getResponseMessageError
import com.yabraa.medical.feature.fragments.notification.notification_hisotry.data.model.response.read_notification_response.ReadNotificationResponseDto
import com.yabraa.medical.feature.fragments.notification.notification_hisotry.domain.repository.read_notification.ReadNotificationRepository
import kotlinx.coroutines.flow.flow
import retrofit2.Response
import javax.inject.Inject

const val TAG_EAD_NOTIFICATION_RESPONSE = "TAG_EAD_NOTIFICATION_RESPONSE"

class ReadNotificationRepositoryImpl @Inject constructor(private val yabraaServices: YabraaServices) :
    BaseRepository<Long, ReadNotificationResponseDto>(), ReadNotificationRepository {


    override suspend fun readNotification(notificationId: Long) = flow {
        emit(getOperationState(notificationId))
    }

    override suspend fun performApiCall(requestDto: Long): State<ReadNotificationResponseDto> {
        val response = yabraaServices.readNotification(requestDto)
        return handleReadNotificationResponse(response)
    }

    private fun handleReadNotificationResponse(response: Response<ReadNotificationResponseDto>): State<ReadNotificationResponseDto> {
        val responseBody = response.body()
        val errorMessageEn = responseBody?.errorMessageEn ?: ""
        val errorMessageAr = responseBody?.errorMessageAr ?: ""
        return when {
            response.isSuccessful && responseBody?.readNotificationResponse != null ->
                State.Success(response.body())

            response.isSuccessful && !responseBody?.errorMessageEn.isNullOrEmpty() -> getResponseMessageError(
                errorMessageEn = errorMessageEn,
                errorMessageAr = errorMessageAr,
                logTag = TAG_EAD_NOTIFICATION_RESPONSE
            )

            else -> getNotSuccessfulResponseState(response)
        }
    }
}