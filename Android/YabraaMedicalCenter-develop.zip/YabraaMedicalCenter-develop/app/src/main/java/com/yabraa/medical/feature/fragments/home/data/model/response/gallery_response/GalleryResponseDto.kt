package com.yabraa.medical.feature.fragments.home.data.model.response.gallery_response


import com.google.gson.annotations.SerializedName

data class GalleryResponseDto(
    @SerializedName("data")
    val galleryDataResponse: GalleryDataResponse? = null,
    @SerializedName("errorMessageAr")
    val errorMessageAr: String? = null,
    @SerializedName("errorMessageEn")
    val errorMessageEn: String? = null,
    @SerializedName("statusCode")
    val statusCode: Int
)