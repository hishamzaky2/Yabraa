package com.yabraa.medical.core.utils.dialog.nationality_bottom_dilaog

import android.app.Activity
import android.widget.EditText
import androidx.recyclerview.widget.RecyclerView
import com.google.android.material.bottomsheet.BottomSheetDialog
import com.yabraa.medical.R
import com.yabraa.medical.databinding.LayoutNationalityBottomSheetBinding
import javax.inject.Inject

class NationalityBottomSheetDialog @Inject constructor(activity: Activity) {

    lateinit var binding: LayoutNationalityBottomSheetBinding
    private var bottomSheetDialog: BottomSheetDialog? = null

    init {
        buildBottomSheetDialog(activity)
    }

    private fun buildBottomSheetDialog(activity: Activity): BottomSheetDialog? {
        binding = LayoutNationalityBottomSheetBinding.inflate(activity.layoutInflater)
        bottomSheetDialog = BottomSheetDialog(activity, R.style.bottom_sheet_style)
        bottomSheetDialog?.setContentView(binding.root)
        return bottomSheetDialog
    }

    fun showBottomSheetDialog() = bottomSheetDialog?.show()


    fun dismissBottomSheet() = bottomSheetDialog?.dismiss()


    fun setRecyclerAdapter(adapter: RecyclerView.Adapter<*>) {
        binding.adapterRv.adapter = adapter
    }

    fun searchInput(searchInput: (EditText) -> Unit) = searchInput(binding.searchEt)
}