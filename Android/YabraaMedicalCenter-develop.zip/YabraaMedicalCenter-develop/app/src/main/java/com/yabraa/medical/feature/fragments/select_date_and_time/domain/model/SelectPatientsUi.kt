package com.yabraa.medical.feature.fragments.select_date_and_time.domain.model


data class SelectPatientsUi(
    var packageId: Long? = null,
    val userFamilyId: Long? = null,
    val birthDate: String? = null,
    val name: String? = null
)