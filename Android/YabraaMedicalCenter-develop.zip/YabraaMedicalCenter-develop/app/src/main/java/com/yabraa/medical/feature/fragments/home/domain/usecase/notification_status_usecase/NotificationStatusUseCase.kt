package com.yabraa.medical.feature.fragments.home.domain.usecase.notification_status_usecase

import com.core.shared.state.State
import com.yabraa.medical.feature.fragments.notification.notification_hisotry.data.model.request.notification_history_request.NotificationHistoryRequestDto
import com.yabraa.medical.feature.fragments.notification.notification_hisotry.data.model.response.notification_history_response.NotificationHistoryResponse
import com.yabraa.medical.feature.fragments.notification.notification_hisotry.data.model.response.notification_history_response.NotificationHistoryResponseDto
import com.yabraa.medical.feature.fragments.notification.notification_hisotry.domain.repository.notification_status_repository.NotificationStatusRepository
import kotlinx.coroutines.async
import kotlinx.coroutines.flow.Flow
import kotlinx.coroutines.flow.channelFlow
import javax.inject.Inject

class NotificationStatusUseCase @Inject constructor(
    private var notificationStatusRepository: NotificationStatusRepository
) {

    private var notificationResponse: NotificationHistoryResponse? = null
    suspend operator fun invoke(requestDto: NotificationHistoryRequestDto): Flow<State<NotificationHistoryResponseDto>> {
        return channelFlow {
            val response = async { notificationStatusRepository.getNotificationStatus(requestDto) }
            response.await().collect {
                if (it is State.Success) {
                    notificationResponse = it.data?.notificationHistoryResponse
                }
                send(it)
            }
        }
    }

    fun isReadAllNotification() = notificationResponse?.isALLRead
}