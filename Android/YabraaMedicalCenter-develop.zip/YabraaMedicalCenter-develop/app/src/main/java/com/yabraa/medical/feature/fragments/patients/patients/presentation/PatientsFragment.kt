package com.yabraa.medical.feature.fragments.patients.patients.presentation

import android.annotation.SuppressLint
import android.os.Bundle
import android.view.View
import androidx.core.view.isVisible
import androidx.fragment.app.viewModels
import androidx.hilt.navigation.fragment.hiltNavGraphViewModels
import androidx.lifecycle.lifecycleScope
import androidx.navigation.fragment.findNavController
import com.yabraa.medical.R
import com.yabraa.medical.core.base_fragment.BaseFragment
import com.yabraa.medical.core.base_fragment.navigate
import com.core.shared.state.State
import com.core.shared.utils.CommonUtils.handleExpirationDate
import com.yabraa.medical.core.utils.custom_views.yabraa_bar.YabraaBarHandler
import com.yabraa.medical.databinding.FragmentPatientsBinding
import com.yabraa.medical.feature.fragments.patients.patients.data.model.response.PatientResponse
import com.yabraa.medical.feature.fragments.patients.patients.domain.viewmodel.PatientListViewModel
import com.yabraa.medical.feature.fragments.patients.patients.presentation.adpater.PatientsAdapter
import com.yabraa.medical.feature.fragments.setting.domain.viewmodel.SettingViewModel
import dagger.hilt.android.AndroidEntryPoint
import kotlinx.coroutines.launch

const val EDIT_PATIENT = "EDIT_PATIENT"

@AndroidEntryPoint
class PatientsFragment : BaseFragment<FragmentPatientsBinding>() {

    override val binding by lazy { FragmentPatientsBinding.inflate(layoutInflater) }
    private val settingViewModel: SettingViewModel by hiltNavGraphViewModels(R.id.setting_graph)
    private val viewModel: PatientListViewModel by viewModels()
    private val patientList get() = viewModel.getPatientList()
    private lateinit var patientsAdapter: PatientsAdapter


    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        showExpirationDateError()
    }

    override fun onViewCreated(view: View, savedInstanceState: Bundle?) {
        super.onViewCreated(view, savedInstanceState)
        handleInternetConnection()
        setOnAddNewPatientClicked()
    }

    override fun onStart() {
        super.onStart()
        lifecycleScope.launch { collectOnPatientResponse() }
    }

    override fun onResume() {
        super.onResume()
        yabraaBarView?.setUpYabraaBarView()
        confirmationView?.setConfirmationAppointmentVisibility(false)
        showBottomNavigation(false)
    }

    private fun YabraaBarHandler.setUpYabraaBarView() {
        val barTitle = settingViewModel.yabraaBarTitle ?: ""
        setYabraaBarVisibility(true)
        setClearAllVisibility(false)
        setBarTitle(barTitle)
        setOnBackArrowClicked { findNavController().popBackStack() }
    }

    @SuppressLint("FragmentLiveDataObserve")
    private fun handleInternetConnection() {
        connectivityManager?.isNetworkConnected?.observe(this@PatientsFragment) {
            binding.handleConnectionViewVisibility(it)
            if (!it) return@observe
            viewModel.getPatients()
        }
    }

    private fun FragmentPatientsBinding.handleConnectionViewVisibility(isVisible: Boolean) {
        patientsRv.isVisible = isVisible
        addNewPatientBtn.isVisible = isVisible
        internetConnection.root.isVisible = !isVisible
    }

    private suspend fun collectOnPatientResponse() {
        viewModel.patientResponseState.collect {
            hideProgressDialog()
            when (it) {
                is State.Error -> it.error.handleError { }
                is State.Initial -> {}
                is State.Loading -> showProgressDialog()
                is State.Success -> setPatientsAdapter()
            }
        }
    }

    private fun setPatientsAdapter() {
        patientsAdapter = PatientsAdapter(patientList) {
            showDelayProgressDialog { navigateToEditPatient(it) }
        }
        binding.patientsRv.adapter = patientsAdapter
        handleAddPatientVisibility()
    }

    private fun handleAddPatientVisibility() {
        binding.addNewPatientBtn.isVisible = true
    }

    private fun navigateToEditPatient(patientResponse: PatientResponse) {
        val bundle = Bundle()
        bundle.putSerializable(EDIT_PATIENT, patientResponse)
        navigate(R.id.actionPatientsFragmentToEditPatientFragment, bundle)
    }

    private fun setOnAddNewPatientClicked() {
        binding.addNewPatientBtn.setOnClickListener {
            showDelayProgressDialog { navigate(R.id.actionPatientsFragmentToAddPatientFragment) }
        }
    }

    private fun showExpirationDateError() =
        tokenHandler.handleExpirationDate { showExpirationDatePopupError() }
}