package com.yabraa.medical.feature.fragments.allergies_and_chronic_diseases.current_medication_fragment.data.model.resopnse


import com.google.gson.annotations.SerializedName

data class CurrentMedicationResponseDto(
    @SerializedName("data")
    val currentMedicationDataResponse: List<CurrentMedicationDataResponse>,
    @SerializedName("errorMessageAr")
    val errorMessageAr: String? = null,
    @SerializedName("errorMessageEn")
    val errorMessageEn: String? = null,
    @SerializedName("statusCode")
    val statusCode: Int
)