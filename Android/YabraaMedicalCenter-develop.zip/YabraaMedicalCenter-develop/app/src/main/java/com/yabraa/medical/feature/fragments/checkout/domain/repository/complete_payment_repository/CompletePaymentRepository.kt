package com.yabraa.medical.feature.fragments.checkout.domain.repository.complete_payment_repository

import kotlinx.coroutines.flow.Flow
import com.core.shared.state.State
import com.yabraa.medical.feature.fragments.checkout.data.model.request.PaymentRequestDto
import com.yabraa.medical.feature.fragments.checkout.data.model.response.payment_response.PaymentResponseDto

interface CompletePaymentRepository {
    suspend fun completePayment(paymentRequestDto: PaymentRequestDto): Flow<State<PaymentResponseDto>>
}