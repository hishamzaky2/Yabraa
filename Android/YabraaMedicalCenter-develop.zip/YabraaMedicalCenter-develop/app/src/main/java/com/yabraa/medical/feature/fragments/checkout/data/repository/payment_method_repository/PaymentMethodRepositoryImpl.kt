package com.yabraa.medical.feature.fragments.checkout.data.repository.payment_method_repository

import com.yabraa.medical.core.base_repository.BaseRepository
import com.yabraa.medical.core.di.network_sevices.YabraaServices
import com.core.shared.state.State
import com.yabraa.medical.core.utils.getResponseMessageError
import com.yabraa.medical.feature.fragments.checkout.data.model.response.payment_method_response.PaymentMethodResponseDto
import com.yabraa.medical.feature.fragments.checkout.data.repository.complete_payment_repository.TAG_COMPLETE_PAYMENT
import com.yabraa.medical.feature.fragments.checkout.domain.repository.payment_method_repository.PaymentMethodRepository
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.flow.flow
import kotlinx.coroutines.flow.flowOn
import retrofit2.Response
import javax.inject.Inject

class PaymentMethodRepositoryImpl @Inject constructor(private val yabraaServices: YabraaServices) :
    BaseRepository<Any, PaymentMethodResponseDto>(), PaymentMethodRepository {


    override suspend fun getPaymentMethods() = flow {
        emit(getOperationState(Any()))
    }.flowOn(Dispatchers.IO)

    override suspend fun performApiCall(requestDto: Any): State<PaymentMethodResponseDto> {
        val response = yabraaServices.getPaymentMethods()
        return handlePaymentMethodsResponse(response)
    }


    private fun handlePaymentMethodsResponse(response: Response<PaymentMethodResponseDto>): State<PaymentMethodResponseDto> {
        val responseBody = response.body()
        val errorMessageEn = responseBody?.errorMessageEn ?: ""
        val errorMessageAr = responseBody?.errorMessageAr ?: ""
        return when {
            response.isSuccessful && responseBody?.paymentMethodResponse != null ->
                State.Success(response.body())

            response.isSuccessful && !responseBody?.errorMessageEn.isNullOrEmpty() -> getResponseMessageError(
                errorMessageEn = errorMessageEn,
                errorMessageAr = errorMessageAr,
                logTag = TAG_COMPLETE_PAYMENT
            )

            else -> getNotSuccessfulResponseState(response)
        }
    }

}