package com.yabraa.medical.feature.fragments.allergies_and_chronic_diseases.current_medication_fragment.presentation.adapter

import android.view.LayoutInflater
import android.view.ViewGroup
import androidx.core.view.isVisible
import androidx.recyclerview.widget.RecyclerView
import com.core.shared.utils.CommonUtils
import com.yabraa.medical.databinding.ItemGeneralAllergiesAndDiseasesBinding
import com.yabraa.medical.feature.fragments.allergies_and_chronic_diseases.current_medication_fragment.domain.model.CurrentMedicationEntityModel

class CurrentMedicationAdapter(
    private val currentMedicationItem: List<CurrentMedicationEntityModel>,
    private val onAddItemClicked: (Long) -> Unit,
    private val onDeleteItemClicked: (Long) -> Unit
) : RecyclerView.Adapter<CurrentMedicationAdapter.ViewHolder>() {


    override fun onCreateViewHolder(parent: ViewGroup, viewType: Int): ViewHolder {
        val binding = ItemGeneralAllergiesAndDiseasesBinding.inflate(
            LayoutInflater.from(parent.context),
            parent,
            false
        )
        return ViewHolder(binding)
    }

    override fun onBindViewHolder(viewHolder: ViewHolder, position: Int) {
        val currentMedicationItem = currentMedicationItem[position]
        viewHolder.bin(currentMedicationItem)
    }

    override fun getItemCount() = currentMedicationItem.size

    override fun getItemViewType(position: Int) = position


    inner class ViewHolder(val binding: ItemGeneralAllergiesAndDiseasesBinding) :
        RecyclerView.ViewHolder(binding.root) {
        fun bin(item: CurrentMedicationEntityModel) {
            binding.setUpViews(item)
        }

        private fun ItemGeneralAllergiesAndDiseasesBinding.setUpViews(item: CurrentMedicationEntityModel) {
            addBtn.setOnClickListener { onAddItemClicked(item.medicationId) }
            deleteBtn.setOnClickListener { onDeleteItemClicked(item.medicationId) }
            titleTv.text = CommonUtils.getLocalizedValue(item.titleEN, item.titleAR)
            handleAddBtnVisibility(item.isAdded)
        }

        private fun ItemGeneralAllergiesAndDiseasesBinding.handleAddBtnVisibility(isShow: Boolean) {
            checkIv.isVisible = isShow
            addBtn.isVisible = !isShow
            deleteBtn.isVisible = isShow
        }
    }
}