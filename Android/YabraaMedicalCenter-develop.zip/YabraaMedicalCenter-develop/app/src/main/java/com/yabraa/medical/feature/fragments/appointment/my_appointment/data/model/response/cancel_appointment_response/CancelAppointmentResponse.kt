package com.yabraa.medical.feature.fragments.appointment.my_appointment.data.model.response.cancel_appointment_response

import com.google.gson.annotations.SerializedName

data class CancelAppointmentResponse(
    @SerializedName("messageEn")
    val messageEn: String,
    @SerializedName("messageAr")
    val messageAr: String
)
