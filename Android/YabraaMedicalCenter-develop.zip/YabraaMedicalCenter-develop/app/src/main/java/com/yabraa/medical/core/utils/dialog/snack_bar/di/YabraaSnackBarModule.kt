package com.yabraa.medical.core.utils.dialog.snack_bar.di

import android.app.Activity
import dagger.Module
import dagger.Provides
import dagger.hilt.InstallIn
import dagger.hilt.android.components.ActivityComponent
import com.yabraa.medical.core.utils.dialog.snack_bar.YabraaSnackBarBuilder

@Module
@InstallIn(ActivityComponent::class)
class YabraaSnackBarModule {

    @Provides
    fun provideYabraaSnackBarBuilder(activity: Activity) = YabraaSnackBarBuilder(activity)
}