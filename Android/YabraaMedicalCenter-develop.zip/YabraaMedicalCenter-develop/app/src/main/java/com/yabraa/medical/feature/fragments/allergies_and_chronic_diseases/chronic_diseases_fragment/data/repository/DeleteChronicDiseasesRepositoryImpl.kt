package com.yabraa.medical.feature.fragments.allergies_and_chronic_diseases.chronic_diseases_fragment.data.repository

import com.yabraa.medical.core.base_repository.BaseRepository
import com.yabraa.medical.core.di.network_sevices.AllergiesAndChronicDiseasesServices
import com.core.shared.state.State
import com.yabraa.medical.core.utils.getResponseMessageError
import com.yabraa.medical.feature.fragments.allergies_and_chronic_diseases.chronic_diseases_fragment.data.model.request.ChronicDiseasesRequestDto
import com.yabraa.medical.feature.fragments.allergies_and_chronic_diseases.chronic_diseases_fragment.data.model.response.ChronicDiseasesResponseDto
import com.yabraa.medical.feature.fragments.allergies_and_chronic_diseases.chronic_diseases_fragment.domain.repository.DeleteChronicDiseasesRepository
import kotlinx.coroutines.flow.flow
import kotlinx.coroutines.flow.flowOn
import retrofit2.Response
import javax.inject.Inject

const val TAG_DELETE_CHRONIC_DISEASES_RESPONSE = "TAG_DELETE_CHRONIC_DISEASES_RESPONSE"

class DeleteChronicDiseasesRepositoryImpl @Inject constructor(
    private val allergiesAndChronicDiseasesServices: AllergiesAndChronicDiseasesServices
) : BaseRepository<ChronicDiseasesRequestDto, ChronicDiseasesResponseDto>(),
    DeleteChronicDiseasesRepository {

    override suspend fun deleteChronicDiseases(requestDto: ChronicDiseasesRequestDto) = flow {
        emit(getOperationState(requestDto))
    }.flowOn(dispatcher)

    override suspend fun performApiCall(requestDto: ChronicDiseasesRequestDto): State<ChronicDiseasesResponseDto> {
        val response = allergiesAndChronicDiseasesServices.deleteChronicDiseasesByUserFamilyId(
            requestDto.chronicDiseaseId, requestDto.userFamilyId
        )
        return handleResponse(response)
    }

    fun handleResponse(response: Response<ChronicDiseasesResponseDto>): State<ChronicDiseasesResponseDto> {
        val responseBody = response.body()
        val errorMessageEn = responseBody?.errorMessageEn ?: ""
        val errorMessageAr = responseBody?.errorMessageAr ?: ""
        return when {
            response.isSuccessful -> State.Success(response.body())

            response.isSuccessful && !responseBody?.errorMessageEn.isNullOrEmpty() -> getResponseMessageError(
                errorMessageEn = errorMessageEn,
                errorMessageAr = errorMessageAr,
                logTag = TAG_DELETE_CHRONIC_DISEASES_RESPONSE
            )

            else -> getNotSuccessfulResponseState(response)
        }
    }
}