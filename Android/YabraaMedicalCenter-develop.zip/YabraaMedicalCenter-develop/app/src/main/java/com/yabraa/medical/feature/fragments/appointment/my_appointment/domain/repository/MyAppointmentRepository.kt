package com.yabraa.medical.feature.fragments.appointment.my_appointment.domain.repository

import com.core.shared.state.State
import com.yabraa.medical.feature.fragments.appointment.my_appointment.data.model.response.MyAppointmentResponseDto
import kotlinx.coroutines.flow.Flow

interface MyAppointmentRepository {
    suspend fun getMytAppointment() : Flow<State<MyAppointmentResponseDto>>
}