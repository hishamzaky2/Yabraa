package com.yabraa.medical.feature.fragments.forget_password.di

import dagger.Module
import dagger.Provides
import dagger.hilt.InstallIn
import dagger.hilt.android.components.ViewModelComponent
import com.yabraa.medical.core.di.network_sevices.SecurityServices
import com.yabraa.medical.feature.fragments.forget_password.data.repository.ForgetPasswordRepositoryImpl
import com.yabraa.medical.feature.fragments.forget_password.data.repository.ResetPasswordRepositoryImpl
import com.yabraa.medical.feature.fragments.forget_password.domain.rposetory.ForgetPasswordRepository
import com.yabraa.medical.feature.fragments.forget_password.domain.rposetory.ResetPasswordRepository

@Module
@InstallIn(ViewModelComponent::class)
object ForgetPasswordModule {

    @Provides
    fun provideForgetPasswordRepository(securityServices: SecurityServices): ForgetPasswordRepository =
        ForgetPasswordRepositoryImpl(securityServices)

    @Provides
    fun provideResetPasswordRepository(securityServices: SecurityServices): ResetPasswordRepository =
        ResetPasswordRepositoryImpl(securityServices)
}