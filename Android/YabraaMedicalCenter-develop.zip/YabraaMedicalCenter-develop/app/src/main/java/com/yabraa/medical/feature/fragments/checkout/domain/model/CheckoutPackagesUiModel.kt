package com.yabraa.medical.feature.fragments.checkout.domain.model

import java.math.BigDecimal

data class CheckoutPackagesUiModel(
    var packageId: Long? = null,
    var userFamilyId: Long? = null,
    var notes: String? = null,
    var price: BigDecimal? = null,
    var dateTime: String? = null
)