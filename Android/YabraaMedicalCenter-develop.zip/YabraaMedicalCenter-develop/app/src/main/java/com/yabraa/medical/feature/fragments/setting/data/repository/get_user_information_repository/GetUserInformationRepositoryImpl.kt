package com.yabraa.medical.feature.fragments.setting.data.repository.get_user_information_repository

import com.yabraa.medical.core.base_repository.BaseRepository
import com.yabraa.medical.core.di.network_sevices.YabraaServices
import com.core.shared.state.State
import com.yabraa.medical.core.utils.getResponseMessageError
import com.yabraa.medical.feature.fragments.setting.data.model.response.user_information_response.UserInformationResponseDto
import com.yabraa.medical.feature.fragments.setting.domain.repository.get_user_information_repository.GetUserInformationRepository
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.flow.flow
import kotlinx.coroutines.flow.flowOn
import retrofit2.Response
import javax.inject.Inject

const val TAG_USER_INFORMATION_RESPONSE = "TAG_USER_INFORMATION_RESPONSE"
class GetUserInformationRepositoryImpl @Inject constructor(private val yabraaServices: YabraaServices) :
    BaseRepository<Any, UserInformationResponseDto>(), GetUserInformationRepository {

    override suspend fun getUserInformation() = flow {
        emit(getOperationState(Any()))
    }.flowOn(Dispatchers.IO)

    override suspend fun performApiCall(requestDto: Any): State<UserInformationResponseDto> {
        val response = yabraaServices.getUserInformation()
        return handleGetUserInformationResponse(response)
    }

    private fun handleGetUserInformationResponse(response: Response<UserInformationResponseDto>): State<UserInformationResponseDto> {
        val responseBody = response.body()
        val errorMessageEn = responseBody?.errorMessageEn ?: ""
        val errorMessageAr = responseBody?.errorMessageAr ?: ""
        return when {
            response.isSuccessful && responseBody?.userInformationResponse != null ->
                State.Success(response.body())

            response.isSuccessful && !responseBody?.errorMessageEn.isNullOrEmpty() ->
                getResponseMessageError(
                    errorMessageEn = errorMessageEn,
                    errorMessageAr = errorMessageAr,
                    logTag = TAG_USER_INFORMATION_RESPONSE
                )

            else -> getNotSuccessfulResponseState(response)
        }
    }
}