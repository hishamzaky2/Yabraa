package com.yabraa.medical.feature.fragments.history_payment.presentation.adapter

import android.graphics.Color
import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import android.widget.TextView
import androidx.recyclerview.widget.RecyclerView
import com.yabraa.medical.R
import com.core.shared.utils.CommonUtils.decodeDateString
import com.core.shared.utils.CommonUtils.getLocalizedValue
import com.yabraa.medical.databinding.ItemHistoryPaymentBinding
import com.yabraa.medical.databinding.ItemHistoryPaymentPackageBinding
import com.yabraa.medical.feature.fragments.appointment.my_appointment.domain.model.MyAppointmentStatus.CANCELED
import com.yabraa.medical.feature.fragments.appointment.my_appointment.domain.model.MyAppointmentStatus.REJECTED
import com.yabraa.medical.feature.fragments.history_payment.data.model.PackageItem
import com.yabraa.medical.feature.fragments.history_payment.data.model.PackagesDate
import java.util.Locale

class HistoryPaymentAdapter(private val historyPayment: List<PackagesDate>) :
    RecyclerView.Adapter<HistoryPaymentAdapter.ViewHolder>() {
    override fun onCreateViewHolder(
        parent: ViewGroup,
        viewType: Int
    ): HistoryPaymentAdapter.ViewHolder {
        val binding =
            ItemHistoryPaymentBinding.inflate(LayoutInflater.from(parent.context), parent, false)
        return ViewHolder(binding)
    }

    override fun onBindViewHolder(viewHolder: HistoryPaymentAdapter.ViewHolder, position: Int) {
        val historyPaymentItem = historyPayment[position]
        viewHolder.bind(historyPaymentItem)
    }

    override fun getItemCount() = historyPayment.size

    override fun getItemViewType(position: Int) = position

    inner class ViewHolder(val binding: ItemHistoryPaymentBinding) :
        RecyclerView.ViewHolder(binding.root) {
        val context = binding.root.context
        fun bind(historyPaymentItem: PackagesDate) {
            binding.setupViews(historyPaymentItem)
        }

        private fun ItemHistoryPaymentBinding.setupViews(historyPaymentItem: PackagesDate) {
            dateTv.text = decodeDateString(historyPaymentItem.date, "yyyy-MM-dd")
            setPackageItem(historyPaymentItem)
        }

        private fun setPackageItem(historyPaymentItem: PackagesDate) {
            binding.packageDataRoot.removeAllViews()
            historyPaymentItem.packageItems.forEach {
                val layoutInflater = LayoutInflater.from(context)
                val view = ItemHistoryPaymentPackageBinding.inflate(
                    layoutInflater, binding.packageDataRoot, true
                )
                view.servicesNameTv.text = getLocalizedValue(it.serviceEN, it.serviceAR)
                if (Locale.getDefault().language == "en") {
                    view.paymentTv.textAlignment = View.TEXT_ALIGNMENT_VIEW_END
                }
                view.handlePrice(it)
                view.packageNameTv.text = getLocalizedValue(it.packageNameEN, it.packageNameAR)
            }
        }

        private fun ItemHistoryPaymentPackageBinding.handlePrice(item: PackageItem) {
            val priceString = if (item.status == REJECTED.value || item.status == CANCELED.value) {
                paymentTv.setTextColor("#059E14")
                context.getString(R.string.plusPrice)
            } else {
                context.getString(R.string.minusPrice)
            }
            paymentTv.text = String.format(Locale.ENGLISH, priceString, item.price)
        }

        private fun TextView.setTextColor(color: String) = setTextColor(Color.parseColor(color))
    }
}