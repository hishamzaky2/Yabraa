package com.yabraa.medical.feature.fragments.notification.notification_hisotry.data.model.response.notification_history_response


import com.google.gson.annotations.SerializedName

data class NotificationHistoryResponse(
    @SerializedName("isALLRead")
    val isALLRead: Boolean,
    @SerializedName("notifications")
    val notifications: List<Notification>,
    @SerializedName("pageNumber")
    val pageNumber: Int,
    @SerializedName("pageSize")
    val pageSize: Int,
    @SerializedName("count")
    val count: Int
)