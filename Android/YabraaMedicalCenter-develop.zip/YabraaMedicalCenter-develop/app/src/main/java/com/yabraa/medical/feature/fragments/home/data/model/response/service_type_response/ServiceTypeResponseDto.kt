package com.yabraa.medical.feature.fragments.home.data.model.response.service_type_response


import com.google.gson.annotations.SerializedName

data class ServiceTypeResponseDto(
    @SerializedName("data")
    val serviceTypeResponse: List<ServiceTypeResponse>,
    @SerializedName("errorMessageAr")
    val errorMessageAr: String? = null,
    @SerializedName("errorMessageEn")
    val errorMessageEn:  String? = null,
    @SerializedName("statusCode")
    val statusCode: Int
)