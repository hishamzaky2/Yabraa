package com.yabraa.medical.feature.fragments.patients.add_patient.domain.usecase

import com.yabraa.medical.feature.fragments.patients.add_patient.data.model.request.AddPatientRequest
import com.yabraa.medical.feature.fragments.patients.add_patient.domain.repository.AddPatientRepository
import javax.inject.Inject

class AddPatientUseCase @Inject constructor(private val addPatientRepository: AddPatientRepository) {
    suspend operator fun invoke(addPatientRequest: AddPatientRequest) =
        addPatientRepository.addPatient(addPatientRequest)

}