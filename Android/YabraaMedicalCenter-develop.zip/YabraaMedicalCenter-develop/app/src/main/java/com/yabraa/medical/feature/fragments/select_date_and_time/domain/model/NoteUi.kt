package com.yabraa.medical.feature.fragments.select_date_and_time.domain.model

data class NoteUi (val packageId : Long? = null , val note : String? = null)