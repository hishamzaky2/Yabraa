package com.yabraa.medical.feature.fragments.home.data.repository.service_type_repository

import com.yabraa.medical.core.base_repository.BaseRepository
import com.yabraa.medical.core.di.network_sevices.YabraaServices
import com.core.shared.state.State
import com.yabraa.medical.core.utils.getResponseMessageError
import com.yabraa.medical.feature.fragments.home.data.model.response.service_type_response.ServiceTypeResponseDto
import com.yabraa.medical.feature.fragments.home.domain.repository.service_type_repository.ServiceTypeRepository
import kotlinx.coroutines.flow.flow
import retrofit2.Response
import javax.inject.Inject

const val TAG_SERVICE_TYPE_RESPONSE = "TAG_SERVICE_TYPE_RESPONSE"

class ServiceTypeRepositoryImpl @Inject constructor(private val yabraaServices: YabraaServices) :
    BaseRepository<Any, ServiceTypeResponseDto>(), ServiceTypeRepository {


    override suspend fun getServiceType() = flow {
        emit(getOperationState(Any()))
    }

    override suspend fun performApiCall(requestDto: Any): State<ServiceTypeResponseDto> {
        val response = yabraaServices.getServiceType()
        return handleServiceTypeResponse(response)
    }

    private fun handleServiceTypeResponse(response: Response<ServiceTypeResponseDto>): State<ServiceTypeResponseDto> {
        val responseBody = response.body()
        val errorMessageEn = responseBody?.errorMessageEn ?: ""
        val errorMessageAr = responseBody?.errorMessageAr ?: ""
        return when {
            response.isSuccessful && responseBody?.serviceTypeResponse != null -> State.Success(
                response.body()
            )

            response.isSuccessful && !responseBody?.errorMessageEn.isNullOrEmpty() -> getResponseMessageError(
                errorMessageEn = errorMessageEn,
                errorMessageAr = errorMessageAr,
                logTag = TAG_SERVICE_TYPE_RESPONSE
            )

            else -> getNotSuccessfulResponseState(response)
        }
    }
}