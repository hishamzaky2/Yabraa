package com.yabraa.medical.feature.fragments.onboard.data.response


import com.google.gson.annotations.SerializedName


data class OnboardPagesResponseDto(
    @SerializedName("data")
    val data: List<StartPageDataResponse>,
    @SerializedName("errorMessageAr")
    val errorMessageAr: String? = null,
    @SerializedName("errorMessageEn")
    val errorMessageEn: String? = null,
    @SerializedName("statusCode")
    val statusCode: Int
)