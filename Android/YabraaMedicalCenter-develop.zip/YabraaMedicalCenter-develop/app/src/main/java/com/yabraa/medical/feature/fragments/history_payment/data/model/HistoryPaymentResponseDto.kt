package com.yabraa.medical.feature.fragments.history_payment.data.model


import com.google.gson.annotations.SerializedName

data class HistoryPaymentResponseDto(
    @SerializedName("data")
    val historyPaymentResponse: HistoryPaymentResponse,
    @SerializedName("errorMessageAr")
    val errorMessageAr: String? = null,
    @SerializedName("errorMessageEn")
    val errorMessageEn: String? = null,
    @SerializedName("statusCode")
    val statusCode: Int
)