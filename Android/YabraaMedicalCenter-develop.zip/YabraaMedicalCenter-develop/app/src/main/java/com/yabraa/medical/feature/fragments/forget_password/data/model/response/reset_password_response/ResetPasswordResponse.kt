package com.yabraa.medical.feature.fragments.forget_password.data.model.response.reset_password_response


import com.google.gson.annotations.SerializedName

data class ResetPasswordResponse(
    @SerializedName("messageAr")
    val messageAr: String,
    @SerializedName("messageEn")
    val messageEn: String,
    @SerializedName("phoneNumber")
    val phoneNumber: String
)