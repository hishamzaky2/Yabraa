package com.yabraa.medical.core.utils.custom_views.confirmation_appointment

import android.content.Context
import android.util.AttributeSet
import android.view.LayoutInflater
import android.widget.FrameLayout
import com.yabraa.medical.databinding.LayoutConfirmationAppointmentsBinding

class ConfirmationAppointmentView @JvmOverloads constructor(
    context: Context, attributes: AttributeSet? = null
) : FrameLayout(context, attributes) {

    val binding =
        LayoutConfirmationAppointmentsBinding.inflate(LayoutInflater.from(context), this, true)

    val confirmationAppointmentBtn by lazy { binding.confirmingAppointmentsBtn }

    val cancelBtn by lazy { binding.cancelAppointmentsBtn }
}