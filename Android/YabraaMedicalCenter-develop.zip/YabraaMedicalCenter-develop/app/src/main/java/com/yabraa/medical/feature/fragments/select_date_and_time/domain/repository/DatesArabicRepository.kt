package com.yabraa.medical.feature.fragments.select_date_and_time.domain.repository

import com.core.shared.state.State
import com.yabraa.medical.feature.fragments.select_date_and_time.data.response.DatesResponseDto
import kotlinx.coroutines.flow.Flow

interface DatesArabicRepository {
    suspend fun getDatesArabic(): Flow<State<DatesResponseDto>>
}