package com.yabraa.medical.feature.fragments.register.data.request


data class RegisterRequestDto(
    val firstName: String,
    val lastName: String,
    val password: String? = null,
    val phoneNumber: String? = null,
    val birthDate: String,
    val gender: String,
    val countryCode: String,
    val idOrIqamaOrPassport: String? = null,
    val email: String? = null
)