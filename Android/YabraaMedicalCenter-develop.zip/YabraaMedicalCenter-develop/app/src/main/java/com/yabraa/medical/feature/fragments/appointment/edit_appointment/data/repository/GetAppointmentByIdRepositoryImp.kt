package com.yabraa.medical.feature.fragments.appointment.edit_appointment.data.repository

import com.yabraa.medical.core.base_repository.BaseRepository
import com.yabraa.medical.core.di.network_sevices.YabraaServices
import com.core.shared.state.State
import com.yabraa.medical.core.utils.getResponseMessageError
import com.yabraa.medical.feature.fragments.appointment.edit_appointment.data.model.response.AppointmentResponseDto
import com.yabraa.medical.feature.fragments.appointment.edit_appointment.domain.repository.GetAppointmentByIdRepository
import kotlinx.coroutines.flow.flow
import retrofit2.Response
import javax.inject.Inject

const val TAG_GET_APPOINTMENT_BY_ID_REPOSITORY = "TAG_GET_APPOINTMENT_BY_ID_REPOSITORY"

class GetAppointmentByIdRepositoryImp @Inject constructor(private val yabraaServices: YabraaServices) :
    BaseRepository<Long, AppointmentResponseDto>(), GetAppointmentByIdRepository {

    override suspend fun getAppointmentById(appointmentId: Long) = flow {
        emit(getOperationState(appointmentId))
    }

    override suspend fun performApiCall(requestDto: Long): State<AppointmentResponseDto> {
        val response = yabraaServices.getAppointmentById(requestDto)
        return handGetAppointmentByIdResponse(response)
    }


    private fun handGetAppointmentByIdResponse(response: Response<AppointmentResponseDto>): State<AppointmentResponseDto> {
        val responseBody = response.body()
        val errorMessageEn = responseBody?.errorMessageEn ?: ""
        val errorMessageAr = responseBody?.errorMessageAr ?: ""
        return when {
            response.isSuccessful && responseBody?.appointmentResponse != null -> State.Success(
                response.body()
            )

            response.isSuccessful && !responseBody?.errorMessageEn.isNullOrEmpty() -> getResponseMessageError(
                errorMessageEn = errorMessageEn,
                errorMessageAr = errorMessageAr,
                logTag = TAG_GET_APPOINTMENT_BY_ID_REPOSITORY
            )

            else -> getNotSuccessfulResponseState(response)
        }
    }
}