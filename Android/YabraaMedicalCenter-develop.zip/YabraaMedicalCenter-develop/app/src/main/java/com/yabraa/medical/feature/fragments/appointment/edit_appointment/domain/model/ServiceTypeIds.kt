package com.yabraa.medical.feature.fragments.appointment.edit_appointment.domain.model

enum class ServiceTypeIds (val serviceTypeId: Long) {
    NORMAL(1L),VIRTUAL(2L)
}