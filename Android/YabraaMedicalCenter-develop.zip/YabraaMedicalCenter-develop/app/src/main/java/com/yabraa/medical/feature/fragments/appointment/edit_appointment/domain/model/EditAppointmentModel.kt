package com.yabraa.medical.feature.fragments.appointment.edit_appointment.domain.model

import java.io.Serializable

data class EditAppointmentModel(
    var isEditAppointmentWay: Boolean,
    var appointmentId : Long,
    var notes: String? = null,
    var locationLatitude: Double? = null,
    var locationLongitude: Double? = null,
    val serviceTypeId : Long
) : Serializable