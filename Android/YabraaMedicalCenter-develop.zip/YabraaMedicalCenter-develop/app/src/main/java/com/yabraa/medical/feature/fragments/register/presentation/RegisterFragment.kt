package com.yabraa.medical.feature.fragments.register.presentation

import android.annotation.SuppressLint
import android.os.Build
import android.os.Bundle
import android.view.View
import android.widget.RadioButton
import androidx.annotation.StringRes
import androidx.core.content.ContextCompat.getColorStateList
import androidx.core.os.bundleOf
import androidx.core.view.isVisible
import androidx.core.widget.doAfterTextChanged
import androidx.hilt.navigation.fragment.hiltNavGraphViewModels
import androidx.lifecycle.lifecycleScope
import com.yabraa.medical.R
import com.yabraa.medical.core.base_fragment.BaseFragment
import com.yabraa.medical.core.base_fragment.navigate
import com.yabraa.medical.core.base_fragment.navigateUp
import com.yabraa.medical.core.base_fragment.setOnGoToConnectionSettingClicked
import com.core.shared.error.EmptyBirthDate
import com.core.shared.error.EmptyCountryCode
import com.core.shared.error.EmptyFirstName
import com.core.shared.error.EmptyGender
import com.core.shared.error.EmptyLastName
import com.core.shared.error.EmptyPassword
import com.core.shared.error.EmptyPhoneNumber
import com.core.shared.error.IdOrOrPassport
import com.core.shared.error.InvalidEmail
import com.core.shared.error.OperationMessage
import com.core.shared.error.PasswordLetThanSixCharacter
import com.core.shared.error.YabraaError
import com.core.shared.state.State
import com.core.shared.utils.CommonUtils.getLocalizedValue
import com.core.shared.utils.CommonUtils.handleExpirationDate
import com.yabraa.medical.core.utils.containsArabicLetters
import com.yabraa.medical.core.utils.dialog.nationality_bottom_dilaog.NationalityBottomSheetDialog
import com.yabraa.medical.core.utils.dialog.yabraa_date_picker_dialog.YabraaDatePickerDialog
import com.yabraa.medical.core.utils.dialog.yabraa_dialog.YabraaDialogBuilder
import com.yabraa.medical.core.utils.getErrorMessage
import com.yabraa.medical.core.utils.removeFirstZeroFromPhoneNumber
import com.yabraa.medical.databinding.FragmentRegisterBinding
import com.yabraa.medical.feature.activits.mainactivity.MainActivity
import com.yabraa.medical.feature.fragments.common.domain.model.ErrorMessageUi
import com.yabraa.medical.feature.fragments.common.domain.viewmodel.RegistrationViewModel
import com.yabraa.medical.feature.fragments.register.data.request.GenderType
import com.yabraa.medical.feature.fragments.register.data.response.nationality_response.Nationality
import com.yabraa.medical.feature.fragments.register.data.response.user_input_validation_response.UserInputValidationResponse
import com.yabraa.medical.feature.fragments.register.domain.model.RegisterUiModel
import com.yabraa.medical.feature.fragments.register.presentation.adapter.NationalityAdapter
import com.yabraa.medical.feature.fragments.setting.data.model.response.user_information_response.UserInformationResponse
import com.yabraa.medical.feature.fragments.setting.presentation.USER_INFORMATION
import dagger.hilt.android.AndroidEntryPoint
import kotlinx.coroutines.FlowPreview
import kotlinx.coroutines.Job
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.debounce
import kotlinx.coroutines.launch
import timber.log.Timber
import javax.inject.Inject

const val REGISTER_FRAGMENT = "REGISTER_FRAGMENT"

@AndroidEntryPoint
class RegisterFragment : BaseFragment<FragmentRegisterBinding>() {

    override val binding by lazy { FragmentRegisterBinding.inflate(layoutInflater) }
    private val viewModel: RegistrationViewModel by hiltNavGraphViewModels(R.id.loginAndRegisterGraph)

    @Inject
    lateinit var nationalityBottomSheetDialog: NationalityBottomSheetDialog

    @Inject
    lateinit var yabraaDatePickerDialog: YabraaDatePickerDialog

    private var birthDate: String? = null
    private var genderType: String? = null
    private var countryCode: String? = null
    private var userInputValidationJob: Job? = null

    private val searchCountryFlow = MutableStateFlow(Nationality())
    private val getNationalityList get() = viewModel.getAllNationalityList()
    private val nationalityAdapter by lazy {
        val nationalityList = getNationalityList ?: emptyList()
        NationalityAdapter(nationalityList) {
            binding.handleSelectedNational(it)
        }
    }

    @Suppress("DEPRECATION")
    private val userInformation
        get() = run {
            if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.TIRAMISU) {
                arguments?.getSerializable(USER_INFORMATION, UserInformationResponse::class.java)
            } else {
                arguments?.getSerializable(USER_INFORMATION)
            }
        } as? UserInformationResponse

    private val isEditAccount get() = userInformation != null

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        if (isEditAccount) showExpirationDateError()
        binding.handleNetworkConnection()
    }

    override fun onViewCreated(view: View, savedInstanceState: Bundle?) {
        super.onViewCreated(view, savedInstanceState)
        binding.setUpViews()
    }

    override fun onResume() {
        super.onResume()
        showYabraaBar(false)
    }

    private fun FragmentRegisterBinding.setUpViews() {
        if (userInformation != null) setUpEditAccountViews()
        internetConnection.goToSettingBtn.setOnGoToConnectionSettingClicked(requireActivity())
        setOnBackClicked()
        setOnDateOfBirthViewClicked()
        setOnGenderSelectedClicked()
        setOnNationalityViewClicked()
        phoneNumberEt.removeFirstZeroFromPhoneNumber()
        lifecycleScope.launch { collectOnInputValidationState() }
        setOnCreateAccountClicked()
        lifecycleScope.launch { collectOnNationalityList() }
        userInputValidationJob = lifecycleScope.launch { collectOnUserInputValidationResponse() }
        handleSearchCountry()
    }

    private fun FragmentRegisterBinding.setOnBackClicked() = backArrowIv.setOnClickListener {
        if (isEditAccount) {
          activity?.onBackPressedDispatcher?.onBackPressed()
        } else {
            backArrowIv.setOnClickListener { navigateUp() }
        }
    }


    private fun FragmentRegisterBinding.setOnDateOfBirthViewClicked() {
        dateOfBirthView.setOnClickListener { setDateOfBirthView() }
    }


    private fun FragmentRegisterBinding.setDateOfBirthView() {
        val dateOfBirthTvColor =
            getColorStateList(requireContext(), R.color.primaryDark900)
        yabraaDatePickerDialog.datePickerDialog(requireActivity()) {
            if (it.isEmpty()) return@datePickerDialog
            dateOfBirthTv.setTextColor(dateOfBirthTvColor)
            dateOfBirthTv.text = it
            birthDate = it
        }?.show()
    }


    private fun FragmentRegisterBinding.setOnGenderSelectedClicked() {
        radioBtnGroup.setOnCheckedChangeListener { _, checkedId ->
            when (checkedId) {
                R.id.maleBtn -> genderType = GenderType.MALE.genderValue
                R.id.femaleBtn -> genderType = GenderType.FEMALE.genderValue
            }
        }
    }

    private fun FragmentRegisterBinding.setOnNationalityViewClicked() {
        nationalityView.setOnClickListener {
            nationalityBottomSheetDialog.showBottomSheetDialog()
        }
    }


    private fun FragmentRegisterBinding.handleNetworkConnection() {
        connectivityManager?.isNetworkConnected?.observe(this@RegisterFragment) {
            handleConnectionViewVisibility(it)
            if (!it) return@observe
            viewModel.getNationalityList()
        }
    }

    private fun FragmentRegisterBinding.handleConnectionViewVisibility(isVisible: Boolean) {
        registerGroup.isVisible = isVisible
        internetConnection.root.isVisible = !isVisible
    }

    private suspend fun collectOnNationalityList() {
        viewModel.nationalityListState.collect {
            hideProgressDialog()
            when (it) {
                is State.Initial -> {}
                is State.Error -> it.error.handleError { }
                is State.Loading -> showProgressDialog()
                is State.Success -> {
                    setNationalityAdapter()
                    observeSearchFlow()
                }
            }
        }
    }

    private fun setNationalityAdapter() {
        nationalityBottomSheetDialog.setRecyclerAdapter(nationalityAdapter)
    }

    private fun FragmentRegisterBinding.handleSelectedNational(nationality: Nationality) {
        val nationalityTvColor = getColorStateList(requireContext(), R.color.primaryDark900)
        nationalityBottomSheetDialog.dismissBottomSheet()
        nationalityTv.text = nationality.getCountryName(nationality)
        nationalityTv.setTextColor(nationalityTvColor)
        countryCode = nationality.countryCode
    }


    private fun FragmentRegisterBinding.setOnCreateAccountClicked() {
        createAccountBtn.setOnClickListener {
            viewModel.validateUserInputValidationInput(setRegisterUiModel(), isEditAccount)
        }
    }

    private suspend fun collectOnInputValidationState() {
        viewModel.validationState.collect {
            when (it) {
                is State.Initial -> {}
                is State.Error -> handleError(it)
                is State.Success -> {}
                is State.Loading -> {}
            }
        }
    }

    private fun handleError(errorState: State.Error<*>) {
        errorState.error.handleError {
            when (exception) {
                is EmptyFirstName -> showInputErrorSnackBar(R.string.pleaseEnterFirstName)
                is EmptyLastName -> showInputErrorSnackBar(R.string.pleaseEnterLastName)
                is EmptyPassword -> showInputErrorSnackBar(R.string.pleaseEnterPassword)
                is PasswordLetThanSixCharacter -> showInputErrorSnackBar(R.string.passwordsMustBeAtLeastSixCharacters)
                is EmptyPhoneNumber -> showInputErrorSnackBar(R.string.pleaseEnterPhoneNumber)
                is EmptyBirthDate -> showInputErrorSnackBar(R.string.pleaseEnterYourBirthDate)
                is EmptyGender -> showInputErrorSnackBar(R.string.pleaseSelectSex)
                is EmptyCountryCode -> showInputErrorSnackBar(R.string.pleaseSelectCountry)
                is IdOrOrPassport -> showInputErrorSnackBar(R.string.pleaseEnterIdOrPassport)
                is InvalidEmail -> showInputErrorSnackBar(R.string.pleaseEnterValidEmail)
            }
        }
    }


    private fun showInputErrorSnackBar(@StringRes message: Int) =
        yabraaSnackBarBuilder.setEndIcon(R.drawable.ic_vector_close).setMessage(message)
            .build(requireView()).show()


    private suspend fun collectOnUserInputValidationResponse() {
        viewModel.userValidationResponseDtoState.collect {
            hideProgressDialog()
            when (it) {
                is State.Initial -> {}
                is State.Error -> it.error.handleRegisterResponseError()
                is State.Loading -> showProgressDialog()
                is State.Success -> navigateToOtpVerificationScreen(it.data?.userInputValidationResponse)
            }
        }
    }


    private fun YabraaError.handleRegisterResponseError() {
        val errorMessageUi =  ErrorMessageUi(logMessageEn, logMessageAr)
        handleError {
            when (exception) {
                is OperationMessage -> showUserInputValidationResponseErrorPopup(errorMessageUi)
            }
        }
    }


    private fun showUserInputValidationResponseErrorPopup(errorMessageUi: ErrorMessageUi) {
        val errorMessage = getErrorMessage(errorMessageUi)
        YabraaDialogBuilder(requireActivity()).setIcon(R.drawable.ic_vector_error)
            .setTitle(R.string.warning)
            .setMessage(errorMessage).setTopButton(R.string.ok) {
                //TODO LOG MESSAGE HERE
            }.setCancelable(false).show()
    }

    private fun navigateToOtpVerificationScreen(userInputValidationResponse: UserInputValidationResponse?) {
        if (userInputValidationResponse == null) return
        userInputValidationJob?.cancel()
        val bundle = bundleOf(REGISTER_FRAGMENT to true)
        navigate(R.id.actionToOtpVerificationFragment, bundle)
    }


    @OptIn(FlowPreview::class)
    private suspend fun observeSearchFlow() = searchCountryFlow.debounce(500).collect {
        try {
            it.getSearchCountry()
        } catch (e: Exception) {
            Timber.e(e)
        }
    }


    private fun Nationality.getSearchCountry() {
        if (countryAr.isNullOrBlank() && countryEn.isNullOrBlank()) {
            setNationalityAdapter()
            return
        }
        nationalityBottomSheetDialog.searchInput {
            val nationalityList = viewModel.getSearchCountryByName(it.text.toString()) ?: emptyList()
            nationalityList.setSearchCountryAdapter()
        }
    }

    private fun List<Nationality>.setSearchCountryAdapter() {
        val adapter = NationalityAdapter(this) {
            binding.handleSelectedNational(it)
        }
        nationalityBottomSheetDialog.setRecyclerAdapter(adapter)
    }

    private fun handleSearchCountry() = nationalityBottomSheetDialog.searchInput {
        it.doAfterTextChanged { editable ->
            val text = editable.toString().trim()
            val searchCountry = when {
                text.containsArabicLetters() -> Nationality(countryAr = text)
                else -> Nationality(countryEn = text)
            }
            searchCountryFlow.tryEmit(searchCountry)
        }
    }

    /* ------------------------- Edit Account Section -------------------- */

    private fun FragmentRegisterBinding.setUpEditAccountViews() {
        setRegisterTv()
        setFirstNameTv()
        setLastNameTv()
        setPhoneNumber()
        setDateOfBirthTv()
        setGenderType()
        setNationalityTv()
        setIdPassport()
        setEmail()
        setEditAccountBtnTv()
        lifecycleScope.launch { collectOnEditAccountResponseState() }
    }

    private fun FragmentRegisterBinding.setRegisterTv() {
        registerTv.text = R.string.editAccount.localize()
    }

    private fun FragmentRegisterBinding.setFirstNameTv() =
        firstNameEt.setText(userInformation?.firstName)

    private fun FragmentRegisterBinding.setLastNameTv() =
        lastNameEt.setText(userInformation?.lastName)


    @SuppressLint("ResourceAsColor")
    private fun FragmentRegisterBinding.setPhoneNumber() {
        phoneNumberEt.isEnabled = false
        phoneNumberEt.setText(userInformation?.phoneNumber)
        phoneNumberEt.setTextColor(R.color.primaryLight400)
        countryCodeTv.setTextColor(R.color.primaryLight400)
    }

    private fun FragmentRegisterBinding.setDateOfBirthTv() {
        birthDate = userInformation?.birthDate
        val dateOfBirthTvColor = getColorStateList(requireContext(), R.color.primaryDark900)
        dateOfBirthTv.text = userInformation?.birthDate
        dateOfBirthTv.setTextColor(dateOfBirthTvColor)
    }

    private fun setGenderType() {
        genderType = userInformation?.gender
        setMaleGenderValue()
        setFemaleGenderValue()
    }

    private fun setMaleGenderValue() {
        val maleBtn = activity?.findViewById(R.id.maleBtn) as RadioButton
        maleBtn.isChecked = userInformation?.gender == GenderType.MALE.genderValue
    }

    private fun setFemaleGenderValue() {
        val femaleBtn = activity?.findViewById(R.id.femaleBtn) as RadioButton
        femaleBtn.isChecked = userInformation?.gender == GenderType.FEMALE.genderValue
    }

    private fun FragmentRegisterBinding.setNationalityTv() {
        val nationality = getLocalizedValue(
            userInformation?.nationalityEn, userInformation?.nationalityAr
        )
        val nationalityTvColor = getColorStateList(requireContext(), R.color.primaryDark900)
        nationalityTv.text = nationality
        nationalityTv.setTextColor(nationalityTvColor)
        countryCode = userInformation?.countryCode
    }

    private fun FragmentRegisterBinding.setIdPassport() {
        if (userInformation?.idOrIqamaOrPassport == null) return
        idOrPassportEt.setText(userInformation?.idOrIqamaOrPassport)
    }

    private fun FragmentRegisterBinding.setEmail() {
        if (userInformation?.email == null) return
        emailEt.setText(userInformation?.email)
    }

    private fun FragmentRegisterBinding.setEditAccountBtnTv() {
        createAccountBtn.text = R.string.editAccount.localize()
    }

    private suspend fun collectOnEditAccountResponseState() {
        viewModel.editAccountResponseDtoState.collect {
            hideProgressDialog()
            when (it) {
                is State.Error -> it.error.handleRegisterResponseError()
                is State.Initial -> {}
                is State.Loading -> showProgressDialog()
                is State.Success -> showEditAccountResponseSuccessPopup()
            }
        }
    }

    private fun showEditAccountResponseSuccessPopup() {
        YabraaDialogBuilder(requireActivity()).setIcon(R.drawable.ic_vector_check_circle)
            .setTitle(R.string.success)
            .setMessage(R.string.pleaseLoginAgain)
            .setTopButton(R.string.ok) { handleRestartActivity() }
            .setCancelable(false)
            .show()
    }

    private fun handleRestartActivity() {
        tokenHandler.clearToken()
        (activity as MainActivity).restartActivity()
    }

    private fun FragmentRegisterBinding.setRegisterUiModel(): RegisterUiModel {
        val idOrPassport =
            if (!idOrPassportEt.text.isNullOrEmpty()) idOrPassportEt.text.toString() else null
        val email = if (!emailEt.text.isNullOrEmpty()) emailEt.text.toString().trim() else null
        val password = if (!passwordEt.text.isNullOrEmpty()) passwordEt.text.toString() else null
        val phoneNumber = if (!isEditAccount) phoneNumberEt.text.toString() else null
        return RegisterUiModel(
            firstName = firstNameEt.text.toString(),
            lastName = lastNameEt.text.toString(),
            password = password,
            phoneNumber = phoneNumber,
            birthDate = birthDate ?: "",
            gender = genderType ?: "",
            countryCode = countryCode ?: "",
            idOrIqamaOrPassport = idOrPassport,
            email = email
        )
    }

    private fun showExpirationDateError() =
        tokenHandler.handleExpirationDate { showExpirationDatePopupError() }
}