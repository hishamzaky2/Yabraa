package com.yabraa.medical.feature.fragments.patients.patients.di

import dagger.Module
import dagger.Provides
import dagger.hilt.InstallIn
import dagger.hilt.android.components.ViewModelComponent
import com.yabraa.medical.core.di.network_sevices.YabraaServices
import com.yabraa.medical.feature.fragments.patients.patients.data.repository.PatientListRepositoryImpl
import com.yabraa.medical.feature.fragments.patients.patients.domain.repository.PatientListRepository

@Module
@InstallIn(ViewModelComponent::class)
object PatientsModule {

    @Provides
    fun providePatientListRepository(yabraaServices: YabraaServices): PatientListRepository =
        PatientListRepositoryImpl(yabraaServices)

}