package com.yabraa.medical.feature.fragments.register.data.response.register_response


import com.google.gson.annotations.SerializedName


data class RegisterResponseDto(
    @SerializedName("data")
    val registerDataResponse: RegisterDataResponse? = null,
    @SerializedName("errorMessageAr")
    val errorMessageAr: String? = null,
    @SerializedName("errorMessageEn")
    val errorMessageEn: String? = null,
    @SerializedName("statusCode")
    val statusCode: Int
)