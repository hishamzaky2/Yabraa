package com.yabraa.medical.feature.fragments.main

import android.os.Bundle
import android.view.View
import androidx.core.view.isVisible
import androidx.navigation.fragment.NavHostFragment
import androidx.navigation.ui.setupWithNavController
import com.yabraa.medical.R
import com.yabraa.medical.core.base_fragment.BaseFragment
import com.yabraa.medical.core.utils.custom_views.confirmation_appointment.ConfirmationAppointmentHandler
import com.yabraa.medical.databinding.FragmentMainBinding


class MainFragment : BaseFragment<FragmentMainBinding>(), BottomNavigationStatus,
    ConfirmationAppointmentHandler {

    override val binding by lazy { FragmentMainBinding.inflate(layoutInflater) }

    private val navController by lazy {
        val navHostFragment =
            childFragmentManager.findFragmentById(R.id.navHostFragment) as NavHostFragment
        navHostFragment.navController
    }

    override fun onViewCreated(view: View, savedInstanceState: Bundle?) {
        super.onViewCreated(view, savedInstanceState)
        binding.navView.setupWithNavController(navController)
    }


    override fun showBottomNavigation(show: Boolean) {
        binding.navView.isVisible = show
    }

    override fun setConfirmationAppointmentVisibility(isVisible: Boolean) {
        binding.confirmationView.isVisible = isVisible
    }

    override fun setOnConfirmationAppointmentClicked(listener: () -> Unit) {
        binding.confirmationView.confirmationAppointmentBtn.setOnClickListener { listener() }
    }

    override fun handleEnabledConfirmationAppointmentBtn(isEnabled: Boolean) {
        binding.confirmationView.confirmationAppointmentBtn.isEnabled = isEnabled
    }

    override fun setTextConfirmationBtn(text: Int) {
        binding.confirmationView.confirmationAppointmentBtn.setText(text)
    }

    override fun setOnCancelClicked(listener: () -> Unit) {
        binding.confirmationView.cancelBtn.setOnClickListener { listener() }
    }

    override fun handleEnabledCancelBtn(isEnabled: Boolean) {
        binding.confirmationView.cancelBtn.isEnabled = isEnabled
    }

    override fun setTextCancelBtn(text: Int) {
        binding.confirmationView.cancelBtn.setText(text)
    }

}

interface BottomNavigationStatus {
    fun showBottomNavigation(show: Boolean)
}