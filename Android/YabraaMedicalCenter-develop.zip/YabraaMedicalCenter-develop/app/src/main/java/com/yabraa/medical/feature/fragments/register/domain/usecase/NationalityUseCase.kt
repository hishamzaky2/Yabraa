package com.yabraa.medical.feature.fragments.register.domain.usecase

import com.core.shared.state.State
import com.yabraa.medical.feature.fragments.register.data.response.nationality_response.NationalityResponseDto
import com.yabraa.medical.feature.fragments.register.domain.repository.NationalityRepository
import kotlinx.coroutines.async
import kotlinx.coroutines.flow.Flow
import kotlinx.coroutines.flow.channelFlow
import javax.inject.Inject

class NationalityUseCase @Inject constructor(private val nationalityRepository: NationalityRepository) {

    private var responseDto: NationalityResponseDto? = null

    operator fun invoke(): Flow<State<NationalityResponseDto>> {
        return channelFlow {
            val nationalityResponseDto = async { nationalityRepository.getNationalityList() }
            nationalityResponseDto.await().collect {
                if (it is State.Success) {
                    responseDto = it.data
                }
                send(it)
            }
        }
    }


    fun getNationalityList() = responseDto?.nationalityDataResponse?.nationalities

    fun getSearchCountryByName(searchInput: String) =
        responseDto?.nationalityDataResponse?.nationalities?.filter {
            it.countryAr?.startsWith(searchInput, ignoreCase = true) == true ||
                    it.countryEn?.startsWith(searchInput, ignoreCase = true) == true
        }
}