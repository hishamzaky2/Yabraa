package com.yabraa.medical.feature.fragments.patients.patients.domain.usecase

import kotlinx.coroutines.async
import kotlinx.coroutines.flow.Flow
import kotlinx.coroutines.flow.channelFlow
import com.core.shared.state.State
import com.yabraa.medical.feature.fragments.patients.patients.data.model.response.PatientResponseDto
import com.yabraa.medical.feature.fragments.patients.patients.domain.repository.PatientListRepository
import javax.inject.Inject

class PatientListUseCase @Inject constructor(private val patientListRepository: PatientListRepository) {

    private var responseDto: PatientResponseDto? = null

    suspend operator fun invoke(): Flow<State<PatientResponseDto>> {
        return channelFlow {
            val patientResponseDto = async { patientListRepository.getPatientList() }
            patientResponseDto.await().collect {
                if (it is State.Success) {
                    responseDto = it.data
                }
                send(it)
            }
        }
    }


    fun getPatientList() = responseDto?.patientResponse?.toMutableList() ?: mutableListOf()
}