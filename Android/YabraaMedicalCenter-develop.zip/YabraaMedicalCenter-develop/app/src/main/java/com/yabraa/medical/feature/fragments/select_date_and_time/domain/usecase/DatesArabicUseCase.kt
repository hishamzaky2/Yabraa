package com.yabraa.medical.feature.fragments.select_date_and_time.domain.usecase

import com.core.shared.state.State
import com.yabraa.medical.feature.fragments.select_date_and_time.data.response.DatesResponseDto
import com.yabraa.medical.feature.fragments.select_date_and_time.domain.repository.DatesArabicRepository
import kotlinx.coroutines.async
import kotlinx.coroutines.flow.Flow
import kotlinx.coroutines.flow.channelFlow
import timber.log.Timber
import javax.inject.Inject

class DatesArabicUseCase @Inject constructor(private val datesArabicRepository: DatesArabicRepository) {

    private var responseDto: DatesResponseDto? = null

    operator fun invoke(): Flow<State<DatesResponseDto>> {
        return channelFlow {
            val datesResponse = async { datesArabicRepository.getDatesArabic() }
            datesResponse.await().collect {
                if (it is State.Success) {
                    Timber.e("${it.data}")
                    responseDto = it.data
                }
                send(it)
            }
        }
    }

    fun getDatesArabicDataResponse() = responseDto?.datesDataResponse ?: emptyList()

    fun getFirstMonthArabic() = responseDto?.datesDataResponse?.first()?.monthName ?: ""

    fun getSecondMonthArabic() = responseDto?.datesDataResponse?.last()?.monthName ?: ""
    fun getFirstYearArabic() =  responseDto?.datesDataResponse?.firstOrNull()?.year ?: 0
    fun getLastYearArabic() =  responseDto?.datesDataResponse?.lastOrNull()?.year ?: 0

}