package com.yabraa.medical.feature.fragments.forget_password.data.repository

import com.yabraa.medical.core.base_repository.BaseRepository
import com.yabraa.medical.core.di.network_sevices.SecurityServices
import com.core.shared.state.State
import com.yabraa.medical.core.utils.getResponseMessageError
import com.yabraa.medical.feature.fragments.forget_password.data.model.request.ForgetPasswordRequestDto
import com.yabraa.medical.feature.fragments.forget_password.data.model.response.forget_password_response.ForgetPasswordResponseDto
import com.yabraa.medical.feature.fragments.forget_password.domain.rposetory.ForgetPasswordRepository
import kotlinx.coroutines.flow.flow
import kotlinx.coroutines.flow.flowOn
import retrofit2.Response
import javax.inject.Inject

const val TAG_FORGET_PASSWORD_RESPONSE = "TAG_FORGET_PASSWORD_RESPONSE"

class ForgetPasswordRepositoryImpl @Inject constructor(private val securityServices: SecurityServices) :
    BaseRepository<ForgetPasswordRequestDto, ForgetPasswordResponseDto>(),
    ForgetPasswordRepository {

    override suspend fun forgetPassword(forgetPasswordRequestDto: ForgetPasswordRequestDto) = flow {
        emit(getOperationState(forgetPasswordRequestDto))
    }.flowOn(dispatcher)

    override suspend fun performApiCall(requestDto: ForgetPasswordRequestDto): State<ForgetPasswordResponseDto> {
        val response = securityServices.forgetPassword(requestDto)
        return handleForgetPasswordResponse(response)
    }

    private fun handleForgetPasswordResponse(response: Response<ForgetPasswordResponseDto>): State<ForgetPasswordResponseDto> {
        val responseBody = response.body()
        val errorMessageEn = responseBody?.errorMessageEn ?: ""
        val errorMessageAr = responseBody?.errorMessageAr ?: ""
        return when {
            response.isSuccessful && responseBody?.forgetPasswordDataResponse != null ->
                State.Success(response.body())

            response.isSuccessful && !responseBody?.errorMessageEn.isNullOrEmpty() -> getResponseMessageError(
                errorMessageEn = errorMessageEn,
                errorMessageAr = errorMessageAr,
                logTag = TAG_FORGET_PASSWORD_RESPONSE
            )

            else -> getNotSuccessfulResponseState(response)
        }
    }

}