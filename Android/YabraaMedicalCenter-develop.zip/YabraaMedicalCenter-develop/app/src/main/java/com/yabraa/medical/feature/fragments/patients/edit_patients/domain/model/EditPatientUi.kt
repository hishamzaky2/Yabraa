package com.yabraa.medical.feature.fragments.patients.edit_patients.domain.model

import com.yabraa.medical.feature.fragments.patients.edit_patients.data.model.request.EditPatientRequest

data class EditPatientUi(
    val userFamilyId: Long,
    val name: String,
    val birthDate: String,
    val gender: String
) {
    fun toUpdatePatient() =
        EditPatientRequest(
            userFamilyId = userFamilyId,
            name = name,
            birthDate = birthDate,
            gender = gender
        )
}