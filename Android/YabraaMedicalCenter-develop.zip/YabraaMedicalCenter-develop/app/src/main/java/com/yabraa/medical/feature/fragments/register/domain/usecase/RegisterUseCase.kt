package com.yabraa.medical.feature.fragments.register.domain.usecase

import com.yabraa.medical.feature.fragments.register.data.request.RegisterRequestDto
import com.yabraa.medical.feature.fragments.register.domain.repository.RegisterRepository
import javax.inject.Inject

class RegisterUseCase @Inject constructor(private val registerRepository: RegisterRepository) {
    suspend operator fun invoke(registerRequestDto: RegisterRequestDto) =
        registerRepository.registerNewAccount(registerRequestDto)

}