package com.yabraa.medical.feature.fragments.allergies_and_chronic_diseases.injuries_fragment.data.model.response


import com.google.gson.annotations.SerializedName

data class InjuriesResponseDto(
    @SerializedName("data")
    val injuriesDataResponse: List<InjuriesDataResponse>,
    @SerializedName("errorMessageAr")
    val errorMessageAr: String? = null,
    @SerializedName("errorMessageEn")
    val errorMessageEn: String? = null,
    @SerializedName("statusCode")
    val statusCode: Int
)