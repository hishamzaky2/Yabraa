package com.yabraa.medical.feature.fragments.allergies_and_chronic_diseases.injuries_fragment.data.repository

import com.yabraa.medical.core.base_repository.BaseRepository
import com.yabraa.medical.core.di.network_sevices.AllergiesAndChronicDiseasesServices
import com.core.shared.state.State
import com.yabraa.medical.core.utils.getResponseMessageError
import com.yabraa.medical.feature.fragments.allergies_and_chronic_diseases.injuries_fragment.data.model.response.InjuriesResponseDto
import com.yabraa.medical.feature.fragments.allergies_and_chronic_diseases.injuries_fragment.domain.repository.InjuriesByUserFamilyIdRepository
import kotlinx.coroutines.flow.flow
import kotlinx.coroutines.flow.flowOn
import retrofit2.Response
import javax.inject.Inject

const val TAG_INJURIES_BY_USER_FAMILY_RESPONSE =
    "TAG_INJURIES_BY_USER_FAMILY_RESPONSE"

class InjuriesByUserFamilyIdRepositoryImpl @Inject constructor(private val allergiesAndChronicDiseasesServices: AllergiesAndChronicDiseasesServices) :
    BaseRepository<Long, InjuriesResponseDto>(),
    InjuriesByUserFamilyIdRepository {

    override suspend fun getInjuriesByUserFamilyId(userFamilyId: Long) = flow {
        emit(getOperationState(userFamilyId))
    }.flowOn(dispatcher)

    override suspend fun performApiCall(requestDto: Long): State<InjuriesResponseDto> {
        val response =
            allergiesAndChronicDiseasesServices.getInjuriesByUserFamilyId(requestDto)
        return handleResponse(response)
    }

    fun handleResponse(response: Response<InjuriesResponseDto>): State<InjuriesResponseDto> {
        val responseBody = response.body()
        val errorMessageEn = responseBody?.errorMessageEn ?: ""
        val errorMessageAr = responseBody?.errorMessageAr ?: ""
        return when {
            response.isSuccessful -> State.Success(response.body())

            response.isSuccessful && !responseBody?.errorMessageEn.isNullOrEmpty() -> getResponseMessageError(
                errorMessageEn = errorMessageEn,
                errorMessageAr = errorMessageAr,
                logTag = TAG_INJURIES_BY_USER_FAMILY_RESPONSE
            )

            else -> getNotSuccessfulResponseState(response)
        }
    }
}