package com.yabraa.medical.feature.fragments.home.data.model.response.service_type_response


import com.google.gson.annotations.SerializedName
import java.io.Serializable

data class ServiceTypeResponse(
    @SerializedName("description")
    val description: String,
    @SerializedName("name")
    val name: String,
    @SerializedName("serviceTypeId")
    val serviceTypeId: Long
) : Serializable