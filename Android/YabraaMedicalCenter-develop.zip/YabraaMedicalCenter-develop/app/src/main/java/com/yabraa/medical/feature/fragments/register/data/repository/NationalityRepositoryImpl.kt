package com.yabraa.medical.feature.fragments.register.data.repository

import kotlinx.coroutines.flow.flow
import kotlinx.coroutines.flow.flowOn
import com.yabraa.medical.core.base_repository.BaseRepository
import com.yabraa.medical.core.di.network_sevices.SecurityServices
import com.core.shared.state.State
import com.yabraa.medical.feature.fragments.register.data.response.nationality_response.NationalityResponseDto
import com.yabraa.medical.feature.fragments.register.domain.repository.NationalityRepository
import retrofit2.Response
import javax.inject.Inject

class NationalityRepositoryImpl @Inject constructor(private val securityServices: SecurityServices) :
    BaseRepository<Any, NationalityResponseDto>(), NationalityRepository {


    override suspend fun getNationalityList() = flow {
        emit(getOperationState(Any()))
    }.flowOn(dispatcher)


    override suspend fun performApiCall(requestDto: Any): State<NationalityResponseDto> {
        val response = securityServices.getNationalityList()
        return handleNationalityResponse(response)
    }


    private fun handleNationalityResponse(response: Response<NationalityResponseDto>): State<NationalityResponseDto> {
        return when {
            response.isSuccessful -> State.Success(response.body())
            else -> getNotSuccessfulResponseState(response)
        }
    }
}