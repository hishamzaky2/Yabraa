package com.yabraa.medical.feature.fragments.appointment.my_appointment_details.domain.repository

import com.core.shared.state.State
import com.yabraa.medical.feature.fragments.appointment.my_appointment_details.data.model.MyAppointmentDetailsResponseDto
import kotlinx.coroutines.flow.Flow

interface MyAppointmentDetailsRepository {
    suspend fun getAppointmentDetails(id: Long): Flow<State<MyAppointmentDetailsResponseDto>>
}