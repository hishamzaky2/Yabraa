package com.yabraa.medical.feature.fragments.forget_password.domain.rposetory

import kotlinx.coroutines.flow.Flow
import com.core.shared.state.State
import com.yabraa.medical.feature.fragments.forget_password.data.model.request.ResetPasswordRequestDto
import com.yabraa.medical.feature.fragments.forget_password.data.model.response.reset_password_response.ResetPasswordResponseDto

interface ResetPasswordRepository {
    suspend fun resetPassword(resetPasswordRequestDto: ResetPasswordRequestDto) : Flow<State<ResetPasswordResponseDto>>

}