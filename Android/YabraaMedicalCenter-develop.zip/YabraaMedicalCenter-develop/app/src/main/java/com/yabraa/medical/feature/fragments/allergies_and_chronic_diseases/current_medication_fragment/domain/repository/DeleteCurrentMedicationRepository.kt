package com.yabraa.medical.feature.fragments.allergies_and_chronic_diseases.current_medication_fragment.domain.repository

import com.core.shared.state.State
import com.yabraa.medical.feature.fragments.allergies_and_chronic_diseases.current_medication_fragment.data.model.request.CurrentMedicationRequestDto
import com.yabraa.medical.feature.fragments.allergies_and_chronic_diseases.current_medication_fragment.data.model.resopnse.CurrentMedicationResponseDto
import kotlinx.coroutines.flow.Flow

interface DeleteCurrentMedicationRepository {
    suspend fun deleteCurrentMedication(requestDto: CurrentMedicationRequestDto): Flow<State<CurrentMedicationResponseDto>>
}