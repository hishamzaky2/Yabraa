package com.yabraa.medical.feature.fragments.allergies_and_chronic_diseases.surgeries_fragment.di

import com.yabraa.medical.core.di.network_sevices.AllergiesAndChronicDiseasesServices
import com.yabraa.medical.feature.fragments.allergies_and_chronic_diseases.surgeries_fragment.data.repository.AddSurgeriesRepositoryImpl
import com.yabraa.medical.feature.fragments.allergies_and_chronic_diseases.surgeries_fragment.data.repository.DeleteSurgeriesRepositoryImpl
import com.yabraa.medical.feature.fragments.allergies_and_chronic_diseases.surgeries_fragment.data.repository.SurgeriesByUserFamilyIdRepositoryImpl
import com.yabraa.medical.feature.fragments.allergies_and_chronic_diseases.surgeries_fragment.data.repository.SurgeriesRepositoryImpl
import com.yabraa.medical.feature.fragments.allergies_and_chronic_diseases.surgeries_fragment.domain.repository.AddSurgeriesRepository
import com.yabraa.medical.feature.fragments.allergies_and_chronic_diseases.surgeries_fragment.domain.repository.DeleteSurgeriesRepository
import com.yabraa.medical.feature.fragments.allergies_and_chronic_diseases.surgeries_fragment.domain.repository.SurgeriesByUserFamilyIdRepository
import com.yabraa.medical.feature.fragments.allergies_and_chronic_diseases.surgeries_fragment.domain.repository.SurgeriesRepository
import dagger.Module
import dagger.Provides
import dagger.hilt.InstallIn
import dagger.hilt.android.components.ViewModelComponent

@Module
@InstallIn(ViewModelComponent::class)
object SurgeriesModule {

    @Provides
    fun provideSurgeriesRepositoryImpl(allergiesAndChronicDiseasesServices: AllergiesAndChronicDiseasesServices): SurgeriesRepository =
        SurgeriesRepositoryImpl(allergiesAndChronicDiseasesServices)

    @Provides
    fun provideSurgeriesByUserFamilyIdRepositoryImpl(allergiesAndChronicDiseasesServices: AllergiesAndChronicDiseasesServices): SurgeriesByUserFamilyIdRepository =
        SurgeriesByUserFamilyIdRepositoryImpl(allergiesAndChronicDiseasesServices)


    @Provides
    fun provideAddSurgeriesRepositoryImpl(allergiesAndChronicDiseasesServices: AllergiesAndChronicDiseasesServices): AddSurgeriesRepository =
        AddSurgeriesRepositoryImpl(allergiesAndChronicDiseasesServices)

    @Provides
    fun provideDeleteSurgeriesRepositoryImpl(allergiesAndChronicDiseasesServices: AllergiesAndChronicDiseasesServices): DeleteSurgeriesRepository =
        DeleteSurgeriesRepositoryImpl(allergiesAndChronicDiseasesServices)
}