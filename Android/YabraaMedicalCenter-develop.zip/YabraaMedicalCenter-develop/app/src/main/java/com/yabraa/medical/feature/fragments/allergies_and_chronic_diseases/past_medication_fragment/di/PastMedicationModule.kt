package com.yabraa.medical.feature.fragments.allergies_and_chronic_diseases.past_medication_fragment.di

import com.yabraa.medical.core.di.network_sevices.AllergiesAndChronicDiseasesServices
import com.yabraa.medical.feature.fragments.allergies_and_chronic_diseases.past_medication_fragment.data.repository.AddPastMedicationRepositoryImpl
import com.yabraa.medical.feature.fragments.allergies_and_chronic_diseases.past_medication_fragment.data.repository.DeletePastMedicationRepositoryImpl
import com.yabraa.medical.feature.fragments.allergies_and_chronic_diseases.past_medication_fragment.data.repository.PastMedicationByUserFamilyIdRepositoryImpl
import com.yabraa.medical.feature.fragments.allergies_and_chronic_diseases.past_medication_fragment.data.repository.PastMedicationRepositoryImpl
import com.yabraa.medical.feature.fragments.allergies_and_chronic_diseases.past_medication_fragment.domain.repository.AddPastMedicationRepository
import com.yabraa.medical.feature.fragments.allergies_and_chronic_diseases.past_medication_fragment.domain.repository.DeletePastMedicationRepository
import com.yabraa.medical.feature.fragments.allergies_and_chronic_diseases.past_medication_fragment.domain.repository.PastMedicationByUserFamilyIdRepository
import com.yabraa.medical.feature.fragments.allergies_and_chronic_diseases.past_medication_fragment.domain.repository.PastMedicationRepository
import dagger.Module
import dagger.Provides
import dagger.hilt.InstallIn
import dagger.hilt.android.components.ViewModelComponent

@Module
@InstallIn(ViewModelComponent::class)
object PastMedicationModule {

    @Provides
    fun providePastMedicationRepositoryImpl(allergiesAndChronicDiseasesServices: AllergiesAndChronicDiseasesServices): PastMedicationRepository =
        PastMedicationRepositoryImpl(allergiesAndChronicDiseasesServices)

    @Provides
    fun providePastMedicationByUserFamilyIdRepositoryImpl(allergiesAndChronicDiseasesServices: AllergiesAndChronicDiseasesServices): PastMedicationByUserFamilyIdRepository =
        PastMedicationByUserFamilyIdRepositoryImpl(allergiesAndChronicDiseasesServices)


    @Provides
    fun provideAddPastMedicationRepositoryImpl(allergiesAndChronicDiseasesServices: AllergiesAndChronicDiseasesServices): AddPastMedicationRepository =
        AddPastMedicationRepositoryImpl(allergiesAndChronicDiseasesServices)

    @Provides
    fun provideDeletePastMedicationRepositoryImpl(allergiesAndChronicDiseasesServices: AllergiesAndChronicDiseasesServices): DeletePastMedicationRepository =
        DeletePastMedicationRepositoryImpl(allergiesAndChronicDiseasesServices)
}