package com.yabraa.medical.feature.fragments.login.domain.repository

import kotlinx.coroutines.flow.Flow
import com.core.shared.state.State
import com.yabraa.medical.feature.fragments.login.data.model.request.LoginRequestDto
import com.yabraa.medical.feature.fragments.login.data.model.response.LoginResponseDto

interface LoginRepository {
    suspend fun login(loginRequestDto: LoginRequestDto): Flow<State<LoginResponseDto>>
}