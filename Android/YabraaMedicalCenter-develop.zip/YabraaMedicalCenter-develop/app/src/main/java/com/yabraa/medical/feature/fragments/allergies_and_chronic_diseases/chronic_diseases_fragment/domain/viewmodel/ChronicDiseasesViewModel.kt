package com.yabraa.medical.feature.fragments.allergies_and_chronic_diseases.chronic_diseases_fragment.domain.viewmodel

import androidx.lifecycle.ViewModel
import androidx.lifecycle.viewModelScope
import com.core.shared.state.State
import com.yabraa.medical.feature.fragments.allergies_and_chronic_diseases.chronic_diseases_fragment.data.model.request.ChronicDiseasesRequestDto
import com.yabraa.medical.feature.fragments.allergies_and_chronic_diseases.chronic_diseases_fragment.domain.repository.AddChronicDiseasesRepository
import com.yabraa.medical.feature.fragments.allergies_and_chronic_diseases.chronic_diseases_fragment.domain.repository.DeleteChronicDiseasesRepository
import com.yabraa.medical.feature.fragments.allergies_and_chronic_diseases.chronic_diseases_fragment.domain.usecase.ChronicDiseasesUseCase
import com.yabraa.medical.feature.fragments.allergies_and_chronic_diseases.chronic_diseases_fragment.data.model.response.ChronicDiseasesResponseDto
import dagger.hilt.android.lifecycle.HiltViewModel
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.launch
import javax.inject.Inject

@HiltViewModel
class ChronicDiseasesViewModel @Inject constructor(
    private val chronicDiseasesUseCase: ChronicDiseasesUseCase,
    private val addChronicDiseasesRepository: AddChronicDiseasesRepository,
    private val deleteChronicDiseasesRepository: DeleteChronicDiseasesRepository
) : ViewModel() {


    private val _chronicDiseasesResponseState =
        MutableStateFlow<State<ChronicDiseasesResponseDto>>(State.Initial())
    val chronicDiseasesResponseState: StateFlow<State<ChronicDiseasesResponseDto>> =
        _chronicDiseasesResponseState

    private val _chronicDiseasesByUserFamilyIdResponseState =
        MutableStateFlow<State<ChronicDiseasesResponseDto>>(State.Initial())
    val chronicDiseasesByUserFamilyIdResponseState: StateFlow<State<ChronicDiseasesResponseDto>> =
        _chronicDiseasesByUserFamilyIdResponseState

    private val _addChronicDiseasesResponseState =
        MutableStateFlow<State<ChronicDiseasesResponseDto>>(State.Initial())
    val addChronicDiseasesResponseState: StateFlow<State<ChronicDiseasesResponseDto>> =
        _addChronicDiseasesResponseState

    private val _deleteChronicDiseasesResponseState =
        MutableStateFlow<State<ChronicDiseasesResponseDto>>(State.Initial())
    val deleteChronicDiseasesResponseState: StateFlow<State<ChronicDiseasesResponseDto>> =
        _deleteChronicDiseasesResponseState

    fun getChronicDiseases() {
        viewModelScope.launch {
            _chronicDiseasesResponseState.emit(State.Loading())
            chronicDiseasesUseCase().collect {
                _chronicDiseasesResponseState.emit(it)
            }
        }
    }


    fun getChronicDiseasesByUserFamilyId(userFamilyId: Long) {
        viewModelScope.launch {
            _chronicDiseasesByUserFamilyIdResponseState.emit(State.Loading())
            chronicDiseasesUseCase(userFamilyId).collect {
                _chronicDiseasesByUserFamilyIdResponseState.emit(it)
            }
        }
    }

    fun addChronicDiseases(requestDto: ChronicDiseasesRequestDto) {
        viewModelScope.launch {
            _addChronicDiseasesResponseState.emit(State.Loading())
            addChronicDiseasesRepository.addChronicDiseases(requestDto).collect {
                _addChronicDiseasesResponseState.emit(it)
            }
        }
    }


    fun deleteChronicDiseases(requestDto: ChronicDiseasesRequestDto) {
        viewModelScope.launch {
            _deleteChronicDiseasesResponseState.emit(State.Loading())
            deleteChronicDiseasesRepository.deleteChronicDiseases(requestDto).collect {
                _deleteChronicDiseasesResponseState.emit(it)
            }
        }
    }

    fun getChronicDiseasesList() = chronicDiseasesUseCase.getChronicDiseasesList()

}