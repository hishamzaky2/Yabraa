package com.yabraa.medical.feature.fragments.setting.data.repository.delete_account_repository

import com.yabraa.medical.core.base_repository.BaseRepository
import com.yabraa.medical.core.di.network_sevices.YabraaServices
import com.core.shared.state.State
import com.yabraa.medical.core.utils.getResponseMessageError
import com.yabraa.medical.feature.fragments.setting.data.model.response.delete_account_response.DeleteAccountResponseDto
import com.yabraa.medical.feature.fragments.setting.domain.repository.delete_account_repository.DeleteAccountRepository
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.flow.flow
import kotlinx.coroutines.flow.flowOn
import retrofit2.Response
import javax.inject.Inject

const val DELETE_STATE = "Deleted"
const val TAG_DELETE_ACCOUNT_RESPONSE = "TAG_DELETE_ACCOUNT_RESPONSE"
class DeleteAccountRepositoryImpl  @Inject constructor(private val yabraaServices: YabraaServices) : BaseRepository<Any,DeleteAccountResponseDto>(),DeleteAccountRepository {

    override suspend fun deleteAccount() = flow {
        emit(getOperationState(Any()))
    }.flowOn(Dispatchers.IO)

    override suspend fun performApiCall(requestDto: Any): State<DeleteAccountResponseDto> {
        val response = yabraaServices.deleteAccount()
        return handDeletePatientResponse(response)
    }


    private fun handDeletePatientResponse(response: Response<DeleteAccountResponseDto>): State<DeleteAccountResponseDto> {
        val responseBody = response.body()
        val errorMessageEn = responseBody?.errorMessageEn ?: ""
        val errorMessageAr = responseBody?.errorMessageAr ?: ""
        return when {
            response.isSuccessful && responseBody?.deleteState == DELETE_STATE -> State.Success(
                response.body()
            )

            response.isSuccessful && !responseBody?.errorMessageEn.isNullOrEmpty() -> getResponseMessageError(
                errorMessageEn = errorMessageEn,
                errorMessageAr = errorMessageAr,
                logTag = TAG_DELETE_ACCOUNT_RESPONSE
            )

            else -> getNotSuccessfulResponseState(response)
        }
    }
}