package com.yabraa.medical.feature.fragments.patients.edit_patients.domain.repository.edit_patient_repository

import com.core.shared.state.State
import com.yabraa.medical.feature.fragments.patients.edit_patients.data.model.request.EditPatientRequest
import com.yabraa.medical.feature.fragments.patients.edit_patients.data.model.response.edit_patient_response.EditPatientResponseDto
import kotlinx.coroutines.flow.Flow

interface EditPatientRepository {
    suspend fun updatePatient(editPatientRequest: EditPatientRequest): Flow<State<EditPatientResponseDto>>
}