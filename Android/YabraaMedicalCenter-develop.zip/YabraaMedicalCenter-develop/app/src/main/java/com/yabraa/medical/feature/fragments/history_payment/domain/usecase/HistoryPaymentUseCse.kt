package com.yabraa.medical.feature.fragments.history_payment.domain.usecase

import com.core.shared.state.State
import com.yabraa.medical.feature.fragments.history_payment.data.model.HistoryPaymentResponse
import com.yabraa.medical.feature.fragments.history_payment.data.model.HistoryPaymentResponseDto
import com.yabraa.medical.feature.fragments.history_payment.domain.repository.HistoryPaymentRepository
import kotlinx.coroutines.async
import kotlinx.coroutines.flow.Flow
import kotlinx.coroutines.flow.channelFlow
import javax.inject.Inject

class HistoryPaymentUseCse @Inject constructor(private val historyPaymentRepository: HistoryPaymentRepository) {

    private var historyPayment : HistoryPaymentResponse? = null

    operator fun invoke() : Flow<State<HistoryPaymentResponseDto>>{
        return channelFlow {
            val response = async { historyPaymentRepository.getHistoryPayment() }
            response.await().collect{
                if(it is State.Success){
                    historyPayment = it.data?.historyPaymentResponse
                }
                send(it)
            }
        }
    }


    fun getHistoryPaymentList() = historyPayment?.packagesDate ?: emptyList()
}