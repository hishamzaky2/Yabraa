package com.yabraa.medical.feature.fragments.home.data.repository.services_details_repository

import com.yabraa.medical.core.base_repository.BaseRepository
import com.yabraa.medical.core.di.network_sevices.YabraaServices
import com.core.shared.state.State
import com.yabraa.medical.core.utils.getResponseMessageError
import com.yabraa.medical.feature.fragments.home.data.model.response.services_details_response.ServicesDetailsResponseDto
import com.yabraa.medical.feature.fragments.home.domain.repository.services_details_repository.ServicesDetailsRepository
import kotlinx.coroutines.flow.flow
import kotlinx.coroutines.flow.flowOn
import retrofit2.Response
import javax.inject.Inject

const val TAG_SERVICES_DETAILS_RESPONSE = "TAG_SERVICES_DETAILS_RESPONSE"

class ServicesDetailsRepositoryImpl @Inject constructor(private val yabraaServices: YabraaServices) :
    BaseRepository<Long, ServicesDetailsResponseDto>(), ServicesDetailsRepository {


    override suspend fun getServicesDetails(serviceTypeId: Long) = flow {
        emit(getOperationState(serviceTypeId))
    }.flowOn(dispatcher)

    override suspend fun performApiCall(requestDto: Long): State<ServicesDetailsResponseDto> {
        val response = yabraaServices.getServicesDetails(requestDto)
        return handleServicesDetailsResponse(response)
    }


    private fun handleServicesDetailsResponse(response: Response<ServicesDetailsResponseDto>): State<ServicesDetailsResponseDto> {
        val responseBody = response.body()
        val errorMessageEn = responseBody?.errorMessageEn ?: ""
        val errorMessageAr = responseBody?.errorMessageAr ?: ""
        return when {
            response.isSuccessful && responseBody?.servicesDataResponse != null ->
                State.Success(response.body())

            response.isSuccessful && !responseBody?.errorMessageEn.isNullOrEmpty() -> getResponseMessageError(
                errorMessageEn = errorMessageEn,
                errorMessageAr = errorMessageAr,
                logTag = TAG_SERVICES_DETAILS_RESPONSE
            )

            else -> getNotSuccessfulResponseState(response)
        }
    }

}