package com.yabraa.medical.feature.fragments.appointment.edit_appointment.data.model.request

data class EditAppointmentRequestDto(
    val appointmentId: Long,
    val notes: String? = null,
    val locationLongitude: Double,
    val locationLatitude: Double,
    val serviceTypeId : Long
)