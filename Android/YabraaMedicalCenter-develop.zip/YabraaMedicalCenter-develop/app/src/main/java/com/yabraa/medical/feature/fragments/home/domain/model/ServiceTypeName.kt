package com.yabraa.medical.feature.fragments.home.domain.model

enum class ServiceTypeName(val typeValue: String) {
    NORMAL("Normal"),VIRTUAL("Virtual")
}