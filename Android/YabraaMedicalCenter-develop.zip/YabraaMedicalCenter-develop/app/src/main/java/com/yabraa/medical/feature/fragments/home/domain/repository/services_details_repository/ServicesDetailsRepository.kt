package com.yabraa.medical.feature.fragments.home.domain.repository.services_details_repository

import com.core.shared.state.State
import com.yabraa.medical.feature.fragments.home.data.model.response.services_details_response.ServicesDetailsResponseDto
import kotlinx.coroutines.flow.Flow

interface ServicesDetailsRepository {

    suspend fun getServicesDetails(serviceTypeId: Long): Flow<State<ServicesDetailsResponseDto>>
}