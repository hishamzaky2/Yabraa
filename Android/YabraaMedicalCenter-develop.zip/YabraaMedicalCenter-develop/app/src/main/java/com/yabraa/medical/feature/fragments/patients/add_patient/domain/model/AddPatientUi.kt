package com.yabraa.medical.feature.fragments.patients.add_patient.domain.model

import com.yabraa.medical.feature.fragments.patients.add_patient.data.model.request.AddPatientRequest

data class AddPatientUi(val name: String, val birthDate: String, val gender: String) {
    fun toAddNewPatient() =
        AddPatientRequest(name = name, birthDate = birthDate, gender = gender)

}