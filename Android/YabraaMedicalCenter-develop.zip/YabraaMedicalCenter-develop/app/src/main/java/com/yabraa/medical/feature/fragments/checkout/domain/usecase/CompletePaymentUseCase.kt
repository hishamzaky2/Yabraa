package com.yabraa.medical.feature.fragments.checkout.domain.usecase

import com.yabraa.medical.feature.fragments.checkout.data.model.request.PaymentRequestDto
import com.yabraa.medical.feature.fragments.checkout.domain.repository.complete_payment_repository.CompletePaymentRepository
import javax.inject.Inject

class CompletePaymentUseCase @Inject constructor(private val completePaymentRepository: CompletePaymentRepository) {

    suspend operator fun invoke(paymentRequestDto: PaymentRequestDto) =
        completePaymentRepository.completePayment(paymentRequestDto)
}