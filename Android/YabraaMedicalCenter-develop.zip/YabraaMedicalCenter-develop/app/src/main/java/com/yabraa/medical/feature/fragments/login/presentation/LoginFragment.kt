package com.yabraa.medical.feature.fragments.login.presentation

import android.annotation.SuppressLint
import android.os.Bundle
import android.view.View
import androidx.annotation.StringRes
import androidx.fragment.app.viewModels
import androidx.lifecycle.lifecycleScope
import androidx.navigation.fragment.findNavController
import dagger.hilt.android.AndroidEntryPoint
import kotlinx.coroutines.launch
import com.yabraa.medical.R
import com.yabraa.medical.core.base_fragment.BaseFragment
import com.yabraa.medical.core.base_fragment.navigate
import com.core.shared.error.EmptyPassword
import com.core.shared.error.EmptyPhoneNumber
import com.core.shared.error.OperationMessage
import com.core.shared.error.YabraaError
import com.core.shared.state.State
import com.yabraa.medical.core.utils.dialog.yabraa_dialog.YabraaDialogBuilder
import com.yabraa.medical.core.utils.getErrorMessage
import com.yabraa.medical.core.utils.removeFirstZeroFromPhoneNumber
import com.yabraa.medical.databinding.FragmentLoginBinding
import com.yabraa.medical.feature.fragments.common.domain.model.ErrorMessageUi
import com.yabraa.medical.feature.fragments.login.data.model.response.LoginDataResponse
import com.yabraa.medical.feature.fragments.login.domain.model.LoginUiModel
import com.yabraa.medical.feature.fragments.login.domain.viewmodel.LoginViewModel

@AndroidEntryPoint
class LoginFragment : BaseFragment<FragmentLoginBinding>() {

    override val binding by lazy { FragmentLoginBinding.inflate(layoutInflater) }
    private val viewModel: LoginViewModel by viewModels()


    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        lifecycleScope.launch { collectOnValidationState() }
        lifecycleScope.launch { collectOnLoginResponse() }
    }


    override fun onViewCreated(view: View, savedInstanceState: Bundle?) {
        super.onViewCreated(view, savedInstanceState)
        binding.setUpViews()
        navigateToHomeFragment()
    }


    override fun onResume() {
        super.onResume()
        showYabraaBar(false)
    }

    private fun FragmentLoginBinding.setUpViews() {
        setOnForgetPasswordClicked()
        setOnRegisterClicked()
        phoneNumberEt.removeFirstZeroFromPhoneNumber()
        setOnLoginClicked()
    }

    private fun FragmentLoginBinding.setOnForgetPasswordClicked() {
        forgetPasswordTv.setOnClickListener {
            navigateToForgetPasswordFragment()
        }
    }

    private fun navigateToForgetPasswordFragment() {
        showDelayProgressDialog {
            navigate(R.id.actionLoginFragmentToForgetPasswordFragment)
        }
    }


    private fun FragmentLoginBinding.setOnRegisterClicked() {
        registerTv.setOnClickListener {
            navigateToRegisterFragment()
        }
    }

    private fun navigateToRegisterFragment() = navigate(R.id.actionLoginFragmentToRegisterFragment)

    @SuppressLint("FragmentLiveDataObserve")
    private fun FragmentLoginBinding.setOnLoginClicked() {
        connectivityManager?.isNetworkConnected?.observe(this@LoginFragment) { isConnected ->
            loginBtn.setOnClickListener {
                if (!isConnected) {
                    showNetworkConnectionErrorPopup()
                    return@setOnClickListener
                }
                viewModel.validateInput(setLoginUiModel())
            }
        }
    }


    private fun FragmentLoginBinding.setLoginUiModel(): LoginUiModel {
        return LoginUiModel(
            phoneNumber = phoneNumberEt.text.toString(),
            password = passwordEt.text.toString()
        )
    }

    private suspend fun collectOnValidationState() {
        viewModel.validationState.collect {
            when (it) {
                is State.Initial -> {}
                is State.Error -> handleError(it)
                is State.Loading -> {}
                is State.Success -> {}
            }
        }
    }

    private fun handleError(errorState: State.Error<*>) {
        errorState.error.handleError {
            when (exception) {
                is EmptyPhoneNumber -> showInputErrorSnackBar(R.string.pleaseEnterYourMobileNumber)
                is EmptyPassword -> showInputErrorSnackBar(R.string.pleaseEnterYourPassword)
            }
        }
    }

    private fun showInputErrorSnackBar(@StringRes message: Int) =
        yabraaSnackBarBuilder.setEndIcon(R.drawable.ic_vector_close).setMessage(message)
            .build(requireView()).show()


    private suspend fun collectOnLoginResponse() {
        viewModel.loginResponse.collect {
            hideProgressDialog()
            when (it) {
                is State.Initial -> {}
                is State.Error -> it.error.handleLoginResponseError()
                is State.Loading -> showProgressDialog()
                is State.Success -> navigateToNextScreen(it.data?.loginData)
            }
        }
    }

    private fun YabraaError.handleLoginResponseError() {
        val errorMessageUi = ErrorMessageUi(logMessageEn, logMessageAr)
        handleError {
            when (exception) {
                is OperationMessage -> showLoginResponseErrorPopup(errorMessageUi)
            }
        }
    }


    private fun showLoginResponseErrorPopup(errorMessageUi: ErrorMessageUi) {
        val errorMessage = getErrorMessage(errorMessageUi)
        YabraaDialogBuilder(requireActivity()).setIcon(R.drawable.ic_vector_error)
            .setTitle(R.string.warning)
            .setMessage(errorMessage)
            .setTopButton(R.string.ok) {
                //TODO LOG MESSAGE HERE
            }.setCancelable(false)
            .show()
    }

    private fun navigateToNextScreen(data: LoginDataResponse?) {
        if (data == null) return
        if (findNavController().currentDestination?.id == R.id.loginFragment) {
            navigate(R.id.actionLoginFragmentToMainNavGraph)
        }
    }

    private fun navigateToHomeFragment() {
        if (tokenHandler.getToken().isNullOrEmpty()) return
        navigate(R.id.actionLoginFragmentToMainNavGraph)
    }
}