package com.yabraa.medical.feature.fragments.forget_password.domain.usecase

import com.yabraa.medical.feature.fragments.forget_password.data.model.request.ResetPasswordRequestDto
import com.yabraa.medical.feature.fragments.forget_password.domain.rposetory.ResetPasswordRepository
import javax.inject.Inject

class ResetPasswordUseCase @Inject constructor(private val resetPasswordRepository: ResetPasswordRepository) {

    suspend operator fun invoke(resetPasswordRequestDto: ResetPasswordRequestDto) =
        resetPasswordRepository.resetPassword(resetPasswordRequestDto)
}