package com.yabraa.medical.feature.fragments.onboard.presentation

import android.annotation.SuppressLint
import android.os.Build
import android.os.Bundle
import android.view.View
import androidx.activity.result.contract.ActivityResultContracts
import androidx.hilt.navigation.fragment.hiltNavGraphViewModels
import androidx.lifecycle.Lifecycle
import androidx.lifecycle.flowWithLifecycle
import androidx.lifecycle.lifecycleScope
import androidx.viewpager2.widget.ViewPager2
import com.yabraa.medical.R
import com.yabraa.medical.core.base_fragment.BaseFragment
import com.core.shared.error.OperationMessage
import com.core.shared.error.YabraaError
import com.core.shared.state.State
import com.core.shared.utils.CommonUtils.getLocalizedValue
import com.core.shared.utils.CommonUtils.load
import com.yabraa.medical.core.utils.dialog.yabraa_dialog.YabraaDialogBuilder
import com.yabraa.medical.core.utils.getErrorMessage
import com.yabraa.medical.databinding.FragmentFirstOnboardBinding
import com.yabraa.medical.feature.fragments.common.domain.model.ErrorMessageUi
import com.yabraa.medical.feature.fragments.common.domain.viewmodel.OnboardViewModel
import dagger.hilt.android.AndroidEntryPoint
import kotlinx.coroutines.launch

@AndroidEntryPoint
class FirstOnboardFragment : BaseFragment<FragmentFirstOnboardBinding>() {

    override val binding by lazy { FragmentFirstOnboardBinding.inflate(layoutInflater) }
    private val viewPager by lazy { activity?.findViewById<ViewPager2>(R.id.viewPager) }

    private val viewModel: OnboardViewModel by hiltNavGraphViewModels(R.id.nav_graph)

    override fun onViewCreated(view: View, savedInstanceState: Bundle?) {
        super.onViewCreated(view, savedInstanceState)
        binding.setUpViews()
    }

    override fun onResume() {
        super.onResume()
        showYabraaBar(false)
    }

    private fun FragmentFirstOnboardBinding.setUpViews() {
        handleFirstSliderBar()
        setOnSkipOnboardScreenClicked()
        handleNetworkConnection()
        lifecycleScope.launch { collectOnOnboardPagesState() }
        handleNotificationPermission()
    }

    private fun FragmentFirstOnboardBinding.handleFirstSliderBar() {
        if (viewPager?.currentItem != 0) return
        sliderBar.firstProgressBar.progress = 25
    }

    private fun FragmentFirstOnboardBinding.setOnSkipOnboardScreenClicked() {
        skipTv.setOnClickListener {
            handleSkipOnboardScreen()
        }
    }

    @SuppressLint("FragmentLiveDataObserve")
    private fun handleNetworkConnection() {
        connectivityManager?.isNetworkConnected?.observe(this@FirstOnboardFragment) {
            if (!it && viewModel.getSuccessState()) showIntentConnectionErrorPopup()
        }
    }

    private suspend fun collectOnOnboardPagesState() {
        viewModel.onboardPagesState.flowWithLifecycle(lifecycle, Lifecycle.State.STARTED).collect {
            hideProgressDialog()
            when (it) {
                is State.Initial -> {}
                is State.Error -> it.error.handleLoginResponseError()
                is State.Loading -> showProgressDialog()
                is State.Success -> setFirstOnboardScreenInfo()
            }
        }
    }

    private fun YabraaError.handleLoginResponseError() {
        val errorMessageUi = ErrorMessageUi(logMessageEn, logMessageAr)
        handleError {
            when (exception) {
                is OperationMessage -> showLoginResponseErrorPopup(errorMessageUi)
            }
        }
    }


    private fun showLoginResponseErrorPopup(errorMessageUi: ErrorMessageUi) {
        val errorMessage = getErrorMessage(errorMessageUi)
        YabraaDialogBuilder(requireActivity()).setIcon(R.drawable.ic_vector_error)
            .setTitle(R.string.warning)
            .setMessage(errorMessage)
            .setTopButton(R.string.ok) {
                //TODO LOG MESSAGE HERE
            }.setCancelable(false)
            .show()
    }

    private fun setFirstOnboardScreenInfo() {
        viewModel.getPagesDetails()?.forEachIndexed { index, it ->
            if (index == 0) {
                binding.titleTv.text = getLocalizedValue(it.titleEn, it.titleAr)
                binding.subTitleTv.text = getLocalizedValue(it.subTitleEn, it.subTitleAr)
                binding.firstOnboardIv.load(requireActivity(), it.path)
            }
        }
    }

    private fun showIntentConnectionErrorPopup() {
        YabraaDialogBuilder(requireActivity()).setIcon(R.drawable.ic_vector_no_internet_connection)
            .setTitle(R.string.noInternetConnection)
            .setMessage(R.string.doNotHaveConnectionWithInternet)
            .setTopButton(R.string.ok) { handleApplicationRestart() }
            .setCancelable(false).show()
    }


    private fun handleNotificationPermission() {
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.TIRAMISU) {
            permissionRequest.launch(android.Manifest.permission.POST_NOTIFICATIONS)
        }
    }

    private val permissionRequest =
        registerForActivityResult(ActivityResultContracts.RequestPermission()) {
            /* no need handle action here */
        }

    override fun handleIoExceptionError() {}
}