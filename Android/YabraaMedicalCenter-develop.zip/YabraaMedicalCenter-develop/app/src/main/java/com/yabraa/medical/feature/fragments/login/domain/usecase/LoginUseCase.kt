package com.yabraa.medical.feature.fragments.login.domain.usecase

import kotlinx.coroutines.async
import kotlinx.coroutines.flow.Flow
import kotlinx.coroutines.flow.channelFlow
import com.core.shared.state.State
import com.core.shared.token_utils.TokenHandler
import com.yabraa.medical.feature.fragments.login.data.model.request.LoginRequestDto
import com.yabraa.medical.feature.fragments.login.data.model.response.LoginResponseDto
import com.yabraa.medical.feature.fragments.login.domain.repository.LoginRepository
import javax.inject.Inject


class LoginUseCase @Inject constructor(
    private val loginRepository: LoginRepository,
    private val tokenHandler: TokenHandler,
) {

    suspend operator fun invoke(loginRequestDto: LoginRequestDto): Flow<State<LoginResponseDto>> {
        return channelFlow {
            val loginResponseDto = async { loginRepository.login(loginRequestDto) }
            loginResponseDto.await().collect {
                if (it is State.Success) {
                    val token = it.data?.loginData?.token ?: ""
                    tokenHandler.handleSaveToken(token)
                }
                send(it)
            }
        }
    }
}