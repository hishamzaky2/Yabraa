package com.yabraa.medical.feature.fragments.home.domain.repository.service_type_repository

import com.core.shared.state.State
import com.yabraa.medical.feature.fragments.home.data.model.response.service_type_response.ServiceTypeResponseDto
import kotlinx.coroutines.flow.Flow

interface ServiceTypeRepository {
    suspend fun getServiceType(): Flow<State<ServiceTypeResponseDto>>
}