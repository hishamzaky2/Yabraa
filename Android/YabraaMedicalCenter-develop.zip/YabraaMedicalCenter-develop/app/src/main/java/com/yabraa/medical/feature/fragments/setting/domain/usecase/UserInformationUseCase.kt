package com.yabraa.medical.feature.fragments.setting.domain.usecase

import com.core.shared.state.State
import com.yabraa.medical.feature.fragments.setting.data.model.response.user_information_response.UserInformationResponseDto
import com.yabraa.medical.feature.fragments.setting.domain.repository.get_user_information_repository.GetUserInformationRepository
import kotlinx.coroutines.async
import kotlinx.coroutines.flow.Flow
import kotlinx.coroutines.flow.channelFlow
import javax.inject.Inject

class UserInformationUseCase @Inject constructor(private val userInformationRepository: GetUserInformationRepository) {

    private var responseDto: UserInformationResponseDto? = null

    suspend operator fun invoke(): Flow<State<UserInformationResponseDto>> {
        return channelFlow {
            val userInformationResponse = async { userInformationRepository.getUserInformation() }
            userInformationResponse.await().collect {
                if (it is State.Success) {
                    responseDto = it.data
                }
                send(it)
            }
        }
    }

    fun getUserInformation() = responseDto?.userInformationResponse
}