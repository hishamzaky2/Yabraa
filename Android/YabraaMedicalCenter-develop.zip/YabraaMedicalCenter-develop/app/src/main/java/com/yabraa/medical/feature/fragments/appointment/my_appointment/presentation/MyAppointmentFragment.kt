package com.yabraa.medical.feature.fragments.appointment.my_appointment.presentation

import android.os.Bundle
import android.view.View
import androidx.core.content.res.ResourcesCompat
import androidx.core.view.isVisible
import androidx.fragment.app.viewModels
import androidx.hilt.navigation.fragment.hiltNavGraphViewModels
import androidx.lifecycle.MutableLiveData
import androidx.lifecycle.lifecycleScope
import androidx.navigation.fragment.findNavController
import com.yabraa.medical.R
import com.yabraa.medical.core.base_fragment.BaseFragment
import com.yabraa.medical.core.base_fragment.navigate
import com.yabraa.medical.core.base_fragment.setOnGoToConnectionSettingClicked
import com.core.shared.error.OperationMessage
import com.core.shared.error.YabraaError
import com.core.shared.state.State
import com.core.shared.utils.CommonUtils.getLocalizedValue
import com.core.shared.utils.CommonUtils.handleExpirationDate
import com.yabraa.medical.core.utils.custom_views.yabraa_bar.YabraaBarHandler
import com.yabraa.medical.core.utils.dialog.yabraa_dialog.YabraaButtonStyle
import com.yabraa.medical.core.utils.dialog.yabraa_dialog.YabraaDialogBuilder
import com.yabraa.medical.core.utils.getErrorMessage
import com.yabraa.medical.databinding.FragmentMyAppointmentBinding
import com.yabraa.medical.feature.fragments.appointment.my_appointment.data.model.request.CancelAppointmentRequestDto
import com.yabraa.medical.feature.fragments.appointment.my_appointment.data.model.response.MyAppointmentResponse
import com.yabraa.medical.feature.fragments.appointment.my_appointment.domain.model.MyAppointmentStatus
import com.yabraa.medical.feature.fragments.appointment.my_appointment.domain.viewmodel.MyAppointmentViewModel
import com.yabraa.medical.feature.fragments.appointment.my_appointment.presentation.adapter.MyAppointmentAdapter
import com.yabraa.medical.feature.fragments.appointment.my_appointment.presentation.adapter.MyAppointmentAdapter.MyAppointmentListener
import com.yabraa.medical.feature.fragments.common.domain.model.ErrorMessageUi
import com.yabraa.medical.feature.fragments.setting.domain.viewmodel.SettingViewModel
import com.yabraa.medical.feature.fragments.splash_screen.presentation.FIREBASE_CLOUD_MESSAGING_TOKEN
import dagger.hilt.android.AndroidEntryPoint
import kotlinx.coroutines.launch

const val MY_APPOINTMENT = "MY_APPOINTMENT"

@AndroidEntryPoint
class MyAppointmentFragment : BaseFragment<FragmentMyAppointmentBinding>(), MyAppointmentListener {

    override val binding by lazy { FragmentMyAppointmentBinding.inflate(layoutInflater) }
    private val settingViewModel: SettingViewModel by hiltNavGraphViewModels(R.id.setting_graph)
    private val viewModel: MyAppointmentViewModel by viewModels()

    private lateinit var myAppointmentAdapter: MyAppointmentAdapter
    private var myAppointmentResponse = MutableLiveData<MutableList<MyAppointmentResponse>>()

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        showExpirationDateError()
        binding.handleNetworkConnection()
    }

    override fun onViewCreated(view: View, savedInstanceState: Bundle?) {
        super.onViewCreated(view, savedInstanceState)
        lifecycleScope.apply {
            launch { collectOnMyAppointmentResponseState() }
            launch { collectOnCancelAppointmentResponseState() }
        }
        binding.setUpViews()
    }

    override fun onResume() {
        super.onResume()
        yabraaBarView?.setUpYabraaBarView()
        confirmationView?.setConfirmationAppointmentVisibility(false)
        showBottomNavigation(false)
    }

    private fun YabraaBarHandler.setUpYabraaBarView() {
        val barTitle = settingViewModel.yabraaBarTitle ?: ""
        setYabraaBarVisibility(true)
        setClearAllVisibility(false)
        setBarTitle(barTitle)
        setOnBackArrowClicked { findNavController().popBackStack() }
    }

    private fun FragmentMyAppointmentBinding.setUpViews() {
        internetConnection.goToSettingBtn.setOnGoToConnectionSettingClicked(requireActivity())
    }

    private fun FragmentMyAppointmentBinding.handleNetworkConnection() {
        connectivityManager?.isNetworkConnected?.observe(this@MyAppointmentFragment) {
            handleConnectionViewVisibility(it)
            handleNoAppointmentGroupVisibility(it)
            if (!it) return@observe
            viewModel.getMyAppointment()
        }
    }

    private fun FragmentMyAppointmentBinding.handleConnectionViewVisibility(isVisible: Boolean) {
        myAppointmentRV.isVisible = isVisible
        internetConnection.root.isVisible = !isVisible
    }

    private suspend fun collectOnMyAppointmentResponseState() {
        viewModel.myAppointmentResponseState.collect {
            hideProgressDialog()
            when (it) {
                is State.Error -> it.error.handleError { }
                is State.Initial -> {}
                is State.Loading -> showProgressDialog()
                is State.Success -> {
                    myAppointmentResponse.postValue(it.data?.myAppointmentResponse?.toMutableList())
                    setMyAppointmentAdapter(it.data?.myAppointmentResponse?.toMutableList())
                }
            }
        }
    }

    private fun setMyAppointmentAdapter(response: MutableList<MyAppointmentResponse>?) {
        val myAppointmentResponse = response ?: return
        myAppointmentAdapter = MyAppointmentAdapter(myAppointmentResponse) {
            showDelayProgressDialog { navigateToEditAppointment(it) }
        }
        myAppointmentAdapter.initializeSetOnAppointmentDetailsCallback(this)
        binding.myAppointmentRV.adapter = myAppointmentAdapter
    }

    private fun navigateToEditAppointment(myAppointmentResponse: MyAppointmentResponse) {
        val bundle = Bundle()
        bundle.putSerializable(MY_APPOINTMENT, myAppointmentResponse)
        navigate(R.id.actionMyAppointmentFragmentToEditAppointmentFragment, bundle)
    }

    private fun FragmentMyAppointmentBinding.handleNoAppointmentGroupVisibility(isVisible: Boolean) {
        myAppointmentResponse.observe(this@MyAppointmentFragment) { response ->
            if (response.isNullOrEmpty()) {
                myAppointmentRV.isVisible = !isVisible
                noAppointmentGroup.isVisible = isVisible
            }
        }
    }

    private fun showExpirationDateError() =
        tokenHandler.handleExpirationDate { showExpirationDatePopupError() }

    override fun setOnAppointmentClicked(item: MyAppointmentResponse) {
        if (item.status == MyAppointmentStatus.DONE.value) {
            navigateToAppointmentDetailsFragment(item)
        } else if (item.status == MyAppointmentStatus.PENDING.value) {
            showCancelAppointmentPopup(item)
        }
    }

    private fun navigateToAppointmentDetailsFragment(item: MyAppointmentResponse) {
        val bundle = Bundle()
        bundle.putSerializable(MY_APPOINTMENT, item)
        navigate(R.id.actionMyAppointmentFragmentToMyAppointmentDetailsFragment, bundle)
    }

    private fun showCancelAppointmentPopup(item: MyAppointmentResponse) {
        val topBtnStyle = YabraaButtonStyle(
            backGround = R.color.primaryLight100,
            textColor = ResourcesCompat.getColor(resources, R.color.primaryDark900, null)
        )
        YabraaDialogBuilder(requireActivity()).setIcon(R.drawable.ic_vector_error)
            .setTitle(R.string.warning)
            .setMessage(R.string.doYouWantCancelThisAppointment)
            .setTopButton(R.string.yes, topBtnStyle) {
                handleCancelAppointment(item)
            }.setBottomButton(R.string.no) {}
            .setCancelable(false)
            .show()
    }

    private fun handleCancelAppointment(item: MyAppointmentResponse) {
        val firebaseToken = sharedPreference.getString(FIREBASE_CLOUD_MESSAGING_TOKEN) ?: ""
        if (connectivityManager?.isNetworkConnected?.value == false) {
            showShortToast(R.string.checkInternetConnection.localize())
            return
        }
        val requestDto = CancelAppointmentRequestDto(item.appointmentId, firebaseToken)
        viewModel.cancelAppointment(requestDto)
    }


    private suspend fun collectOnCancelAppointmentResponseState() {
        viewModel.cancelAppointmentResponseState.collect {
            hideProgressDialog()
            when (it) {
                is State.Error -> it.error.handleLoginResponseError()
                is State.Initial -> {}
                is State.Loading -> showProgressDialog()
                is State.Success -> {
                    val data = it.data?.cancelAppointmentResponse
                    val message = getLocalizedValue(data?.messageEn, data?.messageAr)
                    showCancelAppointmentStatusPopup(message)
                }
            }
        }
    }

    private fun showCancelAppointmentStatusPopup(message: String?) {
        YabraaDialogBuilder(requireActivity())
            .setIcon(R.drawable.ic_vector_check_circle)
            .setMessage(message)
            .setTopButton(R.string.ok) { findNavController().popBackStack() }
            .setCancelable(false)
            .show()
    }

    private fun YabraaError.handleLoginResponseError() {
        val errorMessageUi = ErrorMessageUi(logMessageEn, logMessageAr)
        handleError {
            when (exception) {
                is OperationMessage -> showLoginResponseErrorPopup(errorMessageUi)
            }
        }
    }


    private fun showLoginResponseErrorPopup(errorMessageUi: ErrorMessageUi) {
        val errorMessage = getErrorMessage(errorMessageUi)
        YabraaDialogBuilder(requireActivity()).setIcon(R.drawable.ic_vector_error)
            .setTitle(R.string.warning)
            .setMessage(errorMessage)
            .setTopButton(R.string.ok) {}
            .setCancelable(false)
            .show()
    }
}