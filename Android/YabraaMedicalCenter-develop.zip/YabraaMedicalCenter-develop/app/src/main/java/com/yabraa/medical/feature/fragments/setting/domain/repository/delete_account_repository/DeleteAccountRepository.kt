package com.yabraa.medical.feature.fragments.setting.domain.repository.delete_account_repository

import com.core.shared.state.State
import com.yabraa.medical.feature.fragments.setting.data.model.response.delete_account_response.DeleteAccountResponseDto
import kotlinx.coroutines.flow.Flow

interface DeleteAccountRepository {
    suspend fun deleteAccount() : Flow<State<DeleteAccountResponseDto>>
}