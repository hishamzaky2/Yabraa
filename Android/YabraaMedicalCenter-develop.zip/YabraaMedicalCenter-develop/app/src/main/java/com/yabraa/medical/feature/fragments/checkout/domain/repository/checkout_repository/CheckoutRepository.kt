package com.yabraa.medical.feature.fragments.checkout.domain.repository.checkout_repository

import kotlinx.coroutines.flow.Flow
import com.core.shared.state.State
import com.yabraa.medical.feature.fragments.checkout.data.model.request.CheckoutRequestDto
import com.yabraa.medical.feature.fragments.checkout.data.model.response.checkout_response.CheckoutResponseDto

interface CheckoutRepository {
    suspend fun checkout(checkoutRequestDto: CheckoutRequestDto): Flow<State<CheckoutResponseDto>>
}