package com.yabraa.medical.feature.fragments.allergies_and_chronic_diseases.surgeries_fragment.domain.repository

import com.core.shared.state.State
import com.yabraa.medical.feature.fragments.allergies_and_chronic_diseases.surgeries_fragment.data.model.request.SurgeriesRequestDto
import com.yabraa.medical.feature.fragments.allergies_and_chronic_diseases.surgeries_fragment.data.model.response.SurgeriesResponseDto
import kotlinx.coroutines.flow.Flow

interface AddSurgeriesRepository {
    suspend fun addSurgeries(requestDto: SurgeriesRequestDto): Flow<State<SurgeriesResponseDto>>
}