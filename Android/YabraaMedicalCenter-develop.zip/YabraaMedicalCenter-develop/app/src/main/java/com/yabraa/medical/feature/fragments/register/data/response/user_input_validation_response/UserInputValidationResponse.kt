package com.yabraa.medical.feature.fragments.register.data.response.user_input_validation_response


import com.google.gson.annotations.SerializedName

data class UserInputValidationResponse(
    @SerializedName("birthDate")
    val birthDate: String,
    @SerializedName("countryCode")
    val countryCode: String,
    @SerializedName("email")
    val email: String? = null,
    @SerializedName("firstName")
    val firstName: String,
    @SerializedName("gender")
    val gender: String,
    @SerializedName("idOrIqamaOrPassport")
    val idOrIqamaOrPassport: String,
    @SerializedName("lastName")
    val lastName: String? = null,
    @SerializedName("password")
    val password: String,
    @SerializedName("phoneNumber")
    val phoneNumber: String,
    @SerializedName("verificationCode")
    val verificationCode: String
)