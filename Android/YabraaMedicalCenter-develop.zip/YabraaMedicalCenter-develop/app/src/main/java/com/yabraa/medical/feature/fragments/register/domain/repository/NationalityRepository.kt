package com.yabraa.medical.feature.fragments.register.domain.repository

import kotlinx.coroutines.flow.Flow
import com.core.shared.state.State
import com.yabraa.medical.feature.fragments.register.data.response.nationality_response.NationalityResponseDto

interface NationalityRepository {
    suspend fun getNationalityList(): Flow<State<NationalityResponseDto>>
}