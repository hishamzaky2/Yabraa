package com.yabraa.medical.feature.fragments.select_date_and_time.presentation.adapter

import android.view.LayoutInflater
import android.view.ViewGroup
import androidx.recyclerview.widget.RecyclerView
import com.yabraa.medical.databinding.ItemSelectPatientBinding
import com.yabraa.medical.feature.fragments.patients.patients.data.model.response.PatientResponse

class SelectPatientAdapter(private val patientItems: MutableList<PatientResponse>) :
    RecyclerView.Adapter<SelectPatientAdapter.ViewHolder>() {

    lateinit var setOnPatientCallback: PatientListener

    override fun onCreateViewHolder(parent: ViewGroup, viewType: Int): SelectPatientAdapter.ViewHolder {
        val binding = ItemSelectPatientBinding.inflate(LayoutInflater.from(parent.context), parent, false)
        return ViewHolder(binding)
    }

    override fun onBindViewHolder(viewHolder: SelectPatientAdapter.ViewHolder, position: Int) {
        val item = patientItems[position]
        viewHolder.bind(item)
    }

    override fun getItemCount() = patientItems.size

    override fun getItemViewType(position: Int) = position


    inner class ViewHolder(private val binding: ItemSelectPatientBinding) :
        RecyclerView.ViewHolder(binding.root) {
        fun bind(item: PatientResponse) {
            binding.root.setOnClickListener { setOnPatientCallback.setOnSelectPatientClicked(item) }
            binding.patientNameTv.text = item.name
        }
    }


    fun initializeSetOnPatientCallback(callback: PatientListener) {
        setOnPatientCallback = callback
    }

    interface PatientListener {
        fun setOnSelectPatientClicked(patientResponse: PatientResponse)
    }
}