package com.yabraa.medical.feature.fragments.register.domain.repository

import kotlinx.coroutines.flow.Flow
import com.core.shared.state.State
import com.yabraa.medical.feature.fragments.register.data.request.RegisterRequestDto
import com.yabraa.medical.feature.fragments.register.data.response.register_response.RegisterResponseDto

interface RegisterRepository {
    suspend fun registerNewAccount(request: RegisterRequestDto): Flow<State<RegisterResponseDto>>
}