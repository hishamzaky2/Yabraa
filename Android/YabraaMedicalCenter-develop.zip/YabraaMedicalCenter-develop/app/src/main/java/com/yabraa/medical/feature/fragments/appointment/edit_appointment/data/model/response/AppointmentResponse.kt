package com.yabraa.medical.feature.fragments.appointment.edit_appointment.data.model.response


import com.google.gson.annotations.SerializedName

data class AppointmentResponse(
    @SerializedName("appointmentId")
    val appointmentId: Long,
    @SerializedName("locationAltitude")
    val locationAltitude: Double,
    @SerializedName("locationLongitude")
    val locationLongitude: Double,
    @SerializedName("locationLatitude")
    val locationLatitude: Double,
    @SerializedName("notes")
    val notes: String,
    @SerializedName("packageNameAR")
    val packageNameAR: String,
    @SerializedName("packageNameEN")
    val packageNameEN: String,
    @SerializedName("price")
    val price: Double,
    @SerializedName("serviceAR")
    val serviceAR: String,
    @SerializedName("serviceEN")
    val serviceEN: String,
    @SerializedName("status")
    val status: String,
    @SerializedName("userFamilyName")
    val userFamilyName: String,
    @SerializedName("visitDT")
    val visitDT: String,
    @SerializedName("visitTime")
    val visitTime: String,
    @SerializedName("serviceTypeId")
    val serviceTypeId : Long
)