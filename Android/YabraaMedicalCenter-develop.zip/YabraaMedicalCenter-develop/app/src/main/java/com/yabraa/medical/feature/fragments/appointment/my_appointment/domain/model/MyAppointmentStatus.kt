package com.yabraa.medical.feature.fragments.appointment.my_appointment.domain.model

enum class MyAppointmentStatus(val value: String) {
    PENDING("Pending"), REJECTED("Rejected"), DONE("Done"), CANCELED("Canceled")
}