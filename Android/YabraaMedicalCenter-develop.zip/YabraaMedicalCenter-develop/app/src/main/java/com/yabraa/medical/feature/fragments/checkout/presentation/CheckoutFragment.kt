package com.yabraa.medical.feature.fragments.checkout.presentation

import android.annotation.SuppressLint
import android.os.Bundle
import android.view.View
import androidx.annotation.DrawableRes
import androidx.core.view.isVisible
import androidx.fragment.app.viewModels
import androidx.hilt.navigation.fragment.hiltNavGraphViewModels
import androidx.lifecycle.lifecycleScope
import androidx.navigation.fragment.findNavController
import com.oppwa.mobile.connect.checkout.meta.CheckoutActivityResult
import com.oppwa.mobile.connect.checkout.meta.CheckoutActivityResultContract
import com.oppwa.mobile.connect.checkout.meta.CheckoutSettings
import com.oppwa.mobile.connect.provider.TransactionType.SYNC
import com.yabraa.medical.R
import com.yabraa.medical.R.string.pleaseSelectPaymentMethod
import com.yabraa.medical.core.base_fragment.BaseFragment
import com.yabraa.medical.core.base_fragment.navigate
import com.yabraa.medical.core.base_fragment.onBackPressed
import com.core.shared.error.OperationMessage
import com.core.shared.error.PaymentIsCancelled
import com.core.shared.error.UnsuccessfulPayment
import com.core.shared.error.YabraaError
import com.core.shared.state.State
import com.core.shared.utils.CommonUtils.handleExpirationDate
import com.yabraa.medical.core.utils.custom_views.confirmation_appointment.ConfirmationAppointmentHandler
import com.yabraa.medical.core.utils.custom_views.yabraa_bar.YabraaBarHandler
import com.yabraa.medical.core.utils.dialog.payment_dialog.PaymentDialog
import com.yabraa.medical.core.utils.dialog.yabraa_dialog.YabraaDialogBuilder
import com.yabraa.medical.core.utils.getErrorMessage
import com.yabraa.medical.databinding.FragmentCheckoutBinding
import com.yabraa.medical.feature.fragments.checkout.data.model.request.CheckoutRequestDto
import com.yabraa.medical.feature.fragments.checkout.data.model.request.PaymentRequestDto
import com.yabraa.medical.feature.fragments.checkout.domain.viewmodel.CheckoutViewModel
import com.yabraa.medical.feature.fragments.checkout.presentation.adapter.CheckoutAdapter
import com.yabraa.medical.feature.fragments.checkout.presentation.adapter.PaymentMethodsAdapter
import com.yabraa.medical.feature.fragments.common.domain.model.ErrorMessageUi
import com.yabraa.medical.feature.fragments.common.domain.viewmodel.TransactionViewModel
import com.yabraa.medical.feature.fragments.home.domain.model.ServiceTypeName
import com.yabraa.medical.feature.fragments.splash_screen.presentation.FIREBASE_CLOUD_MESSAGING_TOKEN
import dagger.hilt.android.AndroidEntryPoint
import kotlinx.coroutines.launch
import yabraa.medical.getProviderMode
import java.util.Locale
import java.util.regex.PatternSyntaxException

@AndroidEntryPoint
class CheckoutFragment : BaseFragment<FragmentCheckoutBinding>() {

    override val binding by lazy { FragmentCheckoutBinding.inflate(layoutInflater) }
    private val viewModel: TransactionViewModel by hiltNavGraphViewModels(R.id.mainNavGraph)
    private val checkoutViewModel: CheckoutViewModel by viewModels()
    private val serviceId get() = viewModel.serviceId ?: 0L
    private val paymentMethodsList get() = checkoutViewModel.getPaymentMethodsList()

    private val transactionList get() = viewModel.packagesTransactionList.toMutableList()
    private val checkoutAdapter by lazy {
        CheckoutAdapter(transactionList) {
            navigateBack()
        }
    }

    private val totalPrice get() = viewModel.getPackagesTotalPrice()

    private lateinit var paymentMethodsAdapter: PaymentMethodsAdapter
    private var paymentMethodName: String? = null
    private var paymentMethodId: Long? = null

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        showExpirationDateError()
        binding.handleNetworkConnection()
        lifecycleScope.apply {
            launch { collectOnCheckoutResponseState() }
            launch { collectOnCompleteResponseState() }
            launch { collectOnPaymentMethodResponseState() }
        }
    }

    override fun onViewCreated(view: View, savedInstanceState: Bundle?) {
        super.onViewCreated(view, savedInstanceState)
        binding.setupViews()
    }

    override fun onResume() {
        super.onResume()
        confirmationView?.setConfirmationView()
        yabraaBarView?.setYabraaBarViews()
        showBottomNavigation(false)
    }


    private fun ConfirmationAppointmentHandler.setConfirmationView() {
        setConfirmationAppointmentVisibility(false)
    }

    private fun YabraaBarHandler.setYabraaBarViews() {
        val serviceName = viewModel.getServiceNameByServiceId(serviceId)
        setYabraaBarVisibility(true)
        setBarTitle(R.string.pay.localize())
        setOnBackArrowClicked()
        setClearAllVisibility(false)
    }

    private fun YabraaBarHandler.setOnBackArrowClicked() = setOnBackArrowClicked { navigateBack() }


    private fun FragmentCheckoutBinding.handleNetworkConnection() {
        connectivityManager?.isNetworkConnected?.observe(this@CheckoutFragment) {
            handleConnectionViewVisibility(it)
            if (!it) return@observe
            checkoutViewModel.getPaymentMethod()
        }
    }

    private fun FragmentCheckoutBinding.handleConnectionViewVisibility(isVisible: Boolean) {
        checkoutGroup.isVisible = isVisible
        internetConnection.root.isVisible = !isVisible
    }

    private fun FragmentCheckoutBinding.setupViews() {
        setOnBackPressed()
        setUpCheckoutAdapter()
        setTotalPrice()
        setOnPaymentClicked()
    }

    private fun setOnBackPressed() = onBackPressed { navigateBack() }

    private fun FragmentCheckoutBinding.setUpCheckoutAdapter() {
        checkoutRV.adapter = checkoutAdapter
    }

    private fun FragmentCheckoutBinding.setTotalPrice() {
        totalPriceValueTv.text =
            String.format(Locale.ENGLISH, R.string.price.localize(), totalPrice)
    }

    private suspend fun collectOnPaymentMethodResponseState() {
        checkoutViewModel.paymentMethodResponseState.collect {
            hideProgressDialog()
            when (it) {
                is State.Error -> it.error.handleError { }
                is State.Initial -> {}
                is State.Loading -> showProgressDialog()
                is State.Success -> {}
            }
        }
    }

    @SuppressLint("FragmentLiveDataObserve")
    private fun FragmentCheckoutBinding.setOnPaymentClicked() {
        connectivityManager?.isNetworkConnected?.observe(this@CheckoutFragment) { isConnected ->
            paymentBtn.setOnClickListener {
                if (!isConnected) {
                    showNetworkConnectionErrorPopup()
                    return@setOnClickListener
                }
                showAskPaymentNowPopup()
            }
        }
    }


    private fun showAskPaymentNowPopup() {
        paymentMethodsAdapter = PaymentMethodsAdapter(paymentMethodsList) {
            paymentMethodName = it.name
            paymentMethodId = it.paymentMethodId
        }
        showSelectPaymentMethodPopUp(paymentMethodsAdapter)
    }

    private fun showSelectPaymentMethodPopUp(paymentMethodsAdapter: PaymentMethodsAdapter) {
        PaymentDialog(requireActivity())
            .setPayAdapter(paymentMethodsAdapter)
            .setTopButton(R.string.pay) {
                if (paymentMethodName == null) {
                    showShortToast(getString(pleaseSelectPaymentMethod))
                    return@setTopButton
                }
                handleCheckoutRequest()
            }.show()
    }


    private fun handleCheckoutRequest() {
        val locationLongitude = viewModel.latLng?.longitude
        val locationLatitude = viewModel.latLng?.latitude
        val checkoutRequest = CheckoutRequestDto(
            serviceTypeId = viewModel.serviceTypeId ?: 0L,
            locationLongitude = locationLongitude,
            locationLatitude = locationLatitude,
            amount = totalPrice,
            paymentMethodId = paymentMethodId ?: 0L,
            packages = viewModel.getCheckoutPackagesList()
        )
        checkoutViewModel.checkout(checkoutRequest)
    }

    private suspend fun collectOnCheckoutResponseState() {
        checkoutViewModel.checkoutResponseState.collect {
            hideProgressDialog()
            when (it) {
                is State.Error -> it.error.handleCheckoutResponseError()
                is State.Initial -> {}
                is State.Loading -> showProgressDialog()
                is State.Success -> startCheckout(checkoutViewModel.getCheckoutId())
            }
        }
    }


    private val checkoutLauncher =
        registerForActivityResult(CheckoutActivityResultContract()) { result ->
            handleCheckoutResult(result)
        }

    private fun startCheckout(checkOutId: String) {
        val paymentBrands = hashSetOf(paymentMethodName)
        val checkoutSettings = CheckoutSettings(checkOutId, paymentBrands, getProviderMode())
        //checkoutSettings.shopperResultUrl = "com.yabraa.medical://result"
        checkoutSettings.isCardScanningEnabled = false
        checkoutLauncher.launch(checkoutSettings)
        paymentMethodName = null
    }

    private fun handleCheckoutResult(result: CheckoutActivityResult) {
        val transaction = result.transaction
        when {
            result.isCanceled -> {
                YabraaError.E(
                    exception = UnsuccessfulPayment(),
                    logMessageEn = "${result.isCanceled}"
                )
                showShortToast(R.string.paymentIsCancelled.localize())
                return
            }

            result.isErrored -> {
                YabraaError.E(
                    exception = PaymentIsCancelled(),
                    logMessageEn = "${result.isErrored}"
                )
                showShortToast(R.string.unSuccessfulPayment.localize())
                return
            }

            transaction != null && transaction.transactionType === SYNC -> {
                handleCompletePayment()
            }
        }
    }

    private fun handleCompletePayment() {
        val firebaseToken = sharedPreference.getString(FIREBASE_CLOUD_MESSAGING_TOKEN) ?: ""
        val checkOutId = checkoutViewModel.getCheckoutId()
        val paymentMethodId = paymentMethodId ?: 0L
        val paymentRequestDto = PaymentRequestDto(checkOutId, paymentMethodId, firebaseToken)
        checkoutViewModel.completePayment(paymentRequestDto)
    }

    private suspend fun collectOnCompleteResponseState() {
        checkoutViewModel.completePaymentState.collect {
            hideProgressDialog()
            when (it) {
                is State.Error -> it.error.handleCheckoutResponseError()
                is State.Initial -> {}
                is State.Loading -> showProgressDialog()
                is State.Success -> {
                    val code = it.data?.paymentResponse?.code ?: return@collect
                    //val description = it.data.paymentResponse.description
                    checkOnTransactionStatusCode(code)
                }
            }
        }
    }

    private fun checkOnTransactionStatusCode(code: String): Boolean {
        val pattern1 = getString(R.string.transactionStatusCodePattern1).toRegex()
        val pattern2 = getString(R.string.transactionStatusCodePattern2).toRegex()
        return try {
            when {
                pattern1.containsMatchIn(code) || pattern2.containsMatchIn(code) -> {
                    val description = R.string.successfulPayment.localize()
                    showTransactionStatusPopup(description, isSuccess = true)
                    true
                }

                else -> {
                    val description = R.string.unSuccessfulPayment.localize()
                    val logo = R.drawable.ic_vector_error
                    showTransactionStatusPopup(description, logo, isSuccess = false)
                    false
                }
            }

        } catch (e: PatternSyntaxException) {
            val logMessage = "Invalid regular expression: ${e.localizedMessage}"
            YabraaError.E(exception = e, logMessageEn = logMessage)
            false
        }
    }

    private fun showTransactionStatusPopup(
        description: String,
        @DrawableRes icVector: Int = R.drawable.ic_vector_check_circle,
        isSuccess: Boolean
    ) {
        YabraaDialogBuilder(requireActivity())
            .setIcon(icVector)
            .setMessage(description)
            .setTopButton(R.string.ok) {
                if (isSuccess) findNavController().popBackStack(R.id.homeFragment, false)
            }.setCancelable(false)
            .show()
    }

    private fun YabraaError.handleCheckoutResponseError() {
        val errorMessageUi = ErrorMessageUi(logMessageEn, logMessageAr)
        handleError {
            when (exception) {
                is OperationMessage -> showCheckoutResponseErrorPopup(errorMessageUi)
            }
        }
    }

    private fun showCheckoutResponseErrorPopup(errorMessageUi: ErrorMessageUi) {
        val errorMessage = getErrorMessage(errorMessageUi)
        YabraaDialogBuilder(requireActivity()).setIcon(R.drawable.ic_vector_error)
            .setTitle(R.string.warning)
            .setMessage(errorMessage)
            .setTopButton(R.string.ok) {
                checkoutViewModel.getPaymentMethod()
            }
            .setCancelable(false)
            .show()
    }

    @Suppress("IMPLICIT_CAST_TO_ANY")
    private fun navigateBack() =
        if (viewModel.serviceTypeName == ServiceTypeName.NORMAL.typeValue) {
            navigate(R.id.actionCheckoutFragmentToMapsFragment)
        } else {
            findNavController().popBackStack()
        }


    private fun showExpirationDateError() =
        tokenHandler.handleExpirationDate { showExpirationDatePopupError() }


    override fun handleIoExceptionError() {
        handleCompletePayment()
    }
}