package com.yabraa.medical.feature.fragments.appointment.my_appointment_details.data.model


import com.google.gson.annotations.SerializedName

data class VisitAttachment(
    @SerializedName("createDTs")
    val createDTs: String,
    @SerializedName("path")
    val path: String,
    @SerializedName("title")
    val title: String
)