package com.yabraa.medical.feature.fragments.allergies_and_chronic_diseases.past_medication_fragment.presentation

import android.os.Bundle
import android.view.View
import androidx.core.view.isVisible
import androidx.fragment.app.viewModels
import androidx.lifecycle.lifecycleScope
import androidx.navigation.fragment.findNavController
import com.yabraa.medical.R
import com.yabraa.medical.core.base_fragment.BaseFragment
import com.core.shared.error.OperationMessage
import com.core.shared.error.YabraaError
import com.core.shared.state.State
import com.core.shared.utils.CommonUtils.handleExpirationDate
import com.yabraa.medical.core.utils.custom_views.yabraa_bar.YabraaBarHandler
import com.yabraa.medical.core.utils.dialog.yabraa_dialog.YabraaDialogBuilder
import com.yabraa.medical.core.utils.getErrorMessage
import com.yabraa.medical.databinding.FragmentGeneralAllergiesAndChronicDiseasesBinding
import com.yabraa.medical.feature.fragments.allergies_and_chronic_diseases.past_medication_fragment.data.model.request.PastMedicationRequestDto
import com.yabraa.medical.feature.fragments.allergies_and_chronic_diseases.past_medication_fragment.domain.viewmodel.PastMedicationViewModel
import com.yabraa.medical.feature.fragments.allergies_and_chronic_diseases.past_medication_fragment.presentation.adapter.PastMedicationAdapter
import com.yabraa.medical.feature.fragments.allergies_and_chronic_diseases.select_patient_fragment.presentation.USER_FAMILY_ID
import com.yabraa.medical.feature.fragments.common.domain.model.ErrorMessageUi
import dagger.hilt.android.AndroidEntryPoint
import kotlinx.coroutines.launch

@AndroidEntryPoint
class PastMedicationFragment : BaseFragment<FragmentGeneralAllergiesAndChronicDiseasesBinding>() {

    override val binding by lazy {
        FragmentGeneralAllergiesAndChronicDiseasesBinding.inflate(
            layoutInflater
        )
    }

    private val viewModel: PastMedicationViewModel by viewModels()
    lateinit var adapter: PastMedicationAdapter
    private val userFamilyId get() = arguments?.getLong(USER_FAMILY_ID) ?: 0L

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        showExpirationDateError()
    }


    override fun onViewCreated(view: View, savedInstanceState: Bundle?) {
        super.onViewCreated(view, savedInstanceState)
        handleInternetConnection()
        lifecycleScope.apply {
            launch { collectOnPastMedicationResponseState() }
            launch { collectOnAddPastMedicationResponseState() }
            launch { collectOnDeletePastMedicationResponseState() }
        }
    }

    override fun onResume() {
        super.onResume()
        yabraaBarView?.setUpYabraaBarView()
        confirmationView?.setConfirmationAppointmentVisibility(false)
        showBottomNavigation(false)
    }

    private fun YabraaBarHandler.setUpYabraaBarView() {
        setYabraaBarVisibility(true)
        setClearAllVisibility(false)
        setBarTitle(R.string.pastMedication.localize())
        setOnBackArrowClicked { findNavController().popBackStack() }
    }

    private fun handleInternetConnection() {
        connectivityManager?.isNetworkConnected?.observe(viewLifecycleOwner) {
            binding.handleConnectionViewVisibility(it)
            if (!it) return@observe
            handelPastMedicationRequest()
        }
    }

    private fun FragmentGeneralAllergiesAndChronicDiseasesBinding.handleConnectionViewVisibility(
        isVisible: Boolean
    ) {
        generalRv.isVisible = isVisible
        internetConnection.root.isVisible = !isVisible
    }

    private suspend fun collectOnPastMedicationResponseState() {
        viewModel.pastMedicationResponseState.collect {
            hideProgressDialog()
            when (it) {
                is State.Error -> it.error.handleHomeResponseError()
                is State.Initial -> {}
                is State.Loading -> showProgressDialog()
                is State.Success -> collectOnChronicDiseasesByUserFamilyIdState()
            }
        }
    }

    private suspend fun collectOnChronicDiseasesByUserFamilyIdState() {
        viewModel.pastMedicationByUserFamilyIdResponseState.collect {
            hideProgressDialog()
            when (it) {
                is State.Error -> it.error.handleHomeResponseError()
                is State.Initial -> {}
                is State.Loading -> showProgressDialog()
                is State.Success -> binding.setUpAdapter()
            }
        }
    }

    private fun FragmentGeneralAllergiesAndChronicDiseasesBinding.setUpAdapter() {
        val chronicDiseases = viewModel.getPastMedicationList()
        adapter = PastMedicationAdapter(
            chronicDiseases,
            onAddItemClicked = { id ->
                viewModel.addPastMedication(PastMedicationRequestDto(id, userFamilyId))
            }) { id ->
            viewModel.deletePastMedication(PastMedicationRequestDto(id, userFamilyId))
        }
        generalRv.adapter = adapter
    }

    private suspend fun collectOnAddPastMedicationResponseState() {
        viewModel.addPastMedicationResponseState.collect {
            hideProgressDialog()
            when (it) {
                is State.Error -> it.error.handleHomeResponseError()
                is State.Initial -> {}
                is State.Loading -> showProgressDialog()
                is State.Success -> handelPastMedicationRequest()
            }
        }
    }

    private suspend fun collectOnDeletePastMedicationResponseState() {
        viewModel.deletePastMedicationResponseState.collect {
            hideProgressDialog()
            when (it) {
                is State.Error -> it.error.handleHomeResponseError()
                is State.Initial -> {}
                is State.Loading -> showProgressDialog()
                is State.Success -> handelPastMedicationRequest()
            }
        }
    }

    private fun handelPastMedicationRequest() {
        viewModel.getPastMedication()
        viewModel.getPastMedicationByUserFamilyId(userFamilyId)
    }

    private fun YabraaError.handleHomeResponseError() {
        val errorMessageUi = ErrorMessageUi(logMessageEn, logMessageAr)
        handleError {
            when (exception) {
                is OperationMessage -> showHomeResponseErrorPopup(errorMessageUi)
            }
        }
    }

    private fun showHomeResponseErrorPopup(errorMessageUi: ErrorMessageUi) {
        val errorMessage = getErrorMessage(errorMessageUi)
        YabraaDialogBuilder(requireActivity())
            .setIcon(R.drawable.ic_vector_error)
            .setTitle(R.string.warning)
            .setMessage(errorMessage)
            .setTopButton(R.string.ok) {}
            .setCancelable(false)
            .show()
    }

    private fun showExpirationDateError() =
        tokenHandler.handleExpirationDate { showExpirationDatePopupError() }
}