package com.yabraa.medical.core.di

import com.yabraa.medical.core.di.network_sevices.AllergiesAndChronicDiseasesServices
import com.yabraa.medical.core.di.network_sevices.SecurityServices
import com.yabraa.medical.core.di.network_sevices.YabraaServices
import dagger.Module
import dagger.Provides
import dagger.hilt.InstallIn
import dagger.hilt.components.SingletonComponent
import retrofit2.Retrofit
import javax.inject.Singleton

@Module
@InstallIn(SingletonComponent::class)
object YabraaServicesModule {

    @Singleton
    @Provides
    fun provideSecurityService(retrofit: Retrofit): SecurityServices =
        retrofit.create(SecurityServices::class.java)

    @Singleton
    @Provides
    fun provideYabraaService(retrofit: Retrofit): YabraaServices =
        retrofit.create(YabraaServices::class.java)

    @Singleton
    @Provides
    fun provideAllergiesAndChronicDiseasesServices(retrofit: Retrofit): AllergiesAndChronicDiseasesServices =
        retrofit.create(AllergiesAndChronicDiseasesServices::class.java)
}