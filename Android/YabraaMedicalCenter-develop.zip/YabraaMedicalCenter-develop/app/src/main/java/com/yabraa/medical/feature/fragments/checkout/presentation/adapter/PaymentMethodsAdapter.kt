package com.yabraa.medical.feature.fragments.checkout.presentation.adapter

import android.annotation.SuppressLint
import android.view.LayoutInflater
import android.view.ViewGroup
import androidx.annotation.DrawableRes
import androidx.annotation.StringRes
import androidx.recyclerview.widget.RecyclerView
import com.yabraa.medical.R
import com.core.shared.utils.CommonUtils.load
import com.yabraa.medical.core.utils.localize
import com.yabraa.medical.databinding.ItemPaymentMethodBinding
import com.yabraa.medical.feature.fragments.checkout.data.model.response.payment_method_response.PaymentMethodItem
import com.yabraa.medical.feature.fragments.checkout.domain.model.PaymentCardUtils

class PaymentMethodsAdapter(
    private val paymentItems: MutableList<PaymentMethodItem>,
    private val onItemClicked: (PaymentMethodItem) -> Unit
) : RecyclerView.Adapter<PaymentMethodsAdapter.ViewHolder>() {

    private var checkedPosition = -1

    override fun onCreateViewHolder(
        parent: ViewGroup,
        viewType: Int
    ): PaymentMethodsAdapter.ViewHolder {
        val binding =
            ItemPaymentMethodBinding.inflate(LayoutInflater.from(parent.context), parent, false)
        return ViewHolder(binding)
    }

    override fun onBindViewHolder(viewHolder: PaymentMethodsAdapter.ViewHolder, position: Int) {
        val item = paymentItems[position]
        viewHolder.bind(item)
    }

    override fun getItemCount() = paymentItems.size

    override fun getItemViewType(position: Int) = position

    inner class ViewHolder(val binding: ItemPaymentMethodBinding) :
        RecyclerView.ViewHolder(binding.root) {

        val context = binding.root.context
        fun bind(item: PaymentMethodItem) {
            binding.setUpViews(item)
        }

        private fun ItemPaymentMethodBinding.setUpViews(item: PaymentMethodItem) {
            setSelectItemClicked(item)
            handleCheckedSelectItem()
            when (item.name) {
                PaymentCardUtils.VISA.value ->
                    setPaymentMethodDetails(R.drawable.ic_vector_visa_card, R.string.visa)

                PaymentCardUtils.MASTER.value ->
                    setPaymentMethodDetails(R.drawable.ic_vector_master_card, R.string.master
                )
                PaymentCardUtils.MADA.value ->
                    setPaymentMethodDetails(R.drawable.ic_mada_card, R.string.mada)

                PaymentCardUtils.STC_PAY.value ->
                    setPaymentMethodDetails(R.drawable.ic_stc_pay_card, R.string.stcPay)

            }

        }

        private fun ItemPaymentMethodBinding.setPaymentMethodDetails(
            @DrawableRes icon: Int,
            @StringRes paymentName: Int
        ) {
            paymentMethodIv.load(context, icon)
            paymentNameTv.text = context.localize(paymentName)
        }

        private fun ItemPaymentMethodBinding.setSelectItemClicked(item: PaymentMethodItem) {
            root.setOnClickListener {
                handleSelectedItem()
                if (checkedPosition != absoluteAdapterPosition) {
                    notifyItemChanged(checkedPosition)
                    checkedPosition = absoluteAdapterPosition
                }
                onItemClicked(item)
            }
        }

        @SuppressLint("ResourceAsColor")
        private fun ItemPaymentMethodBinding.handleCheckedSelectItem() {
            if (checkedPosition == -1) handleUnSelectedItem()
            when (checkedPosition) {
                absoluteAdapterPosition -> handleSelectedItem()
                else -> handleUnSelectedItem()
            }
        }

        private fun ItemPaymentMethodBinding.handleSelectedItem() {
            checkIv.setImageResource(R.drawable.ic_vector_circle_checked)
        }

        private fun ItemPaymentMethodBinding.handleUnSelectedItem() {
            checkIv.setImageResource(R.drawable.ic_vector_circle_unchecked)
        }
    }
}