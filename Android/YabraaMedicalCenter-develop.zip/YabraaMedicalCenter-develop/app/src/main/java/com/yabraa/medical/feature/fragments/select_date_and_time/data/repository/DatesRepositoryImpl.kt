package com.yabraa.medical.feature.fragments.select_date_and_time.data.repository

import com.yabraa.medical.core.base_repository.BaseRepository
import com.yabraa.medical.core.di.network_sevices.YabraaServices
import com.core.shared.state.State
import com.yabraa.medical.core.utils.getResponseMessageError
import com.yabraa.medical.feature.fragments.select_date_and_time.data.response.DatesResponseDto
import com.yabraa.medical.feature.fragments.select_date_and_time.domain.repository.DatesRepository
import kotlinx.coroutines.flow.flow
import kotlinx.coroutines.flow.flowOn
import retrofit2.Response
import javax.inject.Inject

const val TAG_DATES_RESPONSE = "TAG_DATES_RESPONSE"

class DatesRepositoryImpl @Inject constructor(private val yabraaServices: YabraaServices) :
    BaseRepository<Any, DatesResponseDto>(), DatesRepository {


    override suspend fun getDates() = flow {
        emit(getOperationState(Any()))
    }.flowOn(dispatcher)


    override suspend fun performApiCall(requestDto: Any): State<DatesResponseDto> {
        val response = yabraaServices.getDates()
        return handleDatesResponse(response)
    }

    private fun handleDatesResponse(response: Response<DatesResponseDto>): State<DatesResponseDto> {
        val responseBody = response.body()
        val errorMessageEn = responseBody?.errorMessageEn ?: ""
        val errorMessageAr = responseBody?.errorMessageAr ?: ""
        return when {
            response.isSuccessful && responseBody?.datesDataResponse != null ->
                State.Success(response.body())

            response.isSuccessful && !responseBody?.errorMessageEn.isNullOrEmpty() ->
                getResponseMessageError(
                    errorMessageEn = errorMessageEn,
                    errorMessageAr = errorMessageAr,
                    logTag = TAG_DATES_RESPONSE
                )

            else -> getNotSuccessfulResponseState(response)
        }
    }
}