package com.yabraa.medical.feature.fragments.patients.edit_patients.presentation

import android.annotation.SuppressLint
import android.os.Build
import android.os.Bundle
import android.view.View
import android.widget.RadioButton
import androidx.annotation.StringRes
import androidx.core.content.ContextCompat.getColorStateList
import androidx.core.content.res.ResourcesCompat
import androidx.core.view.isVisible
import androidx.fragment.app.viewModels
import androidx.lifecycle.lifecycleScope
import androidx.navigation.fragment.findNavController
import com.yabraa.medical.R
import com.yabraa.medical.R.color.primaryDark900
import com.yabraa.medical.R.string.doYouWantToDeleteThisPatient
import com.yabraa.medical.core.base_fragment.BaseFragment
import com.core.shared.error.EmptyBirthDate
import com.core.shared.error.EmptyGender
import com.core.shared.error.OperationMessage
import com.core.shared.error.PatientName
import com.core.shared.error.YabraaError
import com.core.shared.state.State
import com.core.shared.utils.CommonUtils.decodeDateString
import com.core.shared.utils.CommonUtils.handleExpirationDate
import com.yabraa.medical.core.utils.custom_views.yabraa_bar.YabraaBarHandler
import com.yabraa.medical.core.utils.dialog.yabraa_date_picker_dialog.YabraaDatePickerDialog
import com.yabraa.medical.core.utils.dialog.yabraa_dialog.YabraaButtonStyle
import com.yabraa.medical.core.utils.dialog.yabraa_dialog.YabraaDialogBuilder
import com.yabraa.medical.core.utils.getErrorMessage
import com.yabraa.medical.databinding.FragmentAddPatientBinding
import com.yabraa.medical.feature.fragments.common.domain.model.ErrorMessageUi
import com.yabraa.medical.feature.fragments.patients.edit_patients.domain.model.EditPatientUi
import com.yabraa.medical.feature.fragments.patients.edit_patients.domain.viemodel.EditPatientViewModel
import com.yabraa.medical.feature.fragments.patients.patients.data.model.response.PatientResponse
import com.yabraa.medical.feature.fragments.patients.patients.presentation.EDIT_PATIENT
import com.yabraa.medical.feature.fragments.register.data.request.GenderType.FEMALE
import com.yabraa.medical.feature.fragments.register.data.request.GenderType.MALE
import dagger.hilt.android.AndroidEntryPoint
import kotlinx.coroutines.launch
import javax.inject.Inject


@AndroidEntryPoint
class EditPatientFragment : BaseFragment<FragmentAddPatientBinding>() {

    override val binding by lazy { FragmentAddPatientBinding.inflate(layoutInflater) }
    private val vieModel: EditPatientViewModel by viewModels()

    @Inject
    lateinit var yabraaDatePickerDialog: YabraaDatePickerDialog

    private var birthDate: String? = null
    private var genderType: String? = null

    @Suppress("DEPRECATION")
    private val patientDetails
        get() = run {
            if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.TIRAMISU) {
                arguments?.getSerializable(EDIT_PATIENT, PatientResponse::class.java)
            } else {
                arguments?.getSerializable(EDIT_PATIENT)
            }
        } as PatientResponse


    private val userFamilyId get() = patientDetails.userFamilyId

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        showExpirationDateError()
    }

    override fun onViewCreated(view: View, savedInstanceState: Bundle?) {
        super.onViewCreated(view, savedInstanceState)
        lifecycleScope.launch { collectOnDeletePatientResponseState() }
        lifecycleScope.launch { collectOnValidateInput() }
        lifecycleScope.launch { collectOnEditPatientResponseState() }
        binding.setUpViews()
    }

    override fun onResume() {
        super.onResume()
        yabraaBarView?.setUpYabraaBarView()
        confirmationView?.setConfirmationAppointmentVisibility(false)
        showBottomNavigation(false)
    }

    private fun YabraaBarHandler.setUpYabraaBarView() {
        val barTitle = R.string.editPatient.localize()
        setYabraaBarVisibility(true)
        setClearAllVisibility(false)
        setBarTitle(barTitle)
        setOnBackArrowClicked { findNavController().popBackStack() }
    }


    private fun FragmentAddPatientBinding.setUpViews() {
        handleEidGroupVisibility()
        setFirstName()
        setBirthDate()
        setOnDateOfBirthViewClicked()
        setMaleGenderValue()
        setFemaleGenderValue()
        setOnGenderSelectedClicked()
        setOnDeletePatientClicked()
        setOnUpdatePatientClicked()
    }


    private fun FragmentAddPatientBinding.handleEidGroupVisibility() {
        addNewPatientBtn.isVisible = false
        editGroup.isVisible = true
    }


    private fun FragmentAddPatientBinding.setFirstName() =
        patientNameEt.setText(patientDetails.name)

    private fun FragmentAddPatientBinding.setBirthDate() {
        val dateOfBirthTvColor = getColorStateList(requireContext(), primaryDark900)
        dateOfBirthTv.setTextColor(dateOfBirthTvColor)
        dateOfBirthTv.text = decodeDateString(patientDetails.birthDate, "yyyy-MM-dd")
    }

    private fun FragmentAddPatientBinding.setOnDateOfBirthViewClicked() {
        dateOfBirthView.setOnClickListener { setDateOfBirthView() }
    }


    private fun FragmentAddPatientBinding.setDateOfBirthView() {
        val dateOfBirthTvColor = getColorStateList(requireContext(), primaryDark900)
        yabraaDatePickerDialog.datePickerDialog(requireActivity()) {
            if (it.isEmpty()) return@datePickerDialog
            dateOfBirthTv.setTextColor(dateOfBirthTvColor)
            dateOfBirthTv.text = it
            birthDate = it
        }?.show()
    }

    private suspend fun collectOnValidateInput() {
        vieModel.validationState.collect {
            when (it) {
                is State.Error -> handleError(it)
                is State.Initial -> {}
                is State.Loading -> {}
                is State.Success -> {}
            }
        }
    }

    private fun handleError(errorState: State.Error<*>) {
        errorState.error.handleError {
            when (exception) {
                is PatientName -> showInputErrorSnackBar(R.string.pleaseEnterPatientName)
                is EmptyBirthDate -> showInputErrorSnackBar(R.string.pleaseEnterYourBirthDate)
                is EmptyGender -> showInputErrorSnackBar(R.string.pleaseSelectSex)
            }
        }
    }

    private fun setMaleGenderValue() {
        val maleBtn = activity?.findViewById(R.id.maleBtn) as RadioButton
        maleBtn.isChecked = patientDetails.gender == MALE.genderValue
    }

    private fun setFemaleGenderValue() {
        val femaleBtn = activity?.findViewById(R.id.femaleBtn) as RadioButton
        femaleBtn.isChecked = patientDetails.gender == FEMALE.genderValue
    }

    private fun FragmentAddPatientBinding.setOnGenderSelectedClicked() {
        radioBtnGroup.setOnCheckedChangeListener { _, checkedId ->
            when (checkedId) {
                R.id.maleBtn -> genderType = MALE.genderValue
                R.id.femaleBtn -> genderType = FEMALE.genderValue
            }
        }
    }


    private fun showInputErrorSnackBar(@StringRes message: Int) =
        yabraaSnackBarBuilder.setEndIcon(R.drawable.ic_vector_close).setMessage(message)
            .build(requireView()).show()


    @SuppressLint("FragmentLiveDataObserve")
    private fun FragmentAddPatientBinding.setOnDeletePatientClicked() {
        connectivityManager?.isNetworkConnected?.observe(this@EditPatientFragment) { isConnected ->
            deleteBtn.setOnClickListener {
                if (!isConnected) {
                    showNetworkConnectionErrorPopup()
                    return@setOnClickListener
                }
                showDeletePatientPopUp()
            }
        }
    }


    private fun showDeletePatientPopUp() {
        val topBtnStyle = YabraaButtonStyle(
            backGround = R.color.primaryLight100,
            textColor = ResourcesCompat.getColor(resources, primaryDark900, null)
        )
        YabraaDialogBuilder(requireActivity()).setIcon(R.drawable.ic_vector_error)
            .setTitle(R.string.warning)
            .addHtmlMessage(doYouWantToDeleteThisPatient, patientDetails.name)
            .setTopButton(R.string.delete, topBtnStyle) {
                vieModel.deletePatient(userFamilyId)
            }.setBottomButton(R.string.cancel) {}
            .setCancelable(false).show()
    }

    private suspend fun collectOnDeletePatientResponseState() {
        vieModel.deletePatientResponseState.collect {
            hideProgressDialog()
            when (it) {
                is State.Error -> it.error.handlePatientResponseError()
                is State.Initial -> {}
                is State.Loading -> showProgressDialog()
                is State.Success -> showDeletePatientResponseSuccessPopup()
            }
        }
    }

    private fun showDeletePatientResponseSuccessPopup() {
        YabraaDialogBuilder(requireActivity()).setIcon(R.drawable.ic_vector_check_circle)
            .setTitle(R.string.success)
            .setMessage(R.string.thePatientHasBeenDeleted)
            .setTopButton(R.string.ok) {
                findNavController().popBackStack()
            }.setCancelable(false).show()
    }


    @SuppressLint("FragmentLiveDataObserve")
    private fun FragmentAddPatientBinding.setOnUpdatePatientClicked() {
        connectivityManager?.isNetworkConnected?.observe(this@EditPatientFragment) { isConnected ->
            updateBtn.setOnClickListener {
                if (!isConnected) {
                    showNetworkConnectionErrorPopup()
                    return@setOnClickListener
                }
                vieModel.validateInput(setEditPatientRequest())
            }
        }
    }

    private fun FragmentAddPatientBinding.setEditPatientRequest(): EditPatientUi {
        return EditPatientUi(
            userFamilyId = userFamilyId,
            name = patientNameEt.text.toString(),
            birthDate = birthDate ?: "",
            gender = genderType ?: ""
        )
    }

    private suspend fun collectOnEditPatientResponseState() {
        vieModel.editPatientResponseState.collect {
            hideProgressDialog()
            when (it) {
                is State.Error -> it.error.handlePatientResponseError()
                is State.Initial -> {}
                is State.Loading -> showProgressDialog()
                is State.Success -> showEditPatientResponseSuccessPopup()
            }
        }
    }

    private fun YabraaError.handlePatientResponseError() {
        val errorMessageUi =  ErrorMessageUi(logMessageEn, logMessageAr)
        handleError {
            when (exception) {
                is OperationMessage -> showEditPatientResponseErrorPopup(errorMessageUi)
            }
        }
    }


    private fun showEditPatientResponseErrorPopup(errorMessageUi: ErrorMessageUi) {
        val errorMessage = getErrorMessage(errorMessageUi)
        YabraaDialogBuilder(requireActivity()).setIcon(R.drawable.ic_vector_error)
            .setTitle(R.string.warning)
            .setMessage(errorMessage).setTopButton(R.string.ok) {
                //TODO LOG MESSAGE HERE
            }.setCancelable(false).show()
    }


    private fun showEditPatientResponseSuccessPopup() {
        YabraaDialogBuilder(requireActivity()).setIcon(R.drawable.ic_vector_check_circle)
            .setTitle(R.string.success)
            .setMessage(R.string.addPatientHasBeenSuccess)
            .setTopButton(R.string.ok) {
                findNavController().popBackStack()
            }.setCancelable(false).show()
    }

    private fun showExpirationDateError() =
        tokenHandler.handleExpirationDate { showExpirationDatePopupError() }
}