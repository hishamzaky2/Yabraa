package com.yabraa.medical.feature.fragments.patients.add_patient.domain.repository

import kotlinx.coroutines.flow.Flow
import com.core.shared.state.State
import com.yabraa.medical.feature.fragments.patients.add_patient.data.model.reposne.AddPatientResponseDto
import com.yabraa.medical.feature.fragments.patients.add_patient.data.model.request.AddPatientRequest

interface AddPatientRepository {
    suspend fun addPatient(addPatientRequest: AddPatientRequest) : Flow<State<AddPatientResponseDto>>
}