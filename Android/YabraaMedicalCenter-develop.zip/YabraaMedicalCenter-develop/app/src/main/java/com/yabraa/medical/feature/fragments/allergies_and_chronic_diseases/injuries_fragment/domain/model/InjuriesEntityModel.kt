package com.yabraa.medical.feature.fragments.allergies_and_chronic_diseases.injuries_fragment.domain.model

data class InjuriesEntityModel (
    val injuryId: Long,
    val titleAR: String,
    val titleEN: String,
    var isAdded : Boolean = false
)