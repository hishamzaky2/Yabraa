package com.yabraa.medical.feature.fragments.patients.edit_patients.data.repsitory.edit_patient_repository

import com.yabraa.medical.core.base_repository.BaseRepository
import com.yabraa.medical.core.di.network_sevices.YabraaServices
import com.core.shared.state.State
import com.yabraa.medical.core.utils.getResponseMessageError
import com.yabraa.medical.feature.fragments.patients.edit_patients.data.model.request.EditPatientRequest
import com.yabraa.medical.feature.fragments.patients.edit_patients.data.model.response.edit_patient_response.EditPatientResponseDto
import com.yabraa.medical.feature.fragments.patients.edit_patients.domain.repository.edit_patient_repository.EditPatientRepository
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.flow.flow
import kotlinx.coroutines.flow.flowOn
import retrofit2.Response
import javax.inject.Inject

const val TAG_EDIT_PATIENT_RESPONSE = "TAG_DELETE_PATIENT_RESPONSE"

class EditPatientRepositoryImpl @Inject constructor(private val yabraaServices: YabraaServices) :
    BaseRepository<EditPatientRequest, EditPatientResponseDto>(), EditPatientRepository {

    override suspend fun updatePatient(editPatientRequest: EditPatientRequest) = flow {
        emit(getOperationState(editPatientRequest))
    }.flowOn(Dispatchers.IO)

    override suspend fun performApiCall(requestDto: EditPatientRequest): State<EditPatientResponseDto> {
        val response = yabraaServices.updatePatient(requestDto)
        return handEditPatientResponse(response)
    }


    private fun handEditPatientResponse(response: Response<EditPatientResponseDto>): State<EditPatientResponseDto> {
        val responseBody = response.body()
        val errorMessageEn = responseBody?.errorMessageEn ?: ""
        val errorMessageAr = responseBody?.errorMessageAr ?: ""
        return when {
            response.isSuccessful && responseBody?.editPatientResponse != null -> State.Success(
                response.body()
            )

            response.isSuccessful && !responseBody?.errorMessageEn.isNullOrEmpty() -> getResponseMessageError(
                errorMessageEn = errorMessageEn,
                errorMessageAr = errorMessageAr,
                logTag = TAG_EDIT_PATIENT_RESPONSE
            )

            else -> getNotSuccessfulResponseState(response)
        }
    }
}