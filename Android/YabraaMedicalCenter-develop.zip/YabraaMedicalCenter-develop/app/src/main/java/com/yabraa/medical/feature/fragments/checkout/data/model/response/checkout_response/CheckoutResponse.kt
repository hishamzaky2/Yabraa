package com.yabraa.medical.feature.fragments.checkout.data.model.response.checkout_response


import com.google.gson.annotations.SerializedName

data class CheckoutResponse(
    @SerializedName("checkoutId")
    val checkoutId: String,
    @SerializedName("model")
    val model: Model
)