package com.yabraa.medical.feature.fragments.checkout.data.model.response.payment_response


import com.google.gson.annotations.SerializedName

data class PaymentResponseDto(
    @SerializedName("data")
    val paymentResponse: PaymentResponse,
    @SerializedName("errorMessageAr")
    val errorMessageAr: String? = null,
    @SerializedName("errorMessageEn")
    val errorMessageEn: String? = null,
    @SerializedName("statusCode")
    val statusCode: Int
)