package com.yabraa.medical.feature.activits.mainactivity

import android.net.Network
import android.os.Bundle
import android.view.View
import androidx.appcompat.app.AppCompatActivity
import androidx.core.view.WindowInsetsCompat
import androidx.core.view.WindowInsetsControllerCompat
import androidx.core.view.isVisible
import androidx.navigation.fragment.NavHostFragment
import com.yabraa.medical.R
import com.core.shared.connectivity.connectivity_manager.ConnectivityManager
import com.core.shared.connectivity.connectivity_manager.NetworkAwareComponent
import com.core.shared.error.YabraaError
import com.core.shared.error.YabraaErrorHandler
import com.yabraa.medical.core.utils.custom_views.yabraa_bar.YabraaBarHandler
import com.yabraa.medical.databinding.ActivityMainBinding
import dagger.hilt.android.AndroidEntryPoint
import javax.inject.Inject


@AndroidEntryPoint
class MainActivity : AppCompatActivity(), NetworkAwareComponent, YabraaErrorHandler,
    YabraaBarHandler {


    private val binding by lazy { ActivityMainBinding.inflate(layoutInflater) }
    private val navHostFragment by lazy {
        supportFragmentManager.findFragmentById(R.id.navHostFragment) as NavHostFragment
    }

    @Inject
    lateinit var connectivityManager: ConnectivityManager

    override fun onCreate(savedInstanceState: Bundle?) {
        //handleNightModeState()
        super.onCreate(savedInstanceState)
        setContentView(binding.root)
        hideSystemBars(binding.root)
    }
//    private fun handleNightModeState() =
//        AppCompatDelegate.setDefaultNightMode(AppCompatDelegate.MODE_NIGHT_NO)

    override fun onWindowFocusChanged(hasFocus: Boolean) {
        super.onWindowFocusChanged(hasFocus)
        if (hasFocus) {
            hideSystemBars(binding.root)
        }
    }

    private fun hideSystemBars(root: View) {
        val windowInsetsController = WindowInsetsControllerCompat(window, root)
        windowInsetsController.systemBarsBehavior =
            WindowInsetsControllerCompat.BEHAVIOR_SHOW_TRANSIENT_BARS_BY_SWIPE
        windowInsetsController.hide(WindowInsetsCompat.Type.systemBars())
    }


    fun getCurrentFragment() = navHostFragment.childFragmentManager.fragments.firstOrNull()

    override fun onNetworkAvailable(network: Network) {
        (getCurrentFragment() as? NetworkAwareComponent)?.onNetworkAvailable(network)
    }

    override fun onNetworkLost(network: Network) {
        (getCurrentFragment() as? NetworkAwareComponent)?.onNetworkLost(network)
    }

    override fun handleError(error: YabraaError, callback: YabraaError.() -> Unit) {
        error.logError()
        callback(error)
    }

    override fun setYabraaBarVisibility(isVisible: Boolean) {
        binding.yabraaBarView.isVisible = isVisible
    }

    override fun setBarTitle(title: String) {
        binding.yabraaBarView.titleTv.text = title
    }

    override fun setOnBackArrowClicked(listener: () -> Unit) {
        binding.yabraaBarView.backArrowIv.setOnClickListener { listener() }
    }

    override fun setClearAllVisibility(isVisible: Boolean) {
        binding.yabraaBarView.clearAll.isVisible = isVisible
    }

    override fun setOnClearAllClicked(listener: () -> Unit) {
        binding.yabraaBarView.clearAll.setOnClickListener { listener() }
    }

    fun restartActivity() {
        finish()
        startActivity(intent)
    }
}