package com.yabraa.medical.feature.fragments.history_payment.presentation

import android.os.Bundle
import android.view.View
import androidx.core.view.isVisible
import androidx.fragment.app.viewModels
import androidx.hilt.navigation.fragment.hiltNavGraphViewModels
import androidx.lifecycle.MutableLiveData
import androidx.lifecycle.lifecycleScope
import androidx.navigation.fragment.findNavController
import com.yabraa.medical.R
import com.yabraa.medical.core.base_fragment.BaseFragment
import com.yabraa.medical.core.base_fragment.setOnGoToConnectionSettingClicked
import com.core.shared.state.State
import com.core.shared.utils.CommonUtils.handleExpirationDate
import com.yabraa.medical.core.utils.custom_views.yabraa_bar.YabraaBarHandler
import com.yabraa.medical.databinding.FragmentHistoryPaymentBinding
import com.yabraa.medical.feature.fragments.history_payment.data.model.PackagesDate
import com.yabraa.medical.feature.fragments.history_payment.domain.viewmodel.HistoryPaymentViewModel
import com.yabraa.medical.feature.fragments.history_payment.presentation.adapter.HistoryPaymentAdapter
import com.yabraa.medical.feature.fragments.setting.domain.viewmodel.SettingViewModel
import dagger.hilt.android.AndroidEntryPoint
import kotlinx.coroutines.launch

@AndroidEntryPoint
class HistoryPaymentFragment : BaseFragment<FragmentHistoryPaymentBinding>() {

    override val binding by lazy { FragmentHistoryPaymentBinding.inflate(layoutInflater) }

    private val settingViewModel: SettingViewModel by hiltNavGraphViewModels(R.id.setting_graph)
    private val viewModel: HistoryPaymentViewModel by viewModels()
    private val historyPaymentList get() = viewModel.getHistoryPaymentList()
    private val historyPaymentAdapter by lazy { HistoryPaymentAdapter(historyPaymentList) }

    private var packagesDate = MutableLiveData<MutableList<PackagesDate>>()

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        showExpirationDateError()
        binding.handleNetworkConnection()
    }

    override fun onViewCreated(view: View, savedInstanceState: Bundle?) {
        super.onViewCreated(view, savedInstanceState)
        binding.setUpViews()
        lifecycleScope.launch { collectOnHistoryPaymentResponseState() }
    }

    override fun onResume() {
        super.onResume()
        yabraaBarView?.setUpYabraaBarView()
        confirmationView?.setConfirmationAppointmentVisibility(false)
        showBottomNavigation(false)
    }

    private fun YabraaBarHandler.setUpYabraaBarView() {
        val barTitle = settingViewModel.yabraaBarTitle ?: ""
        setYabraaBarVisibility(true)
        setClearAllVisibility(false)
        setBarTitle(barTitle)
        setOnBackArrowClicked { findNavController().popBackStack() }
    }


    private fun showExpirationDateError() =
        tokenHandler.handleExpirationDate { showExpirationDatePopupError() }

    private fun FragmentHistoryPaymentBinding.setUpViews() {
        internetConnection.goToSettingBtn.setOnGoToConnectionSettingClicked(requireActivity())
    }

    private fun FragmentHistoryPaymentBinding.handleNetworkConnection() {
        connectivityManager?.isNetworkConnected?.observe(this@HistoryPaymentFragment) {
            handleConnectionViewVisibility(it)
            handleNoHistoryGroupVisibility(it)
            if (!it) return@observe
            viewModel.getHistoryPayment()
        }
    }

    private fun FragmentHistoryPaymentBinding.handleConnectionViewVisibility(isVisible: Boolean) {
        historyPaymentRv.isVisible = isVisible
        internetConnection.root.isVisible = !isVisible
    }

    private suspend fun collectOnHistoryPaymentResponseState(){
        viewModel.historyPaymentResponseState.collect{
            hideProgressDialog()
            when(it){
                is State.Error -> it.error.handleError {  }
                is State.Initial -> {}
                is State.Loading -> showProgressDialog()
                is State.Success -> {
                    packagesDate.postValue(
                        it.data?.historyPaymentResponse?.packagesDate?.toMutableList()
                    )
                    setHistoryPaymentAdapter()
                }
            }
        }
    }

    private fun setHistoryPaymentAdapter() {
        binding.historyPaymentRv.adapter = historyPaymentAdapter
    }

    private fun FragmentHistoryPaymentBinding.handleNoHistoryGroupVisibility(isVisible: Boolean) {
        packagesDate.observe(this@HistoryPaymentFragment) { response ->
            if (response.isNullOrEmpty()) {
                historyPaymentRv.isVisible = !isVisible
                noHistoryPaymentGroup.isVisible = isVisible
            }
        }
    }
}