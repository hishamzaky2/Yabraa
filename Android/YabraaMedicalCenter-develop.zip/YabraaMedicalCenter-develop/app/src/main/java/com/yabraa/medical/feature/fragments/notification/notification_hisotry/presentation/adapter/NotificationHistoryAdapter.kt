package com.yabraa.medical.feature.fragments.notification.notification_hisotry.presentation.adapter

import android.content.res.ColorStateList
import android.graphics.Color
import android.view.LayoutInflater
import android.view.ViewGroup
import android.widget.TextView
import androidx.paging.PagingDataAdapter
import androidx.recyclerview.widget.DiffUtil
import androidx.recyclerview.widget.RecyclerView
import com.core.shared.utils.CommonUtils
import com.yabraa.medical.databinding.ItemNotificationHistoryBinding
import com.yabraa.medical.feature.fragments.notification.notification_hisotry.data.model.response.notification_history_response.Notification
import com.yabraa.medical.feature.fragments.notification.notification_hisotry.presentation.adapter.NotificationHistoryAdapter.ViewHolder
import java.util.Locale

class NotificationHistoryAdapter(
    diffUtil: DiffUtil.ItemCallback<Notification>, private val onItemClicked: (Notification) -> Unit
) : PagingDataAdapter<Notification, ViewHolder>(diffUtil) {


    override fun onCreateViewHolder(parent: ViewGroup, viewType: Int): ViewHolder {
        val binding = ItemNotificationHistoryBinding.inflate(
            LayoutInflater.from(parent.context), parent, false
        )
        return ViewHolder(binding)
    }

    override fun onBindViewHolder(viewHolder: ViewHolder, position: Int) {
        val item = getItem(position) ?: return
        viewHolder.bind(item)
    }

    inner class ViewHolder(private val binding: ItemNotificationHistoryBinding) :
        RecyclerView.ViewHolder(binding.root) {
        fun bind(item: Notification) {
            binding.setUpViews(item)
        }

        private fun ItemNotificationHistoryBinding.setUpViews(item: Notification) {
            notificationNoValueTv.text = String.format(Locale.ENGLISH, "%d", item.notificationId)
            titleTv.text = CommonUtils.getLocalizedValue(item.titleEn, item.titleAR)
            bodyTv.text = CommonUtils.getLocalizedValue(item.bodyEn, item.bodyAR)
            itemCard.setOnClickListener { onItemClicked(item) }
            handleCardBackground(item)

        }


        private fun ItemNotificationHistoryBinding.handleCardBackground(item: Notification) {
            if (!item.isRead) return
            val textColor = "#ACB7C1"
            notificationNoTv.setTextColor(textColor)
            notificationNoValueTv.setTextColor(textColor)
            titleTv.setTextColor(textColor)
            bodyTv.setTextColor(textColor)
            setCardBackGroundColor("#EBF1F4")

        }

        private fun TextView.setTextColor(color: String) = setTextColor(Color.parseColor(color))

        private fun ItemNotificationHistoryBinding.setCardBackGroundColor(color: String) =
            itemCard.setCardBackgroundColor(ColorStateList.valueOf(Color.parseColor(color)))

    }

    override fun getItemViewType(position: Int) = position
}
