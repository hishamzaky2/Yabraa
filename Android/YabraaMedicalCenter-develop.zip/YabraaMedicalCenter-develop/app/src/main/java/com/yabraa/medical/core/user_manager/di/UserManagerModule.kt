package com.yabraa.medical.core.user_manager.di

import dagger.Module
import dagger.Provides
import dagger.hilt.InstallIn
import dagger.hilt.components.SingletonComponent
import com.core.shared.storage_manager.StorageManager
import com.core.shared.storage_manager.di.StorageManagerModule
import com.yabraa.medical.core.user_manager.UserHandler
import com.yabraa.medical.core.user_manager.UserManager
import javax.inject.Named
import javax.inject.Singleton

@Module
@InstallIn(SingletonComponent::class)
object UserManagerModule {


    @Provides
    @Singleton
    fun provideUserManager(@Named(StorageManagerModule.SHARED_PREFERENCE) sharedPreference: StorageManager): UserHandler =
        UserManager(sharedPreference)

}