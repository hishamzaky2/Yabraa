package com.yabraa.medical.feature.fragments.patients.patients.data.model.response


import com.google.gson.annotations.SerializedName
import java.io.Serializable

data class PatientResponse(
    @SerializedName("birthDate")
    val birthDate: String,
    @SerializedName("name")
    val name: String,
    @SerializedName("userFamilyId")
    val userFamilyId: Long,
    @SerializedName("gender")
    val gender: String,
    @SerializedName("isOwner")
    val isOwner : Boolean
) : Serializable