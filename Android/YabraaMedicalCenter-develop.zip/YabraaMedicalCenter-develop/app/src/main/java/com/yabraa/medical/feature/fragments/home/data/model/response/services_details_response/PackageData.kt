package com.yabraa.medical.feature.fragments.home.data.model.response.services_details_response


import com.google.gson.annotations.SerializedName
import kotlinx.parcelize.IgnoredOnParcel
import com.yabraa.medical.feature.fragments.filter.presentation.adapter.ItemSelectedIHandler
import java.io.Serializable
import java.math.BigDecimal

data class PackageData(
    @SerializedName("detailsAR")
    val detailsAR: String? = null,
    @SerializedName("detailsEN")
    val detailsEN: String? = null,
    @SerializedName("imagePath")
    val imagePath: String? = null,
    @SerializedName("instructionAR")
    val instructionAR: String? = null,
    @SerializedName("instructionEN")
    val instructionEN: String? = null,
    @SerializedName("nameAR")
    val nameAR: String? = null,
    @SerializedName("nameEN")
    val nameEN: String? = null,
    @SerializedName("packageId")
    val packageId: Long,
    @SerializedName("price")
    val price: BigDecimal,
    @SerializedName("subTitleAR")
    val subTitleAR: String? = null,
    @SerializedName("subTitleEN")
    val subTitleEN: String? = null,
    @SerializedName("serviceId")
    val serviceId: Long,
    @SerializedName("filterId")
    val filterId: Long
) : Serializable, ItemSelectedIHandler {
    @IgnoredOnParcel
    override var isItemSelected = false

    override fun setSelected(selected: Boolean) {
        isItemSelected = selected
    }

    override fun isSelected() = isItemSelected
}