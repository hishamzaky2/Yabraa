package com.yabraa.medical.feature.fragments.checkout.domain.repository.payment_method_repository

import com.core.shared.state.State
import com.yabraa.medical.feature.fragments.checkout.data.model.response.payment_method_response.PaymentMethodResponseDto
import kotlinx.coroutines.flow.Flow

interface PaymentMethodRepository {
    suspend fun getPaymentMethods() : Flow<State<PaymentMethodResponseDto>>
}