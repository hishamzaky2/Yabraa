package com.yabraa.medical.feature.fragments.login.data.repository

import kotlinx.coroutines.flow.flow
import kotlinx.coroutines.flow.flowOn
import com.yabraa.medical.core.base_repository.BaseRepository
import com.yabraa.medical.core.di.network_sevices.SecurityServices
import com.core.shared.state.State
import com.yabraa.medical.core.utils.getResponseMessageError
import com.yabraa.medical.feature.fragments.login.data.model.request.LoginRequestDto
import com.yabraa.medical.feature.fragments.login.data.model.response.LoginResponseDto
import com.yabraa.medical.feature.fragments.login.domain.repository.LoginRepository
import retrofit2.Response
import javax.inject.Inject

const val TAG_LOGIN_RESPONSE = "TAG_LOGIN_RESPONSE"

class LoginRepositoryImpl @Inject constructor(
    private val securityServices: SecurityServices
) : BaseRepository<LoginRequestDto, LoginResponseDto>(), LoginRepository {

    override suspend fun login(loginRequestDto: LoginRequestDto) = flow {
        emit(getOperationState(loginRequestDto))
    }.flowOn(dispatcher)

    override suspend fun performApiCall(requestDto: LoginRequestDto): State<LoginResponseDto> {
        val response = securityServices.login(requestDto)
        return handleLoginResponse(response)
    }

    private fun handleLoginResponse(response: Response<LoginResponseDto>): State<LoginResponseDto> {
        val responseBody = response.body()
        val errorMessageEn = responseBody?.errorMessageEn ?: ""
        val errorMessageAr = responseBody?.errorMessageAr ?: ""
        return when {
            response.isSuccessful && responseBody?.loginData != null -> State.Success(response.body())

            response.isSuccessful && !responseBody?.errorMessageEn.isNullOrEmpty() -> getResponseMessageError(
                errorMessageEn = errorMessageEn,
                errorMessageAr = errorMessageAr,
                logTag = TAG_LOGIN_RESPONSE
            )
            else -> getNotSuccessfulResponseState(response)
        }
    }
}