package com.yabraa.medical.core.di.network_sevices

import com.yabraa.medical.feature.fragments.forget_password.data.model.request.ForgetPasswordRequestDto
import com.yabraa.medical.feature.fragments.forget_password.data.model.request.ResetPasswordRequestDto
import com.yabraa.medical.feature.fragments.forget_password.data.model.response.forget_password_response.ForgetPasswordResponseDto
import com.yabraa.medical.feature.fragments.forget_password.data.model.response.reset_password_response.ResetPasswordResponseDto
import com.yabraa.medical.feature.fragments.login.data.model.request.LoginRequestDto
import com.yabraa.medical.feature.fragments.login.data.model.response.LoginResponseDto
import com.yabraa.medical.feature.fragments.onboard.data.response.OnboardPagesResponseDto
import com.yabraa.medical.feature.fragments.register.data.request.RegisterRequestDto
import com.yabraa.medical.feature.fragments.register.data.response.nationality_response.NationalityResponseDto
import com.yabraa.medical.feature.fragments.register.data.response.register_response.RegisterResponseDto
import com.yabraa.medical.feature.fragments.register.data.response.user_input_validation_response.UserInputValidationResponseDto
import retrofit2.Response
import retrofit2.http.Body
import retrofit2.http.GET
import retrofit2.http.POST

interface SecurityServices {

    @GET("api/StartPages")
    suspend fun getStartPages(): Response<OnboardPagesResponseDto>

    @GET("api/auth/PrepareRegistration")
    suspend fun getNationalityList(): Response<NationalityResponseDto>

    @POST("api/auth/userInputsValidation")
    suspend fun userInputValidation(@Body registerRequestDto: RegisterRequestDto): Response<UserInputValidationResponseDto>

    @POST("api/auth/register")
    suspend fun registerNewAccount(@Body registerRequestDto: RegisterRequestDto): Response<RegisterResponseDto>

    @POST("api/auth/login")
    suspend fun login(@Body loginRequest: LoginRequestDto): Response<LoginResponseDto>

    @POST("api/auth/forgotpassword")
    suspend fun forgetPassword(@Body forgetPasswordRequestDto: ForgetPasswordRequestDto): Response<ForgetPasswordResponseDto>

    @POST("api/auth/ResetPassword")
    suspend fun resetPassword(@Body resetPasswordRequestDto: ResetPasswordRequestDto): Response<ResetPasswordResponseDto>

}