package com.yabraa.medical.feature.fragments.setting.data.model.response.user_information_response



import com.google.gson.annotations.SerializedName
import java.io.Serializable

data class UserInformationResponse(
    @SerializedName("birthDate")
    val birthDate: String,
    @SerializedName("countryCode")
    val countryCode: String,
    @SerializedName("countryNameAr")
    val countryNameAr: String,
    @SerializedName("countryNameEn")
    val countryNameEn: String,
    @SerializedName("crateDateTime")
    val crateDateTime: String,
    @SerializedName("email")
    val email: String? = null,
    @SerializedName("firstName")
    val firstName: String,
    @SerializedName("gender")
    val gender: String,
    @SerializedName("idOrIqamaOrPassport")
    val idOrIqamaOrPassport: String? = null,
    @SerializedName("lastName")
    val lastName: String,
    @SerializedName("nationalityAr")
    val nationalityAr: String,
    @SerializedName("nationalityEn")
    val nationalityEn: String,
    @SerializedName("phoneNumber")
    val phoneNumber: String,
    @SerializedName("userName")
    val userName: String
) : Serializable