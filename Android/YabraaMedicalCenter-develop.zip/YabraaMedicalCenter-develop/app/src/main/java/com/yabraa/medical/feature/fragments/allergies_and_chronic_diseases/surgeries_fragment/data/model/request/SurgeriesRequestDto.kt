package com.yabraa.medical.feature.fragments.allergies_and_chronic_diseases.surgeries_fragment.data.model.request

data class SurgeriesRequestDto(var surgeryId: Long, var userFamilyId: Long)