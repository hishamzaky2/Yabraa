package com.yabraa.medical.feature.fragments.appointment.my_appointment.data.model.request

data class CancelAppointmentRequestDto(val appointmentId: Long, val firebaseToken: String)