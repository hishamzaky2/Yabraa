package com.yabraa.medical.feature.fragments.setting.data.model.response.user_information_response


import com.google.gson.annotations.SerializedName

data class UserInformationResponseDto(
    @SerializedName("data")
    val userInformationResponse: UserInformationResponse,
    @SerializedName("errorMessageAr")
    val errorMessageAr: String? = null,
    @SerializedName("errorMessageEn")
    val errorMessageEn: String? = null,
    @SerializedName("statusCode")
    val statusCode: Int
)