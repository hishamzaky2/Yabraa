package com.yabraa.medical.feature.fragments.home.data.model.response.services_details_response


import com.google.gson.annotations.SerializedName

data class ServicesDetailsResponseDto(
    @SerializedName("data")
    val servicesDataResponse: ServicesDataResponse? = null,
    @SerializedName("errorMessageAr")
    val errorMessageAr: String? = null,
    @SerializedName("errorMessageEn")
    val errorMessageEn: String? = null,
    @SerializedName("statusCode")
    val statusCode: Int
)