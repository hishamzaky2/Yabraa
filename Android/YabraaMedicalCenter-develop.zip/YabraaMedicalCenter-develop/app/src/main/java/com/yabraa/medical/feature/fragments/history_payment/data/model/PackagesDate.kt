package com.yabraa.medical.feature.fragments.history_payment.data.model


import com.google.gson.annotations.SerializedName

data class PackagesDate(
    @SerializedName("date")
    val date: String,
    @SerializedName("items")
    val packageItems: List<PackageItem>
)