package com.yabraa.medical.core.utils.custom_views.yabraa_bar

interface YabraaBarHandler {

    fun setYabraaBarVisibility(isVisible : Boolean)

    fun setBarTitle(title: String)

    fun setOnBackArrowClicked(listener: () -> Unit)

    fun setClearAllVisibility(isVisible : Boolean)

    fun setOnClearAllClicked(listener: () -> Unit)
}