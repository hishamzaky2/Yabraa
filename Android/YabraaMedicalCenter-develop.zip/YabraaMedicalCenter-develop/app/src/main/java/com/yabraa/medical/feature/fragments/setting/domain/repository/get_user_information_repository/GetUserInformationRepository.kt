package com.yabraa.medical.feature.fragments.setting.domain.repository.get_user_information_repository

import com.core.shared.state.State
import com.yabraa.medical.feature.fragments.setting.data.model.response.user_information_response.UserInformationResponseDto
import kotlinx.coroutines.flow.Flow

interface GetUserInformationRepository {
    suspend fun getUserInformation() : Flow<State<UserInformationResponseDto>>
}