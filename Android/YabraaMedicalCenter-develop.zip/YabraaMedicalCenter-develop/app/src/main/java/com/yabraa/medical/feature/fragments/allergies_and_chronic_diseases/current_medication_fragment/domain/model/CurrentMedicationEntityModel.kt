package com.yabraa.medical.feature.fragments.allergies_and_chronic_diseases.current_medication_fragment.domain.model

data class CurrentMedicationEntityModel (
    val medicationId: Long,
    val titleAR: String,
    val titleEN: String,
    var isAdded : Boolean = false
)