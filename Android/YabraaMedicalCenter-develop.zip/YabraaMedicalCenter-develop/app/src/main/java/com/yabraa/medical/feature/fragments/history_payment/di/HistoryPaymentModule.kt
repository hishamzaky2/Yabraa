package com.yabraa.medical.feature.fragments.history_payment.di

import com.yabraa.medical.core.di.network_sevices.YabraaServices
import com.yabraa.medical.feature.fragments.history_payment.data.repository.HistoryPaymentRepositoryImpl
import com.yabraa.medical.feature.fragments.history_payment.domain.repository.HistoryPaymentRepository
import dagger.Module
import dagger.Provides
import dagger.hilt.InstallIn
import dagger.hilt.android.components.ViewModelComponent

@Module
@InstallIn(ViewModelComponent::class)
object HistoryPaymentModule {

    @Provides
    fun provideHistoryPaymentRepository(yabraaServices: YabraaServices): HistoryPaymentRepository =
        HistoryPaymentRepositoryImpl(yabraaServices)
}