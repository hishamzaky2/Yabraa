package com.yabraa.medical.feature.fragments.onboard.presentation

import android.os.Bundle
import android.view.View
import androidx.hilt.navigation.fragment.hiltNavGraphViewModels
import androidx.lifecycle.Lifecycle
import androidx.lifecycle.flowWithLifecycle
import androidx.lifecycle.lifecycleScope
import androidx.viewpager2.widget.ViewPager2
import dagger.hilt.android.AndroidEntryPoint
import kotlinx.coroutines.launch
import com.yabraa.medical.R
import com.yabraa.medical.core.base_fragment.BaseFragment
import com.core.shared.state.State
import com.core.shared.utils.CommonUtils.getLocalizedValue
import com.core.shared.utils.CommonUtils.load
import com.yabraa.medical.databinding.FragmentThirdOnboardBinding
import com.yabraa.medical.feature.fragments.common.domain.viewmodel.OnboardViewModel

@AndroidEntryPoint
class ThirdOnboardFragment : BaseFragment<FragmentThirdOnboardBinding>() {

    override val binding by lazy { FragmentThirdOnboardBinding.inflate(layoutInflater) }
    private val viewPager by lazy { activity?.findViewById<ViewPager2>(R.id.viewPager) }
    private val viewModel: OnboardViewModel by hiltNavGraphViewModels(R.id.nav_graph)
    override fun onViewCreated(view: View, savedInstanceState: Bundle?) {
        super.onViewCreated(view, savedInstanceState)
        binding.setUpViews()
    }

    override fun onResume() {
        super.onResume()
        showYabraaBar(false)
    }

    private fun FragmentThirdOnboardBinding.setUpViews() {
        handleThirdSliderBar()
        setOnSkipOnboardScreenClicked()
        lifecycleScope.launch { collectOnOnboardPagesState() }
    }

    private fun FragmentThirdOnboardBinding.handleThirdSliderBar() {
        val pageNumber = viewPager?.currentItem == 0 && viewPager?.currentItem == 1
        if (pageNumber) return
        sliderBar.firstProgressBar.progress = 50
        sliderBar.secondProgressBar.progress = 50
        sliderBar.thirdProgressBar.progress = 25
    }

    private fun FragmentThirdOnboardBinding.setOnSkipOnboardScreenClicked() {
        skipTv.setOnClickListener { handleSkipOnboardScreen() }
    }


    private suspend fun collectOnOnboardPagesState() {
        viewModel.onboardPagesState.flowWithLifecycle(lifecycle, Lifecycle.State.STARTED).collect {
            hideProgressDialog()
            when (it) {
                is State.Initial -> {}
                is State.Error -> {}
                is State.Loading -> showProgressDialog()
                is State.Success -> setThirdOnboardScreenInfo()
            }
        }
    }

    private fun setThirdOnboardScreenInfo() {
        viewModel.getPagesDetails()?.forEachIndexed { index, it ->
            if (index == 2) {
                binding.titleTv.text = getLocalizedValue(it.titleEn, it.titleAr)
                binding.subTitleTv.text = getLocalizedValue(it.subTitleEn, it.subTitleAr)
                binding.firstOnboardIv.load(requireActivity(), it.path)
            }
        }
    }
}