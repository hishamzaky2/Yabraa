package com.yabraa.medical.feature.fragments.allergies_and_chronic_diseases.surgeries_fragment.domain.viewmodel

import androidx.lifecycle.ViewModel
import androidx.lifecycle.viewModelScope
import com.core.shared.state.State
import com.yabraa.medical.feature.fragments.allergies_and_chronic_diseases.surgeries_fragment.data.model.request.SurgeriesRequestDto
import com.yabraa.medical.feature.fragments.allergies_and_chronic_diseases.surgeries_fragment.data.model.response.SurgeriesResponseDto
import com.yabraa.medical.feature.fragments.allergies_and_chronic_diseases.surgeries_fragment.domain.repository.AddSurgeriesRepository
import com.yabraa.medical.feature.fragments.allergies_and_chronic_diseases.surgeries_fragment.domain.repository.DeleteSurgeriesRepository
import com.yabraa.medical.feature.fragments.allergies_and_chronic_diseases.surgeries_fragment.domain.usecase.SurgeriesUseCase
import dagger.hilt.android.lifecycle.HiltViewModel
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.launch
import javax.inject.Inject

@HiltViewModel
class SurgeriesViewModel @Inject constructor(
    private val surgeriesUseCase: SurgeriesUseCase,
    private val addSurgeriesRepository: AddSurgeriesRepository,
    private val deleteSurgeriesRepository: DeleteSurgeriesRepository
) : ViewModel() {


    private val _surgeriesResponseState =
        MutableStateFlow<State<SurgeriesResponseDto>>(State.Initial())
    val surgeriesResponseState: StateFlow<State<SurgeriesResponseDto>> =
        _surgeriesResponseState

    private val _surgeriesByUserFamilyIdResponseState =
        MutableStateFlow<State<SurgeriesResponseDto>>(State.Initial())
    val surgeriesByUserFamilyIdResponseState: StateFlow<State<SurgeriesResponseDto>> =
        _surgeriesByUserFamilyIdResponseState

    private val _addSurgeriesResponseState =
        MutableStateFlow<State<SurgeriesResponseDto>>(State.Initial())
    val addSurgeriesResponseState: StateFlow<State<SurgeriesResponseDto>> =
        _addSurgeriesResponseState

    private val _deleteSurgeriesResponseState =
        MutableStateFlow<State<SurgeriesResponseDto>>(State.Initial())
    val deleteSurgeriesResponseState: StateFlow<State<SurgeriesResponseDto>> =
        _deleteSurgeriesResponseState

    fun getSurgeries() {
        viewModelScope.launch {
            _surgeriesResponseState.emit(State.Loading())
            surgeriesUseCase().collect {
                _surgeriesResponseState.emit(it)
            }
        }
    }


    fun getSurgeriesByUserFamilyId(userFamilyId: Long) {
        viewModelScope.launch {
            _surgeriesByUserFamilyIdResponseState.emit(State.Loading())
            surgeriesUseCase(userFamilyId).collect {
                _surgeriesByUserFamilyIdResponseState.emit(it)
            }
        }
    }

    fun addSurgeries(requestDto: SurgeriesRequestDto) {
        viewModelScope.launch {
            _addSurgeriesResponseState.emit(State.Loading())
            addSurgeriesRepository.addSurgeries(requestDto).collect {
                _addSurgeriesResponseState.emit(it)
            }
        }
    }


    fun deleteSurgeries(requestDto: SurgeriesRequestDto) {
        viewModelScope.launch {
            _deleteSurgeriesResponseState.emit(State.Loading())
            deleteSurgeriesRepository.deleteSurgeries(requestDto).collect {
                _deleteSurgeriesResponseState.emit(it)
            }
        }
    }

    fun getSurgeriesList() = surgeriesUseCase.getSurgeriesList()

}