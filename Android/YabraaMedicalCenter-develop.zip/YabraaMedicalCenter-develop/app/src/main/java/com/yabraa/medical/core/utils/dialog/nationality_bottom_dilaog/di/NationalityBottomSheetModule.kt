package com.yabraa.medical.core.utils.dialog.nationality_bottom_dilaog.di

import android.app.Activity
import com.yabraa.medical.core.utils.dialog.nationality_bottom_dilaog.NationalityBottomSheetDialog
import dagger.Module
import dagger.Provides
import dagger.hilt.InstallIn
import dagger.hilt.android.components.ActivityComponent

@Module
@InstallIn(ActivityComponent::class)
class NationalityBottomSheetModule {

    @Provides
    fun provideNationalityBottomSheetDialog(activity: Activity) = NationalityBottomSheetDialog(activity)
}