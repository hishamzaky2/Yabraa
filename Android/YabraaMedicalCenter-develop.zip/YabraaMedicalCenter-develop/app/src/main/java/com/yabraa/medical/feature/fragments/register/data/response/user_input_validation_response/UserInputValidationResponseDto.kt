package com.yabraa.medical.feature.fragments.register.data.response.user_input_validation_response


import com.google.gson.annotations.SerializedName


data class UserInputValidationResponseDto(
    @SerializedName("data")
    val userInputValidationResponse: UserInputValidationResponse? = null,
    @SerializedName("errorMessageAr")
    val errorMessageAr: String? = null,
    @SerializedName("errorMessageEn")
    val errorMessageEn: String? = null,
    @SerializedName("statusCode")
    val statusCode: Int
)