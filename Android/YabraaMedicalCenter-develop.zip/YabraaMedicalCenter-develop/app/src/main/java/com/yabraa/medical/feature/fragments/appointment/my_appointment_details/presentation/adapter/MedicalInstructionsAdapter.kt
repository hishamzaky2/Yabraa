package com.yabraa.medical.feature.fragments.appointment.my_appointment_details.presentation.adapter

import android.view.LayoutInflater
import android.view.ViewGroup
import androidx.recyclerview.widget.RecyclerView
import com.core.shared.utils.CommonUtils.decodeDateString
import com.yabraa.medical.databinding.ItemMedicalInstructionsBinding
import com.yabraa.medical.feature.fragments.appointment.my_appointment_details.data.model.VisitNote

class MedicalInstructionsAdapter(private val prescription: List<VisitNote>) :
    RecyclerView.Adapter<MedicalInstructionsAdapter.ViewHolder>() {
    override fun onCreateViewHolder(
        parent: ViewGroup, viewType: Int
    ): MedicalInstructionsAdapter.ViewHolder {
        val binding = ItemMedicalInstructionsBinding.inflate(
            LayoutInflater.from(parent.context), parent, false
        )
        return ViewHolder(binding)
    }

    override fun onBindViewHolder(
        viewHolder: MedicalInstructionsAdapter.ViewHolder,
        position: Int
    ) {
        val item = prescription[position]
        viewHolder.bind(item)
    }

    override fun getItemCount() = prescription.size

    override fun getItemViewType(position: Int) = position

    inner class ViewHolder(val binding: ItemMedicalInstructionsBinding) :
        RecyclerView.ViewHolder(binding.root) {
        fun bind(item: VisitNote) {
            binding.setUpViews(item)
        }

        private fun ItemMedicalInstructionsBinding.setUpViews(item: VisitNote) {
            noteTitleTv.text = item.title
            noteTv.text = item.description
            createDateValueTv.text = decodeDateString(item.createDTs, "yyyy-MM-dd")
        }
    }
}