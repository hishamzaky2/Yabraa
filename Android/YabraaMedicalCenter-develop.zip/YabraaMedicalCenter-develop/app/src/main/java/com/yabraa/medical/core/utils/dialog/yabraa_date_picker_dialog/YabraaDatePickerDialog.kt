package com.yabraa.medical.core.utils.dialog.yabraa_date_picker_dialog

import android.app.Activity
import android.app.DatePickerDialog
import java.util.*
import javax.inject.Inject

class YabraaDatePickerDialog @Inject constructor() {

    private var datePickerDialog: DatePickerDialog? = null

    private val calendar by lazy { Calendar.getInstance() }
    private val year = calendar.get(Calendar.YEAR)
    private val month = calendar.get(Calendar.MONTH)
    private val day = calendar.get(Calendar.DAY_OF_MONTH)


    fun datePickerDialog(activity: Activity, date: (String) -> Unit): DatePickerDialog? {
        var day = "0"
        var month = "0"
        datePickerDialog = DatePickerDialog(activity, { _, _year, monthOfYear, dayOfMonth ->
            if (dayOfMonth < 10) day += dayOfMonth else day = dayOfMonth.toString()
            if (monthOfYear + 1 < 10) month += monthOfYear + 1 else month = (monthOfYear + 1).toString()
            date.invoke("$_year-$month-$day")
        }, this.year, this.month, this.day)
        return datePickerDialog
    }
}