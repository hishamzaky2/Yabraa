package com.yabraa.medical.feature.fragments.appointment.my_appointment.domain.viewmodel

import androidx.lifecycle.ViewModel
import androidx.lifecycle.viewModelScope
import com.core.shared.state.State
import com.yabraa.medical.feature.fragments.appointment.my_appointment.data.model.request.CancelAppointmentRequestDto
import com.yabraa.medical.feature.fragments.appointment.my_appointment.data.model.response.MyAppointmentResponseDto
import com.yabraa.medical.feature.fragments.appointment.my_appointment.data.model.response.cancel_appointment_response.CancelAppointmentResponseDto
import com.yabraa.medical.feature.fragments.appointment.my_appointment.domain.repository.MyAppointmentRepository
import com.yabraa.medical.feature.fragments.appointment.my_appointment.domain.repository.cancel_appointment_repository.CancelAppointmentRepository
import dagger.hilt.android.lifecycle.HiltViewModel
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.launch
import javax.inject.Inject

@HiltViewModel
class MyAppointmentViewModel @Inject constructor(
    private val myAppointmentRepository: MyAppointmentRepository,
    private val cancelAppointmentRepository: CancelAppointmentRepository
) : ViewModel() {

    private val _myAppointmentResponseState =
        MutableStateFlow<State<MyAppointmentResponseDto>>(State.Initial())
    val myAppointmentResponseState: StateFlow<State<MyAppointmentResponseDto>> =
        _myAppointmentResponseState

    private val _cancelAppointmentResponseState =
        MutableStateFlow<State<CancelAppointmentResponseDto>>(State.Initial())
    val cancelAppointmentResponseState: StateFlow<State<CancelAppointmentResponseDto>> =
        _cancelAppointmentResponseState

    fun getMyAppointment() {
        viewModelScope.launch {
            _myAppointmentResponseState.emit(State.Loading())
            myAppointmentRepository.getMytAppointment().collect {
                _myAppointmentResponseState.emit(it)
            }
        }
    }

    fun cancelAppointment(requestDto : CancelAppointmentRequestDto) {
        viewModelScope.launch {
            _cancelAppointmentResponseState.emit(State.Loading())
            cancelAppointmentRepository.cancelAppointment(requestDto).collect {
                _cancelAppointmentResponseState.emit(it)
            }
        }
    }
}