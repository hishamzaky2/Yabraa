package com.yabraa.medical.feature.fragments.select_date_and_time.data.response


import com.google.gson.annotations.SerializedName

data class DatesResponseDto(
    @SerializedName("data")
    val datesDataResponse: List<DatesDataResponse>,
    @SerializedName("errorMessageAr")
    val errorMessageAr: String? = null,
    @SerializedName("errorMessageEn")
    val errorMessageEn: String? = null,
    @SerializedName("statusCode")
    val statusCode: Int
)