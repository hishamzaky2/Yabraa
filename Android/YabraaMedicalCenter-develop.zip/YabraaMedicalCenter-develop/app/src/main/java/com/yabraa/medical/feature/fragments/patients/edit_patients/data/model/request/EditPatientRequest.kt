package com.yabraa.medical.feature.fragments.patients.edit_patients.data.model.request

data class EditPatientRequest(
    val userFamilyId: Long,
    val name: String,
    val birthDate: String,
    val gender: String? = null
)