package com.yabraa.medical.feature.fragments.appointment.my_appointment.domain.repository.cancel_appointment_repository

import com.core.shared.state.State
import com.yabraa.medical.feature.fragments.appointment.my_appointment.data.model.request.CancelAppointmentRequestDto
import com.yabraa.medical.feature.fragments.appointment.my_appointment.data.model.response.cancel_appointment_response.CancelAppointmentResponseDto
import kotlinx.coroutines.flow.Flow

interface CancelAppointmentRepository {

    suspend fun cancelAppointment(requestDto: CancelAppointmentRequestDto): Flow<State<CancelAppointmentResponseDto>>
}