package com.yabraa.medical.feature.fragments.allergies_and_chronic_diseases.past_medication_fragment.data.repository

import com.yabraa.medical.core.base_repository.BaseRepository
import com.yabraa.medical.core.di.network_sevices.AllergiesAndChronicDiseasesServices
import com.core.shared.state.State
import com.yabraa.medical.core.utils.getResponseMessageError
import com.yabraa.medical.feature.fragments.allergies_and_chronic_diseases.past_medication_fragment.data.model.response.PastMedicationResponseDto
import com.yabraa.medical.feature.fragments.allergies_and_chronic_diseases.past_medication_fragment.domain.repository.PastMedicationRepository
import kotlinx.coroutines.flow.flow
import kotlinx.coroutines.flow.flowOn
import retrofit2.Response
import javax.inject.Inject

const val TAG_PAST_MEDICATION_RESPONSE = "TAG_PAST_MEDICATION_RESPONSE"

class PastMedicationRepositoryImpl @Inject constructor(private val allergiesAndChronicDiseasesServices: AllergiesAndChronicDiseasesServices) :
    BaseRepository<Any, PastMedicationResponseDto>(), PastMedicationRepository {

    override suspend fun getPastMedication() = flow {
        emit(getOperationState(Any()))
    }.flowOn(dispatcher)

    override suspend fun performApiCall(requestDto: Any): State<PastMedicationResponseDto> {
        val response = allergiesAndChronicDiseasesServices.getPastMedications()
        return handleResponse(response)
    }

    fun handleResponse(response: Response<PastMedicationResponseDto>): State<PastMedicationResponseDto> {
        val responseBody = response.body()
        val errorMessageEn = responseBody?.errorMessageEn ?: ""
        val errorMessageAr = responseBody?.errorMessageAr ?: ""
        return when {
            response.isSuccessful -> State.Success(response.body())

            response.isSuccessful && !responseBody?.errorMessageEn.isNullOrEmpty() -> getResponseMessageError(
                errorMessageEn = errorMessageEn,
                errorMessageAr = errorMessageAr,
                logTag = TAG_PAST_MEDICATION_RESPONSE
            )

            else -> getNotSuccessfulResponseState(response)
        }
    }
}