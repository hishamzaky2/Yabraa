package com.yabraa.medical.feature.fragments.allergies_and_chronic_diseases.allergies_fragment.data.model.request

data class AllergiesRequestDto(var allergyId: Long, var userFamilyId: Long)