package com.yabraa.medical.feature.fragments.select_date_and_time.domain.usecase

import com.core.shared.state.State
import com.yabraa.medical.feature.fragments.select_date_and_time.data.response.DatesResponseDto
import com.yabraa.medical.feature.fragments.select_date_and_time.domain.repository.DatesRepository
import kotlinx.coroutines.async
import kotlinx.coroutines.flow.Flow
import kotlinx.coroutines.flow.channelFlow
import javax.inject.Inject

class DatesUseCase @Inject constructor(private val datesRepository: DatesRepository) {

    private var responseDto: DatesResponseDto? = null

    operator fun invoke(): Flow<State<DatesResponseDto>> {
        return channelFlow {
            val datesResponse = async { datesRepository.getDates() }
            datesResponse.await().collect {
                if (it is State.Success) {
                    responseDto = it.data
                }
                send(it)
            }
        }
    }


    fun getDatesDataResponse() = responseDto?.datesDataResponse ?: emptyList()

    fun getFirstMonth() = responseDto?.datesDataResponse?.first()?.monthName ?: ""

    fun getSecondMonth() = responseDto?.datesDataResponse?.last()?.monthName ?: ""
    fun getFirstYear() = responseDto?.datesDataResponse?.firstOrNull()?.year ?: 0
    fun getLastYear() = responseDto?.datesDataResponse?.lastOrNull()?.year ?: 0


}

