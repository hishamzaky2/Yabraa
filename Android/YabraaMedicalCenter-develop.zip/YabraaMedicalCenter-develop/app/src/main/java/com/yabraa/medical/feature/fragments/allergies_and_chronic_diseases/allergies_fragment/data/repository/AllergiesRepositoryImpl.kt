package com.yabraa.medical.feature.fragments.allergies_and_chronic_diseases.allergies_fragment.data.repository

import com.yabraa.medical.core.base_repository.BaseRepository
import com.yabraa.medical.core.di.network_sevices.AllergiesAndChronicDiseasesServices
import com.core.shared.state.State
import com.yabraa.medical.core.utils.getResponseMessageError
import com.yabraa.medical.feature.fragments.allergies_and_chronic_diseases.allergies_fragment.data.model.response.AllergiesResponseDto
import com.yabraa.medical.feature.fragments.allergies_and_chronic_diseases.allergies_fragment.domain.repository.AllergiesRepository
import kotlinx.coroutines.flow.flow
import kotlinx.coroutines.flow.flowOn
import retrofit2.Response
import javax.inject.Inject

const val TAG_ALLERGIES_RESPONSE = "TAG_ALLERGIES_RESPONSE"

class AllergiesRepositoryImpl @Inject constructor(private val allergiesAndChronicDiseasesServices: AllergiesAndChronicDiseasesServices) :
    BaseRepository<Any, AllergiesResponseDto>(), AllergiesRepository {

    override suspend fun getAllergies() = flow {
        emit(getOperationState(Any()))
    }.flowOn(dispatcher)

    override suspend fun performApiCall(requestDto: Any): State<AllergiesResponseDto> {
        val response = allergiesAndChronicDiseasesServices.getAllergies()
        return handleResponse(response)
    }

    fun handleResponse(response: Response<AllergiesResponseDto>): State<AllergiesResponseDto> {
        val responseBody = response.body()
        val errorMessageEn = responseBody?.errorMessageEn ?: ""
        val errorMessageAr = responseBody?.errorMessageAr ?: ""
        return when {
            response.isSuccessful -> State.Success(response.body())

            response.isSuccessful && !responseBody?.errorMessageEn.isNullOrEmpty() -> getResponseMessageError(
                errorMessageEn = errorMessageEn,
                errorMessageAr = errorMessageAr,
                logTag = TAG_ALLERGIES_RESPONSE
            )

            else -> getNotSuccessfulResponseState(response)
        }
    }
}