package com.yabraa.medical.feature.fragments.history_payment.data.model


import com.google.gson.annotations.SerializedName

data class HistoryPaymentResponse(
    @SerializedName("result")
    val packagesDate: List<PackagesDate>
)