package com.yabraa.medical.feature.fragments.register.domain.repository

import kotlinx.coroutines.flow.Flow
import com.core.shared.state.State
import com.yabraa.medical.feature.fragments.register.data.request.RegisterRequestDto
import com.yabraa.medical.feature.fragments.register.data.response.user_input_validation_response.UserInputValidationResponseDto

interface UserInputsValidationRepository {
    suspend fun getUserInputValidation(registerRequestDto: RegisterRequestDto): Flow<State<UserInputValidationResponseDto>>
}