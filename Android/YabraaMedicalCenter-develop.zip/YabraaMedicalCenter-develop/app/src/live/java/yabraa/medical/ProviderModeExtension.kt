package yabraa.medical

import com.oppwa.mobile.connect.provider.Connect.ProviderMode

fun getProviderMode() = ProviderMode.LIVE